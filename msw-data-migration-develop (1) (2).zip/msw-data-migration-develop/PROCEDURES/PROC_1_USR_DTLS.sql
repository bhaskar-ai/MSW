create or replace PROCEDURE PROC_1_USR_DTLS ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_SI         NUMBER;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_USR_DTLS
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-JUL-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :ROHIT KHOOL
   MODIFIED DATE  :10-SEP-2019, 30-SEP-2019

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_SI_USR_DTLS IS
    SELECT
        XU.LOGINID_C,
		XU.NRIC_N,
		XU.LOGINID_M,
		XU.EMAIL_X,
		XU.MOBILE_N,
		XU.ACTIVATED_I,
		XC.CO_REG_N
    FROM
        XR_USR XU,
		ST_XR_COREG XC
    WHERE
	XU.ORG_C = XC.ORG_C;

------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
    CURSOR CR_USR_DTLS IS
    SELECT
        LOGINID_C,
		NRIC_N,
		LOGINID_M,
		EMAIL_X,
		MOBILE_N,
		ACTIVATED_I,
		CO_REG_N
    FROM
        SI_USR_DTLS;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE REC_SI_USR_DTLS IS RECORD (
        V_LOGINID_C		XR_USR.LOGINID_C%TYPE,
		V_NRIC_N		XR_USR.NRIC_N%TYPE,
		V_LOGINID_M		XR_USR.LOGINID_M%TYPE,
		V_EMAIL_X		XR_USR.EMAIL_X%TYPE,
		V_MOBILE_N		XR_USR.MOBILE_N%TYPE,
		V_ACTIVATED_I	XR_USR.ACTIVATED_I%TYPE,
		V_CO_REG_N		XR_COREG.CO_REG_N%TYPE


    );
    TYPE TYP_SI_USR_DTLS IS
    TABLE OF REC_SI_USR_DTLS INDEX BY PLS_INTEGER;

    LV_SI_USR_DTLS    TYP_SI_USR_DTLS;

    TYPE REC_USR_DTLS IS RECORD (
        V_LOGINID_C		SI_USR_DTLS.LOGINID_C%TYPE,
		V_NRIC_N		SI_USR_DTLS.NRIC_N%TYPE,
		V_LOGINID_M		SI_USR_DTLS.LOGINID_M%TYPE,
		V_EMAIL_X		SI_USR_DTLS.EMAIL_X%TYPE,
		V_MOBILE_N		SI_USR_DTLS.MOBILE_N%TYPE,
		V_ACTIVATED_I	SI_USR_DTLS.ACTIVATED_I%TYPE,
		V_CO_REG_N		SI_USR_DTLS.CO_REG_N%TYPE
    );
    TYPE TYP_USR_DTLS IS
    TABLE OF REC_USR_DTLS INDEX BY PLS_INTEGER;

    LV_USR_DTLS       TYP_USR_DTLS;

BEGIN

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
       XR_USR XU,
		XR_COREG XC
    WHERE
	XU.ORG_C = XC.ORG_C;   ---- DRIVING TABLE COUNT 

    OPEN CR_SI_USR_DTLS;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE SI_USR_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH CR_SI_USR_DTLS BULK COLLECT INTO LV_SI_USR_DTLS LIMIT 10000;
        EXIT WHEN LV_SI_USR_DTLS.COUNT = 0;

        FOR I IN LV_SI_USR_DTLS.FIRST..LV_SI_USR_DTLS.LAST LOOP

        BEGIN
                INSERT INTO SI_USR_DTLS (
										LOGINID_C,
										NRIC_N,
										LOGINID_M,
										EMAIL_X,
										MOBILE_N,
										ACTIVATED_I,
										CO_REG_N
										) 
								VALUES (
										LV_SI_USR_DTLS(I).V_LOGINID_C,		
										LV_SI_USR_DTLS(I).V_NRIC_N,		
										LV_SI_USR_DTLS(I).V_LOGINID_M,		
										LV_SI_USR_DTLS(I).V_EMAIL_X	,	
										LV_SI_USR_DTLS(I).V_MOBILE_N,		
										LV_SI_USR_DTLS(I).V_ACTIVATED_I,	
										LV_SI_USR_DTLS(I).V_CO_REG_N		
										);

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_SI_USR_DTLS(I).V_LOGINID_C || '<{||}>'||	
									LV_SI_USR_DTLS(I).V_NRIC_N	|| '<{||}>'||	
									LV_SI_USR_DTLS(I).V_LOGINID_M	|| '<{||}>'||		
									LV_SI_USR_DTLS(I).V_EMAIL_X		|| '<{||}>'||	
									LV_SI_USR_DTLS(I).V_MOBILE_N	|| '<{||}>'||		
									LV_SI_USR_DTLS(I).V_ACTIVATED_I	|| '<{||}>'||	
									LV_SI_USR_DTLS(I).V_CO_REG_N;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;



    SELECT  COUNT(*)
    INTO LV_CNT_SI
    FROM SI_USR_DTLS;   ---- INTERMIDATE TABLE COUNT 

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('XR_USR', LV_CNT_ST, 'SI_USR_DTLS', LV_CNT_SI, 'N');


    OPEN CR_USR_DTLS;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE USR_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_USR_DTLS BULK COLLECT INTO LV_USR_DTLS LIMIT 10000;
        EXIT WHEN LV_USR_DTLS.COUNT = 0;

        FOR J IN LV_USR_DTLS.FIRST..LV_USR_DTLS.LAST LOOP
            BEGIN
                INSERT INTO    USR_DTLS (
										ID_N,
										USR_LOGON_ID_N,
										USR_ID_TY_C,
										USR_ID_N,
										USR_M,
										USR_EMAIL_ADDR_X,
										USR_TEL_N,
										USR_ST_C,
										USR_PSWD_M,
										CO_UEN_N,
										LOCK_VER_N,
										DELETED_I,
										CRT_ON_DT,
										LST_UPD_ON_DT,
										CRT_BY_N,
										LST_UPD_BY_N
										)
								VALUES (
										SEQ_USR_SERV_ID.NEXTVAL,
										LV_USR_DTLS(J).V_LOGINID_C,
										'NRIC',
										LV_USR_DTLS(J).V_NRIC_N,
										LV_USR_DTLS(J).V_LOGINID_M,
										LV_USR_DTLS(J).V_EMAIL_X,
										LV_USR_DTLS(J).V_MOBILE_N,
										LV_USR_DTLS(J).V_ACTIVATED_I,
										NULL,
										LV_USR_DTLS(J).V_CO_REG_N,
										0,
										0,
										SYSDATE,
										NULL,
										'DATA MIGRATION',
										NULL
										);


            EXCEPTION                   
                WHEN OTHERS THEN        
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI :=LV_USR_DTLS(J).V_LOGINID_C || '<{||}>'||	
									LV_USR_DTLS(J).V_NRIC_N	|| '<{||}>'||	
									LV_USR_DTLS(J).V_LOGINID_M	|| '<{||}>'||		
									LV_USR_DTLS(J).V_EMAIL_X		|| '<{||}>'||	
									LV_USR_DTLS(J).V_MOBILE_N	|| '<{||}>'||		
									LV_USR_DTLS(J).V_ACTIVATED_I	|| '<{||}>'||	
									LV_USR_DTLS(J).V_CO_REG_N;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

            END;
        END LOOP;
        COMMIT;
    END LOOP;



    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM USR_DTLS;  ---- TARGET TABLE COUNT 

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_USR_DTLS', LV_CNT_SI, 'USR_DTLS', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('XR_USR', LV_CNT_ST, 'USR_DTLS', LV_CNT_TAR, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTL', 'PROC_1_USR_DTLS', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_USR_DTLS;
/