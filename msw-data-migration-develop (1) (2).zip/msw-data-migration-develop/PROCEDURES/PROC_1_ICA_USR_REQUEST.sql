create or replace PROCEDURE PROC_1_ICA_USR_REQUEST(PV_RUN_ID IN NUMBER) IS

/*************************************************************************************************************************************************************************	
			PROCEDURE NAME : PROC_PAN_SHIP_CERTIFICATE
			CREATED BY     : Rohit Khool
			DATE           : 03-OCT-2019
			PURPOSE        : INSERTING  THE DATA FROM ICA_USERROLES TO ICA_USR_REQUEST
			MODIFIED BY    :
			MODIFIED DATE  :
*************************************************************************************************************************************************************************/



	CURSOR CR_ICA IS
    SELECT 
	COY_RCB,
	USER_ID,
	ROLES
	FROM ICA_USERROLES;           

	TYPE REC_ICA IS RECORD 
	(
    V_COY_RCB            ICA_USERROLES.COY_RCB%TYPE,
    V_USER_ID            ICA_USERROLES.USER_ID%TYPE,
    V_ROLES              ICA_USERROLES.ROLES%TYPE
    );

    TYPE TYP_REC_ICA IS
	TABLE OF REC_ICA INDEX BY PLS_INTEGER;

    LV_ICA       TYP_REC_ICA;

	LV_CNT_ST         NUMBER;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);

BEGIN

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
	ICA_USERROLES;

    OPEN CR_ICA;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', 'INSERTION INTO TABLE ICA_USR_REQUEST', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO TARGET  TABLE ***********************---------------
        FETCH CR_ICA BULK COLLECT INTO LV_ICA LIMIT 10000;
        EXIT WHEN LV_ICA.COUNT = 0;

        FOR I IN LV_ICA.FIRST..LV_ICA.LAST LOOP

        BEGIN
                INSERT INTO ICA_USR_REQUEST (
											ID_N,
											CO_UEN_N, 
											USR_ID_TY_C,
											USR_ID_N, 
											CRT_BY_N,
											CRT_ON_DT,
											ST_C 
											) 
								VALUES (
										SEQ_USR_REQ.NEXTVAL,
										LV_ICA(I).V_COY_RCB,		
										'NRIC',		
										LV_ICA(I).V_USER_ID,		
										'DATA MIGRATION'	,	
										SYSDATE,		
										NULL		
										);

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG        || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := 'ID_N: '||SEQ_USR_REQ.NEXTVAL || 
									' CO_UEN_N: '||LV_ICA(I).V_COY_RCB || 
									' USR_ID_TY_C: '||'NRIC' ||		
									' USR_ID_N: '||LV_ICA(I).V_USER_ID || 
									' CRT_BY_N: '||'DATA MIGRATION'	||
									' CRT_ON_DT: '||SYSDATE	 ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', V_SQLERRM, 'ERROR', PV_RUN_ID , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;
	CLOSE CR_ICA;


    SELECT  COUNT(*)
    INTO LV_CNT_TAR
    FROM ICA_USR_REQUEST;   ---- INTERMIDATE TABLE COUNT 

    IF ( LV_CNT_TAR = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_ST AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_ST OR LV_CNT_TAR = LV_CNT_ST ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ICA_USERROLES', LV_CNT_ST, 'ICA_USR_REQUEST', LV_CNT_TAR, 'N');



EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ICA_USR_REQUEST;
/