create or replace PROCEDURE PROC_2_ARRGD_PURCAL (PV_RUN_ID  in number)IS


/***********************************************************************************************************
procedure name : PROC_ARRIVAL_GD_APPLICATION
Created By     : R.M.KHOOL
Date           : 16-JUL-2019
Purpose        : Inserting  the data from ST_CV_GDAppln,ST_CV_arrGD,ST_CV_vslCall (main table) to 
                 SI_ARRIVAL_GD_APPLICATION(Intermediate table) to ARRIVAL_GD_APPLICATION & ARRIVAL_GD_PURPOSE_OF_CALL(Target Table)
Modified by    :
Modified date  :

*************************************************************************************************************/

/***********************************************************************************************************
Declaring variables for intermediate table 
*************************************************************************************************************/

	CURSOR CUR_ARR_GD IS 
	SELECT APPLNREF_N,
			GDTY_C,
			AGTDECLRAC_N,
			GDV_N,
			CONTACTPERS_M,
			OFFTEL_N,
			HOMETEL_N,
			MOBILE_N,
			FAX_N,
			EMAILADDR_X,
			VSLGT_Q,
			NEWVSLGT_Q,
			ARRDECLR_DT,
			CTRYARRFR_C,
			LASTPORT_C,
			PAX_Q,
			CREW_Q,
			CGO_Q,
			MSTRONARR_X,
			LOCNONARR_C,
			ARRLOCNONARR_M,
			GRIDREF_N,
			MOTHERGDV_N,
			BUNKR_Q,
			BUNKRGR_C,
			CST_N,
			CHARTERERNAT_C,
			SLN_C,
			CALLRECST_C,
			RTA_DT,
			PCCEXEMPNRSN_X,
			OFFICIALGDV_N,
			ARRGDST_C,
			APPRBY_M,
			APPRON_DT,
			REM_X,
			INTLREM_X,
			ADDRFLR_N,
			ADDRUNIT_N,
			ADDRPOSTALCODE_N,
			APPLCNT_M,
			ADDRBLDG_M,
			FIN_N,
			NRIC_N,
			PASSPT_N,
			ADDRST_M,
			CRTON_DT,
			CRTBY_M,
			UPDON_DT,
			UPDBY_M,
			PURPCALL1_I,
			PURPCALL2_I,
			PURPCALL3_I,
			PURPCALL4_I,
			PURPCALL5_I,
			PURPCALL6_I,
			PURPCALL7_I,
			PURPCALL9_I,
			ARRPURPCALLOTHERS_X,
			PURPCALLOTHERSTOW_X,
			PURPCALLOTHERSTOWVSL_M,
			PURPCALLOTHERSUNDTOWVSL_M,
			MSW_VSL_ID_N,
			APPLN_ARR_DCL_DT,
			APPLN_DEP_DCL_DT,
			RTD_DT,
			MVMTID_N
	FROM SI_ARR_GD;

	/***********************************************************************************************************
	Defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table
	*************************************************************************************************************/

	TYPE REC_ARR_GD IS RECORD (
	V_APPLNREF_N					SI_ARR_GD.APPLNREF_N%TYPE	,
	V_GDTY_C			            SI_ARR_GD.GDTY_C%TYPE	,
	V_AGTDECLRAC_N		            SI_ARR_GD.AGTDECLRAC_N%TYPE	,
	V_GDV_N				            SI_ARR_GD.GDV_N%TYPE	,
	V_CONTACTPERS_M		            SI_ARR_GD.CONTACTPERS_M%TYPE	,
	V_OFFTEL_N			            SI_ARR_GD.OFFTEL_N%TYPE	,
	V_HOMETEL_N			            SI_ARR_GD.HOMETEL_N%TYPE	,
	V_MOBILE_N			            SI_ARR_GD.MOBILE_N%TYPE	,
	V_FAX_N				            SI_ARR_GD.FAX_N%TYPE	,
	V_EMAILADDR_X		            SI_ARR_GD.EMAILADDR_X%TYPE	,
	V_VSLGT_Q			            SI_ARR_GD.VSLGT_Q%TYPE	,
	V_NEWVSLGT_Q		            SI_ARR_GD.NEWVSLGT_Q%TYPE	,
	V_ARRDECLR_DT		            SI_ARR_GD.ARRDECLR_DT%TYPE	,
	V_CTRYARRFR_C		            SI_ARR_GD.CTRYARRFR_C%TYPE	,
	V_LASTPORT_C		            SI_ARR_GD.LASTPORT_C%TYPE	,
	V_PAX_Q				            SI_ARR_GD.PAX_Q%TYPE	,
	V_CREW_Q			            SI_ARR_GD.CREW_Q%TYPE	,
	V_CGO_Q				            SI_ARR_GD.CGO_Q%TYPE	,
	V_MSTRONARR_X		            SI_ARR_GD.MSTRONARR_X%TYPE	,
	V_LOCNONARR_C		            SI_ARR_GD.LOCNONARR_C%TYPE	,
	V_ARRLOCNONARR_M	            SI_ARR_GD.ARRLOCNONARR_M%TYPE	,
	V_GRIDREF_N			            SI_ARR_GD.GRIDREF_N%TYPE	,
	V_MOTHERGDV_N		            SI_ARR_GD.MOTHERGDV_N%TYPE	,
	V_BUNKR_Q			            SI_ARR_GD.BUNKR_Q%TYPE	,
	V_BUNKRGR_C			            SI_ARR_GD.BUNKRGR_C%TYPE	,
	V_CST_N				            SI_ARR_GD.CST_N%TYPE	,
	V_CHARTERERNAT_C	            SI_ARR_GD.CHARTERERNAT_C%TYPE	,
	V_SLN_C				            SI_ARR_GD.SLN_C%TYPE	,
	V_CALLRECST_C		            SI_ARR_GD.CALLRECST_C%TYPE	,
	V_RTA_DT			            SI_ARR_GD.RTA_DT%TYPE	,
	V_PCCEXEMPNRSN_X	            SI_ARR_GD.PCCEXEMPNRSN_X%TYPE	,
	V_OFFICIALGDV_N		            SI_ARR_GD.OFFICIALGDV_N%TYPE	,
	V_ARRGDST_C			            SI_ARR_GD.ARRGDST_C%TYPE	,
	V_APPRBY_M			            SI_ARR_GD.APPRBY_M%TYPE	,
	V_APPRON_DT			            SI_ARR_GD.APPRON_DT%TYPE	,
	V_REM_X				            SI_ARR_GD.REM_X%TYPE	,
	V_INTLREM_X			            SI_ARR_GD.INTLREM_X%TYPE	,
	V_ADDRFLR_N			            SI_ARR_GD.ADDRFLR_N%TYPE	,
	V_ADDRUNIT_N		            SI_ARR_GD.ADDRUNIT_N%TYPE	,
	V_ADDRPOSTALCODE_N	            SI_ARR_GD.ADDRPOSTALCODE_N%TYPE	,
	V_APPLCNT_M			            SI_ARR_GD.APPLCNT_M%TYPE	,
	V_ADDRBLDG_M		            SI_ARR_GD.ADDRBLDG_M%TYPE	,
	V_FIN_N				            SI_ARR_GD.FIN_N%TYPE	,
	V_NRIC_N			            SI_ARR_GD.NRIC_N%TYPE	,
	V_PASSPT_N			            SI_ARR_GD.PASSPT_N%TYPE	,
	V_ADDRST_M			            SI_ARR_GD.ADDRST_M%TYPE	,
	V_CRTON_DT			            SI_ARR_GD.CRTON_DT%TYPE	,
	V_CRTBY_M			            SI_ARR_GD.CRTBY_M%TYPE	,
	V_UPDON_DT			            SI_ARR_GD.UPDON_DT%TYPE	,
	V_UPDBY_M			            SI_ARR_GD.UPDBY_M%TYPE	,
	V_PURPCALL1_I		            SI_ARR_GD.PURPCALL1_I%TYPE	,
	V_PURPCALL2_I		            SI_ARR_GD.PURPCALL2_I%TYPE	,
	V_PURPCALL3_I		            SI_ARR_GD.PURPCALL3_I%TYPE	,
	V_PURPCALL4_I		            SI_ARR_GD.PURPCALL4_I%TYPE	,
	V_PURPCALL5_I					SI_ARR_GD.PURPCALL5_I%TYPE	,
	V_PURPCALL6_I					SI_ARR_GD.PURPCALL6_I%TYPE	,
	V_PURPCALL7_I					SI_ARR_GD.PURPCALL7_I%TYPE	,
	V_PURPCALL9_I					SI_ARR_GD.PURPCALL9_I%TYPE	,
	V_ARRPURPCALLOTHERS_X			SI_ARR_GD.ARRPURPCALLOTHERS_X%TYPE	,
	V_PURPCALLOTHERSTOW_X			SI_ARR_GD.PURPCALLOTHERSTOW_X%TYPE	,
	V_PURPCALLOTHERSTOWVSL_M		SI_ARR_GD.PURPCALLOTHERSTOWVSL_M%TYPE	,
	V_PURPCALLOTHERSUNDTOWVSL_M		SI_ARR_GD.PURPCALLOTHERSUNDTOWVSL_M%TYPE	,
	V_MSW_VSL_ID_N					SI_ARR_GD.MSW_VSL_ID_N%TYPE	,
	V_APPLN_ARR_DCL_DT				SI_ARR_GD.APPLN_ARR_DCL_DT%TYPE	,
	V_APPLN_DEP_DCL_DT				SI_ARR_GD.APPLN_DEP_DCL_DT%TYPE	,
	V_RTD_DT						SI_ARR_GD.RTD_DT%TYPE	,
	V_MVMTID_N						SI_ARR_GD.MVMTID_N%TYPE	
	);

	TYPE TYPE_ARR_GD IS TABLE OF REC_ARR_GD;

	LV_ARR_GD  TYPE_ARR_GD;
	V_ERR_CODE         	NUMBER;
    V_ERR_MSG          	VARCHAR2(500);
    V_SQLERRM          	VARCHAR2(2500);
    V_YEAR_MONTH       	VARCHAR2(40);
    ARR_P_YYMM         	VARCHAR2(100);
    DEP_P_YYMM        	VARCHAR2(100);
    L_VAL   			NUMBER;
    LVAL 				CLOB;
    V_SYL    			CLOB;
    V_POC     			CLOB;
    V_MSW_VSL_CALL_ID_OUT  NUMBER;
    V_FLAG_OUT    		VARCHAR2(100);
    V_MSW_APPLN_REF_ID_X   VARCHAR2(20);
    V_DEL_ARRGD   		NUMBER;
    V_DEL_DEPGD    		NUMBER;
    V_SRC_COUNT   		NUMBER;
    V_TGT_COUNT  		NUMBER;

BEGIN

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_ARR_GD', 'PROC_2_ARRGD_PURCAL','INSERTION INTO SI_ARR_GD  STARTS' , 'START',null,null,null,'T');

	FOR i IN 
	(select --'CV_arrGD', count(*) 
	app.applnRef_n,
	app.gdty_c  ,
	arr.agtDeclrAc_n,
	arr.GDV_n,
	app.contactPers_m,
	app.offTel_n,
	app.homeTel_n,
	app.mobile_n,
	app.fax_n,
	app.emailAddr_x,
	arr.vslGT_q,
	app.newVslGT_q,
	arr.arrDeclr_dt,
	arr.ctryArrFr_c,
	arr.lastPort_c,
	arr.pax_q,
	arr.crew_q,
	arr.cgo_q,
	arr.mstrOnArr_x,
	arr.locnOnArr_c,
	app.arrLocnOnArr_m,
	arr.gridRef_n,
	arr.motherGDV_n,
	arr.bunkr_q,
	arr.bunkrGr_c,
	arr.cst_n,
	arr.chartererNat_c,
	arr.sln_c,
	call.callRecSt_c,
	call.RTA_dt,
	call.pccExempnRsn_x,
	call.officialGDV_n,
	arr.arrGDSt_c,
	pend.apprBy_m,
	pend.apprOn_dt,
	app.rem_x,
	app.intlRem_x,
	app.addrFlr_n,
	app.addrUnit_n,
	app.addrPostalcode_n,
	app.applcnt_m,
	app.addrBldg_m,
	app.FIN_n,
	app.NRIC_n,
	app.passpt_n,
	app.addrSt_m,
	arr.crtOn_dt,
	arr.crtBy_m,
	arr.updOn_dt,
	arr.updBy_m,
	call.PURPCALL1_I,
	call.PURPCALL2_I,
	call.PURPCALL3_I,
	call.PURPCALL4_I,
	call.PURPCALL5_I,
	call.PURPCALL6_I,
	call.PURPCALL7_I,
	call.PURPCALL9_I,
	call.ARRPURPCALLOTHERS_X,
	call.PURPCALLOTHERSTOW_X,
	call.PURPCALLOTHERSTOWVSL_M,
	call.PURPCALLOTHERSUNDTOWVSL_M,
	 vl.MSW_VSL_ID_N,--MSW_VSL_ID_N
	app.arrDeclr_dt APPLN_ARR_DCL_DT,
	app.depDeclr_dt APPLN_DEP_DCL_DT,
	call.rtd_dt,
	call.mvmtId_n
	from 
	st_CV_arrGD arr ,st_CV_GDAppln app,st_CV_vslCall call , st_CV_pendingAppln pend,vessel   vl,
	(
	select distinct app.GDV_n, MAX( app.crtOn_dt) as maxCrtOn_dt from st_CV_arrGD arr ,st_CV_GDAppln app
	where   app.GDV_n = arr.GDV_n 
	 and arr.arrGDSt_c in ('1','5') and app.GDTy_c in ('A', 'C')
	group by app.GDV_n
	) lastedGDApp
	where
	app.GDV_n = arr.GDV_n 
	and  call.GDV_n = arr.GDV_n 
    AND vl.vsl_rec_id_n = arr.vslrecid_n
	and  pend.applnRef_n = app.applnRef_n
	and lastedGDApp.GDV_n = app.GDV_n and lastedGDApp.maxCrtOn_dt = app.crtOn_dt
	)

	LOOP
	BEGIN
		INSERT INTO SI_ARR_GD
		(
		APPLNREF_N,
		GDTY_C,
		AGTDECLRAC_N,
		GDV_N,
		CONTACTPERS_M,
		OFFTEL_N,
		HOMETEL_N,
		MOBILE_N,
		FAX_N,
		EMAILADDR_X,
		VSLGT_Q,
		NEWVSLGT_Q,
		ARRDECLR_DT,
		CTRYARRFR_C,
		LASTPORT_C,
		PAX_Q,
		CREW_Q,
		CGO_Q,
		MSTRONARR_X,
		LOCNONARR_C,
		ARRLOCNONARR_M,
		GRIDREF_N,
		MOTHERGDV_N,
		BUNKR_Q,
		BUNKRGR_C,
		CST_N,
		CHARTERERNAT_C,
		SLN_C,
		CALLRECST_C,
		RTA_DT,
		PCCEXEMPNRSN_X,
		OFFICIALGDV_N,
		ARRGDST_C,
		APPRBY_M,
		APPRON_DT,
		REM_X,
		INTLREM_X,
		ADDRFLR_N,
		ADDRUNIT_N,
		ADDRPOSTALCODE_N,
		APPLCNT_M,
		ADDRBLDG_M,
		FIN_N,
		NRIC_N,
		PASSPT_N,
		ADDRST_M,
		CRTON_DT,
		CRTBY_M,
		UPDON_DT,
		UPDBY_M,
		PURPCALL1_I,
		PURPCALL2_I,
		PURPCALL3_I,
		PURPCALL4_I,
		PURPCALL5_I,
		PURPCALL6_I,
		PURPCALL7_I,
		PURPCALL9_I,
		ARRPURPCALLOTHERS_X,
		PURPCALLOTHERSTOW_X,
		PURPCALLOTHERSTOWVSL_M,
		PURPCALLOTHERSUNDTOWVSL_M,
		MSW_VSL_ID_N,
		APPLN_ARR_DCL_DT,
		APPLN_DEP_DCL_DT,
		RTD_DT,
		MVMTID_N
		)
		VALUES
		(
		i.applnRef_n,
		i.gdty_c  ,
		i.agtDeclrAc_n,
		i.GDV_n,
		i.contactPers_m,
		i.offTel_n,
		i.homeTel_n,
		i.mobile_n,
		i.fax_n,
		i.emailAddr_x,
		i.vslGT_q,
		i.newVslGT_q,
		i.arrDeclr_dt,
		i.ctryArrFr_c,
		i.lastPort_c,
		i.pax_q,
		i.crew_q,
		i.cgo_q,
		i.mstrOnArr_x,
		i.locnOnArr_c,
		i.arrLocnOnArr_m,
		i.gridRef_n,
		i.motherGDV_n,
		i.bunkr_q,
		i.bunkrGr_c,
		i.cst_n,
		i.chartererNat_c,
		i.sln_c,
		i.callRecSt_c,
		i.RTA_dt,
		i.pccExempnRsn_x,
		i.officialGDV_n,
		i.arrGDSt_c,
		i.apprBy_m,
		i.apprOn_dt,
		i.rem_x,
		i.intlRem_x,
		i.addrFlr_n,
		i.addrUnit_n,
		i.addrPostalcode_n,
		i.applcnt_m,
		i.addrBldg_m,
		i.FIN_n,
		i.NRIC_n,
		i.passpt_n,
		i.addrSt_m,
		i.crtOn_dt,
		i.crtBy_m,
		i.updOn_dt,
		i.updBy_m,
		i.PURPCALL1_I,
		i.PURPCALL2_I,
		i.PURPCALL3_I,
		i.PURPCALL4_I,
		i.PURPCALL5_I,
		i.PURPCALL6_I,
		i.PURPCALL7_I,
		i.PURPCALL9_I,
		i.ARRPURPCALLOTHERS_X,
		i.PURPCALLOTHERSTOW_X,
		i.PURPCALLOTHERSTOWVSL_M,
		i.PURPCALLOTHERSUNDTOWVSL_M,
		i.MSW_VSL_ID_N,
		i.APPLN_ARR_DCL_DT,
		i.APPLN_DEP_DCL_DT,
		i.rtd_dt,
		i.mvmtId_n
		);

		EXCEPTION  

		WHEN OTHERS THEN                                                     -- inner exception for handling any errors in the SI table 
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;

				V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
				PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_ARR_GD', 'PROC_2_ARRGD_PURCAL',
				'APPLNREF_N:'||i.applnRef_n||'<{||}>'||
				'GDTY_C:'||i.gdty_c  ||'<{||}>'||
				'AGTDECLRAC_N:'||i.agtDeclrAc_n||'<{||}>'||
				'GDV_N:'||i.GDV_n||'<{||}>'||
				'CONTACTPERS_M:'||i.contactPers_m||'<{||}>'||
				'OFFTEL_N:'||i.offTel_n||'<{||}>'||
				'HOMETEL_N:'||i.homeTel_n||'<{||}>'||
				'MOBILE_N:'||i.mobile_n||'<{||}>'||
				'FAX_N:'||i.fax_n||'<{||}>'||
				'EMAILADDR_X:'||i.emailAddr_x||'<{||}>'||
				'VSLGT_Q:'||i.vslGT_q||'<{||}>'||
				'NEWVSLGT_Q:'||i.newVslGT_q||'<{||}>'||
				'ARRDECLR_DT:'||i.arrDeclr_dt||'<{||}>'||
				'CTRYARRFR_C:'||i.ctryArrFr_c||'<{||}>'||
				'LASTPORT_C:'||i.lastPort_c||'<{||}>'||
				'PAX_Q:'||i.pax_q||'<{||}>'||
				'CREW_Q:'||i.crew_q||'<{||}>'||
				'CGO_Q:'||i.cgo_q||'<{||}>'||
				'MSTRONARR_X:'||i.mstrOnArr_x||'<{||}>'||
				'LOCNONARR_C:'||i.locnOnArr_c||'<{||}>'||
				'ARRLOCNONARR_M:'||i.arrLocnOnArr_m||'<{||}>'||
				'GRIDREF_N:'||i.gridRef_n||'<{||}>'||
				'MOTHERGDV_N:'||i.motherGDV_n||'<{||}>'||
				'BUNKR_Q:'||i.bunkr_q||'<{||}>'||
				'BUNKRGR_C:'||i.bunkrGr_c||'<{||}>'||
				'CST_N:'||i.cst_n||'<{||}>'||
				'CHARTERERNAT_C:'||i.chartererNat_c||'<{||}>'||
				'SLN_C:'||i.sln_c||'<{||}>'||
				'CALLRECST_C:'||i.callRecSt_c||'<{||}>'||
				'RTA_DT:'||i.RTA_dt||'<{||}>'||
				'PCCEXEMPNRSN_X:'||i.pccExempnRsn_x||'<{||}>'||
				'OFFICIALGDV_N:'||i.officialGDV_n||'<{||}>'||
				'ARRGDST_C:'||i.arrGDSt_c||'<{||}>'||
				'APPRBY_M:'||i.apprBy_m||'<{||}>'||
				'APPRON_DT:'||i.apprOn_dt||'<{||}>'||
				'REM_X:'||i.rem_x||'<{||}>'||
				'INTLREM_X:'||i.intlRem_x||'<{||}>'||
				'ADDRFLR_N:'||i.addrFlr_n||'<{||}>'||
				'ADDRUNIT_N:'||i.addrUnit_n||'<{||}>'||
				'ADDRPOSTALCODE_N:'||i.addrPostalcode_n||'<{||}>'||
				'APPLCNT_M:'||i.applcnt_m||'<{||}>'||
				'ADDRBLDG_M:'||i.addrBldg_m||'<{||}>'||
				'FIN_N:'||i.FIN_n||'<{||}>'||
				'NRIC_N:'||i.NRIC_n||'<{||}>'||
				'PASSPT_N:'||i.passpt_n||'<{||}>'||
				'ADDRST_M:'||i.addrSt_m||'<{||}>'||
				'CRTON_DT:'||i.crtOn_dt||'<{||}>'||
				'CRTBY_M:'||i.crtBy_m||'<{||}>'||
				'UPDON_DT:'||i.updOn_dt||'<{||}>'||
				'UPDBY_M:'||i.updBy_m||'<{||}>'||
				'PURPCALL1_I:'||i.PURPCALL1_I||'<{||}>'||
				'PURPCALL2_I:'||i.PURPCALL2_I||'<{||}>'||
				'PURPCALL3_I:'||i.PURPCALL3_I||'<{||}>'||
				'PURPCALL4_I:'||i.PURPCALL4_I||'<{||}>'||
				'PURPCALL5_I:'||i.PURPCALL5_I||'<{||}>'||
				'PURPCALL6_I:'||i.PURPCALL6_I||'<{||}>'||
				'PURPCALL7_I:'||i.PURPCALL7_I||'<{||}>'||
				'PURPCALL9_I:'||i.PURPCALL9_I||'<{||}>'||
				'ARRPURPCALLOTHERS_X:'||i.ARRPURPCALLOTHERS_X||'<{||}>'||
				'PURPCALLOTHERSTOW_X:'||i.PURPCALLOTHERSTOW_X||'<{||}>'||
				'PURPCALLOTHERSTOWVSL_M:'||i.PURPCALLOTHERSTOWVSL_M||'<{||}>'||
				'PURPCALLOTHERSUNDTOWVSL_M:'||i.PURPCALLOTHERSUNDTOWVSL_M||'<{||}>'||
				'MSW_VSL_ID_N:'||i.MSW_VSL_ID_N||'<{||}>'||
				'APPLN_ARR_DCL_DT:'||i.APPLN_ARR_DCL_DT||'<{||}>'||
				'APPLN_DEP_DCL_DT:'||i.APPLN_DEP_DCL_DT||'<{||}>'||
				'RTD_DT:'||i.rtd_dt||'<{||}>'||
				'MVMTID_N:'||i.mvmtId_n||'<{||}>',
				'ERROR',
				PV_RUN_ID,
				V_SQLERRM,
				i.applnRef_n||'<{||}>'||
				i.gdty_c  ||'<{||}>'||
				i.agtDeclrAc_n||'<{||}>'||
				i.GDV_n||'<{||}>'||
				i.contactPers_m||'<{||}>'||
				i.offTel_n||'<{||}>'||
				i.homeTel_n||'<{||}>'||
				i.mobile_n||'<{||}>'||
				i.fax_n||'<{||}>'||
				i.emailAddr_x||'<{||}>'||
				i.vslGT_q||'<{||}>'||
				i.newVslGT_q||'<{||}>'||
				i.arrDeclr_dt||'<{||}>'||
				i.ctryArrFr_c||'<{||}>'||
				i.lastPort_c||'<{||}>'||
				i.pax_q||'<{||}>'||
				i.crew_q||'<{||}>'||
				i.cgo_q||'<{||}>'||
				i.mstrOnArr_x||'<{||}>'||
				i.locnOnArr_c||'<{||}>'||
				i.arrLocnOnArr_m||'<{||}>'||
				i.gridRef_n||'<{||}>'||
				i.motherGDV_n||'<{||}>'||
				i.bunkr_q||'<{||}>'||
				i.bunkrGr_c||'<{||}>'||
				i.cst_n||'<{||}>'||
				i.chartererNat_c||'<{||}>'||
				i.sln_c||'<{||}>'||
				i.callRecSt_c||'<{||}>'||
				i.RTA_dt||'<{||}>'||
				i.pccExempnRsn_x||'<{||}>'||
				i.officialGDV_n||'<{||}>'||
				i.arrGDSt_c||'<{||}>'||
				i.apprBy_m||'<{||}>'||
				i.apprOn_dt||'<{||}>'||
				i.rem_x||'<{||}>'||
				i.intlRem_x||'<{||}>'||
				i.addrFlr_n||'<{||}>'||
				i.addrUnit_n||'<{||}>'||
				i.addrPostalcode_n||'<{||}>'||
				i.applcnt_m||'<{||}>'||
				i.addrBldg_m||'<{||}>'||
				i.FIN_n||'<{||}>'||
				i.NRIC_n||'<{||}>'||
				i.passpt_n||'<{||}>'||
				i.addrSt_m||'<{||}>'||
				i.crtOn_dt||'<{||}>'||
				i.crtBy_m||'<{||}>'||
				i.updOn_dt||'<{||}>'||
				i.updBy_m||'<{||}>'||
				i.PURPCALL1_I||'<{||}>'||
				i.PURPCALL2_I||'<{||}>'||
				i.PURPCALL3_I||'<{||}>'||
				i.PURPCALL4_I||'<{||}>'||
				i.PURPCALL5_I||'<{||}>'||
				i.PURPCALL6_I||'<{||}>'||
				i.PURPCALL7_I||'<{||}>'||
				i.PURPCALL9_I||'<{||}>'||
				i.ARRPURPCALLOTHERS_X||'<{||}>'||
				i.PURPCALLOTHERSTOW_X||'<{||}>'||
				i.PURPCALLOTHERSTOWVSL_M||'<{||}>'||
				i.PURPCALLOTHERSUNDTOWVSL_M||'<{||}>'||
				i.MSW_VSL_ID_N||'<{||}>'||
				i.APPLN_ARR_DCL_DT||'<{||}>'||
				i.APPLN_DEP_DCL_DT||'<{||}>'||
				i.rtd_dt||'<{||}>'||
				i.mvmtId_n||'<{||}>',
				'T'
				);
	END;
	END LOOP;

OPEN CUR_ARR_GD;

	LOOP

	 FETCH CUR_ARR_GD BULK COLLECT INTO LV_ARR_GD LIMIT 10000;
	 EXIT WHEN LV_ARR_GD.count = 0;

	 FOR i IN LV_ARR_GD.FIRST..LV_ARR_GD.LAST 

	LOOP

		--IF	TRIM(LV_ARR_GD(i).V_GDTY_C)  = 'A' THEN

		 /*FINDING the year and month of the 
                         current record based on created on date */
		SELECT TO_CHAR(LV_ARR_GD(i).V_CRTON_DT,'YY')|| TO_CHAR(LV_ARR_GD(i).V_CRTON_DT,'MM') 
        INTO V_YEAR_MONTH 
        FROM DUAL;

		 /*Reset the sequence if the current year month doesnot match with the previous year and month  */ 
        IF V_YEAR_MONTH != ARR_P_YYMM  AND  ARR_P_YYMM IS NOT NULL THEN

        EXECUTE IMMEDIATE 'SELECT ARR_SUB_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
        EXECUTE IMMEDIATE 'ALTER SEQUENCE ARR_SUB_SEQ INCREMENT BY -'|| L_VAL || ' MINVALUE 0';

        EXECUTE IMMEDIATE 'SELECT ARR_SUB_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
        EXECUTE IMMEDIATE 'ALTER SEQUENCE ARR_SUB_SEQ INCREMENT BY 1 MINVALUE 0';


		END IF ;    -- END IF OF  THE SEQUENCE RESET 
		ARR_P_YYMM := V_YEAR_MONTH;

		V_MSW_APPLN_REF_ID_X := 'MSW'||'AGD'||TO_CHAR(LV_ARR_GD(i).V_CRTON_DT,'YY')||TO_CHAR(LV_ARR_GD(i).V_CRTON_DT,'MM')||TO_CHAR(ARR_SUB_SEQ.NEXTVAL,'FM00000' ) ;


		/*********************************************************************************************************************************************************************************
			JSON STARTS
		*******************************************************************************************************************************************************************************/


		LVAL :=  null;                    
		LVAL:='{'; 

		LVAL:=LVAL||'\"agentDeclaredAccountNumber\":\"'||LV_ARR_GD(i).v_agtDeclrAc_n||'\",';

		LVAL := LVAL ||'\"applicationReferenceNumber\":\"'||ARR_GD_APPLN_SEQ.NEXTVAL||'\",';

		LVAL:=LVAL||'\"mobilePhoneNumber\":\"'||LV_ARR_GD(i).v_mobile_n||'\",'; 

		LVAL:=LVAL||'\"homePhoneNumber\":'||LV_ARR_GD(i).v_homeTel_n||',';

		LVAL:=LVAL||'\"emailAddress\":\"'||LV_ARR_GD(i).v_emailAddr_x||'\",'; 

		LVAL:=LVAL||'\"faxNumber\":\"'||LV_ARR_GD(i).v_fax_n||'\",'; 

		LVAL:=LVAL||'\"contactPerson\":\"'||LV_ARR_GD(i).v_contactPers_m||'\",';  

		LVAL:=LVAL||'\"officePhoneNumber\":'||LV_ARR_GD(i).v_offTel_n||',';  

		LVAL:=LVAL||'\"arrivalCharacterNationalityCode\":\"'||LV_ARR_GD(i).v_chartererNat_c||'\",';    

		LVAL:=LVAL||'\"arrivalShippingLineCode\":\"'||LV_ARR_GD(i).v_sln_c||'\",'; 

		LVAL:=LVAL||'\"loading\":'||null||',';

		LVAL:=LVAL||'\"embarking\":'||null||',';

		LVAL:=LVAL||'\"takingBunkers\":'||null||',';

		LVAL:=LVAL||'\"mdo\":'||null||',';

		LVAL:=LVAL||'\"mfo\":'||null||',';

		LVAL:=LVAL||'\"arrivalCST\":\"'||null||'\",';

		LVAL:=LVAL||'\"mgo\":'||null||',';

		LVAL:=LVAL||'\"tonnes\":\"'||null||'\",';

		LVAL:=LVAL||'\"repair\":'||null||',';


		/************************************************************************************************
		JSON OF  SHIP YARD LOCATION  STARTS
		************************************************************************************************/
		V_SYL := null;
		-- need to write for loop when appropriate values are given
		V_SYL := '\"shipYardsLocation\":[{}),';

		LVAL:=LVAL||V_SYL;

		/************************************************************************************************
		JSON OF  SHIP YARD LOCATION  ENDS
		************************************************************************************************/

		LVAL:= LVAL ||'\"takingShip\":'||null||',';

		LVAL:= LVAL ||'\"changing\":'||null||',';

		LVAL:= LVAL ||'\"other\":'||null||',';

		LVAL:= LVAL ||'\"otherAfloatActivities\":\"'||null||'\",';

		LVAL:= LVAL ||'\"othersText\":\"'||null||'\",';

		LVAL:= LVAL ||'\"arrivalDateTime\":\"'||null||'\",';

		LVAL:= LVAL ||'\"locationOnArrivalCode\":\"'||LV_ARR_GD(i).v_locnOnArr_c||'\",';

		LVAL:= LVAL ||'\"highseas\":'||null||',';

		LVAL:= LVAL ||'\"outsidePortLimit\":'||null||',';

		LVAL:= LVAL ||'\"seaTrialSchema\":'||null||',';

		LVAL:= LVAL ||'\"masterOnArrival\":\"'||LV_ARR_GD(i).v_mstrOnArr_x||'\",';

		LVAL:= LVAL ||'\"totalCrewOnBoard\":\"'||null||'\",';

		LVAL:= LVAL ||'\"totalPassengerOnBoard\":\"'||null||'\",';

		LVAL:= LVAL ||'\"totalCargoOnBoard\":\"'||null||'\",';

		LVAL:= LVAL ||'\"confirm\":'||null||',';

		LVAL:= LVAL ||'\"checkTerm\":'||null||',';

		LVAL:= LVAL ||'\"reportedArrivalOnDateTime\":\"'||null||'\",';

		/************************************************************************************************
		JSON OF  PURPOSE OF CALL  STARTS
		************************************************************************************************/
		V_POC := null;

		V_POC := '\"purposeOfCalls\":[';                     

		 if trim(upper(LV_ARR_GD(i).V_PURPCALL1_I)) =  'Y'      then               

		V_POC := V_POC || '{\"gdId\":\"'|| V_MSW_APPLN_REF_ID_X ||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Cargo Operation' || '\"},';                         

		 end if;



		 IF trim(upper(LV_ARR_GD(i).v_purpcall2_i)) =  'Y'  then 

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X ||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Embarking/disembarking Passenger' || '\"},';    

		end if;


		IF trim(upper(LV_ARR_GD(i).v_purpcall3_i)) =  'Y' then 

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Taking Bunkers' || '\"},';    


		END IF;

		IF trim(upper(LV_ARR_GD(i).v_purpcall4_i)) =  'Y' then 

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Taking Suppliers' || '\"},';    

		END IF;

		IF trim(upper(LV_ARR_GD(i).v_purpcall5_i)) =  'Y'  then 

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Changing Crew' || '\"},';    

		END IF;

		IF trim(upper(LV_ARR_GD(i).v_purpcall6_i)) =  'Y' then 
		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Repair/Docking/Outfitting' || '\"},';    

		END IF;

		IF trim(upper(LV_ARR_GD(i).v_purpcall7_i)) =  'Y' then 
		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Offshore Vessel' || '\"},';    

		END IF;

		IF trim(upper(LV_ARR_GD(i).v_purpcall9_i)) =  'Y' then 

		if LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X  = 'SI' then
		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Shipped in as Cargo' || '\"},';

		end if;



		if trim(LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X)  = 'SO' then

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Shipped out as Cargo' || '\"},';

		end if;


		if trim(LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X)  = 'TO' then

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Towing' || '\"},';


		end if;



		if trim(LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X)  = 'RP'  then

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Recreation/Pleasure' || '\"},';

		end if;

		if trim(LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X)  = 'OT'  then

		V_POC := V_POC || '{\"gdId\":\"'||V_MSW_APPLN_REF_ID_X||'\",';
		V_POC := V_POC || '\"arrivalOrDeparture\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';
		V_POC := V_POC || '\"purposeOfCall\":\"'||'Other' || '\"},';

		end if;   

		END IF;   --IF upper(LV_ARR_GD(i).v_arr_POC_purpcall9_i) =  'Y' then 


		 V_POC := RTRIM(V_POC,',') ||'],';

		/************************************************************************************************
		JSON OF  PURPOSE OF CALL  ENDS
		************************************************************************************************/
		LVAL := LVAL || V_POC;                        

		LVAL := LVAL ||'\"officialGDVNumber\":\"'||LV_ARR_GD(i).v_officialGDV_n||'\",';
		LVAL := LVAL || '\"callRecordStatus\":\"'||LV_ARR_GD(i).v_callRecSt_c||'\",';
		LVAL := LVAL || '\"applicationStatus\":\"'||LV_ARR_GD(i).V_ARRGDST_C||'\",';                                                                                                                                
		LVAL := LVAL || '\"gdTypeCode\":\"'||LV_ARR_GD(i).v_GDTy_c||'\",';                                                                                         
		LVAL := LVAL || '\"voyageNumber\":'||null||',';
		LVAL := LVAL || '\"applicantId\":\"' ||null||'\",';
		LVAL := LVAL || '\"externalApplicationReference\":\"'||LV_ARR_GD(i).v_applnRef_n||'\",';                                                                                                                         
		LVAL := LVAL || '\"createdOn\":\"'||LV_ARR_GD(i).v_crtOn_dt||'\",';
		LVAL := LVAL || '\"createdBy\":\"'||LV_ARR_GD(i).v_crtBy_m||'\",';
		LVAL := LVAL || '\"agdShipCertificates\": [{}],';     --still clarity is reqd

		LVAL := LVAL || '}"';  


/*********************************************************************************************************************************************************************************
			JSON ENDS
*******************************************************************************************************************************************************************************/


/**************************************************************************************************************************************

insertion into VesselCall and Application submission starts
***************************************************************************************************************************************/
		PROC_2_VC_AS(LV_ARR_GD(i).V_MSW_VSL_ID_N, 
                   LV_ARR_GD(i).V_APPLN_ARR_DCL_DT,
                   LV_ARR_GD(i).V_APPLN_DEP_DCL_DT,
                   LV_ARR_GD(i).V_RTA_DT,
                   LV_ARR_GD(i).V_RTD_DT,
                   LV_ARR_GD(i).V_MVMTID_N,
                   V_MSW_APPLN_REF_ID_X, 
                   LV_ARR_GD(i).V_APPLNREF_N,
                   'AGD', 
                   LVAL,
                 PV_RUN_ID, 
                'ARRIVAL_GD_APPLICATION',
                V_MSW_VSL_CALL_ID_OUT, 
                V_FLAG_OUT);

/**************************************************************************************************************************************

insertion into VesselCall and Application submission Ends
***************************************************************************************************************************************/

		IF V_FLAG_OUT  IS NULL THEN


		/***************************************************************************************************************************************
		insertion into ARR_GD_APP starts
		****************************************************************************************************************************************/

			BEGIN
				INSERT INTO ARRIVAL_GD_APPLICATION
				(APPLN_REF_N	,
				MSW_APPLN_REF_ID_X	,
				EXTL_APPLN_REF_ID_X	,
				APPLCNT_ID_X	,
				VSL_CALL_ID_N	,
				MSW_VSL_ID_N	,
				GD_TY_C	,
				AGT_DECLR_AC_N	,
				GDV_N	,
				CONTACT_PERS_M	,
				OFF_TEL_N	,
				HOME_TEL_N	,
				MOBILE_N	,
				FAX_N	,
				EMAIL_ADDR_X	,
				VSL_GT_Q	,
				NEW_VSL_GT_Q	,
				ARR_DECLR_DT	,
				ARR_CTRY_FR_C	,
				ARR_LAST_PORT_C	,
				ARR_PAX_Q	,
				ARR_CREW_Q	,
				ARR_CGO_Q	,
				ARR_MSTR_ON_ARR_X	,
				ARR_LOCN_ON_ARR_C	,
				ARR_LOCN_ON_ARR_M	,
				ARR_GRID_REF_N	,
				ARR_MOTHER_GDV_N	,
				ARR_BUNKR_Q	,
				ARR_BUNKR_GR_C	,
				ARR_CST_N	,
				ARR_CHARTERER_NAT_C	,
				ARR_SLN_C	,
				CALL_REC_ST_C	,
				RTA_DT	,
				PCC_EXEMPN_RSN_X	,
				OFFICIAL_GDV_N	,
				APPLN_ST_C	,
				PROCESSED_BY_X	,
				PROCESSED_ON_DT	,
				PROCESSING_REM_X	,
				INTL_REM_X	,
				UNIT_NO_FROM	,
				UNIT_NO_TO	,
				POSTAL_CODE	,
				APPLICANT_NAME	,
				BUILDING_NAME	,
				FIN	,
				NRIC	,
				PASSPORT	,
				STREET_NAME	,
				DELETED_I	,
				LOCK_VER_N	,
				CRT_ON_DT	,
				CRT_BY_N	,
				UPT_ON_DT	,
				UPT_BY_X	
				)
				values
				(ARR_GD_APPLN_SEQ.CURRVAL,
				V_MSW_APPLN_REF_ID_X,
				LV_ARR_GD(i).V_APPLNREF_N	,
				'A',
				V_MSW_VSL_CALL_ID_OUT,
				LV_ARR_GD(i).V_MSW_VSL_ID_N,
				DECODE(TRIM(LV_ARR_GD(i).V_GDTy_C),'A','ARRIVAL','D','DEPARTURE','C','ARRIVAL' ||'&'|| 'DEPARTURE')	,
				LV_ARR_GD(i).v_agtDeclrAc_n	,
				LV_ARR_GD(i).v_GDV_n	,
				LV_ARR_GD(i).v_contactPers_m	,
				LV_ARR_GD(i).v_offTel_n	,
				LV_ARR_GD(i).v_homeTel_n	,
				LV_ARR_GD(i).v_mobile_n	,
				LV_ARR_GD(i).v_fax_n	,
				LV_ARR_GD(i).v_emailAddr_x	,
				LV_ARR_GD(i).v_vslGT_q	,
				LV_ARR_GD(i).v_newVslGT_q	,
				LV_ARR_GD(i).v_arrDeclr_dt	,
				LV_ARR_GD(i).v_ctryArrFr_c	,
				LV_ARR_GD(i).v_lastPort_c	,
				LV_ARR_GD(i).v_pax_q	,
				LV_ARR_GD(i).v_crew_q	,
				LV_ARR_GD(i).v_cgo_q	,
				LV_ARR_GD(i).v_mstrOnArr_x	,
				LV_ARR_GD(i).v_locnOnArr_c	,
				LV_ARR_GD(i).v_arrLocnOnArr_m	,
				LV_ARR_GD(i).v_gridRef_n	,
				LV_ARR_GD(i).v_motherGDV_n	,
				LV_ARR_GD(i).v_bunkr_q	,
				LV_ARR_GD(i).v_bunkrGr_c	,
				LV_ARR_GD(i).v_cst_n	,
				decode(LV_ARR_GD(i).v_chartererNat_c , 1,'SINGAPOREAN',2,'NON-SINGAPOREAN',3,'NIL'	),
				LV_ARR_GD(i).v_sln_c	,
				decode(LV_ARR_GD(i).v_callRecSt_c	,1,'CALL ACTIVE',2,'CALL CLOSED',3,'CALL CANCELLED',5,'CALL DUPLCATE'),
				LV_ARR_GD(i).v_RTA_dt	,
				LV_ARR_GD(i).v_pccExempnRsn_x	,
				LV_ARR_GD(i).v_officialGDV_n	,
				decode(LV_ARR_GD(i).v_arrgdSt_c,1,'APPROVED',4,'CANCELLED',5,'DUPLICATE'),
				LV_ARR_GD(i).v_apprBy_m	,
				LV_ARR_GD(i).v_apprOn_dt	,
				LV_ARR_GD(i).v_rem_x	,
				LV_ARR_GD(i).v_intlRem_x	,
				LV_ARR_GD(i).v_addrFlr_n	,
				LV_ARR_GD(i).v_addrUnit_n	,
				LV_ARR_GD(i).v_addrPostalcode_n	,
				LV_ARR_GD(i).v_applcnt_m	,
				LV_ARR_GD(i).v_addrBldg_m	,
				LV_ARR_GD(i).v_FIN_n	,
				LV_ARR_GD(i).v_NRIC_n	,
				LV_ARR_GD(i).v_passpt_n	,
				LV_ARR_GD(i).v_addrSt_m	,
				0	,
				0	,
				LV_ARR_GD(i).v_crtOn_dt	,
				LV_ARR_GD(i).v_crtBy_m	,
				LV_ARR_GD(i).v_updOn_dt	,
				LV_ARR_GD(i).v_updBy_m	
				);

				EXCEPTION        

				WHEN OTHERS THEN 

						V_ERR_CODE := SQLCODE;
						V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
						V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

						PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
						( 'ARRIVAL_GD_APPLICATION',
						'PROC_2_ARRGD_PURCAL',
						'APPLN_REF_N	:'||ARR_GD_APPLN_SEQ.CURRVAL	||'<{||}>'||
						'MSW_APPLN_REF_ID_X	:'||V_MSW_APPLN_REF_ID_X	||'<{||}>'||
						'EXTL_APPLN_REF_ID_X	:'||LV_ARR_GD(i).v_applnRef_n	||'<{||}>'||
						'APPLCNT_ID_X:'||null	||'<{||}>'||
						'VSL_CALL_ID_N:'||v_msw_vsl_call_id_out	||'<{||}>'||
						'MSW_VSL_ID_N:'||LV_ARR_GD(i).V_MSW_VSL_ID_N	||'<{||}>'||
						'GD_TY_C	:'||trim(LV_ARR_GD(i).v_GDTy_c)	||'<{||}>'||
						'AGT_DECLR_AC_N:'||	LV_ARR_GD(i).v_agtDeclrAc_n	||'<{||}>'||
						'GDV_N:'||	LV_ARR_GD(i).v_GDV_n	||'<{||}>'||
						'CONTACT_PERS_M:'||	LV_ARR_GD(i).v_contactPers_m	||'<{||}>'||
						'OFF_TEL_N:'||	LV_ARR_GD(i).v_offTel_n	||'<{||}>'||
						'HOME_TEL_N:'||	LV_ARR_GD(i).v_homeTel_n	||'<{||}>'||
						'MOBILE_N:'||	LV_ARR_GD(i).v_mobile_n	||'<{||}>'||
						'FAX_N:'||	LV_ARR_GD(i).v_fax_n	||'<{||}>'||
						'EMAIL_ADDR_X	:'||	LV_ARR_GD(i).v_emailAddr_x	||'<{||}>'||
						'VSL_GT_Q:'||	LV_ARR_GD(i).v_vslGT_q	||'<{||}>'||
						'NEW_VSL_GT_Q:'||	LV_ARR_GD(i).v_newVslGT_q	||'<{||}>'||
						'ARR_DECLR_DT:'||	LV_ARR_GD(i).v_arrDeclr_dt	||'<{||}>'||
						'ARR_CTRY_FR_C:'||	LV_ARR_GD(i).v_ctryArrFr_c	||'<{||}>'||
						'ARR_LAST_PORT_C	:'||	LV_ARR_GD(i).v_lastPort_c	||'<{||}>'||
						'ARR_PAX_Q:'||	LV_ARR_GD(i).v_pax_q	||'<{||}>'||
						'ARR_CREW_Q:'||	LV_ARR_GD(i).v_crew_q	||'<{||}>'||
						'ARR_CGO_Q:'||	LV_ARR_GD(i).v_cgo_q	||'<{||}>'||
						'ARR_MSTR_ON_ARR_X:'||	LV_ARR_GD(i).v_mstrOnArr_x	||'<{||}>'||
						'ARR_LOCN_ON_ARR_C:'||	LV_ARR_GD(i).v_locnOnArr_c	||'<{||}>'||
						'ARR_LOCN_ON_ARR_M:'||	LV_ARR_GD(i).v_arrLocnOnArr_m	||'<{||}>'||
						'ARR_GRID_REF_N:'||	LV_ARR_GD(i).v_gridRef_n	||'<{||}>'||
						'ARR_MOTHER_GDV_N:'||	LV_ARR_GD(i).v_motherGDV_n	||'<{||}>'||
						'ARR_BUNKR_Q	:'||	LV_ARR_GD(i).v_bunkr_q	||'<{||}>'||
						'ARR_BUNKR_GR_C	:'||	LV_ARR_GD(i).v_bunkrGr_c	||'<{||}>'||
						'ARR_CST_N:'||	LV_ARR_GD(i).v_cst_n	||'<{||}>'||
						'ARR_CHARTERER_NAT_C	:'||	LV_ARR_GD(i).v_chartererNat_c	||'<{||}>'||
						'ARR_SLN_C:'||	LV_ARR_GD(i).v_sln_c	||'<{||}>'||
						'CALL_REC_ST_C:'||	LV_ARR_GD(i).v_callRecSt_c	||'<{||}>'||
						'RTA_DT:'||	LV_ARR_GD(i).v_RTA_dt	||'<{||}>'||
						'PCC_EXEMPN_RSN_X:'||	LV_ARR_GD(i).v_pccExempnRsn_x	||'<{||}>'||
						'OFFICIAL_GDV_N:'||	LV_ARR_GD(i).v_officialGDV_n	||'<{||}>'||
						'APPLN_ST_C:'||	LV_ARR_GD(i).v_arrgdSt_c	||'<{||}>'||
						'PROCESSED_BY_X:'||	LV_ARR_GD(i).v_apprBy_m	||'<{||}>'||
						'PROCESSED_ON_DT:'||	LV_ARR_GD(i).v_apprOn_dt	||'<{||}>'||
						'PROCESSING_REM_X:'||	LV_ARR_GD(i).v_rem_x	||'<{||}>'||
						'INTL_REM_X:'||	LV_ARR_GD(i).v_intlRem_x	||'<{||}>'||
						'UNIT_NO_FROM:'||	LV_ARR_GD(i).v_addrFlr_n	||'<{||}>'||
						'UNIT_NO_TO:'||	LV_ARR_GD(i).v_addrUnit_n	||'<{||}>'||
						'POSTAL_CODE:'||	LV_ARR_GD(i).v_addrPostalcode_n	||'<{||}>'||
						'APPLICANT_NAME:'||	LV_ARR_GD(i).v_applcnt_m	||'<{||}>'||
						'BUILDING_NAME:'||	LV_ARR_GD(i).v_addrBldg_m	||'<{||}>'||
						'FIN	:'||	LV_ARR_GD(i).v_FIN_n	||'<{||}>'||
						'NRIC:'||	LV_ARR_GD(i).v_NRIC_n	||'<{||}>'||
						'PASSPORT:'||	LV_ARR_GD(i).v_passpt_n	||'<{||}>'||
						'STREET_NAME:'||	LV_ARR_GD(i).v_addrSt_m	||'<{||}>'||
						'DELETED_I:'||	'0'	||'<{||}>'||
						'LOCK_VER_N:'||	0	||'<{||}>'||
						'CRT_ON_DT:'||	LV_ARR_GD(i).v_crtOn_dt	||'<{||}>'||
						'CRT_BY_N:'||	LV_ARR_GD(i).v_crtBy_m	||'<{||}>'||
						'UPT_ON_DT:'||	LV_ARR_GD(i).v_updOn_dt	||'<{||}>'||
						'UPT_BY_X:'||	LV_ARR_GD(i).v_updBy_m
						 ,
						'ERROR',
						PV_RUN_ID,
						V_SQLERRM,
						ARR_GD_APPLN_SEQ.CURRVAL	||'<{||}>'||
						V_MSW_APPLN_REF_ID_X	||'<{||}>'||
						LV_ARR_GD(i).v_applnRef_n	||'<{||}>'||
						null	||'<{||}>'||
						v_msw_vsl_call_id_out	||'<{||}>'||
						LV_ARR_GD(i).v_applnRef_n	||'<{||}>'||
						trim(LV_ARR_GD(i).v_GDTy_c)	||'<{||}>'||
						LV_ARR_GD(i).v_agtDeclrAc_n	||'<{||}>'||
						LV_ARR_GD(i).v_GDV_n	||'<{||}>'||
						LV_ARR_GD(i).v_contactPers_m	||'<{||}>'||
						LV_ARR_GD(i).v_offTel_n	||'<{||}>'||
						LV_ARR_GD(i).v_homeTel_n	||'<{||}>'||
						LV_ARR_GD(i).v_mobile_n	||'<{||}>'||
						LV_ARR_GD(i).v_fax_n	||'<{||}>'||
						LV_ARR_GD(i).v_emailAddr_x	||'<{||}>'||
						LV_ARR_GD(i).v_vslGT_q	||'<{||}>'||
						LV_ARR_GD(i).v_newVslGT_q	||'<{||}>'||
						LV_ARR_GD(i).v_arrDeclr_dt	||'<{||}>'||
						LV_ARR_GD(i).v_ctryArrFr_c	||'<{||}>'||
						LV_ARR_GD(i).v_lastPort_c	||'<{||}>'||
						LV_ARR_GD(i).v_pax_q	||'<{||}>'||
						LV_ARR_GD(i).v_crew_q	||'<{||}>'||
						LV_ARR_GD(i).v_cgo_q	||'<{||}>'||
						LV_ARR_GD(i).v_mstrOnArr_x	||'<{||}>'||
						LV_ARR_GD(i).v_locnOnArr_c	||'<{||}>'||
						LV_ARR_GD(i).v_arrLocnOnArr_m	||'<{||}>'||
						LV_ARR_GD(i).v_gridRef_n	||'<{||}>'||
						LV_ARR_GD(i).v_motherGDV_n	||'<{||}>'||
						LV_ARR_GD(i).v_bunkr_q	||'<{||}>'||
						LV_ARR_GD(i).v_bunkrGr_c	||'<{||}>'||
						LV_ARR_GD(i).v_cst_n	||'<{||}>'||
						LV_ARR_GD(i).v_chartererNat_c	||'<{||}>'||
						LV_ARR_GD(i).v_sln_c	||'<{||}>'||
						LV_ARR_GD(i).v_callRecSt_c	||'<{||}>'||
						LV_ARR_GD(i).v_RTA_dt	||'<{||}>'||
						LV_ARR_GD(i).v_pccExempnRsn_x	||'<{||}>'||
						LV_ARR_GD(i).v_officialGDV_n	||'<{||}>'||
						LV_ARR_GD(i).v_arrgdSt_c	||'<{||}>'||
						LV_ARR_GD(i).v_apprBy_m	||'<{||}>'||
						LV_ARR_GD(i).v_apprOn_dt	||'<{||}>'||
						LV_ARR_GD(i).v_rem_x	||'<{||}>'||
						LV_ARR_GD(i).v_intlRem_x	||'<{||}>'||
						LV_ARR_GD(i).v_addrFlr_n	||'<{||}>'||
						LV_ARR_GD(i).v_addrUnit_n	||'<{||}>'||
						LV_ARR_GD(i).v_addrPostalcode_n	||'<{||}>'||
						LV_ARR_GD(i).v_applcnt_m	||'<{||}>'||
						LV_ARR_GD(i).v_addrBldg_m	||'<{||}>'||
						LV_ARR_GD(i).v_FIN_n	||'<{||}>'||
						LV_ARR_GD(i).v_NRIC_n	||'<{||}>'||
						LV_ARR_GD(i).v_passpt_n	||'<{||}>'||
						LV_ARR_GD(i).v_addrSt_m	||'<{||}>'||
						'0'	||'<{||}>'||
						0	||'<{||}>'||
						LV_ARR_GD(i).v_crtOn_dt	||'<{||}>'||
						LV_ARR_GD(i).v_crtBy_m	||'<{||}>'||
						LV_ARR_GD(i).v_updOn_dt	||'<{||}>'||
						LV_ARR_GD(i).v_updBy_m	
						 ,
						 'T'
						 );

				DELETE FROM VESSEL_CALL WHERE VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT; -- NEED TO CHECK 

				DELETE FROM APPLICATION_SUBMISSION WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;-- NEED TO CHECK


				CONTINUE;        

			END ;

			/***************************************************************************************************************************************

			insertion into SI_ARR_DEP_GD2 STARTS
			*******************************************************************************************************************************************/

			BEGIN 

				INSERT INTO SI_ARR_DEP_GD2
							(GDV_N,
							MSW_APPLN_REF_ID_X,
							VSL_CALL_ID_N,
							MSW_VSL_ID_N,
							ETA_DT,
							ETD_DT
							)
					VALUES(
							LV_ARR_GD(i).v_GDV_n,
							V_MSW_APPLN_REF_ID_X,
							V_MSW_VSL_CALL_ID_OUT,
							LV_ARR_GD(i).V_MSW_VSL_ID_N,
							LV_ARR_GD(i).V_APPLN_ARR_DCL_DT,
                            LV_ARR_GD(i).V_APPLN_DEP_DCL_DT
							);




				EXCEPTION     -- EXCEPTION OF ARRPOC
				WHEN OTHERS THEN 
					  V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


						PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
				  ( 'SI_ARR_DEP_GD2',
				  'PROC_2_ARRGD_PURCAL',
				'GDV_N:'||LV_ARR_GD(i).v_GDV_n	||'<{||}>'||
				'VSL_CALL_ID_N:'||V_MSW_APPLN_REF_ID_X	||'<{||}>'||
				 'PURPCALL_C:'||V_MSW_VSL_CALL_ID_OUT||'<{||}>'||
				 'MSW_VSL_ID_N:'||LV_ARR_GD(i).V_MSW_VSL_ID_N ||'<{||}>'||
				 'ETA_DT :'||LV_ARR_GD(i).v_arrDeclr_dt	||'<{||}>'||
				 'ETD_DT	:'||NULL	
				 ,
				'ERROR',
				PV_RUN_ID,
				V_SQLERRM,
				LV_ARR_GD(i).v_GDV_n	||'<{||}>'||
				V_MSW_APPLN_REF_ID_X	||'<{||}>'||
				V_MSW_VSL_CALL_ID_OUT 	||'<{||}>'||
				LV_ARR_GD(i).V_MSW_VSL_ID_N 	||'<{||}>'||
				LV_ARR_GD(i).v_arrDeclr_dt	
				 ,
				 'T'
				 ); 

				END;    


			/****************************************************************************************************************************************

			insertion into SI_ARR_DEP_GD2 ENDS
			*******************************************************************************************************************************************/


			/***************************************************************************************************************************************

			insertion into ARR_POC STARTS
			*******************************************************************************************************************************************/

			BEGIN  -- begin of arrpoc

				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL1_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'CARGO OPERATION',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'CARGO OPERATION' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'CARGO OPERATION' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'|| 0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL2_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Embarking/disembarking Passenger',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Embarking/disembarking Passenger' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'CARGO OPERATION' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL3_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Taking Bunkers',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Embarking/disembarking Passenger' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'Taking Bunkers' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL4_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Taking Suppliers',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Taking Suppliers' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'Taking Bunkers' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL5_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Changing Crew',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Changing Crew' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'Taking Bunkers' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;

				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL6_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Repair/Docking/Outfitting',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Changing Crew' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'Repair/Docking/Outfitting' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL7_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															'Offshore Vessel',
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Changing Crew' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'Offshore Vessel' ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;


				BEGIN 

					IF TRIM(UPPER(LV_ARR_GD(I).V_PURPCALL9_I)) =  'Y'
					THEN INSERT INTO ARRIVAL_GD_PURPOSE_OF_CALL 
														(  ARR_GD_PURP_OF_CALL_ID_N,
														   APPLN_REF_N, 
														   PURPCALL_C,                       
														   OTHERS_PURPOSE_X,                    
														   PURP_CALL_OTHERS_TOW_X,                    
														   PURPCALL_OTHERS_TOW_VSL_M,                   
														   PURPCALL_OTHERS_UND_TOW_VSL_M,                   
														   LOCK_VER_N,                   
														   DELETED_I)                    
													VALUES  (ARR_GD_POC_SEQ.NEXTVAL,
															ARR_GD_APPLN_SEQ.CURRVAL,
															Decode(LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X,'SI','Shipped in as Cargo','SO','Shipped out as Cargo','TO','Towing','RP',' Recreation/Pleasure','OT','Other'),
															LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,NULL),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE(LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOU', LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M,NULL))),
															DECODE(LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X,'TO',
															(DECODE( LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X,'TOW',LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M,NULL))),
															0,
															0
														);
					END IF;


					EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
							  'PROC_2_ARRGD_PURCAL',
							'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							'PURP_CALL_OTHERS_TOW_X:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							'PURPCALL_OTHERS_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							'PURPCALL_OTHERS_UND_TOW_VSL_M:'||LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0
							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							ARR_GD_POC_SEQ.CURRVAL ||'<{||}>'||
							ARR_GD_APPLN_SEQ.CURRVAL ||'<{||}>'||
							LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M ||'<{||}>'||
							LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0	
							 ,
							 'T'
							 );

				END;

				EXCEPTION     -- EXCEPTION OF ARRPOC
				WHEN OTHERS THEN 
					  V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


						PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
				  ( 'ARRIVAL_GD_PURPOSE_OF_CALL',
				  'PROC_2_ARRGD_PURCAL',
				'ARR_GD_PURP_OF_CALL_ID_N:'||ARR_GD_POC_SEQ.CURRVAL	||'<{||}>'||
				'APPLN_REF_N:'||ARR_GD_APPLN_SEQ.CURRVAL	||'<{||}>'||
				 'PURPCALL_C:'||LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
				 'OTHERS_PURPOSE_X:'||LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X ||'<{||}>'||
				 'PURP_CALL_OTHERS_TOW_X :'||LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X	||'<{||}>'||
				 'PURPCALL_OTHERS_TOW_VSL_M	:'||LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M	||'<{||}>'||
				 'PURPCALL_OTHERS_UND_TOW_VSL_M	:'|| LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M	||'<{||}>'||
				 'LOCK_VER_N:'||	0	||'<{||}>'||
				 'DELETED_I:'|| 0	
				 ,
				'ERROR',
				PV_RUN_ID,
				V_SQLERRM,
				ARR_GD_POC_SEQ.CURRVAL	||'<{||}>'||
				ARR_GD_APPLN_SEQ.CURRVAL	||'<{||}>'||
				LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X 	||'<{||}>'||
				LV_ARR_GD(i).V_ARRPURPCALLOTHERS_X 	||'<{||}>'||
				LV_ARR_GD(I).V_PURPCALLOTHERSTOW_X	||'<{||}>'||
				LV_ARR_GD(I).V_PURPCALLOTHERSTOWVSL_M	||'<{||}>'||
				LV_ARR_GD(I).V_PURPCALLOTHERSUNDTOWVSL_M	||'<{||}>'||
				0	||'<{||}>'||0	
				 ,
				 'T'
				 );   

				CONTINUE;

				END;    -- END OF ARRPOC


			/****************************************************************************************************************************************

			insertion into ARR_POC ENDS
			*******************************************************************************************************************************************/

		END IF ; -- end if of vlag_out is null 	

	END LOOP;    -- end loop of LV_ARR_GD.FIRST..LV_ARR_GD.LAST   

	END LOOP;   -- end loop of  cursor CUR_ARR_GD

CLOSE CUR_ARR_GD;  -- close the cursor 

COMMIT;   -- commit for insertion  on all tables .

/***************************************************************************************************
Recon starts
*********************************************************************************************************/
/***********************************************************************************************************
Reconciling the count of staging table  GD Arrival  and SI  table of GD Arrival starts
*************************************************************************************************************/

	SELECT COUNT(*)
	INTO    V_SRC_COUNT
	FROM    st_cv_gdappln appln
	where   appln.gdty_c in ('A' ,'C');


	SELECT COUNT(*)
	INTO V_TGT_COUNT
	FROM SI_ARR_GD;

	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_GDAPPLN', V_SRC_COUNT, 'SI_ARR_GD', V_TGT_COUNT,'N');

/***********************************************************************************************************
Reconciling the count of staging table  GD Arrival  and target table of GD Arrival  ends
*************************************************************************************************************/

/***********************************************************************************************************
Reconciling the count of source intermediate GD Arrival  and target table of GD Arrival 
*************************************************************************************************************/



	SELECT COUNT(*)
	INTO V_SRC_COUNT
	FROM SI_ARR_GD;


    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM ARRIVAL_GD_APPLICATION;

	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_ARR_GD', V_SRC_COUNT, 'ARRIVAL_GD_APPLICATION', V_TGT_COUNT,'N');

	 IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_APPLICATION', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO ARRIVAL_GD_APPLICATION TABLE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

	ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_APPLICATION', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_APPLICATION TABLE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


	ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_APPLICATION', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_APPLICATION TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

	ELSE 

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_APPLICATION', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_APPLICATION TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

	END IF;

/***********************************************************************************************************
Reconcilation of source intermediate GD Arrival  and target table of GD Arrival  ends
*************************************************************************************************************/



/***********************************************************************************************************
Reconciling the count of staging table  GD Arrival  and target table of GD Arrival starts
*************************************************************************************************************/

	SELECT COUNT(*)
	INTO    V_SRC_COUNT
	FROM    st_cv_gdappln appln
	where   appln.gdty_c in ('A' ,'C');


     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM ARRIVAL_GD_APPLICATION;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_GDAPPLN', V_SRC_COUNT, 'ARRIVAL_GD_APPLICATION', V_TGT_COUNT,'Y');	  


/***********************************************************************************************************
Reconciling the count of staging table  GD Arrival  and target table of GD Arrival  ends
*************************************************************************************************************/

/***********************************************************************************************************
Reconciling the count of number of 'Y's' in source intermediate  and target table of arrival_gd_purpose_of_call starts
*************************************************************************************************************/



     SELECT SUM (CNT) INTO v_src_count  FROM (
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL1_I ='Y' )
     UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL2_I ='Y' )
     UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL3_I ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL4_I ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL5_I ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL6_I ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL7_I ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_ARR_GD WHERE PURPCALL9_I ='Y')
    );

	SELECT COUNT(*)  INTO V_TGT_COUNT FROM ARRIVAL_GD_PURPOSE_OF_CALL;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('NO:OF YS IN SI_ARR_GD', V_SRC_COUNT, 'ARRIVAL_GD_PURPOSE_OF_CALL', V_TGT_COUNT,'Y');	  



    IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO ARRIVAL_GD_PURPOSE_OF_CALL TABLE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

        ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_PURPOSE_OF_CALL TABLE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


		ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_PURPOSE_OF_CALL TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

        ELSE 

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO ARRIVAL_GD_PURPOSE_OF_CALL TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

	END IF;

/***********************************************************************************************************
Reconciling the count of number of 'Y's' in source intermediate  and target table of arrival_gd_purpose_of_call ends
*************************************************************************************************************/

/***********************************************************************************************************
RECONCILATION OF ARRIVAL GD APPLICATION   AND APPLICATION SUBMISSION  STARTS 
*************************************************************************************************************/


	SELECT COUNT(*) INTO V_SRC_COUNT FROM ARRIVAL_GD_APPLICATION ;

	SELECT COUNT(*)INTO V_TGT_COUNT  FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C = 'AGD';


	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ARRIVAL_GD_APPLICATION', V_SRC_COUNT, 'APPLICATION_SUBMISSION', V_TGT_COUNT,'Y');	  




	IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('APPLICATION_SUBMISSION_AGD', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO APPLICATION_SUBMISSION TABLE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

        ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('APPLICATION_SUBMISSION_AGD', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO APPLICATION_SUBMISSION TABLE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


		ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('APPLICATION_SUBMISSION_AGD', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO APPLICATION_SUBMISSION TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

        ELSE 

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('APPLICATION_SUBMISSION_AGD', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO APPLICATION_SUBMISSION TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

	END IF;


/***********************************************************************************************************
RECONCILATION OF ARRIVAL GD APPLICATION   AND APPLICATION SUBMISSION  ENDS 
*************************************************************************************************************/


/***********************************************************************************************************
RECONCILATION OF ARR GD APPLICATION   AND VESSEL CALL  STARTS 
*************************************************************************************************************/

	SELECT COUNT(*) INTO V_SRC_COUNT FROM ARRIVAL_GD_APPLICATION ;
	SELECT COUNT(*)INTO V_TGT_COUNT  FROM VESSEL_CALL where vsl_call_id_n in (SELECT vsl_call_id_n FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C = 'AGD') ;



	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ARRIVAL_GD_APPLICATION', V_SRC_COUNT, 'VESSEL_CALL', V_TGT_COUNT,'Y');	  

    IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_CALL TABLE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

        ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CALL TABLE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


		ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CALL TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

        ELSE 

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_ARRGD_PURCAL', 
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CALL TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

END IF;




/***********************************************************************************************************
RECONCILATION OF ARR GD APPLICATION   AND VESSELCALL  ENDS 
*************************************************************************************************************/




EXCEPTION  --OUTER EXCEPTION 

WHEN OTHERS THEN 


        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_APPLICATION','PROC_2_ARRGD_PURCAL', V_SQLERRM, 'FAIL',null,null,null,'T');
END;
/