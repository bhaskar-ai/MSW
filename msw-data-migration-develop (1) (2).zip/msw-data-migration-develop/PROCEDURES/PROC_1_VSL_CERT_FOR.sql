create or replace PROCEDURE proc_1_vsl_cert_for(P_count  out number,
                                                PV_RUN_ID IN NUMBER) IS

  
/***********************************************************************************************************
Declaring variables for Main table 
*************************************************************************************************************/
CURSOR cur_ST_CV_vslCert IS
  SELECT
        v.MSW_VSL_ID_N,
        vc.certTy_c,
        vc.issAuthyCtry_c,
        vc.issgcl_c,
        vc.issd_dt,
        vc.due_dt,
        vc.docidatth_n,
        vc.certst_c,
        vc.issgcl_m,
        vc.crtOn_dt,
        vc.crtBy_m,
        vc.updOn_dt,
        vc.updBy_m,
	    vc.lastApprBy_m,
        vc.intlRem_x

    FROM
        ST_CV_vslCert vc , vessel v 
    where
         vc.vslRecID_n=v.VSL_REC_ID_N;




-- defining the 'record type'  type to serve as the datatype of collection variable  of main table 

    TYPE rec_vslcrt_m IS RECORD (
       v_m_vslRecID_n          vessel.MSW_VSL_ID_N%type ,
         v_m_certTy_c          ST_CV_vslCert.certTy_c%type ,
        v_m_issAuthyCtry       ST_CV_vslCert.issAuthyCtry_c%type ,
        v_m_issgcl_c           ST_CV_vslCert.issgcl_c%type ,
        v_m_issd_dt            ST_CV_vslCert.issd_dt%type ,
        v_m_due_dt             ST_CV_vslCert.due_dt%type ,
        v_m_docidatth_n        ST_CV_vslCert.docidatth_n%type ,
        v_m_certst_c           ST_CV_vslCert.certst_c%type ,
        v_m_issgcl_m           ST_CV_vslCert.issgcl_m%type, 
        v_m_crtOn_dt             ST_CV_vslCert.crtOn_dt%type,
        v_m_crtBy_m               ST_CV_vslCert.crtBy_m%type,
        v_m_updOn_dt              ST_CV_vslCert.updOn_dt%type,
        v_m_updBy_m              ST_CV_vslCert.updBy_m%type,
	    v_m_lastApprBy_m        ST_CV_vslCert.lastApprBy_m%type,
        v_m_intlRem_x          ST_CV_vslCert.intlRem_x%type

    );

V_exp_rows1            NUMBER(7,0);
V_exp_rows2            VARCHAR2(4 BYTE);
V_exp_rows3            CHAR(2 BYTE);
V_exp_rows4            VARCHAR2(8 BYTE);
V_exp_rows5            DATE;
V_exp_rows6            DATE;
V_exp_rows7            NUMBER(10,0);
V_exp_rows8            CHAR(1 BYTE);
V_exp_rows9            VARCHAR2(80 BYTE);
V_exp_rows             varchar2(4000);

    TYPE type_vslcrt_m IS TABLE OF rec_vslcrt_m;

    lv_m_vsl_cert        type_vslcrt_m;
    v_m_src_count        INTEGER;
    v_m_tgt_count        INTEGER;
    v_m_err_code         NUMBER;
    v_m_err_msg          VARCHAR2(200);
    v_m_sqlerrm          VARCHAR2(2500);
    v_m_blkexptn_count   NUMBER(20, 0);
    v_m_blkexptn_desc    varchar2(3000);
    v_m_certst_c            varchar2(100);



/***********************************************************************************************************
Declaring variables for intermeduiate table 
*************************************************************************************************************/

    CURSOR cur_vessel_certificate IS
    SELECT
        MSW_VSL_ID_N,
        certTy_c,
        issAuthyCtry_c,
        issgcl_c,
        issd_dt,
        due_dt,
        docidatth_n,
        certst_c,
        issgcl_m,
        CRTON_DT,
        CRTBY_M,
        UPDON_DT,
        UPDBY_M,
        LASTAPPRBY_M,
        INTLREM_X
    FROM
        SI_cv_vslcert;

  -- defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table 

    TYPE rec_vslcrt IS RECORD (
        v_vslRecID_n       SI_cv_vslcert.MSW_VSL_ID_N%type,   
        v_certTy_c         SI_cv_vslcert.certTy_c%type,   
        v_issAuthyCtry_c   SI_cv_vslcert.issAuthyCtry_c%type,   
        v_issgcl_c         SI_cv_vslcert.issgcl_c%type,   
        v_issd_dt          SI_cv_vslcert.issd_dt%type,   
        v_due_dt           SI_cv_vslcert.due_dt%type,   
        v_docidatth_n      SI_cv_vslcert.docidatth_n%type,   
        v_certst_c         SI_cv_vslcert.certst_c%type,   
        v_issgcl_m         SI_cv_vslcert.issgcl_m%type,
        v_CRTON_DT         SI_cv_vslcert.CRTON_DT%type,
        v_CRTBY_M          SI_cv_vslcert.CRTBY_M%type,
        v_UPDON_DT         SI_cv_vslcert.UPDON_DT%type,
        v_UPDBY_M          SI_cv_vslcert.UPDBY_M%type,
        v_LASTAPPRBY_M     SI_cv_vslcert.LASTAPPRBY_M%type,
        v_INTLREM_X        SI_cv_vslcert.INTLREM_X%type


    );

    --assigning the record type data to colelction variable for intermeditae table 
    TYPE type_vslcrt IS
        TABLE OF rec_vslcrt;

    lv_vsl_cert        type_vslcrt;
    v_sq_vslCrtId      number;
    v_src_count        INTEGER;
    v_tgt_count        INTEGER;
    v_err_code         NUMBER;
    v_err_msg          VARCHAR2(2000);
    v_sqlerrm          VARCHAR2(2500);
    v_blkexptn_count   NUMBER(20, 0);
    v_blkexptn_desc    varchar2(3000);
    v_m_sqlerrm123        VARCHAR2(2000);
BEGIN 

/***********************************************************************************************************
procedure name : proc_1_vsl_cert
Created By     : C.N.Bhaskar
Date           : 26-mar-2019
Purpose        : Inserting  the data from ST_CV_vslCert (main table) to SI_CV_vslCert(Intermediate table) to VESSEL_CERTIFICATE(Target Table)
Modified by    :Bhaskar
Modified date  :19-APR-19 (Mapping sheet change)

*************************************************************************************************************/


/***********************************************************************************************************
INSERTING DATA FROM MAIN TABLE INTO INTERMEDIATE TABLE
*************************************************************************************************************/


   --opening the cursor cur_ST_CV_vslCert to initiate the process of migrating the data from main table into intermediate table 

    OPEN cur_ST_CV_vslCert;

       pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                     'PROC_1_VSL_CERT_FOR',
                                                     'INSERTION INTO SI_VSL_CERT STARTS' , 
                                                     'START',
                                                      PV_RUN_ID,
                                                      null,
                                                      null,
                                                      'T');

       loop


   --loading the data of cursor into the collection variable in the batches of the value specified in limit
             FETCH cur_ST_CV_vslCert BULK COLLECT INTO lv_m_vsl_cert LIMIT 5000;

               EXIT WHEN lv_m_vsl_cert.count = 0;
   -- inserting the data from the collection variable into the intermediate table in the batche value specified in limit     
                 for i IN lv_m_vsl_cert.first..lv_m_vsl_cert.last 
                   loop

                     begin

                        INSERT INTO si_cv_vslcert  (   MSW_VSL_ID_N,
                                                        CERTTY_C,
                                                       ISSAUTHYCTRY_C,
                                                          ISSGCL_C,
                                                           ISSD_DT,
                                                            DUE_DT,
                                                       DOCIDATTH_N,
                                                          CERTST_C,
                                                          ISSGCL_M,
                                                          CRTON_DT,
                                                            CRTBY_M,
                                                            UPDON_DT,
                                                              UPDBY_M,
                                                         LASTAPPRBY_M,
                                                             INTLREM_X

                                                          ) 
                           VALUES (lv_m_vsl_cert(i).v_m_vslRecID_n,
                                     lv_m_vsl_cert(i).v_m_certTy_c,
                                 lv_m_vsl_cert(i).v_m_issAuthyCtry,
                                     lv_m_vsl_cert(i).v_m_issgcl_c,
                                      lv_m_vsl_cert(i).v_m_issd_dt,
                                       lv_m_vsl_cert(i).v_m_due_dt,
                                  lv_m_vsl_cert(i).v_m_docidatth_n,
                                     lv_m_vsl_cert(i).v_m_certst_c,
                                      lv_m_vsl_cert(i).v_m_issgcl_m,
                                      lv_m_vsl_cert(i).v_m_crtOn_dt,
                                      lv_m_vsl_cert(i).v_m_crtBy_m,
                                      lv_m_vsl_cert(i).v_m_updOn_dt,
                                      lv_m_vsl_cert(i).v_m_updBy_m,
                                      lv_m_vsl_cert(i).v_m_lastApprBy_m,
                                      lv_m_vsl_cert(i).v_m_intlRem_x

                                                               );


    -- defining the inner exception to prevent the control breaking out of loop abruptly in case of failure 
          EXCEPTION

             WHEN OTHERS THEN


                v_m_err_code := sqlcode;

                v_m_err_msg := substr(sqlerrm, 1, 200);

                v_m_sqlerrm := v_m_err_code || v_m_err_msg;





      pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                     'PROC_1_VSL_CERT_FOR',
                                                      'MSW_VSL_ID_N:'||lv_m_vsl_cert(i).v_m_vslRecID_n||'*|'||
                                                      'CERTTY_C:'||lv_m_vsl_cert(i).v_m_certTy_c||'*|'||
                                                      'ISSAUTHYCTRY_C:'||lv_m_vsl_cert(i).v_m_issAuthyCtry||'*|'||
                                                      'ISSGCL_C:'|| lv_m_vsl_cert(i).v_m_issgcl_c||'*|'||
                                                      'ISSD_DT:'||lv_m_vsl_cert(i).v_m_issd_dt||'*|'||
                                                      'DUE_DT:'||lv_m_vsl_cert(i).v_m_due_dt||'*|'||
                                                      'DOCIDATTH_N:'||lv_m_vsl_cert(i).v_m_docidatth_n||'*|'||
                                                      'CERTST_C:'||lv_m_vsl_cert(i).v_m_certst_c||'*|'||
                                                      'ISSGCL_M:'||lv_m_vsl_cert(i).v_m_issgcl_m||'*|'||
                                                      'CRTON_DT:'||lv_m_vsl_cert(i).v_m_crtOn_dt||'*|'||
                                                      'CRTBY_M:'||lv_m_vsl_cert(i).v_m_crtBy_m||'*|'||
                                                      'UPDON_DT:'||lv_m_vsl_cert(i).v_m_updOn_dt||'*|'||
                                                      'UPDBY_M:'||lv_m_vsl_cert(i).v_m_updBy_m||'*|'||
                                                      'LASTAPPRBY_M:'||lv_m_vsl_cert(i).v_m_lastApprBy_m||'*|'||
                                                      'INTLREM_X:'||lv_m_vsl_cert(i).v_m_intlRem_x,
                                                     'ERROR',
                                                     PV_RUN_ID,
                                                     v_m_err_msg, 
                                                      lv_m_vsl_cert(i).v_m_vslRecID_n ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_certTy_c ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_issAuthyCtry ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_issgcl_c ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_issd_dt ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_due_dt ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_docidatth_n ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_certst_c ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_issgcl_m ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_crtOn_dt ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_crtBy_m ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_updOn_dt ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_updBy_m ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_lastApprBy_m ||'*|'||
                                                      lv_m_vsl_cert(i).v_m_intlRem_x,
                                                      'B');



             end; -- inner begin
 --find the count of main table(source table) to compare the count with the that of intermediate table for reconcialation purpose
         end loop;  -- for loop


        END LOOP;-- cursor

        commit;

        close cur_ST_CV_vslCert;



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel starts 
*************************************************************************************************************/



begin 

for i in (
select 
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT		       
from ST_CV_vslCert 
where vslRecID_n not in (  select VSL_REC_ID_N from vessel)

)  
loop


 pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                'PROC_1_VSL_CERT_FOR',
                                                'UNCOMMON RECORDS  of ST_CV_vslCert because of JOIN CONDITION FAILURE between ST_CV_vslCert AND VESSEL ',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                   i.CERTTY_C	||'*|'|| i.VSLRECID_N	||'*|'|| i.ISSD_DT	||'*|'||  i.DUE_DT	||'*|'||   i.REGST_C	||'*|'|| i.ISSDBY_C	||'*|'|| 
                                                   i.ISSAUTHYCTRY_C	||'*|'|| i.ISSGCL_C	||'*|'|| i.PERSALLW_Q	||'*|'|| i.SOPEPSMPEPONBD_I	||'*|'|| i.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   i.INCOMPLYMARPOLREGU21_I	||'*|'|| i.BCCAPPLN_N	||'*|'|| 
                                                   i.BCCAPPLNST_C	||'*|'|| i.BCCISSD_DT	||'*|'|| i.INSURTY_C	||'*|'|| i.INSURVALTILL_DT	||'*|'|| i.DOCIDATTH_N	||'*|'|| 
                                                   i.CERTST_C	||'*|'||i.LASTAPPRBY_N	||'*|'|| i.LASTAPPRBY_M	||'*|'|| i.CRTBY_N	||'*|'|| i.CRTBY_M	||'*|'|| i.CRTBYDEPT_M	||'*|'||
                                                   i.CRTON_DT	||'*|'|| i.UPDBY_N	||'*|'|| i.UPDBY_M	||'*|'|| i.UPDBYDEPT_M	||'*|'|| i.UPDON_DT	||'*|'|| i.INTLREM_X	||'*|'|| 
                                                   i.ISSGCL_M	||'*|'|| i.INCOMPLYMARPOLREGU20_DT	||'*|'|| i.INCOMPLYMARPOLREGU21_DT    ,
                                               'D');



end loop;


exception  when others then null;
end;




/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel ends 
*************************************************************************************************************/



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN vessel  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel starts 
*************************************************************************************************************/









begin
for i  in (
select 
MSW_VSL_ID_N	,
VSL_REC_ID_N	,
VSL_M	,
OFFICIAL_N	,
VSL_FLAG_C	,
VSL_TYPE_ID_N	,
CRAFT_TYPE_ID_N	,
VSL_DWT_N	,
ST_C	,
VSL_CRAFT_LIC_N	,
VSL_ATTAINABLE_HGT_Q	,
VSL_YR_BLT_N	,
PORT_OF_REGY_C	,
PORT_N	,
VSL_LEN_Q	,
LOA_Q	,
VSL_DEPTH_Q	,
VSL_BRE_Q	,
MECHANIC_PROPEL_I	,
VSL_MMSI_N	,
LOCK_VER_N	,
CRT_ON_DT	,
CRT_BY_X	,
UPT_ON_DT	,
UPT_BY_X	,
VSL_GT_Q	,
VSL_NT_Q	,
VSL_CALL_SIGN_N	,
VSL_IMO_N	,
VSL_OWNR	,
DELETED_I	,
DELIVERY_DT	,
BOW_BRIDGE	,
BOW_THRUSTER	,
STERN_THRUSTER	,
DBL_HULL_CONSTRUCT_I	,
APPR_FOR_SEA_TRIAL_I	,
LAUNCH_ON_DT	,
MERGE_FR_TO_VSL_REC_ID	,
BARTER_TRADE_I	,
BARE_BOAT_CHARTER_OUT_I	,
TRANSIT_I	,
UNOFFICIAL_VSL_M	,
UNOFFCIAL_VSL_CALL_SIGN	,
UNOFFICIAL_VSL_TY_C	,
UNOFFICIAL_VSL_FLAG_C	,
UNOFFICIAL_VSL_GT	,
GT_FROM_E_PAN_Q	,
GT_FROM_E_PAN_DT	,
BUILDER_M	,
OWNER_CTRY_C	,
VSL_BUILT_PLACE_C	

from vessel   where VSL_REC_ID_N not in  (select  VSLRECID_N  from  ST_CV_vslCert))


loop

pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                'PROC_1_VSL_CERT_FOR',
                                                'UNCOMMON RECORDS  of VESSEL because of JOIN CONDITION FAILURE between ST_CV_vslCert AND VESSEL ',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                  i.MSW_VSL_ID_N	||'*|'||
i.VSL_REC_ID_N	||'*|'||
i.VSL_M	||'*|'||
i.OFFICIAL_N	||'*|'||
i.VSL_FLAG_C	||'*|'||
i.VSL_TYPE_ID_N	||'*|'||
i.CRAFT_TYPE_ID_N	||'*|'||
i.VSL_DWT_N	||'*|'||
i.ST_C	||'*|'||
i.VSL_CRAFT_LIC_N	||'*|'||
i.VSL_ATTAINABLE_HGT_Q	||'*|'||
i.VSL_YR_BLT_N	||'*|'||
i.PORT_OF_REGY_C	||'*|'||
i.PORT_N	||'*|'||
i.VSL_LEN_Q	||'*|'||
i.LOA_Q	||'*|'||
i.VSL_DEPTH_Q	||'*|'||
i.VSL_BRE_Q	||'*|'||
i.MECHANIC_PROPEL_I	||'*|'||
i.VSL_MMSI_N	||'*|'||
i.LOCK_VER_N	||'*|'||
i.CRT_ON_DT	||'*|'||
i.CRT_BY_X	||'*|'||
i.UPT_ON_DT	||'*|'||
i.UPT_BY_X	||'*|'||
i.VSL_GT_Q	||'*|'||
i.VSL_NT_Q	||'*|'||
i.VSL_CALL_SIGN_N	||'*|'||
i.VSL_IMO_N	||'*|'||
i.VSL_OWNR	||'*|'||
i.DELETED_I	||'*|'||
i.DELIVERY_DT	||'*|'||
i.BOW_BRIDGE	||'*|'||
i.BOW_THRUSTER	||'*|'||
i.STERN_THRUSTER	||'*|'||
i.DBL_HULL_CONSTRUCT_I	||'*|'||
i.APPR_FOR_SEA_TRIAL_I	||'*|'||
i.LAUNCH_ON_DT	||'*|'||
i.MERGE_FR_TO_VSL_REC_ID	||'*|'||
i.BARTER_TRADE_I	||'*|'||
i.BARE_BOAT_CHARTER_OUT_I	||'*|'||
i.TRANSIT_I	||'*|'||
i.UNOFFICIAL_VSL_M	||'*|'||
i.UNOFFCIAL_VSL_CALL_SIGN	||'*|'||
i.UNOFFICIAL_VSL_TY_C	||'*|'||
i.UNOFFICIAL_VSL_FLAG_C	||'*|'||
i.UNOFFICIAL_VSL_GT	||'*|'||
i.GT_FROM_E_PAN_Q	||'*|'||
i.GT_FROM_E_PAN_DT	||'*|'||
i.BUILDER_M	||'*|'||
i.OWNER_CTRY_C	||'*|'||
i.VSL_BUILT_PLACE_C	   ,
 'D');



end loop;




exception

 when others  then null;

end;



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN vessel  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel ends 
*************************************************************************************************************/








 /*********************************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel   ENDS
***********************************************************************************************************************/

      --Reconcialation  
         SELECT COUNT(*)
            INTO v_m_src_count
            FROM ST_CV_vslCert;


            SELECT COUNT(*)
            INTO v_m_tgt_count
            FROM si_cv_vslcert;



        pkg_datamigration_generic.proc_migration_recon('ST_CV_vslCert', v_m_src_count, 'si_cv_vslcert', v_m_tgt_count,'N');



        if (v_m_tgt_count =  v_m_src_count ) and v_m_src_count <>  0  and v_m_tgt_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                        'proc_1_vsl_cert_for', 
                                                        v_m_tgt_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into si_cv_vslcert table' ,
                                                        'SUCCESS',
                                                        null,
                                                        null,
                                                        null,
                                                        null);

        elsif v_m_tgt_count  <> v_m_src_count and v_m_tgt_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                      'proc_1_vsl_cert_for', 
                                                      v_m_tgt_count ||' out of ' ||v_m_src_count ||' rows have been inserted into si_cv_vslcert table' ,
                                                           'PARTIALLY SUCCESSFULL',
                                                           null,
                                                              null,
                                                                null,
                                                                null);


    elsif (v_m_tgt_count  <> v_m_src_count or v_m_tgt_count  = v_m_src_count ) and (v_m_tgt_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
        'proc_1_vsl_cert_for', 
 v_m_tgt_count ||' out of ' ||v_m_src_count ||' rows have been inserted into si_cv_vslcert table' ,
        'FAIL',
        null,
        null,
        null,
        null);

        else 

     pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                    'proc_1_vsl_cert_for', 
                                                     v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into vessel_certificate table' ,
                                                     'AMBIGIOUS',
                                                         null,
                                                           null,
                                                              null,
                                                                 null);

end if;



   --opening the cursor cur_vessel_certificate to initiate the process of migrating the data from intermediate table into target table 

/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/

    OPEN cur_vessel_certificate;

           pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                           'proc_1_vsl_cert_for',
                                                           ' insertion into vessel_certificate starts ' ,
                                                           'START',   
                                                           PV_RUN_ID,
                                                              null,
                                                              null,
                                                               'T');

       loop


   --loading the data of cursor into the collection variable in the batches of the value specified in limit
         --  v_sq_vslCrtId := seq_vsl_cert.nextval;

             FETCH cur_vessel_certificate BULK COLLECT INTO lv_vsl_cert LIMIT 5000;

               EXIT WHEN lv_vsl_cert.count = 0;
   -- inserting the data from the collection variable into the target table in the batches of the value specified in limit     
                 FOR i IN lv_vsl_cert.first..lv_vsl_cert.last 
                  loop

                    begin


                       INSERT INTO vessel_certificate (  vsl_Cert_Id_n,
                                                         MSW_VSL_ID_N,
                                                         cert_Ty_c,
                                                         iss_authy_ctry_c,
                                                         issg_cl_c,
                                                         issd_dt,
                                                         due_dt,
                                                         doc_id_atth_n,
                                                         st_c ,
                                                         issg_cl_m   ,
                                                         lock_ver_n  ,
                                                         crt_on_dt   ,
                                                         crt_by_x    ,
                                                         upt_on_dt,
                                                         upt_by_x,
                                                         deleted_i,
                                                         LAST_APPROVED_BY_M,
                                                         INTL_REM_X) 
                       VALUES (seq_vsl_cert.nextval,
                               lv_vsl_cert(i).v_vslRecID_n,
                               lv_vsl_cert(i).v_certTy_c,                  
                               lv_vsl_cert(i).v_issAuthyCtry_c,
                               lv_vsl_cert(i).v_issgcl_c,
                               lv_vsl_cert(i).v_issd_dt,
                               lv_vsl_cert(i).v_due_dt,
                               lv_vsl_cert(i).v_docidatth_n,
                               decode(lv_vsl_cert(i).v_certst_c,1,'APPROVED',2,'REJECTED',3,'REJECTED FOR AMMENDED'),
                               lv_vsl_cert(i).v_issgcl_m,
                               0,
                               SYSDATE,
                               'DATA MIGRATION',
                               SYSDATE,
                               'DATA MIGRATION',
                               0,
                               lv_vsl_cert(i).v_LASTAPPRBY_M,
                               lv_vsl_cert(i).v_INTLREM_X);




    -- defining the inner exception to prevent the control breaking out of loop abruptly in case of failure 
          EXCEPTION

             WHEN OTHERS THEN

                v_m_err_code := sqlcode;

                v_m_err_msg := substr(sqlerrm, 1, 200);

                v_m_sqlerrm := v_m_err_code || v_m_err_msg;


v_m_sqlerrm123 :=   'vsl_Cert_Id_n:'||seq_vsl_cert.currval ||'*|'||'MSW_VSL_ID_N:'||lv_vsl_cert(i).v_vslRecID_n||'*|'||'cert_Ty_c:'|| lv_vsl_cert(i).v_certTy_c||'*|'||'iss_authy_ctry_c:'||lv_vsl_cert(i).v_issAuthyCtry_c||'*|'||
 'issg_cl_c:'||lv_vsl_cert(i).v_issgcl_c||'*|'||'issd_dt:'||lv_vsl_cert(i).v_issd_dt||'*|'||'due_dt:'||lv_vsl_cert(i).v_due_dt||'*|'||'doc_id_atth_n:'||lv_vsl_cert(i).v_docidatth_n||'*|'||'st_c :'||lv_vsl_cert(i).v_certst_c||'*|'||
'issg_cl_m:'||lv_vsl_cert(i).v_issgcl_m||'*|'||'lock_ver_n:'||0||'*|'||'crt_on_dt:'|| SYSDATE||'*|'||'crt_by_x :'||'DATA MIGRATION'||'*|'|| 'upt_on_dt:'||SYSDATE||'*|'||'upt_by_x:'||'DATA MIGRATION'||'*|'||'deleted_i:'||0||'LASTAPPRBY_M:'||lv_vsl_cert(i).v_LASTAPPRBY_M||'Intelrem_x:'|| lv_vsl_cert(i).v_INTLREM_X ;




             pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                            'proc_1_vsl_cert_for', 
                                                            v_m_sqlerrm123||v_m_sqlerrm, 
                                                            'ERROR',
                                                            PV_RUN_ID,
                                                            v_m_err_msg,
                                                            seq_vsl_cert.currval||'*|'|| lv_vsl_cert(i).v_vslRecID_n ||'*|'||  lv_vsl_cert(i).v_certTy_c ||'*|'|| lv_vsl_cert(i).v_issAuthyCtry_c ||'*|'||
         lv_vsl_cert(i).v_issgcl_c ||'*|'|| lv_vsl_cert(i).v_issd_dt ||'*|'|| lv_vsl_cert(i).v_due_dt ||'*|'||lv_vsl_cert(i).v_docidatth_n ||'*|'||
lv_vsl_cert(i).v_certst_c ||'*|'||lv_vsl_cert(i).v_issgcl_m ||'*|'||0 ||'*|'||
SYSDATE ||'*|'||'DATA MIGRATION' ||'*|'||SYSDATE ||'*|'||'DATA MIGRATION' ||'*|'||0||'*|'||lv_vsl_cert(i).v_LASTAPPRBY_M||'*|'||lv_vsl_cert(i).v_INTLREM_X,
'T' );

               end;
               end loop;
               COMMIT;





        END LOOP;
        close cur_vessel_certificate;


        --find the count of intermediate table(source table) to compare the count with the that of target table

    SELECT COUNT(*)
      INTO v_src_count
      FROM si_cv_vslcert;



        SELECT COUNT(*)
        INTO v_tgt_count
        FROM vessel_certificate;

        pkg_datamigration_generic.proc_migration_recon('SI_CV_vslCert', v_src_count, 'VESSEL_CERTIFICATE', v_tgt_count,'N');

        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
         'proc_1_vsl_cert_for', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into vessel_certificate table' ,
        'SUCCESS',
        null,
        null,
        null,
        null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
        'proc_1_vsl_cert_for', 
 v_tgt_count ||' out of ' ||v_src_count ||'rows  have been inserted into vessel_certificate table' ,
        'PARTIALLY SUCCESSFULL',
        null,
        null,
        null,
        null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
        'proc_1_vsl_cert_for', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into vessel_certificate table' ,
        'FAIL',
        null,
        null,
        null,
        null);

        else 

     pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
     'proc_1_vsl_cert_for', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into vessel_certificate table' ,
        'AMBIGIOUS',
        null,
        null,
        null,
        null);


        end if;


        --Reconciling the staging table cnt and target table cnt

            SELECT COUNT(*)
      INTO v_src_count
      FROM st_cv_vslcert;



        SELECT COUNT(*)
        INTO v_tgt_count
        FROM vessel_certificate;

        pkg_datamigration_generic.proc_migration_recon('ST_CV_vslCert', v_src_count, 'VESSEL_CERTIFICATE', v_tgt_count,'Y');



        if v_m_tgt_count > 0 and (v_m_tgt_count - v_tgt_count) = 0 then  
          P_count := 0;
          else 
           P_count :=  -1;

        end if ;



begin 

for i in
(
select 
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT	

from ST_CV_vslCert 
where   vslRecID_n    not in 

(  SELECT
      vc.vslRecID_n
    FROM
        ST_CV_vslCert vc , 
        vessel v 
    where
         vc.vslRecID_n=v.VSL_REC_ID_N))


loop

pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                'proc_1_vsl_cert_for',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_vslCert AND WHOLE QUERY DUE TO JOIN CONDITION FAILURE',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                  i.CERTTY_C	||'*|'||
i.VSLRECID_N||'*|'||
i.ISSD_DT	||'*|'||
i.DUE_DT	||'*|'||
i.REGST_C	||'*|'||
i.ISSDBY_C	||'*|'||
i.ISSAUTHYCTRY_C	||'*|'||
i.ISSGCL_C	||'*|'||
i.PERSALLW_Q	||'*|'||
i.SOPEPSMPEPONBD_I	||'*|'||
i.INCOMPLYMARPOLREGU20_I	||'*|'||
i.INCOMPLYMARPOLREGU21_I	||'*|'||
i.BCCAPPLN_N	||'*|'||
i.BCCAPPLNST_C	||'*|'||
i.BCCISSD_DT	||'*|'||
i.INSURTY_C	||'*|'||
i.INSURVALTILL_DT	||'*|'||
i.DOCIDATTH_N	||'*|'||
i.CERTST_C	||'*|'||
i.LASTAPPRBY_N	||'*|'||
i.LASTAPPRBY_M	||'*|'||
i.CRTBY_N	||'*|'||
i.CRTBY_M	||'*|'||
i.CRTBYDEPT_M	||'*|'||
i.CRTON_DT	||'*|'||
i.UPDBY_N	||'*|'||
i.UPDBY_M	||'*|'||
i.UPDBYDEPT_M	||'*|'||
i.UPDON_DT	||'*|'||
i.INTLREM_X	||'*|'||
i.ISSGCL_M	||'*|'||
i.INCOMPLYMARPOLREGU20_DT	||'*|'||
i.INCOMPLYMARPOLREGU21_DT	   ,
 'B');



end loop;




exception

when others then null;

end;































EXCEPTION
    WHEN OTHERS THEN
         v_err_code := sqlcode;

                v_err_msg := substr(sqlerrm, 1, 200);

                v_sqlerrm := v_err_code || v_err_msg;

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 'proc_1_vsl_cert_for', v_sqlerrm, 'ERROR',null,null,null,'T');
END;