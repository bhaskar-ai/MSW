create or replace PROCEDURE proc_2_pan_app (PV_RUN_ID IN NUMBER) IS 


/***********************************************************************************************************
procedure name : PROC_2_pan_app
Created By     : V. R. Yembarwar
Date           : 10-MAY-2019
Purpose        : Inserting  the data from , ST_pans_pansinfofrmrlog ,ST_pans_pansinfofrmrlog2,
                 ST_pans_pansinfofrmrlog3, ST_PTMS_BWMC,ST_PTMS_NOAFREFORMHIST (staging table) to 
                 SI_PAN_APPLICATION(Intermediate table) to 
				 Target Table PAN_APPLICATION AND PAN_PURPOSE_OF_CALLS.
Modified by    :  C.N.Bhaskar
Modified date  :  8-Aug-2019

*************************************************************************************************************/


 ---**** cursor for fetching data from Source Staging Table ****Z

    CURSOR cur_si_pan IS
    SELECT 
		d.VSL_REC_ID_N,
        a.pansid_n,
        d.msw_vsl_id_n,
        b.mvvoyageno_x,
        b.mvfwddft_q,
        b.mvmiddft_q,
        b.mvaftdft_q,
        f.MVHGT_Q,
        a.vslimscallno_c,
        a.csoname_x,
        a.csotelno_c,
        a.agentname_x,
        a.locnlatlong_x,
        a.locnlong_x,
        a.agenttelno_c,
        a.agentfaxno_c,
        f.agentEmail,
        f.shipEmail,
        b.anchdaysstay_n,
        b.ancheta_dt,
        b.anchetd_dt,
        a.cargo_x,
        a.shpsecplan_i,
        a.securitylevel_c,
        b.securityper_i,
        f.slopSludge_i,
        f.slopQty_q,
        f.sludgeQty_q,
        f.SSContent_x,
        f.SSRepFac_x,
        a.userid_x,
        f.safetyRem_i,
        d.vsl_mmsi_n,
        a.coname_x,
        f.mvConRem_i,
        f.fireHzRem_i,
        b.armsstrongrm_i,
        b.armsstrongrmlocn_x,
        f.mvRem_x,
        b.mvhms_i,
        b.mvhms_x,
        f.GPP_c,
        e.bwmc_i,
        e.ibwmc_i,
        e.bwmcExempted_i,
        e.bwmc_c,
        e.bwmcD1_i,
        e.bwmcD1Reason_x,
        e.bwmcD1Discharge_i,
        e.bwmcD1Discharge_q,
        e.bwmcD2_i,
        e.bwmcD2Reason_i,
        e.bwmcD2Discharge_i,
        e.bwmcD2Discharge_q,
        e.bwmcD4_i,
        a.usertitle,
        a.locn_x,
        a.timestamp_dt,
        b.armsammunition_i,
        b.armstype_x,
        a.dgcargo_c,
        a.dgcargopc_i,
        a.crewlst_i,
        a.paxlst_i,
        e.eta_dt,
        b.etd_dt,
        a.vslgt_q,
        e.ETA_DT  as BWMC_ETA_DT ,
        c.validbcc_i,
        f.manRem_i,
        f. mvDirnFr_c,
        a.reportdate_dt,
        b.userid_n,
        a.purposecall_c,
        a.otherspurpose_x,
        b.anchpurpose_c,
        b.anchpurpose_x

    FROM
        st_pans_pansinfofrmrlog    a,
        st_pans_pansinfofrmrlog2   b,
        st_pans_pansinfofrmrlog3   c,
        ST_PTMS_BWMC e,
        ST_PTMS_NOAFREFORMHIST f,
        VESSEL   d
      WHERE
        a.pansid_n = b.pansid_n       
        AND a.pansid_n = c.pansid_n   
        and a.pansID_n = e.transID_n(+)
        and a.vslRecID_n = e.vslRecID_n(+)
        and a.pansID_n = f.pansID_n(+)    
        AND a.vslrecid_n = d.vsl_rec_id_n;  



-- de claring the 'record type'  type to serve as the datatype of collection variable  of main table 

    v_dr_st_count          NUMBER;
    v_m_tgt_count1         NUMBER;
    v_m_src_count          NUMBER;
    v_si_count             NUMBER;
    v_m_tgt_count          NUMBER;
    v_m_err_code           NUMBER;
    v_exp_rows_si          VARCHAR2(2500);
    v_m_err_msg            VARCHAR2(200);
    v_m_sqlerrm            VARCHAR2(2500);
    v_err_code             VARCHAR2(1000);
    v_err_msg              VARCHAR2(1000);
    v_sqlerrm              VARCHAR2(1000);
    v_blkexptn_count       VARCHAR2(10000);
    v_blkexptn_desc        VARCHAR2(10000);
    v_src_count            NUMBER;  
    v_len                  VARCHAR2(10);
    v_len2                 VARCHAR2(20);
    v_regex                VARCHAR2(20);
    v_regexx               VARCHAR2(20); 
    v_cnt_poc              NUMBER := 0;
    l_val                  NUMBER;
    p_yymm                 VARCHAR2(20);
    V_YEAR_MONTH           VARCHAR2(20) ;
    lv_data_lump           CLOB;
    V_FLAG                 VARCHAR2(1);


   CURSOR cur_tg_pan IS

    SELECT 

           VSL_REC_ID_N,
            PANSID_N	,
            MSW_VSL_ID_N	,
            MVVOYAGENO_X	,
            MVFWDDFT_Q	,
            MVMIDDFT_Q	,
            MVAFTDFT_Q	,
            MVHGT_Q	,
            VSLIMSCALLNO_C	,
            CSONAME_X	,
            CSOTELNO_C	,
            AGENTNAME_X	,
            LOCNLATLONG_X	,
            LOCNLONG_X	,
            AGENTTELNO_C	,
            AGENTFAXNO_C	,
            AGENTEMAIL	,
            SHIPEMAIL	,
            ANCHDAYSSTAY_N	,
            ANCHETA_DT	,
            ANCHETD_DT	,
            CARGO_X	,
            SHPSECPLAN_I	,
            SECURITYLEVEL_C	,
            SECURITYPER_I	,
            SLOPSLUDGE_I	,
            SLOPQTY_Q	,
            SLUDGEQTY_Q	,
            SSCONTENT_X	,
            SSREPFAC_X	,
            USERID_X	,
            SAFETYREM_I	,
            VSL_MMSI_N	,
            CONAME_X	,
            MVCONREM_I	,
            FIREHZREM_I	,
            ARMSSTRONGRM_I	,
            ARMSSTRONGRMLOCN_X	,
            MVREM_X	,
            MVHMS_I	,
            MVHMS_X	,
            GPP_C	,
            BWMC_I	,
            IBWMC_I	,
            BWMCEXEMPTED_I	,
            BWMC_C	,
            BWMCD1_I	,
            BWMCD1REASON_X	,
            BWMCD1DISCHARGE_I	,
            BWMCD1DISCHARGE_Q	,
            BWMCD2_I	,
            BWMCD2REASON_I	,
            BWMCD2DISCHARGE_I	,
            BWMCD2DISCHARGE_Q	,
            BWMCD4_I	,
            USERTITLE	,
            LOCN_X	,
            TIMESTAMP_DT	,
            ARMSAMMUNITION_I	,
            ARMSTYPE_X	,
            DGCARGO_C	,
            DGCARGOPC_I	,
            CREWLST_I	,
            PAXLST_I	,
            ETA_DT	,
            ETD_DT	,
            VSLGT_Q	,
            BWMC_ETA_DT	,
            VALIDBCC_I	,
            MANREM_I	,
            REPORTDATE_DT	,
            USERID_N	,
            MVDIRNFR_C	,
            PURPOSECALL_C	,
            OTHERSPURPOSE_X	,
            anchpurpose_c ,
            anchpurpose_x


    FROM
        si_pan_application
        ORDER BY reportdate_dt;

    TYPE rec_pan_app_tg IS RECORD (

        v_VSL_REC_ID_N         si_pan_application.VSL_REC_ID_N%TYPE,	
        v_pansid_n             si_pan_application.pansid_n%TYPE,	
        v_msw_vsl_id_n         si_pan_application.msw_vsl_id_n%TYPE,	
        v_mvvoyageno_x         si_pan_application.mvvoyageno_x%TYPE,	
        v_mvfwddft_q           si_pan_application.mvfwddft_q%TYPE,	
        v_mvmiddft_q           si_pan_application.mvmiddft_q%TYPE,	
        v_mvaftdft_q           si_pan_application.mvaftdft_q%TYPE,	
        v_mvhgt_q              si_pan_application.mvhgt_q%TYPE,	
        v_vslimscallno_c       si_pan_application.vslimscallno_c%TYPE,	
        v_csoname_x            si_pan_application.csoname_x%TYPE,	
        v_csotelno_c           si_pan_application.csotelno_c%TYPE,	
        v_agentname_x          si_pan_application.agentname_x%TYPE,	
        v_locnlatlong_x        si_pan_application.locnlatlong_x%TYPE,	
        v_locnlong_x           si_pan_application.locnlong_x%TYPE,	
        v_agenttelno_c         si_pan_application.agenttelno_c%TYPE,	
        v_agentfaxno_c         si_pan_application.agentfaxno_c%TYPE,	
        v_agentemail           si_pan_application.agentemail%TYPE,	
        v_shipemail            si_pan_application.shipemail%TYPE,	
        v_anchdaysstay_n       si_pan_application.anchdaysstay_n%TYPE,	
        v_ancheta_dt           si_pan_application.ancheta_dt%TYPE,	
        v_anchetd_dt           si_pan_application.anchetd_dt%TYPE,	
        v_cargo_x              si_pan_application.cargo_x%TYPE,	
        v_shpsecplan_i         si_pan_application.shpsecplan_i%TYPE,	
        v_securitylevel_c      si_pan_application.securitylevel_c%TYPE,	
        v_securityper_i        si_pan_application.securityper_i%TYPE,	
        v_slopsludge_i         si_pan_application.slopsludge_i%TYPE,	
        v_slopqty_q            si_pan_application.slopqty_q%TYPE,	
        v_sludgeqty_q          si_pan_application.sludgeqty_q%TYPE,	
        v_sscontent_x          si_pan_application.sscontent_x%TYPE,	
        v_ssrepfac_x           si_pan_application.ssrepfac_x%TYPE,	
        v_userid_x             si_pan_application.userid_x%TYPE,	
        v_safetyrem_i          si_pan_application.safetyrem_i%TYPE,	
        v_vsl_mmsi_n           si_pan_application.vsl_mmsi_n%TYPE,	
        v_coname_x             si_pan_application.coname_x%TYPE,	
        v_mvconrem_i           si_pan_application.mvconrem_i%TYPE,	
        v_firehzrem_i          si_pan_application.firehzrem_i%TYPE,	
        v_armsstrongrm_i       si_pan_application.armsstrongrm_i%TYPE,	
        v_armsstrongrmlocn_x   si_pan_application.armsstrongrmlocn_x%TYPE,	
        v_mvrem_x              si_pan_application.mvrem_x%TYPE,	
        v_mvhms_i              si_pan_application.mvhms_i%TYPE,	
        v_mvhms_x              si_pan_application.mvhms_x%TYPE,	
        v_gpp_c                si_pan_application.gpp_c%TYPE,	
        v_bwmc_i               si_pan_application.bwmc_i%TYPE,	
        v_ibwmc_i              si_pan_application.ibwmc_i%TYPE,	
        v_bwmcexempted_i       si_pan_application.bwmcexempted_i%TYPE,	
        v_bwmc_c               si_pan_application.bwmc_c%TYPE,	
        v_bwmcd1_i             si_pan_application.bwmcd1_i%TYPE,	
        v_bwmcd1reason_x       si_pan_application.bwmcd1reason_x%TYPE,	
        v_bwmcd1discharge_i    si_pan_application.bwmcd1discharge_i%TYPE,	
        v_bwmcd1discharge_q    si_pan_application.bwmcd1discharge_q%TYPE,	
        v_bwmcd2_i             si_pan_application.bwmcd2_i%TYPE,	
        v_bwmcd2reason_i       si_pan_application.bwmcd2reason_i%TYPE,	
        v_bwmcd2discharge_i    si_pan_application.bwmcd2discharge_i%TYPE,	
        v_bwmcd2discharge_q    si_pan_application.bwmcd2discharge_q%TYPE,	
        v_bwmcd4_i             si_pan_application.bwmcd4_i%TYPE,	
        v_usertitle            si_pan_application.usertitle%TYPE,	
        v_locn_x               si_pan_application.locn_x%TYPE,	
        v_timestamp_dt         si_pan_application.timestamp_dt%TYPE,	
        v_armsammunition_i     si_pan_application.armsammunition_i%TYPE,	
        v_armstype_x           si_pan_application.armstype_x%TYPE,	
        v_dgcargo_c            si_pan_application.dgcargo_c%TYPE,	
        v_dgcargopc_i          si_pan_application.dgcargopc_i%TYPE,	
        v_crewlst_i            si_pan_application.crewlst_i%TYPE,	
        v_paxlst_i             si_pan_application.paxlst_i%TYPE,	
        v_eta_dt               si_pan_application.eta_dt%TYPE,	
        v_etd_dt               si_pan_application.etd_dt%TYPE,	
        v_vslgt_q              si_pan_application.vslgt_q%TYPE,	
        v_BWMC_ETA_DT          si_pan_application.BWMC_ETA_DT%TYPE,	
        v_validbcc_i           si_pan_application.validbcc_i%TYPE,	
        v_MANREM_I             si_pan_application.MANREM_I%type,	
        v_reportdate_dt        si_pan_application.reportdate_dt%TYPE,	
        v_userid_n             si_pan_application.userid_n%TYPE,
        v_MVDIRNFR_C           si_pan_application.MVDIRNFR_C%TYPE,
        v_purposecall_c        si_pan_application.purposecall_c%TYPE,	
        v_otherspurpose_x      si_pan_application.otherspurpose_x%TYPE,	
        v_anchpurpose_c        si_pan_application.anchpurpose_c%TYPE,	
        v_anchpurpose_x        si_pan_application.anchpurpose_x%TYPE	


    );
    TYPE type_pan_app_tg IS   
        TABLE OF rec_pan_app_tg INDEX BY PLS_INTEGER;

    lv_rec_pan_app_tg        type_pan_app_tg;
    lv_seq_pan_app           pan_application.appln_ref_n%TYPE;
    lv_seq_pan_purp          pan_purpose_of_call.pan_purp_of_call_id_n%TYPE;


    LVAL                     CLOB;
    v_msw_appln_ref_id_x     VARCHAR2(20);            
    v_msw_vsl_call_id        VARCHAR2(250);
    v_exp_rows               VARCHAR2(250);
    LV_GPP_c_i               CHAR(1);
    LV_BURNING_LNG_I         CHAR(1);
    LV_BURNING_CLN_FUEL_I    CHAR(1);

BEGIN		-- outer begin 


 ---------find the count of main table(source table) to compare the count with the that of intermediate table for reconcialation purpose




 ------insertig the rcords into the si intermediate table---------------



    pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 'PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


        FOR i IN cur_si_pan      -- for loop to insert data into si_pan_application table 

        loop                     -- for loop to insert data into si_pan_application table 

        BEGIN                    -- inner begin of si_pan_application

            INSERT INTO si_pan_application (
            VSL_REC_ID_N,
            PANSID_N	,
            MSW_VSL_ID_N	,
            MVVOYAGENO_X	,
            MVFWDDFT_Q	,
            MVMIDDFT_Q	,
            MVAFTDFT_Q	,
            MVHGT_Q	,
            VSLIMSCALLNO_C	,
            CSONAME_X	,
            CSOTELNO_C	,
            AGENTNAME_X	,
            LOCNLATLONG_X	,
            LOCNLONG_X	,
            AGENTTELNO_C	,
            AGENTFAXNO_C	,
            AGENTEMAIL	,
            SHIPEMAIL	,
            ANCHDAYSSTAY_N	,
            ANCHETA_DT	,
            ANCHETD_DT	,
            CARGO_X	,
            SHPSECPLAN_I	,
            SECURITYLEVEL_C	,
            SECURITYPER_I	,
            SLOPSLUDGE_I	,
            SLOPQTY_Q	,
            SLUDGEQTY_Q	,
            SSCONTENT_X	,
            SSREPFAC_X	,
            USERID_X	,
            SAFETYREM_I	,
            VSL_MMSI_N	,
            CONAME_X	,
            MVCONREM_I	,
            FIREHZREM_I	,
            ARMSSTRONGRM_I	,
            ARMSSTRONGRMLOCN_X	,
            MVREM_X	,
            MVHMS_I	,
            MVHMS_X	,
            GPP_C	,
            BWMC_I	,
            IBWMC_I	,
            BWMCEXEMPTED_I	,
            BWMC_C	,
            BWMCD1_I	,
            BWMCD1REASON_X	,
            BWMCD1DISCHARGE_I	,
            BWMCD1DISCHARGE_Q	,
            BWMCD2_I	,
            BWMCD2REASON_I	,
            BWMCD2DISCHARGE_I	,
            BWMCD2DISCHARGE_Q	,
            BWMCD4_I	,
            USERTITLE	,
            LOCN_X	,
            TIMESTAMP_DT	,
            ARMSAMMUNITION_I	,
            ARMSTYPE_X	,
            DGCARGO_C	,
            DGCARGOPC_I	,
            CREWLST_I	,
            PAXLST_I	,
            ETA_DT	,
            ETD_DT	,
            VSLGT_Q	,
            BWMC_ETA_DT	,
            VALIDBCC_I	,
            MANREM_I	,
            REPORTDATE_DT	,
            USERID_N	,
            MVDIRNFR_C	,
            PURPOSECALL_C	,
            OTHERSPURPOSE_X	,
            anchpurpose_c ,
            anchpurpose_x

            ) 

            VALUES (

                i.VSL_REC_ID_N	,
                i.pansid_n	,
                i.msw_vsl_id_n	,
                i.mvvoyageno_x	,
                i.mvfwddft_q	,
                i.mvmiddft_q	,
                i.mvaftdft_q	,
                i.MVHGT_Q	,
                i.vslimscallno_c	,
                i.csoname_x	,
                i.CSOTELNO_C	,
                i.AGENTNAME_X	,
                i.locnlatlong_x	,
                i.locnlong_x	,
                i.agenttelno_c	,
                i.agentfaxno_c	,
                i.AGENTEMAIL	,
                i.SHIPEMAIL	,
                i.anchdaysstay_n	,
                i.ancheta_dt	,
                i.anchetd_dt	,
                i.cargo_x	,
                i.shpsecplan_i	,
                i.securitylevel_c	,
                i.securityper_i	,
                i.SLOPSLUDGE_I	,
                i.SLOPQTY_Q	,
                i.SLUDGEQTY_Q	,
                i.SSCONTENT_X	,
                i.SSREPFAC_X	,
                i.userid_x	,
                i.SAFETYREM_I	,
                i.vsl_mmsi_n	,
                i.coname_x	,
                i.MVCONREM_I	,
                i.FIREHZREM_I	,
                i.armsstrongrm_i	,
                i.armsstrongrmlocn_x	,
                i.MVREM_X                         	,
                i.mvhms_i	,
                i.MVHMS_X	,
                i.GPP_C	,
                i.bwmc_i	,
                i.ibwmc_i	,
                i.bwmcexempted_i	,
                i.bwmc_c	,
                i.bwmcd1_i	,
                i.bwmcd1reason_x	,
                i.bwmcd1discharge_i	,
                i.bwmcd1discharge_q	,
                i.bwmcd2_i	,
                i.bwmcd2reason_i	,
                i.bwmcd2discharge_i	,
                i.bwmcd2discharge_q	,
                i.bwmcd4_i	,
                i.usertitle	,
                i.locn_x	,
                i.timestamp_dt	,
                i.armsammunition_i	,
                i.armstype_x	,
                i.dgcargo_c	,
                i.dgcargopc_i	,
                i.crewlst_i	,
                i.paxlst_i	,
                i.eta_dt	,
                i.etd_dt ,   --to_timestamp(i.etd_dt,'yyyy mm dd''hh24:mi:ss')	,   --date format needs to be check accoding to data 
                i.vslgt_q	,
                i.BWMC_ETA_DT 	,
                i.validbcc_i	,
                i.MANREM_I	,
                i.reportdate_dt	,
                substr(i.userid_n,1,20),
                i.MVDIRNFR_C	,
                i.purposecall_c	,
                i.otherspurpose_x	,
                i.anchpurpose_c	,
                i.anchpurpose_x	

            );

    EXCEPTION                                             -- inner exception of si_pan_application
        WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := sqlerrm;
            v_sqlerrm := dbms_utility.format_error_backtrace|| v_err_code || v_err_msg||dbms_utility.format_call_stack;
             v_exp_rows_si := 
                        ' VSL_REC_ID_N:'||	i.VSL_REC_ID_N||'<{||}>'||
						' PANSID_N:'	||i.pansid_n||'<{||}>'||
						' MSW_VSL_ID_N:'||i.msw_vsl_id_n||'<{||}>'||
						' MVVOYAGENO_X:'||i.mvvoyageno_x||'<{||}>'||
						' MVFWDDFT_Q:'  ||i.mvfwddft_q||'<{||}>'||
						' MVMIDDFT_Q:'  ||i.mvmiddft_q||'<{||}>'||
						' MVAFTDFT_Q:'  ||i.mvaftdft_q||'<{||}>'||
						' MVHGT_Q:'		||i.MVHGT_Q||'<{||}>'||
						' VSLIMSCALLNO_C:'||i.vslimscallno_c||'<{||}>'||
						' CSONAME_X:'	||i.csoname_x||'<{||}>'||
						' CSOTELNO_C:'	||i.CSOTELNO_C||'<{||}>'||
						' AGENTNAME_X:'	||i.AGENTNAME_X||'<{||}>'||
						' LOCNLATLONG_X:'||i.locnlatlong_x||'<{||}>'||
						' LOCNLONG_X:'	||i.locnlong_x||'<{||}>'||
						' AGENTTELNO_C:'||i.agenttelno_c||'<{||}>'||
						' AGENTFAXNO_C:'||i.agentfaxno_c||'<{||}>'||
						' AGENTEMAIL:'	||i.AGENTEMAIL||'<{||}>'||
						' SHIPEMAIL:'	||i.SHIPEMAIL||'<{||}>'||
						' ANCHDAYSSTAY_N:'||i.anchdaysstay_n||'<{||}>'||
						' ANCHETA_DT:'	||i.ancheta_dt||'<{||}>'||
						' ANCHETD_DT:'	||i.anchetd_dt||'<{||}>'||
						' CARGO_X:'		||i.cargo_x||'<{||}>'||
						' SHPSECPLAN_I:'||i.shpsecplan_i||'<{||}>'||
						' SECURITYLEVEL_C:'	||i.securitylevel_c||'<{||}>'||
						' SECURITYPER_I:'||i.securityper_i||'<{||}>'||
						' SLOPSLUDGE_I:'||i.SLOPSLUDGE_I||'<{||}>'||
						' SLOPQTY_Q:'	||i.SLOPQTY_Q||'<{||}>'||
						' SLUDGEQTY_Q:'	||i.SLUDGEQTY_Q||'<{||}>'||
						' SSCONTENT_X:'	||i.SSCONTENT_X||'<{||}>'||
						' SSREPFAC_X:'	||i.SSREPFAC_X||'<{||}>'||
						' USERID_X:'	||i.userid_x||'<{||}>'||
						' SAFETYREM_I:'	||i.SAFETYREM_I||'<{||}>'||
						' VSL_MMSI_N:'	||i.vsl_mmsi_n||'<{||}>'||
						' CONAME_X:'	||i.coname_x||'<{||}>'||
						' MVCONREM_I:'	||i.MVCONREM_I||'<{||}>'||
						' FIREHZREM_I:'	||i.FIREHZREM_I||'<{||}>'||
						' ARMSSTRONGRM_I:'||i.armsstrongrm_i||'<{||}>'||
						' ARMSSTRONGRMLOCN_X:'||i.armsstrongrmlocn_x||'<{||}>'||
						' MVREM_X:'	||i.MVREM_X ||'<{||}>'||
						' MVHMS_I:'	||i.mvhms_i||'<{||}>'||
						' MVHMS_X:'	||i.MVHMS_X||'<{||}>'||
						' GPP_C:'	||i.GPP_C||'<{||}>'||
						' BWMC_I:'	||i.bwmc_i||'<{||}>'||
						' IBWMC_I:'	||i.ibwmc_i||'<{||}>'||
						' BWMCEXEMPTED_I:'||i.bwmcexempted_i||'<{||}>'||
						' BWMC_C:'||i.bwmc_c||'<{||}>'||
						' BWMCD1_I:'||i.bwmcd1_i||'<{||}>'||
						' BWMCD1REASON_X:'||i.bwmcd1reason_x||'<{||}>'||
						' BWMCD1DISCHARGE_I:'||i.bwmcd1discharge_i||'<{||}>'||
						' BWMCD1DISCHARGE_Q:'||i.bwmcd1discharge_q||'<{||}>'||
						' BWMCD2_I:'	||i.bwmcd2_i||'<{||}>'||
						' BWMCD2REASON_I:'	||i.bwmcd2reason_i||'<{||}>'||
						' BWMCD2DISCHARGE_I:'	||i.bwmcd2discharge_i||'<{||}>'||
						' BWMCD2DISCHARGE_Q:'	||i.bwmcd2discharge_q||'<{||}>'||
						' BWMCD4_I:'	||i.bwmcd4_i||'<{||}>'||
						' USERTITLE:'	||i.usertitle||'<{||}>'||
						' LOCN_X:'	|| i.locn_x||'<{||}>'||
						' TIMESTAMP_DT:'||i.timestamp_dt||'<{||}>'||
						' ARMSAMMUNITION_I:'|| i.armsammunition_i||'<{||}>'||
						' ARMSTYPE_X:'	||i.armstype_x||'<{||}>'||
						' DGCARGO_C:'	||i.dgcargo_c||'<{||}>'||
						' DGCARGOPC_I:'	||i.dgcargopc_i||'<{||}>'||
						' CREWLST_I:'	||i.crewlst_i||'<{||}>'||
						' PAXLST_I:'	||i.paxlst_i||'<{||}>'||
						' ETA_DT:'	||i.eta_dt||'<{||}>'||
						' ETD_DT:'	||i.etd_dt||'<{||}>'||
						' VSLGT_Q:'	||i.vslgt_q||'<{||}>'||
						' BWMC_ETA_DT:'	||i.BWMC_ETA_DT||'<{||}>'||
						' VALIDBCC_I:'	||i.validbcc_i||'<{||}>'||
						' MANREM_I:'	||i.MANREM_I||'<{||}>'||
						' REPORTDATE_DT:'	||i.reportdate_dt||'<{||}>'||
						' USERID_N:'	||i.userid_n||'<{||}>'||
						' MVDIRNFR_C:'	||i.MVDIRNFR_C||'<{||}>'||
						' PURPOSECALL_C:'	||i.purposecall_c||'<{||}>'||
						' OTHERSPURPOSE_X:'	||i.otherspurpose_x||'<{||}>'||
						' anchpurpose_c ,:'	||i.anchpurpose_c||'<{||}>'||
						' anchpurpose_x:'	||i.anchpurpose_x;


         pkg_datamigration_generic.proc_trace_exception('SI_PAN_APLICATION', 
         'proc_2_pan_app',
         dbms_utility.format_error_backtrace , 
         'ERROR',
         PV_RUN_ID,
         dbms_utility.format_error_stack ||v_sqlerrm,
         v_exp_rows_si  ,
         'T');






    END;     -- inner end of si_pan_application
  END LOOP;   -- inner end loop of  si_pan_application table
 COMMIT;
---Records Missed in the Business Logic


/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/

 OPEN cur_tg_pan;     -- cursor loop  to insert data into PAN_APPLICATION and PAN_POC table 

    pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_pan_app', 'Insertion begins into PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


    LOOP                 ---loop to start  cursor loop  to insert data into PAN_APPLICATION and PAN_POC table 

        FETCH cur_tg_pan
        BULK COLLECT INTO
        lv_rec_pan_app_tg LIMIT 10000;

        EXIT WHEN lv_rec_pan_app_tg.count = 0;

        FOR i IN lv_rec_pan_app_tg.first..lv_rec_pan_app_tg.last 

           LOOP           ---for loop

      --      lv_seq_pan_app := seq_pan_app.nextval;

     --       lv_seq_pan_purp := seq_pan_purp.nextval;

                BEGIN                                   -- inner begin when  any exception occurs in JSON or sequence reset


                          V_YEAR_MONTH:= TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'YY')|| TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'MM') ;


          ------    if APP_SUB_PAN_SEQ.nextval>=300000  

--------------logic for sequence reset------------

                                    IF V_YEAR_MONTH != p_yymm  AND p_yymm IS NOT NULL                       
                                     THEN

                                             EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual'
                                             INTO l_val;
                                              EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by -'|| l_val || ' minvalue 0';

                                              EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual'
                                                 INTO l_val;
                                              EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by 1 minvalue 0';

                                      end if;

                                            p_yymm := V_YEAR_MONTH ;



                                        v_msw_appln_ref_id_x := 'MSW'
                                            || 'PAN'
                                            || TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt, 'YY')
                                            || TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt, 'MM') 
                                            || TO_CHAR(APP_SUB_PAN_SEQ.nextval, 'FM00000');




  ---------- TRANSFORMATION DECODE LOGIC FOR FUEL TOOK IN VARIBLE---

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'N',0,'L',1,1) 
                                                                   INTO LV_GPP_c_i FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',1,'Y',0,NULL) 
                                                                   INTO LV_BURNING_LNG_I FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',0,'Y',1,NULL)
                                                                   INTO LV_BURNING_CLN_FUEL_I FROM DUAL;





                                                                   proc_2_vc_as
                                                                  ( lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                  nvl(lv_rec_pan_app_tg(i).v_eta_dt,sysdate), -- need to change in future after clarification
                                                                  lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  v_msw_appln_ref_id_x,
                                                                  lv_rec_pan_app_tg(i).v_pansid_n,
                                                                  'PAN',
                                                                  null,--json (need to change)
                                                                  PV_RUN_ID, 
                                                                  'PAN_APPLICATION',
                                                                  v_msw_vsl_call_id,
                                                                  V_FLAG);



                                        IF V_FLAG IS NULL THEN


                                 /************************************************************************************************************************************

                                                                                               PAN_APPLICATION  

                                 ******************************************************************************************************************************************/


                                                              Begin    -- inner begin to insert data into pan application

                                                                    INSERT INTO pan_application (

                                                                        APPLN_REF_N,
                                                                        VSL_CALL_ID_N,
                                                                        MSW_APPLN_REF_ID_X,
                                                                        EXTL_APPLN_REF_ID_X,
                                                                        MSW_VSL_ID_N,
                                                                        VOY_X,
                                                                        APPLCNT_ID_X,
                                                                        ARR_FWD_DFT_Q,
                                                                        ARR_MID_DFT_Q,
                                                                        ARR_AFT_DFT_Q,
                                                                        AIR_DFT_Q,
                                                                        VSL_IMS_CALL_NO_C,
                                                                        CSO_M,
                                                                        CSO_TEL_N,
                                                                        AGT_NM_M,
                                                                        LOCN_LAT_N,
                                                                        LOCN_LONG_N,
                                                                        AGT_TEL_N,
                                                                        AGT_FAX_N,
                                                                        AGT_EMAIL_X,
                                                                        SHP_EMAIL_X,
                                                                        ANCH_DURN_N,
                                                                        ANCH_ETA_DT,
                                                                        ANCH_ETD_DT,
                                                                        CGO_DESC_X,
                                                                        SHP_SECU_PLAN_I,
                                                                        SECU_LVL_SG_C,
                                                                        SECU_PERS_I,
                                                                        APPLN_ST_C,
                                                                        SLOP_SLUDGE_I,
                                                                        SLOP_QTY_Q,
                                                                        SLUDGE_QTY_Q,
                                                                        SS_CONTENT_X,
                                                                        SS_REP_FAC_X,
                                                                        HEIGHT_N,
                                                                        NAME_PER_REPORTING_X,
                                                                        SAFETY_SEC_AFFECT_I,
                                                                        VSL_MMSI_N,
                                                                        CO_NAME_X,
                                                                        MV_CON_REM_I,
                                                                        SAFETY_REM_I,
                                                                        FIRE_HZ_REM_I,
                                                                        ARMS_STRONG_RM_I,
                                                                        ARMS_STRONG_RM_LOCN_X,
                                                                        MV_REM_X,
                                                                        MV_HMS_I,
                                                                        MV_HMS_X,
                                                                        GPP_C_I,
                                                                        BURNING_LNG_I,
                                                                        BURNING_CLN_FUEL_I,
                                                                        BWMC_I,
                                                                        IBWMC_I,
                                                                        BWMC_EXEMPTED_I,
                                                                        BWMC_COM_C,
                                                                        BWMC_D1_I,
                                                                        BWMC_D1_REASON_X,
                                                                        BWMC_D1_DISCHARGE_I,
                                                                        BWMC_D1_DISCHARGE_Q,
                                                                        BWMC_D2_I,
                                                                        BWMC_D2_REASON_I,
                                                                        BWMC_D2_DISCHARGE_I,
                                                                        BWMC_D2_DISCHARGE_Q,
                                                                        BWMC_D4_I,
                                                                        USER_TITLE_X,
                                                                        LOCN_X,
                                                                        TIME_STAMP_DT,
                                                                        ARMS_AMMUNITION_I,
                                                                        ARMS_TYPE_X,
                                                                        ARMS_QTY_Q,
                                                                        HNS_I,
                                                                        DG_ON_BOARD_I,
                                                                        DG_CGO_MANF_I,
                                                                        CR_LIST_I,
                                                                        PASSN_LIST_ICA_I,
                                                                        PORT_FACILITY_ETA_DT,
                                                                        PORT_FACILITY_ETD_DT,
                                                                        GRS_TNG_N,
                                                                        IS_NOA_I,
                                                                        DRAFT_X,
                                                                        LAST_PORT_X,
                                                                        ETA_DT,
                                                                        VALID_BCC_I,
                                                                        MAN_REM_I,
                                                                        SAFETY_SECURITY_I,
                                                                        LOCATION_X,
                                                                        OTHER_LOCATION_X,
                                                                        MV_STM_DT,
                                                                        LOCN_TO_X,
                                                                        MARPOL_I,
                                                                        OTERM_FAC_C,
                                                                        OTERM_FAC_X,
                                                                        TRANS_ID_N,
                                                                        NEW_NOA_I,
                                                                        PAGER_X,
                                                                        SESS_X,
                                                                        OTH_REM_I,
                                                                        ARMS_SRC_I,
                                                                        SOURCE_I,
                                                                        USER_ID_X,
                                                                        LATD_DIRCN_C,
                                                                        LONGD_DIRCN_C,
                                                                        SHP_ARVL_DIRCN_C,
                                                                        SUBR_EMAIL_I,
                                                                        SUBR_SMS_I,
                                                                        PROCESSING_REM_X,
                                                                        PROCESSED_BY_X,
                                                                        PROCESSED_ON_DT,
                                                                        CRT_BY_N,
                                                                        CRT_ON_DT,
                                                                        UPT_BY_X,
                                                                        UPT_ON_DT,
                                                                        LOCK_VER_N,
                                                                        DELETED_I
                                                                    ) VALUES (
                                                                            seq_pan_app.nextval,
                                                                            v_msw_vsl_call_id ,    
                                                                            v_msw_appln_ref_id_x,         
                                                                            lv_rec_pan_app_tg(i).v_pansid_n,
                                                                            lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                            lv_rec_pan_app_tg(i).v_mvvoyageno_x,
                                                                            'D1',                                                  ---Pending on User Service Data Model
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10,     
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10,
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10  ,    
                                                                            lv_rec_pan_app_tg(i).v_mvHgt_q,
                                                                            lv_rec_pan_app_tg(i).v_vslimscallno_c,
                                                                            lv_rec_pan_app_tg(i).v_csoname_x,
                                                                            lv_rec_pan_app_tg(i).v_csotelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentname_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlatlong_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlong_x,
                                                                            lv_rec_pan_app_tg(i).v_agenttelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentfaxno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentEmail,
                                                                            lv_rec_pan_app_tg(i).v_shipEmail,
                                                                            lv_rec_pan_app_tg(i).v_anchdaysstay_n,
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            lv_rec_pan_app_tg(i).v_cargo_x,
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_shpsecplan_i), 'N', 0, 'Y',1),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securitylevel_c), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securityper_i), 'N', 0, 'Y', 1),
                                                                            'PROCESSED',                                            ---as per mapping sheet
                                                                            decode(TRIM(lv_rec_pan_app_tg(i).v_slopSludge_i), 'N',0,'Y',1),
                                                                            TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q),
                                                                            TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q),
                                                                            lv_rec_pan_app_tg(i).v_SSContent_x,
                                                                            lv_rec_pan_app_tg(i).v_SSRepFac_x,
                                                                            0,                                              --according to mapping sheet
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(trim(lv_rec_pan_app_tg(i).v_safetyRem_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_vsl_mmsi_n,
                                                                            lv_rec_pan_app_tg(i).v_coname_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvConRem_i),'N',0,'Y',1),
                                                                            0,                                          --according to mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_fireHzRem_i),'N',0,'Y',1),
                                                                            substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1, 1),
                                                                            lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x,
                                                                            lv_rec_pan_app_tg(i).v_mvRem_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvhms_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_mvhms_x,
                                                                            LV_GPP_c_i ,                            
                                                                            LV_BURNING_LNG_I,                                
                                                                            LV_BURNING_CLN_FUEL_I ,                                
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_ibwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcexempted_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmc_c,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1reason_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2_i,
                                                                            Decode(Trim(lv_rec_pan_app_tg(i).v_bwmcd2reason_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd2discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd4_i,
                                                                            lv_rec_pan_app_tg(i).v_usertitle,
                                                                            lv_rec_pan_app_tg(i).v_locn_x,
                                                                            lv_rec_pan_app_tg(i).v_timestamp_dt,
                                                                            lv_rec_pan_app_tg(i).v_armsammunition_i,
                                                                            lv_rec_pan_app_tg(i).v_armsType_x,         
                                                                            0,
                                                                            0,                                                --- accordingly to a mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_dgcargo_c),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_dgcargopc_i,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_crewlst_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_paxlst_i,
                                                                            lv_rec_pan_app_tg(i).v_eta_dt,
                                                                            lv_rec_pan_app_tg(i).v_etd_dt,
                                                                            lv_rec_pan_app_tg(i).v_vslgt_q,
                                                                            0,
                                                                            'DM',                                            ---pending
                                                                            'DM',
                                                                            lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_validbcc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_manRem_i),'N',0,'Y',1),
                                                                            0,
                                                                            'PAN',
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnlatlong_x),-1),'N','NORTH','S','SOUTH'),
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnLong_x),-1),'W', 'WEST', 'E', 'EAST'),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvDirnFr_c) , 'W', 'WEST', 'E', 'EAST','S', 'SOUTN', 'N', 'NORTH'),
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).v_userId_n,
                                                                            nvl(lv_rec_pan_app_tg(i).v_reportdate_dt,sysdate),
                                                                            NULL,
                                                                            NULL,
                                                                            0,
                                                                            0
                                                                          );



                                                    ------------------------------



                                                    EXCEPTION --inner exception for PAN_APPLICATION
                                                                    WHEN OTHERS THEN
                                                                    ---deleting records from vessel_call and Application_submission  table when we get exception while inserting records in PAN_APPLICATION
                                                                         DELETE FROM vessel_call     
                                                                         WHERE   vsl_call_id_n = v_msw_vsl_call_id;

                                                                         DELETE FROM Application_submission     
                                                                         WHERE   VSL_CALL_ID_N = v_msw_vsl_call_id;

                                                                        v_err_code := sqlcode;
                                                                        v_err_msg := substr(sqlerrm, 1, 200);
                                                                        v_sqlerrm := v_err_code
                                                                                     || v_err_msg
                                                                                     || dbms_utility.format_error_backtrace;

                                                                        v_exp_rows:=    'APPLN_REF_N :'	||seq_pan_app.currval||'<{||}>'||
                                                                                        'VSL_CALL_ID_N,:'|| v_msw_vsl_call_id||'<{||}>'||
                                                                                        'MSW_APPLN_REF_ID_X:'|| v_msw_appln_ref_id_x||'<{||}>'||
                                                                                        'EXTL_APPLN_REF_ID_X:'||lv_rec_pan_app_tg(i).v_pansid_n	||'<{||}>'||
                                                                                        'MSW_VSL_ID_N:' ||lv_rec_pan_app_tg(i).v_msw_vsl_id_n||'<{||}>'||
                                                                                        'VOY_X:'		||lv_rec_pan_app_tg(i).v_mvvoyageno_x||'<{||}>'||
                                                                                        'APPLCNT_ID_X:'	||'D1'||'<{||}>'  ||           
                                                                                        'ARR_FWD_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_MID_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_AFT_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10||'<{||}>'||
                                                                                        'AIR_DFT_Q:'	||lv_rec_pan_app_tg(i).v_mvHgt_q	||	'<{||}>'||
                                                                                        'VSL_IMS_CALL_NO_C:'||lv_rec_pan_app_tg(i).v_vslimscallno_c	||'<{||}>'||
                                                                                        'CSO_M:'		||lv_rec_pan_app_tg(i).v_csoname_x||'<{||}>'||
                                                                                        'CSO_TEL_N:'	||lv_rec_pan_app_tg(i).v_csotelno_c	||'<{||}>'||
                                                                                        'AGT_NM_M:'		||lv_rec_pan_app_tg(i).v_agentname_x||'<{||}>'||
                                                                                        'LOCN_LAT_N:'	||lv_rec_pan_app_tg(i).v_locnlatlong_x||'<{||}>'||
                                                                                        'LOCN_LONG_N:'	||lv_rec_pan_app_tg(i).v_locnlong_x	||'<{||}>'||
                                                                                        'AGT_TEL_N:'	||lv_rec_pan_app_tg(i).v_agenttelno_c||'<{||}>'||
                                                                                        'AGT_FAX_N:'	||lv_rec_pan_app_tg(i).v_agentfaxno_c||'<{||}>'||
                                                                                        'AGT_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_agentEmail	||'<{||}>'||
                                                                                        'SHP_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_shipEmail	||'<{||}>'||
                                                                                        'ANCH_DURN_N:'	||lv_rec_pan_app_tg(i).v_anchdaysstay_n	||	'<{||}>'||
                                                                                        'ANCH_ETA_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'ANCH_ETD_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'CGO_DESC_X:'	||lv_rec_pan_app_tg(i).v_cargo_x||'<{||}>'||									
                                                                                        'APPLN_ST_C:'	||'PROCESSED' ||	'<{||}>'||								
                                                                                        'SLOP_QTY_Q:'	||TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q)	||	'<{||}>'||
                                                                                        'SLUDGE_QTY_Q:'	||TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q)	||	'<{||}>'||
                                                                                        'SS_CONTENT_X:'	||lv_rec_pan_app_tg(i).v_SSContent_x||	'<{||}>'||
                                                                                        'SS_REP_FAC_X:'	||lv_rec_pan_app_tg(i).v_SSRepFac_x	||	'<{||}>'||									
                                                                                        'NAME_PER_REPORTING_X:'	||lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||									
                                                                                        'VSL_MMSI_N:'	||lv_rec_pan_app_tg(i).v_vsl_mmsi_n	||	'<{||}>'||
                                                                                        'CO_NAME_X:'	||lv_rec_pan_app_tg(i).v_coname_x	||	'<{||}>'||			
                                                                                        'ARMS_STRONG_RM_I:'	|| substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1 ,1)	||	'<{||}>'||
                                                                                        'ARMS_STRONG_RM_LOCN_X:'||	 lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x	||	'<{||}>'||
                                                                                        'MV_REM_X:'		||	 lv_rec_pan_app_tg(i).v_mvRem_x	||	'<{||}>'||									
                                                                                        'MV_HMS_X:'		||	 lv_rec_pan_app_tg(i).v_mvhms_x	||	'<{||}>'||
                                                                                        'GPP_C_I:'		||	 LV_GPP_c_i||'<{||}>'||
                                                                                        'BURNING_LNG_I:'||	 LV_BURNING_LNG_I ||	'<{||}>'||
                                                                                        'BURNING_CLN_FUEL_I:'	||	 LV_BURNING_CLN_FUEL_I||'<{||}>'||									
                                                                                        'BWMC_COM_C:'	||	 lv_rec_pan_app_tg(i).v_bwmc_c	||	'<{||}>'||									
                                                                                        'BWMC_D1_REASON_X:'	|| lv_rec_pan_app_tg(i).v_bwmcd1reason_x	||	'<{||}>'||								
                                                                                        'BWMC_D1_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd1discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D2_I:'	||lv_rec_pan_app_tg(i).v_bwmcd2_i	||	'<{||}>'||								
                                                                                        'BWMC_D2_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd2discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D4_I:'	||lv_rec_pan_app_tg(i).v_bwmcd4_i	||	'<{||}>'||
                                                                                        'USER_TITLE_X:'	||lv_rec_pan_app_tg(i).v_usertitle	||	'<{||}>'||
                                                                                        'LOCN_X:'		||lv_rec_pan_app_tg(i).v_locn_x	||	'<{||}>'||
                                                                                        'TIME_STAMP_DT:'|| lv_rec_pan_app_tg(i).v_timestamp_dt	||	'<{||}>'||
                                                                                        'ARMS_AMMUNITION_I:'||lv_rec_pan_app_tg(i).v_armsammunition_i	||	'<{||}>'||
                                                                                        'ARMS_TYPE_X:'	||lv_rec_pan_app_tg(i).v_armsType_x        	||	'<{||}>'||																		
                                                                                        'DG_CGO_MANF_I:'||lv_rec_pan_app_tg(i).v_dgcargopc_i	||	'<{||}>'||									
                                                                                        'PASSN_LIST_ICA_I:'	||	 lv_rec_pan_app_tg(i).v_paxlst_i	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETA_DT:'	||	 lv_rec_pan_app_tg(i).v_eta_dt	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETD_DT:'	||	 lv_rec_pan_app_tg(i).v_etd_dt	||	'<{||}>'||
                                                                                        'GRS_TNG_N:'	||	 lv_rec_pan_app_tg(i).v_vslgt_q	||	'<{||}>'||								
                                                                                        'ETA_DT:'		||	 lv_rec_pan_app_tg(i).v_BWMC_ETA_DT	||	'<{||}>'||
                                                                                        'VALID_BCC_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_validbcc_i)	||	'<{||}>'||
                                                                                        'MAN_REM_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_manRem_i)	||	'<{||}>'||									
                                                                                        'USER_ID_X:'	||	 lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||				
                                                                                        'CRT_BY_N:'	||	 lv_rec_pan_app_tg(i).v_userId_n	||	'<{||}>'||
                                                                                        'CRT_ON_DT:'||	 lv_rec_pan_app_tg(i).v_reportdate_dt;


                                                                pkg_datamigration_generic.proc_trace_exception('pan_APPLICATION', 'proc_2_pan_app', dbms_utility.format_error_backtrace,'ERROR',
                                                                                                                                                            PV_RUN_ID,SQLERRM, v_exp_rows,'T');                                                                                       


                                                                continue;

                                                              END;     ---begin end for pan application




                                 /************************************************************************************************************************************

                                                                                               PURPOSE OF CALL  

                                 ******************************************************************************************************************************************/




             v_len:=   length(Trim(lv_rec_pan_app_tg(i).v_purposecall_c));

              WHILE v_len > 0
              LOOP    --start while loop

                   ---logic for purposeof call---

                   v_regex:=  nvl(substr(regexp_substr(trim(lv_rec_pan_app_tg(i).v_purposecall_c), '[0-9]+', 1, v_len), 1, 1), 0);

                    IF v_regex <> 0 THEN
                        v_cnt_poc := v_cnt_poc + 1;
                        IF v_regex = 1 THEN 

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Cargo Operation',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );
                           EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Cargo Operation' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Cargo Operation' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;

                        ELSIF v_regex = 2 THEN

                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Embarking/disembarking Passenger',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );

                                EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Embarking/disembarking Passenger' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Embarking/disembarking Passenger' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;


                        ELSIF v_regex = 3 THEN

                        begin 


                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Taking Bunkers',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                             EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Taking Bunkers' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Taking Bunkers' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;



                        ELSIF v_regex = 4 THEN

                        begin 
                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Taking Suppliers',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Taking Suppliers' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Taking Suppliers' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;


                        ELSIF v_regex = 5 THEN

                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Changing Crew',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                           EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Changing Crew' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Changing Crew' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;


                        ELSIF v_regex = 6 THEN

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                               seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Repair/Docking/Outfitting',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Repair/Docking/Outfitting' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Repair/Docking/Outfitting' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;



                        ELSIF v_regex = 7 THEN

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Offshore Vessel',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );


                              EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Offshore Vessel' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Offshore Vessel' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;



                        ELSIF v_regex = 9 THEN


                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'others',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'others' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0
						 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'others' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                            end;


                        END IF;

                    END IF;

                    v_len := v_len - 1;
               END LOOP;    
                                           ----end while loop for purpose of call c




----transformation logic for anchpurpose-----

           v_len2:=  length(trim(lv_rec_pan_app_tg(i).v_anchpurpose_c));                   

           WHILE v_len2 > 0 LOOP    
                  ---start while loop for anchorpurpose of call
                v_regexx:=   nvl(substr(trim(regexp_substr(lv_rec_pan_app_tg(i).v_anchpurpose_c, '[0-9]+', 1,v_len2)), 1, 1), 0);
                --- dbms_output.put_line(' v_regexx : ' || v_regexx);

                    IF v_regexx <> 0 THEN
                        v_cnt_poc := v_cnt_poc + 1;
                    begin 

                        INSERT INTO pan_purpose_of_call (
                            pan_purp_of_call_id_n,
                            appln_ref_n,
                            purpcall_c,
                            others_purpose_x,
                            arrival_purpse_c,
                            lock_ver_n,
                            deleted_i
                        ) VALUES (
                             seq_pan_purp.nextval,
                                seq_pan_app.currval,
                            v_regexx,
                            lv_rec_pan_app_tg(i).v_anchpurpose_x,
                            'ANCHORAGE',
                            0,
                            0
                        );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'proc_2_pan_app',

							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || v_regexx ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'ANCHORAGE' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
					seq_pan_purp.CURRVAL ||'<{||}>'||
					seq_pan_app.CURRVAL ||'<{||}>'||
					 v_regexx ||'<{||}>'||
					lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
					'ANCHORAGE' ||'<{||}>'||
					0 ||'<{||}>'||
					0
							 ,
							 'T'
							 );

                            end;



                    END IF;

                 v_len2 := v_len2 - 1;

                END LOOP;                   --END WHILE LOOP



                             end if ;  -- if V_FLAG is null



 commit;

 exception              -- inner exception  when  any exception occurs in JSON or sequence reset

      WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := sqlerrm;
            v_sqlerrm := dbms_utility.format_error_backtrace|| v_err_code || v_err_msg||dbms_utility.format_call_stack;

            pkg_datamigration_generic.proc_trace_exception('JSON_EXCEPTION' , 'PROC_2_PAN_APP', dbms_utility.format_error_backtrace , 'ERROR',PV_RUN_ID,dbms_utility.format_error_stack ||v_sqlerrm, V_YEAR_MONTH  ,'T');

 continue;

end;  -- inner end which covers only JSON



















      END LOOP;    ----end for loop
      COMMIT;

    END LOOP;     ---end cursor loop


CLOSE cur_tg_pan;  -- close cursor loop

 /****************************************************************************************/
---------------------------------------------------------------------------------------------------------------------------------------------


---RECON LOGIC FOR SI PAN APPLICATION------------





 SELECT
        COUNT(*)
    INTO v_m_src_count
    FROM
        st_pans_pansinfofrmrlog    a,
        st_pans_pansinfofrmrlog2   b,
        st_pans_pansinfofrmrlog3   c,
        ST_PTMS_BWMC e,
        ST_PTMS_NOAFREFORMHIST f,
        VESSEL   d
      WHERE
        a.pansid_n = b.pansid_n       
        AND a.pansid_n = c.pansid_n   
        and a.pansID_n = e.transID_n(+)
        and a.vslRecID_n = e.vslRecID_n(+)
        and a.pansID_n = f.pansID_n(+)    
        AND a.vslrecid_n = d.vsl_rec_id_n;  --QUERY 




    SELECT
        COUNT(*)
    INTO v_si_count                     ----COUNT FOR SI PN SPPLICATION
    FROM
        si_pan_application;



   if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into si_pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into SI_PAN_APPLICATION table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into SI_PAN_APPLICATION table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('SI_QUERY', v_m_src_count, 'SI_pan_application', v_si_count, 'N');    





    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    SELECT   COUNT(*)
    INTO v_m_src_count                     ----COUNT FOR SI PN SPPLICATION
    FROM   si_pan_application;




        select count(*)

        into v_si_count

        from pan_application;





   if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_application table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_application  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('si_pan_application', v_m_src_count, 'pan_application', v_si_count, 'N');     



   --------------------------------------------------------------------------------------------------------------------------------------------------------------


   ----
 select  count(*)
   into v_m_src_count
    from  st_pans_pansinfofrmrlog ;    ----driving table count


     select count(*)
        into v_si_count
       from pan_application;



      if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_application table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_application  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('st_pans_pansinfofrmrlog', v_m_src_count, 'pan_application', v_si_count, 'Y');     



 ----------------------------------------------------------------------------------------------------------------------------------------------------------  





  v_m_src_count :=  v_cnt_poc;



     select count(*)
        into v_si_count
       from pan_purpose_of_call;



      if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_purpose_of_call table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_purpose_of_call table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_PAN_APP', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_purpose_of_call  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('count of POC ', v_m_src_count, 'pan_purpose_of_call', v_si_count, 'Y');     






/*
    pkg_datamigration_generic.proc_migration_recon('SI_pan_application', v_si_count, 'pan_application', v_m_tgt_count, 'N');

    pkg_datamigration_generic.proc_migration_recon('ST_PANS_pansInfoFrMRLog',v_dr_st_count, 'PAN_APPLICATION', v_m_tgt_count,'Y');

    pkg_datamigration_generic.proc_migration_recon('SI_pan_application',v_cnt_poc, 'PAN_PURPOSE_OF_CALL', v_m_tgt_count1, 'Y');   ---FOR PAN_PURPOSE_OF_CALLL

*/

--------outer exception-----

EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;
        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_2_pan_appABC', v_sqlerrm, 'ERROR',PV_RUN_ID,NULL,NULL,'T');
END proc_2_pan_app;
/