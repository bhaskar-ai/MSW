create or replace PROCEDURE PROC_3_PUSH_MASTERS  IS

    
    
/***********************************************************************************************************
procedure name : PROC_3_PUSH_MASTERS
Created By     : Rohit Khool
Date           : 11-Jun-2019
Purpose        : To push master table records from MSW_DATA_MIGRATION schema to respective target schemas VESSEL_SERVICE.
Modified by    :
Modified date  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****
    CURSOR CR_VSL IS
    SELECT
        VL.MSW_VSL_ID_N,
		VL.VSL_REC_ID_N,
		VL.VSL_M,
		VL.OFFICIAL_N,
		VL.VSL_FLAG_C,
		VL.VSL_TYPE_ID_N,
		VL.CRAFT_TYPE_ID_N,
		VL.VSL_DWT_N,
		VL.ST_C,
		VL.VSL_CRAFT_LIC_N,
		VL.VSL_ATTAINABLE_HGT_Q,
		VL.VSL_YR_BLT_N,
		VL.PORT_OF_REGY_C,
		VL.PORT_N,
		VL.VSL_LEN_Q,
		VL.LOA_Q,
		VL.VSL_DEPTH_Q,
		VL.VSL_BRE_Q,
		VL.MECHANIC_PROPEL_I,
		VL.VSL_MMSI_N,
		VL.LOCK_VER_N,
		VL.CRT_ON_DT,
		VL.CRT_BY_X,
		VL.UPT_ON_DT,
		VL.UPT_BY_X,
		VL.GRS_TNG_N,
		VL.NET_TNG_N,
		VL.VSL_CALL_SIGN_N,
		VL.VSL_IMO_N,
		VL.VSL_OWNR,
		VL.DELETED_I
    FROM
        VESSEL VL;


	TYPE REC_VSL IS RECORD
	(V_MSW_VSL_ID_N		VESSEL.MSW_VSL_ID_N%TYPE	,
	V_VSL_REC_ID_N		VESSEL.VSL_REC_ID_N%TYPE	,
	V_VSL_M				VESSEL.VSL_M%TYPE	,
	V_OFFICIAL_N		VESSEL.OFFICIAL_N%TYPE	,
	V_VSL_FLAG_C		VESSEL.VSL_FLAG_C%TYPE	,
	V_VSL_TYPE_ID_N		VESSEL.VSL_TYPE_ID_N%TYPE	,
	V_CRAFT_TYPE_ID_N	VESSEL.CRAFT_TYPE_ID_N%TYPE	,
	V_VSL_DWT_N			VESSEL.VSL_DWT_N%TYPE	,
	V_ST_C				VESSEL.ST_C%TYPE	,
	V_VSL_CRAFT_LIC_N	VESSEL.VSL_CRAFT_LIC_N%TYPE	,
	V_VSL_ATTAINABLE_HGT_Q		VESSEL.VSL_ATTAINABLE_HGT_Q%TYPE	,
	V_VSL_YR_BLT_N		VESSEL.VSL_YR_BLT_N%TYPE	,
	V_PORT_OF_REGY_C	VESSEL.PORT_OF_REGY_C%TYPE	,
	V_PORT_N			VESSEL.PORT_N%TYPE	,
	V_VSL_LEN_Q			VESSEL.VSL_LEN_Q%TYPE	,
	V_LOA_Q				VESSEL.LOA_Q%TYPE	,
	V_VSL_DEPTH_Q		VESSEL.VSL_DEPTH_Q%TYPE	,
	V_VSL_BRE_Q			VESSEL.VSL_BRE_Q%TYPE	,
	V_MECHANIC_PROPEL_I	VESSEL.MECHANIC_PROPEL_I%TYPE	,
	V_VSL_MMSI_N		VESSEL.VSL_MMSI_N%TYPE	,
	V_LOCK_VER_N		VESSEL.LOCK_VER_N%TYPE	,
	V_CRT_ON_DT			VESSEL.CRT_ON_DT%TYPE	,
	V_CRT_BY_X			VESSEL.CRT_BY_X%TYPE	,
	V_UPT_ON_DT			VESSEL.UPT_ON_DT%TYPE	,
	V_UPT_BY_X			VESSEL.UPT_BY_X%TYPE	,
	V_GRS_TNG_N			VESSEL.GRS_TNG_N%TYPE	,
	V_NET_TNG_N			VESSEL.NET_TNG_N%TYPE	,
	V_VSL_CALL_SIGN_N	VESSEL.VSL_CALL_SIGN_N%TYPE	,
	V_VSL_IMO_N			VESSEL.VSL_IMO_N%TYPE	,
	V_VSL_OWNR			VESSEL.VSL_OWNR%TYPE	,
	V_DELETED_I			VESSEL.DELETED_I%TYPE	
	);

	CURSOR CR_VSL_CERT IS
	SELECT
		VC.VSL_CERT_ID_N,
		VC.MSW_VSL_ID_N,
		VC.CERT_TY_C,
		VC.ISS_AUTHY_CTRY_C,
		VC.ISSG_CL_C,
		VC.ISSD_DT,
		VC.DUE_DT,
		VC.DOC_ID_ATTH_N,
		VC.ST_C,
		VC.ISSG_CL_M,
		VC.LOCK_VER_N,
		VC.CRT_ON_DT,
		VC.CRT_BY_X,
		VC.UPT_ON_DT,
		VC.UPT_BY_X,
		VC.DELETED_I
	FROM VESSEL_CERTIFICATE VC;


	TYPE REC_VSL_CERT IS RECORD
	(V_VSL_CERT_ID_N		VESSEL_CERTIFICATE.VSL_CERT_ID_N%TYPE	,
	V_MSW_VSL_ID_N			VESSEL_CERTIFICATE.MSW_VSL_ID_N%TYPE	,
	V_CERT_TY_C				VESSEL_CERTIFICATE.CERT_TY_C%TYPE	,
	V_ISS_AUTHY_CTRY_C		VESSEL_CERTIFICATE.ISS_AUTHY_CTRY_C%TYPE	,
	V_ISSG_CL_C				VESSEL_CERTIFICATE.ISSG_CL_C%TYPE	,
	V_ISSD_DT				VESSEL_CERTIFICATE.ISSD_DT%TYPE	,
	V_DUE_DT				VESSEL_CERTIFICATE.DUE_DT%TYPE	,
	V_DOC_ID_ATTH_N			VESSEL_CERTIFICATE.DOC_ID_ATTH_N%TYPE	,
	V_ST_C					VESSEL_CERTIFICATE.ST_C%TYPE	,
	V_ISSG_CL_M				VESSEL_CERTIFICATE.ISSG_CL_M%TYPE	,
	V_LOCK_VER_N			VESSEL_CERTIFICATE.LOCK_VER_N%TYPE	,
	V_CRT_ON_DT				VESSEL_CERTIFICATE.CRT_ON_DT%TYPE	,
	V_CRT_BY_X				VESSEL_CERTIFICATE.CRT_BY_X%TYPE	,
	V_UPT_ON_DT				VESSEL_CERTIFICATE.UPT_ON_DT%TYPE	,
	V_UPT_BY_X				VESSEL_CERTIFICATE.UPT_BY_X%TYPE	,
	V_DELETED_I				VESSEL_CERTIFICATE.DELETED_I%TYPE
	);

	CURSOR CR_VSL_CERT_ATR IS
	SELECT
		VCA.VSL_CERT_ATTRB_ID_N,
		VCA.VSL_CERT_ID_N,
		VCA.REG_ST_C,
		VCA.PERS_ALLW_Q,
		VCA.SOPEP_SMPEP_ONBD_I,
		VCA.IN_COMPLY_MARPOL_REGU19_I,
		VCA.IN_COMPLY_MARPOL_REGU20_I,
		VCA.IN_COMPLY_MARPOL_REGU21_I,
		VCA.CRT_ON_DT,
		VCA.CRT_BY_X,
		VCA.UPT_ON_DT,
		VCA.UPT_BY_X,
		VCA.LOCK_VER_N,
		VCA.DELETED_I
	FROM VESSEL_CERTIFICATE_ATTRIBUTES VCA;

	TYPE REC_VSL_CERT_ATR IS RECORD
	(V_VSL_CERT_ATTRB_ID_N		VESSEL_CERTIFICATE_ATTRIBUTES.VSL_CERT_ATTRB_ID_N%TYPE	,
	V_VSL_CERT_ID_N				VESSEL_CERTIFICATE_ATTRIBUTES.VSL_CERT_ID_N%TYPE	,
	V_REG_ST_C					VESSEL_CERTIFICATE_ATTRIBUTES.REG_ST_C%TYPE	,
	V_PERS_ALLW_Q				VESSEL_CERTIFICATE_ATTRIBUTES.PERS_ALLW_Q%TYPE	,
	V_SOPEP_SMPEP_ONBD_I		VESSEL_CERTIFICATE_ATTRIBUTES.SOPEP_SMPEP_ONBD_I%TYPE	,
	V_IN_COMPLY_MARPOL_REGU19_I		VESSEL_CERTIFICATE_ATTRIBUTES.IN_COMPLY_MARPOL_REGU19_I%TYPE	,
	V_IN_COMPLY_MARPOL_REGU20_I		VESSEL_CERTIFICATE_ATTRIBUTES.IN_COMPLY_MARPOL_REGU20_I%TYPE	,
	V_IN_COMPLY_MARPOL_REGU21_I		VESSEL_CERTIFICATE_ATTRIBUTES.IN_COMPLY_MARPOL_REGU21_I%TYPE	,
	V_CRT_ON_DT					VESSEL_CERTIFICATE_ATTRIBUTES.CRT_ON_DT%TYPE	,
	V_CRT_BY_X					VESSEL_CERTIFICATE_ATTRIBUTES.CRT_BY_X%TYPE	,
	V_UPT_ON_DT					VESSEL_CERTIFICATE_ATTRIBUTES.UPT_ON_DT%TYPE	,
	V_UPT_BY_X					VESSEL_CERTIFICATE_ATTRIBUTES.UPT_BY_X%TYPE	,
	V_LOCK_VER_N				VESSEL_CERTIFICATE_ATTRIBUTES.LOCK_VER_N%TYPE	,
	V_DELETED_I					VESSEL_CERTIFICATE_ATTRIBUTES.DELETED_I%TYPE	
	);





	TYPE TYPE_VSL  IS TABLE OF REC_VSL;
	LV_VSL				TYPE_VSL;

	TYPE TYPE_VSL_CERT  IS TABLE OF REC_VSL_CERT;
	LV_VSL_CERT				TYPE_VSL_CERT;

	TYPE TYPE_VSL_CERT_ATR  IS TABLE OF REC_VSL_CERT_ATR;
	LV_VSL_CERT_ATR				TYPE_VSL_CERT_ATR;

	LV_CNT_DM_VL        NUMBER;
	LV_CNT_TT_VL		NUMBER;
	LV_CNT_DM_VC        NUMBER;
	LV_CNT_TT_VC		NUMBER;
	LV_CNT_DM_VCA        NUMBER;
	LV_CNT_TT_VCA		NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);
	V_BLKEXPTN_COUNT    NUMBER(20, 0);
	V_BLKEXPTN_DESC     VARCHAR2(3000);
    V_EXP_ROWS          VARCHAR2(1000);
    V_EXP_ROWS1         VARCHAR2(1000);
    V_EXP_ROWS2         VARCHAR2(1000);
    V_EXP_ROWS3         VARCHAR2(1000);
    V_EXP_ROWS4         VARCHAR2(1000);
    V_EXP_ROWS5         VARCHAR2(1000);
    V_EXP_ROWS6         VARCHAR2(1000);
    V_EXP_ROWS7         VARCHAR2(1000);
    V_EXP_ROWS8         VARCHAR2(1000);
    V_EXP_ROWS9         VARCHAR2(1000);
    V_EXP_ROWS10        VARCHAR2(1000);


BEGIN
    SELECT
    COUNT(*) INTO LV_CNT_DM_VL
    FROM
    VESSEL;

	SELECT
    COUNT(*) INTO LV_CNT_DM_VC
    FROM
    VESSEL_CERTIFICATE;

	SELECT
    COUNT(*) INTO LV_CNT_DM_VCA
    FROM
    VESSEL_CERTIFICATE_ATTRIBUTES;


	OPEN  CR_VSL;
	pkg_datamigration_generic.proc_trace_exception('DM_VESSEL', 'PROC_3_PUSH_MASTERS', 'Insertion into target Table VESSEL', 'START');

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.VESSEL and inseting into target table VESSEL_SERVICE.VESSEL ************------------------        
        BEGIN 

			FETCH CR_VSL BULK COLLECT INTO LV_VSL LIMIT 10000;
            EXIT WHEN LV_VSL.count = 0;
			FORALL i IN LV_VSL.first..LV_VSL.last SAVE EXCEPTIONS         
-------------************ SYN_VSL is synonym of VESSEL_SERVICE.VESSEL  ************------------------  

            INSERT INTO SYN_VSL (
								MSW_VSL_ID_N,
								VSL_REC_ID_N,
								VSL_M,
								OFFICIAL_N,
								VSL_FLAG_C,
								VSL_TYPE_ID_N,
								CRAFT_TYPE_ID_N,
								VSL_DWT_N,
								ST_C,
								VSL_CRAFT_LIC_N,
								VSL_ATTAINABLE_HGT_Q,
								VSL_YR_BLT_N,
								PORT_OF_REGY_C,
								PORT_N,
								VSL_LEN_Q,
								LOA_Q,
								VSL_DEPTH_Q,
								VSL_BRE_Q,
								MECHANIC_PROPEL_I,
								VSL_MMSI_N,
								LOCK_VER_N,
								CRT_ON_DT,
								CRT_BY_X,
								UPT_ON_DT,
								UPT_BY_X,
								GRS_TNG_N,
								NET_TNG_N,
								VSL_CALL_SIGN_N,
								VSL_IMO_N,
								VSL_OWNR,
								DELETED_I
								) 

						VALUES (
								LV_VSL(i).V_MSW_VSL_ID_N	,
								LV_VSL(i).V_VSL_REC_ID_N	,
								LV_VSL(i).V_VSL_M	,
								LV_VSL(i).V_OFFICIAL_N	,
								LV_VSL(i).V_VSL_FLAG_C	,
								LV_VSL(i).V_VSL_TYPE_ID_N	,
								LV_VSL(i).V_CRAFT_TYPE_ID_N	,
								LV_VSL(i).V_VSL_DWT_N	,
								LV_VSL(i).V_ST_C	,
								LV_VSL(i).V_VSL_CRAFT_LIC_N	,
								LV_VSL(i).V_VSL_ATTAINABLE_HGT_Q	,
								LV_VSL(i).V_VSL_YR_BLT_N	,
								LV_VSL(i).V_PORT_OF_REGY_C	,
								LV_VSL(i).V_PORT_N	,
								LV_VSL(i).V_VSL_LEN_Q	,
								LV_VSL(i).V_LOA_Q	,
								LV_VSL(i).V_VSL_DEPTH_Q	,
								LV_VSL(i).V_VSL_BRE_Q	,
								LV_VSL(i).V_MECHANIC_PROPEL_I	,
								LV_VSL(i).V_VSL_MMSI_N	,
								LV_VSL(i).V_LOCK_VER_N	,
								LV_VSL(i).V_CRT_ON_DT	,
								LV_VSL(i).V_CRT_BY_X	,
								LV_VSL(i).V_UPT_ON_DT	,
								LV_VSL(i).V_UPT_BY_X	,
								LV_VSL(i).V_GRS_TNG_N	,
								LV_VSL(i).V_NET_TNG_N	,
								LV_VSL(i).V_VSL_CALL_SIGN_N	,
								LV_VSL(i).V_VSL_IMO_N	,
								LV_VSL(i).V_VSL_OWNR	,
								LV_VSL(i).V_DELETED_I	
								);


        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;
            V_BLKEXPTN_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
            FOR k IN 1..V_BLKEXPTN_COUNT LOOP
                  -- Print out details of each error during bulk insert
                V_BLKEXPTN_DESC := 'Error#: '
                                   || k
                                   || '; Row Number : '
                                   || SQL%bulk_exceptions(k).error_index
                                   || ' message: '
                                   || sqlerrm
                                   || SQL%bulk_exceptions(k).error_code
                                   || ' i2T'
                                   || sqlerrm(0 - SQL%bulk_exceptions(k).error_code);
			    v_exp_rows1 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_MSW_VSL_ID_N ;
                v_exp_rows2 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_REC_ID_N   ;
                v_exp_rows3 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_M ;
                v_exp_rows4 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_OFFICIAL_N    ;
                v_exp_rows5 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_FLAG_C    ;
                v_exp_rows6 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_TYPE_ID_N  ;
                v_exp_rows7 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_CRAFT_TYPE_ID_N ;
                v_exp_rows8 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_DWT_N   ;
                v_exp_rows9 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_ST_C ;
                v_exp_rows10 := LV_VSL(SQL%bulk_exceptions(k).error_index).V_VSL_CRAFT_LIC_N ;

                v_exp_rows := 'MSW_VSL_ID_N '
                              || v_exp_rows1
                              || 'VSL_REC_ID_N'
                              || v_exp_rows2
                              || 'VSL_M '
                              || v_exp_rows3
                              || 'OFFICIAL_N'
                              || v_exp_rows4
                              || 'VSL_FLAG_C    '
                              || v_exp_rows5
                              || 'VSL_TYPE_ID_N '
                              || v_exp_rows6
                              || 'CRAFT_TYPE_ID_N '
                              || v_exp_rows7
                              || 'VSL_DWT_N '
                              || v_exp_rows8
                              || 'ST_C '
                              || v_exp_rows9
                              || 'VSL_CRAFT_LIC_N'
                              || v_exp_rows10
                              || '....'
                              ;

             pkg_datamigration_generic.proc_trace_exception('DM_VESSEL', 'PROC_3_PUSH_MASTERS', v_exp_rows
                                                                                                       || v_blkexptn_desc
                                                                                                       || v_sqlerrm, 'ERROR');


			END LOOP;

        END;
    END LOOP;
	CLOSE CR_VSL;	

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_VL
     FROM
     SYN_VSL;

	IF( LV_CNT_TT_VL =  LV_CNT_DM_VL ) AND LV_CNT_DM_VL <>  0  AND  LV_CNT_TT_VL <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VL||' OUT OF ' || LV_CNT_TT_VL ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL' ,
        'SUCCESS');

    ELSIF  LV_CNT_DM_VL  <> LV_CNT_TT_VL AND  LV_CNT_DM_VL <> 0 AND  LV_CNT_TT_VL <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VL||' OUT OF ' || LV_CNT_TT_VL ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL' ,
        'PARTIALLY SUCCESSFULL');


    ELSIF  LV_CNT_DM_VL  <> 0 AND  LV_CNT_TT_VL = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VL||' OUT OF ' || LV_CNT_TT_VL ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL' ,
        'FAIL');

    END IF;   



    pkg_datamigration_generic.proc_migration_recon('DM_VESSEL', LV_CNT_DM_VL, 'VESSEL', LV_CNT_TT_VL,'Y');


	/***********************************************************************************************************
	Pushing records into VESSEL_SERVICE.VESSEL_CERTIFICATE
    ***********************************************************************************************************/

	OPEN  CR_VSL_CERT;
	pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CERTIFICATE', 'PROC_3_PUSH_MASTERS', 'Insertion into target Table VESSEL_SERVICE.VESSEL_CERTIFICATE', 'START');

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.VESSEL_CERTIFICATE and inseting into target table VESSEL_SERVICE.VESSEL_CERTIFICATE ************------------------        
        BEGIN 

			FETCH CR_VSL_CERT BULK COLLECT INTO LV_VSL_CERT LIMIT 10000;
            EXIT WHEN LV_VSL_CERT.count = 0;
			FORALL i IN LV_VSL_CERT.first..LV_VSL_CERT.last SAVE EXCEPTIONS         
-------------************ SYN_VSL_CERT is synonym of VESSEL_SERVICE.VESSEL_CERTIFICATE  ************------------------  

            INSERT INTO SYN_VSL_CERT (
								VSL_CERT_ID_N,
                                MSW_VSL_ID_N,
                                CERT_TY_C,
                                ISS_AUTHY_CTRY_C,
                                ISSG_CL_C,
                                ISSD_DT,
                                DUE_DT,
                                DOC_ID_ATTH_N,
                                ST_C,
                                ISSG_CL_M,
                                LOCK_VER_N,
                                CRT_ON_DT,
                                CRT_BY_X,
                                UPT_ON_DT,
                                UPT_BY_X,
                                DELETED_I

								) 

						VALUES (
								LV_VSL_CERT(i).V_VSL_CERT_ID_N,
								LV_VSL_CERT(i).V_MSW_VSL_ID_N,
								LV_VSL_CERT(i).V_CERT_TY_C,
								LV_VSL_CERT(i).V_ISS_AUTHY_CTRY_C,
								LV_VSL_CERT(i).V_ISSG_CL_C,
								LV_VSL_CERT(i).V_ISSD_DT,
								LV_VSL_CERT(i).V_DUE_DT,
								LV_VSL_CERT(i).V_DOC_ID_ATTH_N,
								LV_VSL_CERT(i).V_ST_C,
								LV_VSL_CERT(i).V_ISSG_CL_M,
								LV_VSL_CERT(i).V_LOCK_VER_N,
								LV_VSL_CERT(i).V_CRT_ON_DT,
								LV_VSL_CERT(i).V_CRT_BY_X,
								LV_VSL_CERT(i).V_UPT_ON_DT,
								LV_VSL_CERT(i).V_UPT_BY_X,
								LV_VSL_CERT(i).V_DELETED_I
								);


        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;
            V_BLKEXPTN_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
            FOR k IN 1..V_BLKEXPTN_COUNT LOOP
                  -- Print out details of each error during bulk insert
                V_BLKEXPTN_DESC := 'Error#: '
                                   || k
                                   || '; Row Number : '
                                   || SQL%bulk_exceptions(k).error_index
                                   || ' message: '
                                   || sqlerrm
                                   || SQL%bulk_exceptions(k).error_code
                                   || ' i2T'
                                   || sqlerrm(0 - SQL%bulk_exceptions(k).error_code);
			    v_exp_rows1 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_VSL_CERT_ID_N ;
                v_exp_rows2 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_MSW_VSL_ID_N   ;
                v_exp_rows3 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_CERT_TY_C ;
                v_exp_rows4 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_ISS_AUTHY_CTRY_C    ;
                v_exp_rows5 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_ISSG_CL_C    ;
                v_exp_rows6 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_DUE_DT  ;
                v_exp_rows7 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_DOC_ID_ATTH_N ;
                v_exp_rows8 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_ST_C   ;
                v_exp_rows9 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_ISSG_CL_M ;
                v_exp_rows10 := LV_VSL_CERT(SQL%bulk_exceptions(k).error_index).V_LOCK_VER_N ;

                v_exp_rows := 'VSL_CERT_ID_N '
                              || v_exp_rows1
                              || 'VSL_REC_ID_N'
                              || v_exp_rows2
                              || 'CERT_TY_C '
                              || v_exp_rows3
                              || 'ISS_AUTHY_CTRY_C'
                              || v_exp_rows4
                              || 'ISSG_CL_C    '
                              || v_exp_rows5
                              || 'DUE_DT '
                              || v_exp_rows6
                              || 'DOC_ID_ATTH_N '
                              || v_exp_rows7
                              || 'ST_C '
                              || v_exp_rows8
                              || 'ISSG_CL_M '
                              || v_exp_rows9
                              || 'LOCK_VER_N'
                              || v_exp_rows10
                              || '....'
                              ;

             pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CERTIFICATE', 'PROC_3_PUSH_MASTERS', v_exp_rows
                                                                                                       || v_blkexptn_desc
                                                                                                       || v_sqlerrm, 'ERROR');


			END LOOP;

        END;
    END LOOP;
	CLOSE CR_VSL_CERT;	

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_VC
     FROM
     SYN_VSL_CERT;

	IF( LV_CNT_TT_VC =  LV_CNT_DM_VC ) AND LV_CNT_DM_VC <>  0  AND  LV_CNT_TT_VC <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VC||' OUT OF ' || LV_CNT_TT_VC ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE' ,
        'SUCCESS');

    ELSIF  LV_CNT_DM_VC  <> LV_CNT_TT_VC AND  LV_CNT_DM_VC <> 0 AND  LV_CNT_TT_VC <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VC||' OUT OF ' || LV_CNT_TT_VC ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE' ,
        'PARTIALLY SUCCESSFULL');


    ELSIF  LV_CNT_DM_VC  <> 0 AND  LV_CNT_TT_VC = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VC||' OUT OF ' || LV_CNT_TT_VC ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE' ,
        'FAIL');

    END IF;


    pkg_datamigration_generic.proc_migration_recon('DM_VESSEL_CERTIFICATE', LV_CNT_DM_VC, 'VESSEL_CERTIFICATE', LV_CNT_TT_VC,'Y');

	/***********************************************************************************************************
	Pushing records into VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES
    ***********************************************************************************************************/


OPEN  CR_VSL_CERT_ATR;
	pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_3_PUSH_MASTERS', 'Insertion into target Table VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES', 'START');

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.VESSEL_CERTIFICATE_ATTRIBUTES and inseting into target table VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES ************------------------        
        BEGIN 

			FETCH CR_VSL_CERT_ATR BULK COLLECT INTO LV_VSL_CERT_ATR LIMIT 10000;
            EXIT WHEN LV_VSL_CERT_ATR.count = 0;
			FORALL i IN LV_VSL_CERT_ATR.first..LV_VSL_CERT_ATR.last SAVE EXCEPTIONS         
-------------************ SYN_VSL_CERT_ATR is synonym of VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES  ************------------------  

            INSERT INTO SYN_VSL_CERT_ATR (
								VSL_CERT_ATTRB_ID_N,
								VSL_CERT_ID_N,
								REG_ST_C,
								PERS_ALLW_Q,
								SOPEP_SMPEP_ONBD_I,
								IN_COMPLY_MARPOL_REGU19_I,
								IN_COMPLY_MARPOL_REGU20_I,
								IN_COMPLY_MARPOL_REGU21_I,
								CRT_ON_DT,
								CRT_BY_X,
								UPT_ON_DT,
								UPT_BY_X,
								LOCK_VER_N,
								DELETED_I
								) 

						VALUES (
								LV_VSL_CERT_ATR(i).V_VSL_CERT_ATTRB_ID_N	,
								LV_VSL_CERT_ATR(i).V_VSL_CERT_ID_N	,
								LV_VSL_CERT_ATR(i).V_REG_ST_C	,
								LV_VSL_CERT_ATR(i).V_PERS_ALLW_Q	,
								LV_VSL_CERT_ATR(i).V_SOPEP_SMPEP_ONBD_I	,
								LV_VSL_CERT_ATR(i).V_IN_COMPLY_MARPOL_REGU19_I	,
								LV_VSL_CERT_ATR(i).V_IN_COMPLY_MARPOL_REGU20_I	,
								LV_VSL_CERT_ATR(i).V_IN_COMPLY_MARPOL_REGU21_I	,
								LV_VSL_CERT_ATR(i).V_CRT_ON_DT	,
								LV_VSL_CERT_ATR(i).V_CRT_BY_X	,
								LV_VSL_CERT_ATR(i).V_UPT_ON_DT	,
								LV_VSL_CERT_ATR(i).V_UPT_BY_X	,
								LV_VSL_CERT_ATR(i).V_LOCK_VER_N,
								LV_VSL_CERT_ATR(i).V_DELETED_I	
								);


        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;
            V_BLKEXPTN_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
            FOR k IN 1..V_BLKEXPTN_COUNT LOOP
                  -- Print out details of each error during bulk insert
                V_BLKEXPTN_DESC := 'Error#: '
                                   || k
                                   || '; Row Number : '
                                   || SQL%bulk_exceptions(k).error_index
                                   || ' message: '
                                   || sqlerrm
                                   || SQL%bulk_exceptions(k).error_code
                                   || ' i2T'
                                   || sqlerrm(0 - SQL%bulk_exceptions(k).error_code);
			    v_exp_rows1 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_VSL_CERT_ATTRB_ID_N ;
                v_exp_rows2 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_VSL_CERT_ID_N   ;
                v_exp_rows3 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_REG_ST_C ;
                v_exp_rows4 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_PERS_ALLW_Q    ;
                v_exp_rows5 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_SOPEP_SMPEP_ONBD_I    ;
                v_exp_rows6 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_IN_COMPLY_MARPOL_REGU19_I  ;
                v_exp_rows7 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_IN_COMPLY_MARPOL_REGU20_I ;
                v_exp_rows8 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_IN_COMPLY_MARPOL_REGU21_I   ;
                v_exp_rows9 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_CRT_ON_DT ;
                v_exp_rows10 := LV_VSL_CERT_ATR(SQL%bulk_exceptions(k).error_index).V_CRT_BY_X ;

                v_exp_rows := 'VSL_CERT_ATTRB_ID_N '
                              || v_exp_rows1
                              || ' VSL_CERT_ID_N '
                              || v_exp_rows2
                              || ' REG_ST_C '
                              || v_exp_rows3
                              || ' PERS_ALLW_Q '
                              || v_exp_rows4
                              || ' SOPEP_SMPEP_ONBD_I '
                              || v_exp_rows5
                              || ' IN_COMPLY_MARPOL_REGU19_I '
                              || v_exp_rows6
                              || ' IN_COMPLY_MARPOL_REGU20_I '
                              || v_exp_rows7
                              || ' IN_COMPLY_MARPOL_REGU21_I '
                              || v_exp_rows8
                              || ' CRT_ON_DT '
                              || v_exp_rows9
                              || ' CRT_BY_X'
                              || v_exp_rows10
                              || '....'
                              ;

             pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_3_PUSH_MASTERS', v_exp_rows
                                                                                                       || v_blkexptn_desc
                                                                                                       || v_sqlerrm, 'ERROR');


			END LOOP;

        END;
    END LOOP;
	CLOSE CR_VSL_CERT_ATR;	

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_VCA
     FROM
     SYN_VSL_CERT_ATR;

	IF( LV_CNT_TT_VCA =  LV_CNT_DM_VCA ) AND LV_CNT_DM_VCA <>  0  AND  LV_CNT_TT_VCA <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VCA||' OUT OF ' || LV_CNT_TT_VCA ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES' ,
        'SUCCESS');

    ELSIF  LV_CNT_DM_VCA  <> LV_CNT_TT_VCA AND  LV_CNT_DM_VCA <> 0 AND  LV_CNT_TT_VCA <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VCA||' OUT OF ' || LV_CNT_TT_VCA ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES' ,
        'PARTIALLY SUCCESSFULL');


    ELSIF  LV_CNT_DM_VCA  <> 0 AND  LV_CNT_TT_VCA = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_3_PUSH_MASTERS',
        LV_CNT_DM_VCA||' OUT OF ' || LV_CNT_TT_VCA ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_SERVICE.VESSEL_CERTIFICATE_ATTRIBUTES' ,
        'FAIL');

    END IF;


    COMMIT;


    pkg_datamigration_generic.proc_migration_recon('DM_VESSEL_CERTIFICATE_ATTRIBUTES', LV_CNT_DM_VCA, 'VESSEL_CERTIFICATE_ATTRIBUTES', LV_CNT_TT_VCA,'Y');

	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_VESSEL', 'PROC_3_PUSH_MASTERS', V_SQLERRM, 'ERROR');

END PROC_3_PUSH_MASTERS;
/