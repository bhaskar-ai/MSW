#!/bin/bash
echo "Start of Clean Up Truncating Tables"
sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
spool on
spool cleanup_script.log
@ cleanup_script.sql;
spool off;
EOF
echo "End of Tuncating the tables"
