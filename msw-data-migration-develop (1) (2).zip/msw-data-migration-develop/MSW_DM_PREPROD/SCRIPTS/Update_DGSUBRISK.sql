update  &DGDS_SCHEMA_NAME..dg_subrisk d set d.subrisk_c=
(select dm.subrisk_c from dg_subrisk dm where dm.subrisk_id=d.subrisk_id);
commit;
/