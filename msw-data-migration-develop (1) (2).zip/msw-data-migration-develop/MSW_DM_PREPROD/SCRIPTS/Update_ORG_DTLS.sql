update  &AUTH_SCHEMA_NAME..org_dtls a set a.CO_UEN_N=
(select b.UEN_N from ST_ORGCD_UEN b where b.ORG_C=a.ORG_C);
commit;
/