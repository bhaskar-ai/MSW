#!/bin/bash
echo "Start of Deployment"
sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
spool on
spool  clean_up_deploy.log
@ clean_up_deploy.sql;
spool off;
EOF
echo 'End of Script'
