#!/bin/bash
echo "Start of Grant"
sqlplus / as sysdba <<EOF
spool on
spool Grant.log
@ Grant_sequence.sql;
spool off;
EOF
echo "End of Grant Script"
