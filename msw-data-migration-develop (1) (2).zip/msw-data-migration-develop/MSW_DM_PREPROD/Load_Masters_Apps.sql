set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--DBMS_OUTPUT.PUT_line('1');
-- User Profile
PROC_1_ORG_CODE(lv_runid);
PROC_1_USR_DTLS(lv_runid);
PROC_1_USR_DTLS_PU(lv_runid);
PROC_1_ORG_DTLS(lv_runid);
PROC_1_ORG_DTLS_PU(lv_runid);
PROC_1_ORG_PRIVILEGES(lv_runid);
PROC_1_ORG_ST_AUDIT(lv_runid);
PROC_1_ICA_USR_REQUEST(lv_runid);
PROC_1_CREW_CO_REQ(lv_runid);
-- Master
SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL' AND FLOW='TRANSFORM';
--DBMS_OUTPUT.PUT_line('LV_CHK_RUN 2'||LV_CHK_RUN);
IF LV_CHK_RUN = 0 THEN 
proc_1_vsl(lv_cnt,lv_runid);
/*m if lv_cnt = 0 then 
insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL','Y',SYSDATE);
END IF;--LV_CNT

else 
--DBMS_OUTPUT.PUT_line('Inside slese 3');
	SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL_CERTIFICATE' AND FLOW='TRANSFORM';
--DBMS_OUTPUT.PUT_line('LV_CHK_RUN slese 3'||LV_CHK_RUN);
	if LV_CHK_RUN =0 then 
    --DBMS_OUTPUT.PUT_line('inside 5');
m*/	 --
proc_1_vsl_cert_for(lv_cnt,lv_runid);
    --DBMS_OUTPUT.PUT_line('inside 6 - '||lv_cnt);
/*m	if lv_cnt=0 then 
		insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL_CERTIFICATE','Y',SYSDATE);
	end if;--lv_cnt
	else 
    -- DBMS_OUTPUT.PUT_line('inside 7 - '||lv_cnt);
	SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL_CERTIFICATE_ATTRIBUTES' AND FLOW='TRANSFORM'; 
		if LV_CHK_RUN =0 then 
m*/			--
proc_1_vsl_cert_Attr(lv_runid);
/*m            insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL_CERTIFICATE_ATTRIBUTES','Y',SYSDATE);
		end if;
	end if; --LV_CHK_RUN VESSEL_CERTIFICATE
*/
END IF; --LV_CHK_RUN Vessel
-- Master
PROC_1_SUBSTANCE(lv_runid);
PROC_1_CRUISE_OPERATOR_CONTROL(lv_runid);
PROC_2_PATCH_VESSEL_AGENT;
-- Transaction
PROC_2_ARRGD_PURCAL(lv_runid);
PROC_1_ARRIVAL_GD_SHIPYARD_LOC(lv_runid);
PROC_AGD_JSON;
PROC_UPD_APP_DATA('AGD');
PROC_2_DEPGD_DEPOC(lv_runid);
PROC_1_DEP_GD_P_CLRCE_CERT(lv_runid);
PROC_1_DEP_GD_SHIPYARD_LOC(lv_runid);
PROC_DEP_JSON;
PROC_UPD_APP_DATA('GDD');
PROC_CGD_JSON;
PROC_UPD_APP_DATA('CGD');
PROC_2_PAN_APP_VCALL(lv_runid);
PROC_1_PSC(lv_runid);
PROC_1_PSA(lv_runid);
PROC_1_PASS_PORT(lv_runid);
PROC_1_PAN_JSON;
PROC_UPD_APP_DATA('PAN');
PROC_2_DG_APPL_VSLCALL(lv_runid);
PROC_DG_JSON;
PROC_UPD_APP_DATA('DGD');
PROC_2_HNS_APPL_VSLCALL(lv_runid);
-- Push User Profile
PROC_5_PUSH_ORG;
PROC_5_PUSH_ORG_ST_AUDIT;
PROC_2_PUSH_USR;
PROC_1_PUSH_ICA_USR_REQUEST;
--PROC_1_PUSH_CREW_CO_REQ;
-- Push Master
PROC_3_PUSH_MASTERS;
PROC_2_PUSH_DGCHEM_DGPSN;
PROC_1_PUSH_DGSUBRISK;
PROC_1_PUSH_SUBSTANCE;
PROC_1_PUSH_COC;
-- Push Transactional
PROC_3_PUSH_ARRGD;
PROC_3_PUSH_DEPGD;
PROC_2_PUSH_DGDS;
PROC_1_PUSH_DG_PSA_JPC;
PROC_2_PUSH_PA_POC;
PROC_3_PUSH_PSC_PSA_PPC;
PROC_2_PUSH_HNS;
PROC_3_PUSH_VC_AS_VR;

exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
   

end;
/
