#!/bin/bash
echo "Start of Deployment"
sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
spool on
spool  Deploy.log
@ Deploy.sql;
spool off;
EOF
echo 'End of Script'
