CREATE OR REPLACE PROCEDURE PROC_2_PATCH_VESSEL_AGENT IS

puId NUMBER;
mswId NUMBER;
ownerType VARCHAR2(10);
bizKey VARCHAR2(20);

TYPE t IS TABLE OF VESSEL%ROWTYPE;
vsls t;

CURSOR CR_VSL IS
SELECT * FROM VESSEL;

BEGIN
	
	OPEN  CR_VSL;
	LOOP
		FETCH CR_VSL BULK COLLECT INTO vsls LIMIT 10000;
        EXIT WHEN vsls.count = 0;
		FOR i IN vsls.first..vsls.last
		LOOP

		puId := NULL;
	    ownerType := NULL;
	    mswId := NULL;
	    bizKey := NULL;
	  
	  	SELECT PUID_N INTO puId FROM ST_CV_VSL WHERE VSLRECID_N = vsls(i).VSL_REC_ID_N;
	  
	  	IF puId IS NOT NULL THEN 
		  	SELECT NVL2(max(PUID_N), 'I', 'O') INTO ownerType FROM ST_PU_USRINDV WHERE PUID_N = puId;
		  	
		  	-- Organisation
		  	IF ownerType = 'O' THEN
		  		BEGIN
			  		SELECT ORG_C INTO bizKey FROM ST_PU_USRORG WHERE PUID_N = puId;
			  		SELECT MAX(a.ID_N) INTO mswId FROM ORG_DTLS o LEFT JOIN AUTH_PROFILE a ON o.ID_N = a.REFR_ID AND a.PROFILE_TY = 'ORGANIZATION' WHERE o.ORG_C = bizKey;
				   	UPDATE VESSEL SET AGT_ID_N = mswId WHERE MSW_VSL_ID_N = vsls(i).MSW_VSL_ID_N;
			  	EXCEPTION
		   			WHEN NO_DATA_FOUND THEN
		   				NULL;
		   				--dbms_output.put_line ('sorry no agent found for '||vsls(i).VSL_REC_ID_N||':(' );
				END;
			-- Individual
			ELSE
				BEGIN
			  		SELECT NVL(ID_N,PASSPT_N) INTO bizKey FROM ST_PU_USRINDV WHERE PUID_N = puId;
			  		SELECT MAX(a.ID_N) INTO mswId FROM USR_DTLS u LEFT JOIN AUTH_PROFILE a ON u.ID_N = a.REFR_ID AND a.PROFILE_TY = 'INDIVIDUAL' WHERE u.USR_ID_N = bizKey;
			  	EXCEPTION
		   			WHEN NO_DATA_FOUND THEN
		   				NULL;
		   				--dbms_output.put_line ('sorry no agent found for '||vsls(i).VSL_REC_ID_N||':(' );
				END;
			END IF;
			UPDATE VESSEL SET AGT_ID_N = mswId WHERE MSW_VSL_ID_N = vsls(i).MSW_VSL_ID_N;
		ELSE
			NULL;
			--dbms_output.put_line ('puId is null for '||vsls(i).VSL_REC_ID_N||':(' );
	  	END IF;
  
  		END LOOP;
		commit;
  	END LOOP;
   COMMIT;
END PROC_2_PATCH_VESSEL_AGENT;
/