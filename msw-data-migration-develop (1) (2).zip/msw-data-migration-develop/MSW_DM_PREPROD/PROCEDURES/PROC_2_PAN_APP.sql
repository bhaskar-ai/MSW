create or replace PROCEDURE PROC_2_PAN_APP (PV_RUN_ID IN NUMBER) IS 


/***********************************************************************************************************
PROCEDURE NAME : PROC_2_PAN_APP
CREATED BY     : V. R. YEMBARWAR
DATE           : 10-MAY-2019
PURPOSE        : INSERTING  THE DATA FROM , ST_PANS_PANSINFOFRMRLOG ,ST_PANS_PANSINFOFRMRLOG2,
                 ST_PANS_PANSINFOFRMRLOG3, ST_PTMS_BWMC,ST_PTMS_NOAFREFORMHIST (STAGING TABLE) TO 
                 SI_PAN_APPLICATION(INTERMEDIATE TABLE) TO 
				 TARGET TABLE PAN_APPLICATION AND PAN_PURPOSE_OF_CALLS.
MODIFIED BY    :  C.N.BHASKAR
MODIFIED DATE  :  8-AUG-2019

*************************************************************************************************************/


 ---**** CURSOR FOR FETCHING DATA FROM SOURCE STAGING TABLE ****Z

    CURSOR CUR_SI_PAN IS
    SELECT 
		D.VSL_REC_ID_N,
        A.PANSID_N,
        D.MSW_VSL_ID_N,
        B.MVVOYAGENO_X,
        B.MVFWDDFT_Q,
        B.MVMIDDFT_Q,
        B.MVAFTDFT_Q,
        F.MVHGT_Q,
        A.VSLIMSCALLNO_C,
        A.CSONAME_X,
        A.CSOTELNO_C,
        A.AGENTNAME_X,
        A.LOCNLATLONG_X,
        A.LOCNLONG_X,
        A.AGENTTELNO_C,
        A.AGENTFAXNO_C,
        F.AGENTEMAIL,
        F.SHIPEMAIL,
        B.ANCHDAYSSTAY_N,
        B.ANCHETA_DT,
        B.ANCHETD_DT,
        A.CARGO_X,
        A.SHPSECPLAN_I,
        A.SECURITYLEVEL_C,
        B.SECURITYPER_I,
        F.SLOPSLUDGE_I,
        F.SLOPQTY_Q,
        F.SLUDGEQTY_Q,
        F.SSCONTENT_X,
        F.SSREPFAC_X,
        A.USERID_X,
        F.SAFETYREM_I,
        D.VSL_MMSI_N,
        A.CONAME_X,
        F.MVCONREM_I,
        F.FIREHZREM_I,
        B.ARMSSTRONGRM_I,
        B.ARMSSTRONGRMLOCN_X,
        F.MVREM_X,
        B.MVHMS_I,
        B.MVHMS_X,
        F.GPP_C,
        E.BWMC_I,
        E.IBWMC_I,
        E.BWMCEXEMPTED_I,
        E.BWMC_C,
        E.BWMCD1_I,
        E.BWMCD1REASON_X,
        E.BWMCD1DISCHARGE_I,
        E.BWMCD1DISCHARGE_Q,
        E.BWMCD2_I,
        E.BWMCD2REASON_I,
        E.BWMCD2DISCHARGE_I,
        E.BWMCD2DISCHARGE_Q,
        E.BWMCD4_I,
        A.USERTITLE,
        A.LOCN_X,
        A.TIMESTAMP_DT,
        B.ARMSAMMUNITION_I,
        B.ARMSTYPE_X,
        A.DGCARGO_C,
        A.DGCARGOPC_I,
        A.CREWLST_I,
        A.PAXLST_I,
        E.ETA_DT,
        B.ETD_DT,
        A.VSLGT_Q,
        E.ETA_DT  AS BWMC_ETA_DT ,
        C.VALIDBCC_I,
        F.MANREM_I,
        F. MVDIRNFR_C,
        A.REPORTDATE_DT,
        B.USERID_N,
        A.PURPOSECALL_C,
        A.OTHERSPURPOSE_X,
        B.ANCHPURPOSE_C,
        B.ANCHPURPOSE_X,
		A.VSLMVID_N,
        D.PORT_OF_REGY_C,
        D.VSL_CRAFT_LIC_N,
        D.VSL_NT_Q

    FROM
        ST_PANS_PANSINFOFRMRLOG    A,
        ST_PANS_PANSINFOFRMRLOG2   B,
        ST_PANS_PANSINFOFRMRLOG3   C,
        ST_PTMS_BWMC E,
        ST_PTMS_NOAFREFORM F,
        VESSEL   D
      WHERE
        A.PANSID_N = B.PANSID_N       
        AND A.PANSID_N = C.PANSID_N   
        AND A.PANSID_N = E.TRANSID_N(+)
        AND A.VSLRECID_N = E.VSLRECID_N(+)
        AND A.PANSID_N = F.PANSID_N(+)    
        AND A.VSLRECID_N = D.VSL_REC_ID_N;



-- DE CLARING THE 'RECORD TYPE'  TYPE TO SERVE AS THE DATATYPE OF COLLECTION VARIABLE  OF MAIN TABLE 

    V_DR_ST_COUNT          NUMBER;
    V_M_TGT_COUNT1         NUMBER;
    V_M_SRC_COUNT          NUMBER;
    V_SI_COUNT             NUMBER;
    V_M_TGT_COUNT          NUMBER;
    V_M_ERR_CODE           NUMBER;
    V_EXP_ROWS_SI          VARCHAR2(2500);
    V_M_ERR_MSG            VARCHAR2(200);
    V_M_SQLERRM            VARCHAR2(2500);
    V_ERR_CODE             VARCHAR2(1000);
    V_ERR_MSG              VARCHAR2(1000);
    V_SQLERRM              VARCHAR2(1000);
    V_BLKEXPTN_COUNT       VARCHAR2(10000);
    V_BLKEXPTN_DESC        VARCHAR2(10000);
    V_SRC_COUNT            NUMBER;  
    V_LEN                  VARCHAR2(10);
    V_LEN2                 VARCHAR2(20);
    V_REGEX                VARCHAR2(20);
    V_REGEXX               VARCHAR2(20); 
    V_CNT_POC              NUMBER := 0;
    L_VAL                  NUMBER;
    P_YYMM                 VARCHAR2(20);
    V_YEAR_MONTH           VARCHAR2(20) ;
    LV_DATA_LUMP           CLOB;
    V_FLAG                 VARCHAR2(1);
    V_VSL_REF_ID_OUT    NUMBER;

    V_FLAG_OUT   VARCHAR2(100);
    I_EXCEP_CNT   NUMBER := 0;
    I_EXCEP_CNT_POC  NUMBER := 0;
    I_EXCEP_CNT_SI   NUMBER := 0;
	V_VSL_CALL_ID 	NUMBER:=NULL;
	V_VSL_REF_ID_N	NUMBER:=NULL;


   CURSOR CUR_TG_PAN IS

    SELECT
			SI.VSL_REC_ID_N,
			SI.PANSID_N	,
			SI.MSW_VSL_ID_N	,
			SI.MVVOYAGENO_X	,
			SI.MVFWDDFT_Q	,
			SI.MVMIDDFT_Q	,
			SI.MVAFTDFT_Q	,
			SI.MVHGT_Q	,
			SI.VSLIMSCALLNO_C	,
			SI.CSONAME_X	,
			SI.CSOTELNO_C	,
			SI.AGENTNAME_X	,
			SI.LOCNLATLONG_X	,
			SI.LOCNLONG_X	,
			SI.AGENTTELNO_C	,
			SI.AGENTFAXNO_C	,
			SI.AGENTEMAIL	,
			SI.SHIPEMAIL	,
			SI.ANCHDAYSSTAY_N	,
			SI.ANCHETA_DT	,
			SI.ANCHETD_DT	,
			SI.CARGO_X	,
			SI.SHPSECPLAN_I	,
			SI.SECURITYLEVEL_C	,
			SI.SECURITYPER_I	,
			SI.SLOPSLUDGE_I	,
			SI.SLOPQTY_Q	,
			SI.SLUDGEQTY_Q	,
			SI.SSCONTENT_X	,
			SI.SSREPFAC_X	,
			SI.USERID_X	,
			SI.SAFETYREM_I	,
			SI.VSL_MMSI_N	,
			SI.CONAME_X	,
			SI.MVCONREM_I	,
			SI.FIREHZREM_I	,
			SI.ARMSSTRONGRM_I	,
			SI.ARMSSTRONGRMLOCN_X	,
			SI.MVREM_X	,
			SI.MVHMS_I	,
			SI.MVHMS_X	,
			SI.GPP_C	,
			SI.BWMC_I	,
			SI.IBWMC_I	,
			SI.BWMCEXEMPTED_I	,
			SI.BWMC_C	,
			SI.BWMCD1_I	,
			SI.BWMCD1REASON_X	,
			SI.BWMCD1DISCHARGE_I	,
			SI.BWMCD1DISCHARGE_Q	,
			SI.BWMCD2_I	,
			SI.BWMCD2REASON_I	,
			SI.BWMCD2DISCHARGE_I	,
			SI.BWMCD2DISCHARGE_Q	,
			SI.BWMCD4_I	,
			SI.USERTITLE	,
			SI.LOCN_X	,
			SI.TIMESTAMP_DT	,
			SI.ARMSAMMUNITION_I	,
			SI.ARMSTYPE_X	,
			SI.DGCARGO_C	,
			SI.DGCARGOPC_I	,
			SI.CREWLST_I	,
			SI.PAXLST_I	,
			SI.ETA_DT	,
			SI.ETD_DT	,
			SI.VSLGT_Q	,
			SI.BWMC_ETA_DT	,
			SI.VALIDBCC_I	,
			SI.MANREM_I	,
			SI.REPORTDATE_DT	,
			SI.USERID_N	,
			SI.MVDIRNFR_C	,
			SI.PURPOSECALL_C	,
			SI.OTHERSPURPOSE_X	,
			SI.ANCHPURPOSE_C ,
			SI.ANCHPURPOSE_X,
			SI.VSLMVID_N,
            SI2.MSW_APPLN_REF_ID_N AS MSW_APPLN_REF_ID_X,
			SI2.VSL_CALL_ID_N,
            SI.PORT_OF_REGY_C,    --NEWLY ADDED FOR VESSEL REFERENCE 
            SI.VSL_CRAFT_LIC_N, -- NEWLY ADDED FOR VESSEL REFERENCEE 
            SI.VSL_NT_Q       ,        -- NEWLY ADDED FOR VESSEL REFERENCE
            SI.SECRTY_REM_X,     --NEWLY ADDED BELOW COLUMNS FOR TARGET PAN APPLICATION TBALE
            SI.SUBMISSION_MODE,
            SI.SHP_ARR_DIRN_DESC_X,
            SI.P_LOCN_DESC_X,
            SI.SECU_LVL_SG_DESC_X,
            SI.LATD_DIRN_DESC_X,
            SI.LONGD_DIRN_DESC_X,
            SI.BWMC_COM_DESC_X,
            SI.BWMC_D1_RSN_DESC_X,
            SI.INTENDED_LOCN_DESC_X,
            SI.SEC_REF_I


    FROM
        SI_PAN_APPLICATION SI, SI_AS_VC_VR  SI2
        WHERE 
        TO_CHAR(SI.PANSID_N)= SI2.EXTL_APPLN_REF_ID_X(+)
        AND SI.MSW_VSL_ID_N    = SI2.MSW_VSL_ID_N(+)
        ORDER BY REPORTDATE_DT,MSW_APPLN_REF_ID_N;

    TYPE REC_PAN_APP_TG IS RECORD (

        V_VSL_REC_ID_N         SI_PAN_APPLICATION.VSL_REC_ID_N%TYPE,	
        V_PANSID_N             SI_PAN_APPLICATION.PANSID_N%TYPE,	
        V_MSW_VSL_ID_N         SI_PAN_APPLICATION.MSW_VSL_ID_N%TYPE,	
        V_MVVOYAGENO_X         SI_PAN_APPLICATION.MVVOYAGENO_X%TYPE,	
        V_MVFWDDFT_Q           SI_PAN_APPLICATION.MVFWDDFT_Q%TYPE,	
        V_MVMIDDFT_Q           SI_PAN_APPLICATION.MVMIDDFT_Q%TYPE,	
        V_MVAFTDFT_Q           SI_PAN_APPLICATION.MVAFTDFT_Q%TYPE,	
        V_MVHGT_Q              SI_PAN_APPLICATION.MVHGT_Q%TYPE,	
        V_VSLIMSCALLNO_C       SI_PAN_APPLICATION.VSLIMSCALLNO_C%TYPE,	
        V_CSONAME_X            SI_PAN_APPLICATION.CSONAME_X%TYPE,	
        V_CSOTELNO_C           SI_PAN_APPLICATION.CSOTELNO_C%TYPE,	
        V_AGENTNAME_X          SI_PAN_APPLICATION.AGENTNAME_X%TYPE,	
        V_LOCNLATLONG_X        SI_PAN_APPLICATION.LOCNLATLONG_X%TYPE,	
        V_LOCNLONG_X           SI_PAN_APPLICATION.LOCNLONG_X%TYPE,	
        V_AGENTTELNO_C         SI_PAN_APPLICATION.AGENTTELNO_C%TYPE,	
        V_AGENTFAXNO_C         SI_PAN_APPLICATION.AGENTFAXNO_C%TYPE,	
        V_AGENTEMAIL           SI_PAN_APPLICATION.AGENTEMAIL%TYPE,	
        V_SHIPEMAIL            SI_PAN_APPLICATION.SHIPEMAIL%TYPE,	
        V_ANCHDAYSSTAY_N       SI_PAN_APPLICATION.ANCHDAYSSTAY_N%TYPE,	
        V_ANCHETA_DT           SI_PAN_APPLICATION.ANCHETA_DT%TYPE,	
        V_ANCHETD_DT           SI_PAN_APPLICATION.ANCHETD_DT%TYPE,	
        V_CARGO_X              SI_PAN_APPLICATION.CARGO_X%TYPE,	
        V_SHPSECPLAN_I         SI_PAN_APPLICATION.SHPSECPLAN_I%TYPE,	
        V_SECURITYLEVEL_C      SI_PAN_APPLICATION.SECURITYLEVEL_C%TYPE,	
        V_SECURITYPER_I        SI_PAN_APPLICATION.SECURITYPER_I%TYPE,	
        V_SLOPSLUDGE_I         SI_PAN_APPLICATION.SLOPSLUDGE_I%TYPE,	
        V_SLOPQTY_Q            SI_PAN_APPLICATION.SLOPQTY_Q%TYPE,	
        V_SLUDGEQTY_Q          SI_PAN_APPLICATION.SLUDGEQTY_Q%TYPE,	
        V_SSCONTENT_X          SI_PAN_APPLICATION.SSCONTENT_X%TYPE,	
        V_SSREPFAC_X           SI_PAN_APPLICATION.SSREPFAC_X%TYPE,	
        V_USERID_X             SI_PAN_APPLICATION.USERID_X%TYPE,	
        V_SAFETYREM_I          SI_PAN_APPLICATION.SAFETYREM_I%TYPE,	
        V_VSL_MMSI_N           SI_PAN_APPLICATION.VSL_MMSI_N%TYPE,	
        V_CONAME_X             SI_PAN_APPLICATION.CONAME_X%TYPE,	
        V_MVCONREM_I           SI_PAN_APPLICATION.MVCONREM_I%TYPE,	
        V_FIREHZREM_I          SI_PAN_APPLICATION.FIREHZREM_I%TYPE,	
        V_ARMSSTRONGRM_I       SI_PAN_APPLICATION.ARMSSTRONGRM_I%TYPE,	
        V_ARMSSTRONGRMLOCN_X   SI_PAN_APPLICATION.ARMSSTRONGRMLOCN_X%TYPE,	
        V_MVREM_X              SI_PAN_APPLICATION.MVREM_X%TYPE,	
        V_MVHMS_I              SI_PAN_APPLICATION.MVHMS_I%TYPE,	
        V_MVHMS_X              SI_PAN_APPLICATION.MVHMS_X%TYPE,	
        V_GPP_C                SI_PAN_APPLICATION.GPP_C%TYPE,	
        V_BWMC_I               SI_PAN_APPLICATION.BWMC_I%TYPE,	
        V_IBWMC_I              SI_PAN_APPLICATION.IBWMC_I%TYPE,	
        V_BWMCEXEMPTED_I       SI_PAN_APPLICATION.BWMCEXEMPTED_I%TYPE,	
        V_BWMC_C               SI_PAN_APPLICATION.BWMC_C%TYPE,	
        V_BWMCD1_I             SI_PAN_APPLICATION.BWMCD1_I%TYPE,	
        V_BWMCD1REASON_X       SI_PAN_APPLICATION.BWMCD1REASON_X%TYPE,	
        V_BWMCD1DISCHARGE_I    SI_PAN_APPLICATION.BWMCD1DISCHARGE_I%TYPE,	
        V_BWMCD1DISCHARGE_Q    SI_PAN_APPLICATION.BWMCD1DISCHARGE_Q%TYPE,	
        V_BWMCD2_I             SI_PAN_APPLICATION.BWMCD2_I%TYPE,	
        V_BWMCD2REASON_I       SI_PAN_APPLICATION.BWMCD2REASON_I%TYPE,	
        V_BWMCD2DISCHARGE_I    SI_PAN_APPLICATION.BWMCD2DISCHARGE_I%TYPE,	
        V_BWMCD2DISCHARGE_Q    SI_PAN_APPLICATION.BWMCD2DISCHARGE_Q%TYPE,	
        V_BWMCD4_I             SI_PAN_APPLICATION.BWMCD4_I%TYPE,	
        V_USERTITLE            SI_PAN_APPLICATION.USERTITLE%TYPE,	
        V_LOCN_X               SI_PAN_APPLICATION.LOCN_X%TYPE,	
        V_TIMESTAMP_DT         SI_PAN_APPLICATION.TIMESTAMP_DT%TYPE,	
        V_ARMSAMMUNITION_I     SI_PAN_APPLICATION.ARMSAMMUNITION_I%TYPE,	
        V_ARMSTYPE_X           SI_PAN_APPLICATION.ARMSTYPE_X%TYPE,	
        V_DGCARGO_C            SI_PAN_APPLICATION.DGCARGO_C%TYPE,	
        V_DGCARGOPC_I          SI_PAN_APPLICATION.DGCARGOPC_I%TYPE,	
        V_CREWLST_I            SI_PAN_APPLICATION.CREWLST_I%TYPE,	
        V_PAXLST_I             SI_PAN_APPLICATION.PAXLST_I%TYPE,	
        V_ETA_DT               SI_PAN_APPLICATION.ETA_DT%TYPE,	
        V_ETD_DT               SI_PAN_APPLICATION.ETD_DT%TYPE,	
        V_VSLGT_Q              SI_PAN_APPLICATION.VSLGT_Q%TYPE,	
        V_BWMC_ETA_DT          SI_PAN_APPLICATION.BWMC_ETA_DT%TYPE,	
        V_VALIDBCC_I           SI_PAN_APPLICATION.VALIDBCC_I%TYPE,	
        V_MANREM_I             SI_PAN_APPLICATION.MANREM_I%TYPE,	
        V_REPORTDATE_DT        SI_PAN_APPLICATION.REPORTDATE_DT%TYPE,	
        V_USERID_N             SI_PAN_APPLICATION.USERID_N%TYPE,
        V_MVDIRNFR_C           SI_PAN_APPLICATION.MVDIRNFR_C%TYPE,
        V_PURPOSECALL_C        SI_PAN_APPLICATION.PURPOSECALL_C%TYPE,	
        V_OTHERSPURPOSE_X      SI_PAN_APPLICATION.OTHERSPURPOSE_X%TYPE,	
        V_ANCHPURPOSE_C        SI_PAN_APPLICATION.ANCHPURPOSE_C%TYPE,	
        V_ANCHPURPOSE_X        SI_PAN_APPLICATION.ANCHPURPOSE_X%TYPE,
		V_VSLMVID_N            SI_PAN_APPLICATION.VSLMVID_N%TYPE,
        V_MSW_APPLN_REF_ID_X2    	SI_AS_VC_VR.MSW_APPLN_REF_ID_N%TYPE,
		V_VSL_CALL_ID_N             SI_AS_VC_VR.VSL_CALL_ID_N%TYPE,
        V_PORT_OF_REGY_C         	SI_PAN_APPLICATION.PORT_OF_REGY_C%TYPE,
        V_VSL_CRAFT_LIC_N        	SI_PAN_APPLICATION.VSL_CRAFT_LIC_N%TYPE,
        V_VSL_NT_Q               	SI_PAN_APPLICATION.VSL_NT_Q%TYPE,
        V_SECRTY_REM_X		        SI_PAN_APPLICATION.SECRTY_REM_X%TYPE,
        V_SUBMISSION_MODE		    SI_PAN_APPLICATION.SUBMISSION_MODE%TYPE,
        V_SHP_ARR_DIRN_DESC_X		SI_PAN_APPLICATION.SHP_ARR_DIRN_DESC_X%TYPE,
        V_P_LOCN_DESC_X		        SI_PAN_APPLICATION.P_LOCN_DESC_X%TYPE,
        V_SECU_LVL_SG_DESC_X		SI_PAN_APPLICATION.SECU_LVL_SG_DESC_X%TYPE,
        V_LATD_DIRN_DESC_X		    SI_PAN_APPLICATION.LATD_DIRN_DESC_X%TYPE,
        V_LONGD_DIRN_DESC_X		    SI_PAN_APPLICATION.LONGD_DIRN_DESC_X%TYPE,
        V_BWMC_COM_DESC_X		    SI_PAN_APPLICATION.BWMC_COM_DESC_X%TYPE,
        V_BWMC_D1_RSN_DESC_X		SI_PAN_APPLICATION.BWMC_D1_RSN_DESC_X%TYPE,
        V_INTENDED_LOCN_DESC_X		SI_PAN_APPLICATION.INTENDED_LOCN_DESC_X%TYPE,
        V_SEC_REF_I		            SI_PAN_APPLICATION.SEC_REF_I%TYPE

	);

   	TYPE TYPE_PAN_APP_TG IS   
    TABLE OF REC_PAN_APP_TG INDEX BY PLS_INTEGER;

    LV_REC_PAN_APP_TG        TYPE_PAN_APP_TG;
    LV_SEQ_PAN_APP           PAN_APPLICATION.APPLN_REF_N%TYPE;
    LV_SEQ_PAN_PURP          PAN_PURPOSE_OF_CALL.PAN_PURP_OF_CALL_ID_N%TYPE;


    LVAL                     CLOB;
    V_MSW_APPLN_REF_ID_X     VARCHAR2(20);            
    V_MSW_VSL_CALL_ID        VARCHAR2(250);
    V_EXP_ROWS               VARCHAR2(3500);
    LV_GPP_C_I               CHAR(1);
    LV_BURNING_LNG_I         CHAR(1);
    LV_BURNING_CLN_FUEL_I    CHAR(1);

BEGIN		-- outer begin 


EXECUTE IMMEDIATE 'TRUNCATE TABLE SI_PAN_APPLICATION';


 ------insertig the rcords into the si intermediate table---------------



    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 'PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


        FOR I IN CUR_SI_PAN      -- FOR LOOP TO INSERT DATA INTO SI_PAN_APPLICATION TABLE 

        LOOP                     -- for loop to insert data into si_pan_application table 

        BEGIN                    -- inner begin of si_pan_application

            INSERT INTO SI_PAN_APPLICATION (
            VSL_REC_ID_N,
            PANSID_N	,
            MSW_VSL_ID_N	,
            MVVOYAGENO_X	,
            MVFWDDFT_Q	,
            MVMIDDFT_Q	,
            MVAFTDFT_Q	,
            MVHGT_Q	,
            VSLIMSCALLNO_C	,
            CSONAME_X	,
            CSOTELNO_C	,
            AGENTNAME_X	,
            LOCNLATLONG_X	,
            LOCNLONG_X	,
            AGENTTELNO_C	,
            AGENTFAXNO_C	,
            AGENTEMAIL	,
            SHIPEMAIL	,
            ANCHDAYSSTAY_N	,
            ANCHETA_DT	,
            ANCHETD_DT	,
            CARGO_X	,
            SHPSECPLAN_I	,
            SECURITYLEVEL_C	,
            SECURITYPER_I	,
            SLOPSLUDGE_I	,
            SLOPQTY_Q	,
            SLUDGEQTY_Q	,
            SSCONTENT_X	,
            SSREPFAC_X	,
            USERID_X	,
            SAFETYREM_I	,
            VSL_MMSI_N	,
            CONAME_X	,
            MVCONREM_I	,
            FIREHZREM_I	,
            ARMSSTRONGRM_I	,
            ARMSSTRONGRMLOCN_X	,
            MVREM_X	,
            MVHMS_I	,
            MVHMS_X	,
            GPP_C	,
            BWMC_I	,
            IBWMC_I	,
            BWMCEXEMPTED_I	,
            BWMC_C	,
            BWMCD1_I	,
            BWMCD1REASON_X	,
            BWMCD1DISCHARGE_I	,
            BWMCD1DISCHARGE_Q	,
            BWMCD2_I	,
            BWMCD2REASON_I	,
            BWMCD2DISCHARGE_I	,
            BWMCD2DISCHARGE_Q	,
            BWMCD4_I	,
            USERTITLE	,
            LOCN_X	,
            TIMESTAMP_DT	,
            ARMSAMMUNITION_I	,
            ARMSTYPE_X	,
            DGCARGO_C	,
            DGCARGOPC_I	,
            CREWLST_I	,
            PAXLST_I	,
            ETA_DT	,
            ETD_DT	,
            VSLGT_Q	,
            BWMC_ETA_DT	,
            VALIDBCC_I	,
            MANREM_I	,
            REPORTDATE_DT	,
            USERID_N	,
            MVDIRNFR_C	,
            PURPOSECALL_C	,
            OTHERSPURPOSE_X	,
            anchpurpose_c ,
            anchpurpose_x,
			VSLMVID_N,
            PORT_OF_REGY_C,
            VSL_CRAFT_LIC_N,
            VSL_NT_Q,
            SECRTY_REM_X,
            SUBMISSION_MODE,
            SHP_ARR_DIRN_DESC_X,
            P_LOCN_DESC_X,
            SECU_LVL_SG_DESC_X,
            LATD_DIRN_DESC_X,
            LONGD_DIRN_DESC_X,
            BWMC_COM_DESC_X,
            BWMC_D1_RSN_DESC_X,
            INTENDED_LOCN_DESC_X,
            SEC_REF_I
            ) 

            VALUES (

                I.VSL_REC_ID_N	,
                I.PANSID_N	,
                I.MSW_VSL_ID_N	,
                I.MVVOYAGENO_X	,
                I.MVFWDDFT_Q	,
                I.MVMIDDFT_Q	,
                I.MVAFTDFT_Q	,
                I.MVHGT_Q	,
                I.VSLIMSCALLNO_C	,
                I.CSONAME_X	,
                I.CSOTELNO_C	,
                I.AGENTNAME_X	,
                I.LOCNLATLONG_X	,
                I.LOCNLONG_X	,
                I.AGENTTELNO_C	,
                I.AGENTFAXNO_C	,
                I.AGENTEMAIL	,
                I.SHIPEMAIL	,
                I.ANCHDAYSSTAY_N	,
                I.ANCHETA_DT	,
                I.ANCHETD_DT	,
                I.CARGO_X	,
                I.SHPSECPLAN_I	,
                I.SECURITYLEVEL_C	,
                I.SECURITYPER_I	,
                I.SLOPSLUDGE_I	,
                TRIM(I.SLOPQTY_Q),
                TRIM(I.SLUDGEQTY_Q),
                I.SSCONTENT_X	,
                I.SSREPFAC_X	,
                I.USERID_X	,
                I.SAFETYREM_I	,
                I.VSL_MMSI_N	,
                I.CONAME_X	,
                I.MVCONREM_I	,
                I.FIREHZREM_I	,
                I.ARMSSTRONGRM_I	,
                I.ARMSSTRONGRMLOCN_X	,
                I.MVREM_X                         	,
                I.MVHMS_I	,
                I.MVHMS_X	,
                I.GPP_C	,
                I.BWMC_I	,
                I.IBWMC_I	,
                I.BWMCEXEMPTED_I	,
                I.BWMC_C	,
                I.BWMCD1_I	,
                I.BWMCD1REASON_X	,
                I.BWMCD1DISCHARGE_I	,
                I.BWMCD1DISCHARGE_Q	,
                I.BWMCD2_I	,
                I.BWMCD2REASON_I	,
                I.BWMCD2DISCHARGE_I	,
                I.BWMCD2DISCHARGE_Q	,
                I.BWMCD4_I	,
                I.USERTITLE	,
                I.LOCN_X	,
                I.TIMESTAMP_DT	,
                I.ARMSAMMUNITION_I	,
                I.ARMSTYPE_X	,
                I.DGCARGO_C	,
                I.DGCARGOPC_I	,
                I.CREWLST_I	,
                I.PAXLST_I	,
                I.ETA_DT	,
                I.ETD_DT ,   --TO_TIMESTAMP(I.ETD_DT,'YYYY MM DD''HH24:MI:SS')	,   --DATE FORMAT NEEDS TO BE CHECK ACCODING TO DATA 
                I.VSLGT_Q	,
                I.BWMC_ETA_DT 	,
                I.VALIDBCC_I	,
                I.MANREM_I	,
                I.REPORTDATE_DT	,
                SUBSTR(I.USERID_N,1,20),
                I.MVDIRNFR_C	,
                I.PURPOSECALL_C	,
                I.OTHERSPURPOSE_X	,
                I.ANCHPURPOSE_C	,
                I.ANCHPURPOSE_X	,
				I.VSLMVID_N,
                I.PORT_OF_REGY_C,
                I.VSL_CRAFT_LIC_N,
                I.VSL_NT_Q,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            );

    EXCEPTION                                             -- INNER EXCEPTION OF SI_PAN_APPLICATION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SQLERRM;
            V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| V_ERR_CODE || V_ERR_MSG||DBMS_UTILITY.FORMAT_CALL_STACK;
             V_EXP_ROWS_SI := 
                        ' VSL_REC_ID_N:'||	I.VSL_REC_ID_N||'<{||}>'||
						' PANSID_N:'	||I.PANSID_N||'<{||}>'||
						' MSW_VSL_ID_N:'||I.MSW_VSL_ID_N||'<{||}>'||
						' MVVOYAGENO_X:'||I.MVVOYAGENO_X||'<{||}>'||
						' MVFWDDFT_Q:'  ||I.MVFWDDFT_Q||'<{||}>'||
						' MVMIDDFT_Q:'  ||I.MVMIDDFT_Q||'<{||}>'||
						' MVAFTDFT_Q:'  ||I.MVAFTDFT_Q||'<{||}>'||
						' MVHGT_Q:'		||I.MVHGT_Q||'<{||}>'||
						' VSLIMSCALLNO_C:'||I.VSLIMSCALLNO_C||'<{||}>'||
						' CSONAME_X:'	||I.CSONAME_X||'<{||}>'||
						' CSOTELNO_C:'	||I.CSOTELNO_C||'<{||}>'||
						' AGENTNAME_X:'	||I.AGENTNAME_X||'<{||}>'||
						' LOCNLATLONG_X:'||I.LOCNLATLONG_X||'<{||}>'||
						' LOCNLONG_X:'	||I.LOCNLONG_X||'<{||}>'||
						' AGENTTELNO_C:'||I.AGENTTELNO_C||'<{||}>'||
						' AGENTFAXNO_C:'||I.AGENTFAXNO_C||'<{||}>'||
						' AGENTEMAIL:'	||I.AGENTEMAIL||'<{||}>'||
						' SHIPEMAIL:'	||I.SHIPEMAIL||'<{||}>'||
						' ANCHDAYSSTAY_N:'||I.ANCHDAYSSTAY_N||'<{||}>'||
						' ANCHETA_DT:'	||I.ANCHETA_DT||'<{||}>'||
						' ANCHETD_DT:'	||I.ANCHETD_DT||'<{||}>'||
						' CARGO_X:'		||I.CARGO_X||'<{||}>'||
						' SHPSECPLAN_I:'||I.SHPSECPLAN_I||'<{||}>'||
						' SECURITYLEVEL_C:'	||I.SECURITYLEVEL_C||'<{||}>'||
						' SECURITYPER_I:'||I.SECURITYPER_I||'<{||}>'||
						' SLOPSLUDGE_I:'||I.SLOPSLUDGE_I||'<{||}>'||
						' SLOPQTY_Q:'	||I.SLOPQTY_Q||'<{||}>'||
						' SLUDGEQTY_Q:'	||I.SLUDGEQTY_Q||'<{||}>'||
						' SSCONTENT_X:'	||I.SSCONTENT_X||'<{||}>'||
						' SSREPFAC_X:'	||I.SSREPFAC_X||'<{||}>'||
						' USERID_X:'	||I.USERID_X||'<{||}>'||
						' SAFETYREM_I:'	||I.SAFETYREM_I||'<{||}>'||
						' VSL_MMSI_N:'	||I.VSL_MMSI_N||'<{||}>'||
						' CONAME_X:'	||I.CONAME_X||'<{||}>'||
						' MVCONREM_I:'	||I.MVCONREM_I||'<{||}>'||
						' FIREHZREM_I:'	||I.FIREHZREM_I||'<{||}>'||
						' ARMSSTRONGRM_I:'||I.ARMSSTRONGRM_I||'<{||}>'||
						' ARMSSTRONGRMLOCN_X:'||I.ARMSSTRONGRMLOCN_X||'<{||}>'||
						' MVREM_X:'	||I.MVREM_X ||'<{||}>'||
						' MVHMS_I:'	||I.MVHMS_I||'<{||}>'||
						' MVHMS_X:'	||I.MVHMS_X||'<{||}>'||
						' GPP_C:'	||I.GPP_C||'<{||}>'||
						' BWMC_I:'	||I.BWMC_I||'<{||}>'||
						' IBWMC_I:'	||I.IBWMC_I||'<{||}>'||
						' BWMCEXEMPTED_I:'||I.BWMCEXEMPTED_I||'<{||}>'||
						' BWMC_C:'||I.BWMC_C||'<{||}>'||
						' BWMCD1_I:'||I.BWMCD1_I||'<{||}>'||
						' BWMCD1REASON_X:'||I.BWMCD1REASON_X||'<{||}>'||
						' BWMCD1DISCHARGE_I:'||I.BWMCD1DISCHARGE_I||'<{||}>'||
						' BWMCD1DISCHARGE_Q:'||I.BWMCD1DISCHARGE_Q||'<{||}>'||
						' BWMCD2_I:'	||I.BWMCD2_I||'<{||}>'||
						' BWMCD2REASON_I:'	||I.BWMCD2REASON_I||'<{||}>'||
						' BWMCD2DISCHARGE_I:'	||I.BWMCD2DISCHARGE_I||'<{||}>'||
						' BWMCD2DISCHARGE_Q:'	||I.BWMCD2DISCHARGE_Q||'<{||}>'||
						' BWMCD4_I:'	||I.BWMCD4_I||'<{||}>'||
						' USERTITLE:'	||I.USERTITLE||'<{||}>'||
						' LOCN_X:'	|| I.LOCN_X||'<{||}>'||
						' TIMESTAMP_DT:'||I.TIMESTAMP_DT||'<{||}>'||
						' ARMSAMMUNITION_I:'|| I.ARMSAMMUNITION_I||'<{||}>'||
						' ARMSTYPE_X:'	||I.ARMSTYPE_X||'<{||}>'||
						' DGCARGO_C:'	||I.DGCARGO_C||'<{||}>'||
						' DGCARGOPC_I:'	||I.DGCARGOPC_I||'<{||}>'||
						' CREWLST_I:'	||I.CREWLST_I||'<{||}>'||
						' PAXLST_I:'	||I.PAXLST_I||'<{||}>'||
						' ETA_DT:'	||I.ETA_DT||'<{||}>'||
						' ETD_DT:'	||I.ETD_DT||'<{||}>'||
						' VSLGT_Q:'	||I.VSLGT_Q||'<{||}>'||
						' BWMC_ETA_DT:'	||I.BWMC_ETA_DT||'<{||}>'||
						' VALIDBCC_I:'	||I.VALIDBCC_I||'<{||}>'||
						' MANREM_I:'	||I.MANREM_I||'<{||}>'||
						' REPORTDATE_DT:'	||I.REPORTDATE_DT||'<{||}>'||
						' USERID_N:'	||I.USERID_N||'<{||}>'||
						' MVDIRNFR_C:'	||I.MVDIRNFR_C||'<{||}>'||
						' PURPOSECALL_C:'	||I.PURPOSECALL_C||'<{||}>'||
						' OTHERSPURPOSE_X:'	||I.OTHERSPURPOSE_X||'<{||}>'||
						' ANCHPURPOSE_C ,:'	||I.ANCHPURPOSE_C||'<{||}>'||
						' ANCHPURPOSE_X:'	||I.ANCHPURPOSE_X||'<{||}>'||
						' VSLMVID_N:'	||I.VSLMVID_N;


          I_EXCEP_CNT_SI := I_EXCEP_CNT_SI +1;

        IF I_EXCEP_CNT_SI < 50000  THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_PAN_APLICATION','PROC_2_PAN_APP',DBMS_UTILITY.FORMAT_ERROR_BACKTRACE , 
         'ERROR',   PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_STACK ||V_SQLERRM,  V_EXP_ROWS_SI  , 'T');

		END IF;





    END;     -- inner end of si_pan_application
  END LOOP;   -- inner end loop of  si_pan_application table
 COMMIT;
---Records Missed in the Business Logic


/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/

 OPEN CUR_TG_PAN;     -- CURSOR LOOP  TO INSERT DATA INTO PAN_APPLICATION AND PAN_POC TABLE 

 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 'INSERTION BEGINS INTO PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


    LOOP                 ---loop to start  cursor loop  to insert data into PAN_APPLICATION and PAN_POC table 

        FETCH CUR_TG_PAN
        BULK COLLECT INTO
        LV_REC_PAN_APP_TG LIMIT 10000;

        EXIT WHEN LV_REC_PAN_APP_TG.COUNT = 0;

        FOR I IN LV_REC_PAN_APP_TG.FIRST..LV_REC_PAN_APP_TG.LAST 

        LOOP           


		BEGIN                                   -- inner begin when  any exception occurs in JSON or sequence reset

				IF LV_REC_PAN_APP_TG(I).V_MSW_APPLN_REF_ID_X2 IS  NULL THEN

                        V_YEAR_MONTH:= TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'YY')|| TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'MM') ;


          ------    if APP_SUB_PAN_SEQ.nextval>=300000  

--------------logic for sequence reset------------

                                    IF V_YEAR_MONTH != P_YYMM  AND P_YYMM IS NOT NULL                       
                                     THEN

                                            EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual' INTO l_val;
                                            EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by -'|| l_val || ' minvalue 0';

                                            EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual'INTO l_val;
											EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_PAN_SEQ INCREMENT BY 1000 MINVALUE 0';
											EXECUTE IMMEDIATE 'SELECT APP_SUB_PAN_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                                            EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by 1 minvalue 0';

                                    END IF;

                                        P_YYMM := V_YEAR_MONTH ;



                                        V_MSW_APPLN_REF_ID_X := 'MSW'
                                            || 'PAN'
                                            || TO_CHAR(LV_REC_PAN_APP_TG(I).V_REPORTDATE_DT, 'YY')
                                            || TO_CHAR(LV_REC_PAN_APP_TG(I).V_REPORTDATE_DT, 'MM') 
                                            || TO_CHAR(APP_SUB_PAN_SEQ.NEXTVAL, 'FM00000');




  ---------- TRANSFORMATION DECODE LOGIC FOR FUEL TOOK IN VARIBLE---

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'N',0,'L',1,1) 
                                                                   INTO LV_GPP_c_i FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',1,'Y',0,NULL) 
                                                                   INTO LV_BURNING_LNG_I FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',0,'Y',1,NULL)
                                                                   INTO LV_BURNING_CLN_FUEL_I FROM DUAL;



                                                                 PROC_1_VSL_REF(lv_rec_pan_app_tg(i).v_msw_vsl_id_n,--V_MSW_VSL_ID_N 
                                                                                lv_rec_pan_app_tg(i).v_VSL_REC_ID_N,--V_VSL_REC_ID_N 
                                                                                null,--V_VSL_M  done 
                                                                                lv_rec_pan_app_tg(i).V_PORT_OF_REGY_C,--V_PORT_OF_REGY_C  done 
                                                                                null,--V_VSL_IMO_N
                                                                                null,--V_VSL_CALL_SIGN_N  done
                                                                                lv_rec_pan_app_tg(i).V_VSL_CRAFT_LIC_N,--V_VSL_CRAFT_LIC_N
                                                                                null,--V_VSL_GT_Q  done 
                                                                                lv_rec_pan_app_tg(i).V_VSL_NT_Q,--V_VSL_NT_Q
                                                                                null,--V_VSL_FLAG_C  done
                                                                                null,--VSLTY_C  done
                                                                                V_VSL_REF_ID_OUT,
                                                                                V_FLAG_OUT);


                                                  IF V_FLAG_OUT IS NULL THEN                     


                                                                   proc_2_vc_as
                                                                  ( lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                  nvl(lv_rec_pan_app_tg(i).v_eta_dt,sysdate), -- need to change in future after clarification
                                                                  lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                   v_msw_appln_ref_id_x,
                                                                  lv_rec_pan_app_tg(i).v_pansid_n,
                                                                  'PAN',
                                                                  null,--json (need to change)
                                                                  PV_RUN_ID, 
                                                                  'PAN_APPLICATION',
                                                                  v_msw_vsl_call_id,
                                                                  V_FLAG,
                                                                  'MSW',
                                                                  V_VSL_REF_ID_OUT,
                                                                  'PROCESSED',
                                                                  lv_rec_pan_app_tg(i).v_reportdate_dt,
                                                                  lv_rec_pan_app_tg(i).v_userId_n,
                                                                  lv_rec_pan_app_tg(i).v_reportdate_dt,
                                                                  lv_rec_pan_app_tg(i).v_userId_n);




                                    IF V_FLAG IS NULL THEN

                                 /************************************************************************************************************************************

																PAN_APPLICATION  

                                 ******************************************************************************************************************************************/


                                    BEGIN    -- inner begin to insert data into pan application

                                                                    INSERT INTO PAN_APPLICATION (

                                                                        APPLN_REF_N,
                                                                        VSL_CALL_ID_N,
                                                                        MSW_APPLN_REF_ID_X,
                                                                        EXTL_APPLN_REF_ID_X,
                                                                        MSW_VSL_ID_N,
                                                                        VOY_X,
                                                                        APPLCNT_ID_X,
                                                                        ARR_FWD_DFT_Q,
                                                                        ARR_MID_DFT_Q,
                                                                        ARR_AFT_DFT_Q,
                                                                        AIR_DFT_Q,
                                                                        VSL_IMS_CALL_NO_C,
                                                                        CSO_M,
                                                                        CSO_TEL_N,
                                                                        AGT_NM_M,
                                                                        LOCN_LAT_N,
                                                                        LOCN_LONG_N,
                                                                        AGT_TEL_N,
                                                                        AGT_FAX_N,
                                                                        AGT_EMAIL_X,
                                                                        SHP_EMAIL_X,
                                                                        ANCH_DURN_N,
                                                                        ANCH_ETA_DT,
                                                                        ANCH_ETD_DT,
                                                                        CGO_DESC_X,
                                                                        SHP_SECU_PLAN_I,
                                                                        SECU_LVL_SG_C,
                                                                        SECU_PERS_I,
                                                                        APPLN_ST_C,
                                                                        SLOP_SLUDGE_I,
                                                                        SLOP_QTY_Q,
                                                                        SLUDGE_QTY_Q,
                                                                        SS_CONTENT_X,
                                                                        SS_REP_FAC_X,
                                                                        HEIGHT_N,
                                                                        NAME_PER_REPORTING_X,
                                                                        SAFETY_SEC_AFFECT_I,
                                                                        VSL_MMSI_N,
                                                                        CO_NAME_X,
                                                                        MV_CON_REM_I,
                                                                        SAFETY_REM_I,
                                                                        FIRE_HZ_REM_I,
                                                                        ARMS_STRONG_RM_I,
                                                                        ARMS_STRONG_RM_LOCN_X,
                                                                        MV_REM_X,
                                                                        MV_HMS_I,
                                                                        MV_HMS_X,
                                                                        GPP_C_I,
                                                                        BURNING_LNG_I,
                                                                        BURNING_CLN_FUEL_I,
                                                                        BWMC_I,
                                                                        IBWMC_I,
                                                                        BWMC_EXEMPTED_I,
                                                                        BWMC_COM_C,
                                                                        BWMC_D1_I,
                                                                        BWMC_D1_REASON_X,
                                                                        BWMC_D1_DISCHARGE_I,
                                                                        BWMC_D1_DISCHARGE_Q,
                                                                        BWMC_D2_I,
                                                                        BWMC_D2_REASON_I,
                                                                        BWMC_D2_DISCHARGE_I,
                                                                        BWMC_D2_DISCHARGE_Q,
                                                                        BWMC_D4_I,
                                                                        USER_TITLE_X,
                                                                        LOCN_X,
                                                                        TIME_STAMP_DT,
                                                                        ARMS_AMMUNITION_I,
                                                                        ARMS_TYPE_X,
                                                                        ARMS_QTY_Q,
                                                                        HNS_I,
                                                                        DG_ON_BOARD_I,
                                                                        DG_CGO_MANF_I,
                                                                        CR_LIST_I,
                                                                        PASSN_LIST_ICA_I,
                                                                        PORT_FACILITY_ETA_DT,
                                                                        PORT_FACILITY_ETD_DT,
                                                                        GRS_TNG_N,
                                                                        IS_NOA_I,
                                                                        DRAFT_X,
                                                                        LAST_PORT_X,
                                                                        ETA_DT,
                                                                        VALID_BCC_I,
                                                                        MAN_REM_I,
                                                                        SAFETY_SECURITY_I,
                                                                        LOCATION_X,
                                                                        OTHER_LOCATION_X,
                                                                        MV_STM_DT,
                                                                        LOCN_TO_X,
                                                                        MARPOL_I,
                                                                        OTERM_FAC_C,
                                                                        OTERM_FAC_X,
                                                                        TRANS_ID_N,
                                                                        NEW_NOA_I,
                                                                        PAGER_X,
                                                                        SESS_X,
                                                                        OTH_REM_I,
                                                                        ARMS_SRC_I,
                                                                        SOURCE_I,
                                                                        USER_ID_X,
                                                                        LATD_DIRCN_C,
                                                                        LONGD_DIRCN_C,
                                                                        SHP_ARVL_DIRCN_C,
                                                                        SUBR_EMAIL_I,
                                                                        SUBR_SMS_I,
                                                                        PROCESSING_REM_X,
                                                                        PROCESSED_BY_X,
                                                                        PROCESSED_ON_DT,
                                                                        CRT_BY_N,
                                                                        CRT_ON_DT,
                                                                        UPT_BY_X,
                                                                        UPT_ON_DT,
                                                                        LOCK_VER_N,
                                                                        DELETED_I,
                                                                        SECRTY_REM_X,
                                                                        ETD_DT,
                                                                        SUBMISSION_MODE,
                                                                        SHP_ARR_DIRN_DESC_X,
                                                                        P_LOCN_DESC_X,
                                                                        SECU_LVL_SG_DESC_X,
                                                                        LATD_DIRN_DESC_X,
                                                                        LONGD_DIRN_DESC_X,
                                                                        BWMC_COM_DESC_X,
                                                                        BWMC_D1_RSN_DESC_X,
                                                                        INTENDED_LOCN_DESC_X,
                                                                        SEC_REF_I
																			) 
																	VALUES (
                                                                            SEQ_PAN_APP.NEXTVAL,
                                                                            V_MSW_VSL_CALL_ID ,    
                                                                            V_MSW_APPLN_REF_ID_X,         
                                                                            LV_REC_PAN_APP_TG(I).V_PANSID_N,
                                                                            LV_REC_PAN_APP_TG(I).V_MSW_VSL_ID_N,
                                                                            LV_REC_PAN_APP_TG(I).V_MVVOYAGENO_X,
                                                                            'D1',                                                  ---PENDING ON USER SERVICE DATA MODEL
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVFWDDFT_Q,'0')/10,     
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVMIDDFT_Q,'0')/10,
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVAFTDFT_Q,'0')/10  ,    
                                                                            LV_REC_PAN_APP_TG(I).V_MVHGT_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_VSLIMSCALLNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_CSONAME_X,
                                                                            LV_REC_PAN_APP_TG(I).V_CSOTELNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTNAME_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCNLATLONG_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCNLONG_X,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTTELNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTFAXNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTEMAIL,
                                                                            LV_REC_PAN_APP_TG(I).V_SHIPEMAIL,
                                                                            LV_REC_PAN_APP_TG(I).V_ANCHDAYSSTAY_N,
                                                                            TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETA_DT, 'YYYYMMDD HH24:MI:SS'),                 
                                                                            TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETD_DT, 'YYYYMMDD HH24:MI:SS'),                 
                                                                            LV_REC_PAN_APP_TG(I).V_CARGO_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SHPSECPLAN_I), 'N', 0, 'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SECURITYLEVEL_C), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SECURITYPER_I), 'N', 0, 'Y', 1),
                                                                            'PROCESSED',                                            ---AS PER MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SLOPSLUDGE_I), 'N',0,'Y',1),
                                                                            TO_NUMBER (LV_REC_PAN_APP_TG(I).V_SLOPQTY_Q),
                                                                            TO_NUMBER(LV_REC_PAN_APP_TG(I).V_SLUDGEQTY_Q),
                                                                            LV_REC_PAN_APP_TG(I).V_SSCONTENT_X,
                                                                            LV_REC_PAN_APP_TG(I).V_SSREPFAC_X,
                                                                            0,                                              --ACCORDING TO MAPPING SHEET
                                                                            LV_REC_PAN_APP_TG(I).V_USERID_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SAFETYREM_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_VSL_MMSI_N,
                                                                            LV_REC_PAN_APP_TG(I).V_CONAME_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVCONREM_I),'N',0,'Y',1),
                                                                            0,                                          --ACCORDING TO MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_FIREHZREM_I),'N',0,'Y',1),
                                                                            SUBSTR(LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRM_I, 1, 1),
                                                                            LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRMLOCN_X,
                                                                            LV_REC_PAN_APP_TG(I).V_MVREM_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVHMS_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_MVHMS_X,
                                                                            LV_GPP_C_I ,                            
                                                                            LV_BURNING_LNG_I,                                
                                                                            LV_BURNING_CLN_FUEL_I ,                                
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_IBWMC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCEXEMPTED_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_C,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD1_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD1REASON_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD1DISCHARGE_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD1DISCHARGE_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD2_I,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD2REASON_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD2DISCHARGE_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD2DISCHARGE_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD4_I,
                                                                            LV_REC_PAN_APP_TG(I).V_USERTITLE,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCN_X,
                                                                            LV_REC_PAN_APP_TG(I).V_TIMESTAMP_DT,
                                                                            DECODE(LV_REC_PAN_APP_TG(I).V_ARMSAMMUNITION_I,'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_ARMSTYPE_X,         
                                                                            0,
                                                                            0,                                                --- ACCORDINGLY TO A MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_DGCARGO_C),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_DGCARGOPC_I,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_CREWLST_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_PAXLST_I,
                                                                            LV_REC_PAN_APP_TG(I).V_ETA_DT,
                                                                            LV_REC_PAN_APP_TG(I).V_ETD_DT,
                                                                            LV_REC_PAN_APP_TG(I).V_VSLGT_Q,
                                                                            0,
                                                                            'DM',                                            ---PENDING
                                                                            'DM',
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_ETA_DT,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_VALIDBCC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MANREM_I),'N',0,'Y',1),
                                                                            0,
                                                                            'PAN',
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            LV_REC_PAN_APP_TG(I).V_USERID_X,
                                                                            DECODE(SUBSTR(TRIM(LV_REC_PAN_APP_TG(I).V_LOCNLATLONG_X),-1),'N','NORTH','S','SOUTH'),
                                                                            DECODE(SUBSTR(TRIM(LV_REC_PAN_APP_TG(I).V_LOCNLONG_X),-1),'W', 'WEST', 'E', 'EAST'),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVDIRNFR_C) , 'W', 'WEST', 'E', 'EAST','S', 'SOUTN', 'N', 'NORTH'),
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            'DATA MIGRATION',
                                                                            SYSDATE,
                                                                            'DATA MIGRATION',
                                                                            SYSDATE,
                                                                            0,
                                                                            0,
                                                                            LV_REC_PAN_APP_TG(I).V_SECRTY_REM_X,
                                                                            NULL,
                                                                            LV_REC_PAN_APP_TG(I).V_SUBMISSION_MODE,
                                                                            LV_REC_PAN_APP_TG(I).V_SHP_ARR_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_P_LOCN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_SECU_LVL_SG_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LATD_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LONGD_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_COM_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_D1_RSN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_INTENDED_LOCN_DESC_X,
                                                                            0
                                                                          );



                                                    ------------------------------



                                                    EXCEPTION --inner exception for PAN_APPLICATION
                                                                    WHEN OTHERS THEN
																	V_ERR_CODE := SQLCODE;
                                                                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                    V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;




                                                                    V_EXP_ROWS:=    	'APPLN_REF_N :'	||seq_pan_app.currval||'<{||}>'||
                                                                                        'VSL_CALL_ID_N,:'|| v_msw_vsl_call_id||'<{||}>'||
                                                                                        'MSW_APPLN_REF_ID_X:'|| v_msw_appln_ref_id_x||'<{||}>'||
                                                                                        'EXTL_APPLN_REF_ID_X:'||lv_rec_pan_app_tg(i).v_pansid_n	||'<{||}>'||
                                                                                        'MSW_VSL_ID_N:' ||lv_rec_pan_app_tg(i).v_msw_vsl_id_n||'<{||}>'||
                                                                                        'VOY_X:'		||lv_rec_pan_app_tg(i).v_mvvoyageno_x||'<{||}>'||
                                                                                        'APPLCNT_ID_X:'	||'D1'||'<{||}>'  ||           
                                                                                        'ARR_FWD_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_MID_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_AFT_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10||'<{||}>'||
                                                                                        'AIR_DFT_Q:'	||lv_rec_pan_app_tg(i).v_mvHgt_q	||	'<{||}>'||
                                                                                        'VSL_IMS_CALL_NO_C:'||lv_rec_pan_app_tg(i).v_vslimscallno_c	||'<{||}>'||
                                                                                        'CSO_M:'		||lv_rec_pan_app_tg(i).v_csoname_x||'<{||}>'||
                                                                                        'CSO_TEL_N:'	||lv_rec_pan_app_tg(i).v_csotelno_c	||'<{||}>'||
                                                                                        'AGT_NM_M:'		||lv_rec_pan_app_tg(i).v_agentname_x||'<{||}>'||
                                                                                        'LOCN_LAT_N:'	||lv_rec_pan_app_tg(i).v_locnlatlong_x||'<{||}>'||
                                                                                        'LOCN_LONG_N:'	||lv_rec_pan_app_tg(i).v_locnlong_x	||'<{||}>'||
                                                                                        'AGT_TEL_N:'	||lv_rec_pan_app_tg(i).v_agenttelno_c||'<{||}>'||
                                                                                        'AGT_FAX_N:'	||lv_rec_pan_app_tg(i).v_agentfaxno_c||'<{||}>'||
                                                                                        'AGT_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_agentEmail	||'<{||}>'||
                                                                                        'SHP_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_shipEmail	||'<{||}>'||
                                                                                        'ANCH_DURN_N:'	||lv_rec_pan_app_tg(i).v_anchdaysstay_n	||	'<{||}>'||
                                                                                        'ANCH_ETA_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'ANCH_ETD_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'CGO_DESC_X:'	||lv_rec_pan_app_tg(i).v_cargo_x||'<{||}>'||									
                                                                                        'APPLN_ST_C:'	||'PROCESSED' ||	'<{||}>'||								
                                                                                        'SLOP_QTY_Q:'	||TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q)	||	'<{||}>'||
                                                                                        'SLUDGE_QTY_Q:'	||TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q)	||	'<{||}>'||
                                                                                        'SS_CONTENT_X:'	||lv_rec_pan_app_tg(i).v_SSContent_x||	'<{||}>'||
                                                                                        'SS_REP_FAC_X:'	||lv_rec_pan_app_tg(i).v_SSRepFac_x	||	'<{||}>'||									
                                                                                        'NAME_PER_REPORTING_X:'	||lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||									
                                                                                        'VSL_MMSI_N:'	||lv_rec_pan_app_tg(i).v_vsl_mmsi_n	||	'<{||}>'||
                                                                                        'CO_NAME_X:'	||lv_rec_pan_app_tg(i).v_coname_x	||	'<{||}>'||			
                                                                                        'ARMS_STRONG_RM_I:'	|| substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1 ,1)	||	'<{||}>'||
                                                                                        'ARMS_STRONG_RM_LOCN_X:'||	 lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x	||	'<{||}>'||
                                                                                        'MV_REM_X:'		||	 lv_rec_pan_app_tg(i).v_mvRem_x	||	'<{||}>'||									
                                                                                        'MV_HMS_X:'		||	 lv_rec_pan_app_tg(i).v_mvhms_x	||	'<{||}>'||
                                                                                        'GPP_C_I:'		||	 LV_GPP_c_i||'<{||}>'||
                                                                                        'BURNING_LNG_I:'||	 LV_BURNING_LNG_I ||	'<{||}>'||
                                                                                        'BURNING_CLN_FUEL_I:'	||	 LV_BURNING_CLN_FUEL_I||'<{||}>'||									
                                                                                        'BWMC_COM_C:'	||	 lv_rec_pan_app_tg(i).v_bwmc_c	||	'<{||}>'||									
                                                                                        'BWMC_D1_REASON_X:'	|| lv_rec_pan_app_tg(i).v_bwmcd1reason_x	||	'<{||}>'||								
                                                                                        'BWMC_D1_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd1discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D2_I:'	||lv_rec_pan_app_tg(i).v_bwmcd2_i	||	'<{||}>'||								
                                                                                        'BWMC_D2_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd2discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D4_I:'	||lv_rec_pan_app_tg(i).v_bwmcd4_i	||	'<{||}>'||
                                                                                        'USER_TITLE_X:'	||lv_rec_pan_app_tg(i).v_usertitle	||	'<{||}>'||
                                                                                        'LOCN_X:'		||lv_rec_pan_app_tg(i).v_locn_x	||	'<{||}>'||
                                                                                        'TIME_STAMP_DT:'|| lv_rec_pan_app_tg(i).v_timestamp_dt	||	'<{||}>'||
                                                                                        'ARMS_AMMUNITION_I:'||lv_rec_pan_app_tg(i).v_armsammunition_i	||	'<{||}>'||
                                                                                        'ARMS_TYPE_X:'	||lv_rec_pan_app_tg(i).v_armsType_x        	||	'<{||}>'||																		
                                                                                        'DG_CGO_MANF_I:'||lv_rec_pan_app_tg(i).v_dgcargopc_i	||	'<{||}>'||									
                                                                                        'PASSN_LIST_ICA_I:'	||	 lv_rec_pan_app_tg(i).v_paxlst_i	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETA_DT:'	||	 lv_rec_pan_app_tg(i).v_eta_dt	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETD_DT:'	||	 lv_rec_pan_app_tg(i).v_etd_dt	||	'<{||}>'||
                                                                                        'GRS_TNG_N:'	||	 lv_rec_pan_app_tg(i).v_vslgt_q	||	'<{||}>'||								
                                                                                        'ETA_DT:'		||	 lv_rec_pan_app_tg(i).v_BWMC_ETA_DT	||	'<{||}>'||
                                                                                        'VALID_BCC_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_validbcc_i)	||	'<{||}>'||
                                                                                        'MAN_REM_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_manRem_i)	||	'<{||}>'||									
                                                                                        'USER_ID_X:'	||	 lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||				
                                                                                        'CRT_BY_N:'	||	 'DATA MIGRATION'	||	'<{||}>'||
                                                                                        'CRT_ON_DT:'||	 SYSDATE ||	'<{||}>'||
                                                                                        'UPT_BY_X:'|| 'DATA MIGRATION' ||	'<{||}>'||
                                                                                        'UPT_ON_DT:'|| SYSDATE ||	'<{||}>'||
                                                                                        'LOCK_VER_N:'||0 ||	'<{||}>'||
                                                                                        'DELETED_I:'|| 0    ||	'<{||}>'||
                                                                                        'SEC_REF_I:'||0 ||	'<{||}>'||
                                                                                        'SECRTY_REM_X: '||lv_rec_pan_app_tg(i).V_SECRTY_REM_X|| '<{||}>'||
                                                                                        'SUBMISSION_MODE: '||lv_rec_pan_app_tg(i).V_SUBMISSION_MODE|| '<{||}>'||
                                                                                        'SHP_ARR_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X|| '<{||}>'||
                                                                                        'P_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SECU_LVL_SG_DESC_X: '||lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X|| '<{||}>'||
                                                                                        'LATD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'LONGD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'BWMC_COM_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X|| '<{||}>'||
                                                                                        'BWMC_D1_RSN_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X|| '<{||}>'||
                                                                                        'INTENDED_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SEC_REF_I: '||NVL(lv_rec_pan_app_tg(i).V_SEC_REF_I,0)
                                                                                        ;


								I_EXCEP_CNT := I_EXCEP_CNT +1;
								IF I_EXCEP_CNT < 50000  THEN 

								PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',PV_RUN_ID,SQLERRM, V_EXP_ROWS,'T');                                                                                       
								END IF;

                                CONTINUE;

                            END;     ---begin end for pan application
                            ELSE
                            CONTINUE;
							END IF ;  -- IF V_FLAG IS NULL
                            ELSE
                            CONTINUE;
							END IF ;--- IF V_FLAG_OUT IS NULL THEN



				ELSE  --LV_REC_PAN_APP_TG(I).V_MSW_APPLN_REF_ID_X2 IS  NULL

                                    V_MSW_APPLN_REF_ID_X := LV_REC_PAN_APP_TG(I).V_MSW_APPLN_REF_ID_X2 ;

                                    V_VSL_CALL_ID := LV_REC_PAN_APP_TG(I).V_VSL_CALL_ID_N;

                                   SELECT  DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_GPP_C),'N',0,'L',1,1) 
                                   INTO LV_GPP_C_I 
                                   FROM DUAL;

                                   IF   TRIM(LV_REC_PAN_APP_TG(I).V_GPP_C) = 'N' THEN 
                                   LV_BURNING_LNG_I  := NULL;
                                   LV_BURNING_CLN_FUEL_I := NULL;
                                   END IF;


                                   SELECT DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_GPP_C),'L',1,'Y',0,NULL) INTO LV_BURNING_LNG_I FROM DUAL;
                                   SELECT DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_GPP_C),'L',0,'Y',1,NULL)INTO LV_BURNING_CLN_FUEL_I FROM DUAL;

                                         BEGIN    -- INNER BEGIN TO INSERT DATA INTO PAN APPLICATION

                                                                    INSERT INTO PAN_APPLICATION (

                                                                        APPLN_REF_N,
                                                                        VSL_CALL_ID_N,
                                                                        MSW_APPLN_REF_ID_X,
                                                                        EXTL_APPLN_REF_ID_X,
                                                                        MSW_VSL_ID_N,
                                                                        VOY_X,
                                                                        APPLCNT_ID_X,
                                                                        ARR_FWD_DFT_Q,
                                                                        ARR_MID_DFT_Q,
                                                                        ARR_AFT_DFT_Q,
                                                                        AIR_DFT_Q,
                                                                        VSL_IMS_CALL_NO_C,
                                                                        CSO_M,
                                                                        CSO_TEL_N,
                                                                        AGT_NM_M,
                                                                        LOCN_LAT_N,
                                                                        LOCN_LONG_N,
                                                                        AGT_TEL_N,
                                                                        AGT_FAX_N,
                                                                        AGT_EMAIL_X,
                                                                        SHP_EMAIL_X,
                                                                        ANCH_DURN_N,
                                                                        ANCH_ETA_DT,
                                                                        ANCH_ETD_DT,
                                                                        CGO_DESC_X,
                                                                        SHP_SECU_PLAN_I,
                                                                        SECU_LVL_SG_C,
                                                                        SECU_PERS_I,
                                                                        APPLN_ST_C,
                                                                        SLOP_SLUDGE_I,
                                                                        SLOP_QTY_Q,
                                                                        SLUDGE_QTY_Q,
                                                                        SS_CONTENT_X,
                                                                        SS_REP_FAC_X,
                                                                        HEIGHT_N,
                                                                        NAME_PER_REPORTING_X,
                                                                        SAFETY_SEC_AFFECT_I,
                                                                        VSL_MMSI_N,
                                                                        CO_NAME_X,
                                                                        MV_CON_REM_I,
                                                                        SAFETY_REM_I,
                                                                        FIRE_HZ_REM_I,
                                                                        ARMS_STRONG_RM_I,
                                                                        ARMS_STRONG_RM_LOCN_X,
                                                                        MV_REM_X,
                                                                        MV_HMS_I,
                                                                        MV_HMS_X,
                                                                        GPP_C_I,
                                                                        BURNING_LNG_I,
                                                                        BURNING_CLN_FUEL_I,
                                                                        BWMC_I,
                                                                        IBWMC_I,
                                                                        BWMC_EXEMPTED_I,
                                                                        BWMC_COM_C,
                                                                        BWMC_D1_I,
                                                                        BWMC_D1_REASON_X,
                                                                        BWMC_D1_DISCHARGE_I,
                                                                        BWMC_D1_DISCHARGE_Q,
                                                                        BWMC_D2_I,
                                                                        BWMC_D2_REASON_I,
                                                                        BWMC_D2_DISCHARGE_I,
                                                                        BWMC_D2_DISCHARGE_Q,
                                                                        BWMC_D4_I,
                                                                        USER_TITLE_X,
                                                                        LOCN_X,
                                                                        TIME_STAMP_DT,
                                                                        ARMS_AMMUNITION_I,
                                                                        ARMS_TYPE_X,
                                                                        ARMS_QTY_Q,
                                                                        HNS_I,
                                                                        DG_ON_BOARD_I,
                                                                        DG_CGO_MANF_I,
                                                                        CR_LIST_I,
                                                                        PASSN_LIST_ICA_I,
                                                                        PORT_FACILITY_ETA_DT,
                                                                        PORT_FACILITY_ETD_DT,
                                                                        GRS_TNG_N,
                                                                        IS_NOA_I,
                                                                        DRAFT_X,
                                                                        LAST_PORT_X,
                                                                        ETA_DT,
                                                                        VALID_BCC_I,
                                                                        MAN_REM_I,
                                                                        SAFETY_SECURITY_I,
                                                                        LOCATION_X,
                                                                        OTHER_LOCATION_X,
                                                                        MV_STM_DT,
                                                                        LOCN_TO_X,
                                                                        MARPOL_I,
                                                                        OTERM_FAC_C,
                                                                        OTERM_FAC_X,
                                                                        TRANS_ID_N,
                                                                        NEW_NOA_I,
                                                                        PAGER_X,
                                                                        SESS_X,
                                                                        OTH_REM_I,
                                                                        ARMS_SRC_I,
                                                                        SOURCE_I,
                                                                        USER_ID_X,
                                                                        LATD_DIRCN_C,
                                                                        LONGD_DIRCN_C,
                                                                        SHP_ARVL_DIRCN_C,
                                                                        SUBR_EMAIL_I,
                                                                        SUBR_SMS_I,
                                                                        PROCESSING_REM_X,
                                                                        PROCESSED_BY_X,
                                                                        PROCESSED_ON_DT,
                                                                        CRT_BY_N,
                                                                        CRT_ON_DT,
                                                                        UPT_BY_X,
                                                                        UPT_ON_DT,
                                                                        LOCK_VER_N,
                                                                        DELETED_I,
                                                                        SECRTY_REM_X,
                                                                        ETD_DT,
                                                                        SUBMISSION_MODE,
                                                                        SHP_ARR_DIRN_DESC_X,
                                                                        P_LOCN_DESC_X,
                                                                        SECU_LVL_SG_DESC_X,
                                                                        LATD_DIRN_DESC_X,
                                                                        LONGD_DIRN_DESC_X,
                                                                        BWMC_COM_DESC_X,
                                                                        BWMC_D1_RSN_DESC_X,
                                                                        INTENDED_LOCN_DESC_X,
                                                                        SEC_REF_I
                                                                    ) VALUES (
                                                                            SEQ_PAN_APP.NEXTVAL,
                                                                            V_VSL_CALL_ID ,    
                                                                            V_MSW_APPLN_REF_ID_X,         
                                                                            LV_REC_PAN_APP_TG(I).V_PANSID_N,
                                                                            LV_REC_PAN_APP_TG(I).V_MSW_VSL_ID_N,
                                                                            LV_REC_PAN_APP_TG(I).V_MVVOYAGENO_X,
                                                                            'D1',                                                  ---PENDING ON USER SERVICE DATA MODEL
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVFWDDFT_Q,'0')/10,     
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVMIDDFT_Q,'0')/10,
                                                                            LTRIM(LV_REC_PAN_APP_TG(I).V_MVAFTDFT_Q,'0')/10  ,    
                                                                            LV_REC_PAN_APP_TG(I).V_MVHGT_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_VSLIMSCALLNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_CSONAME_X,
                                                                            LV_REC_PAN_APP_TG(I).V_CSOTELNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTNAME_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCNLATLONG_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCNLONG_X,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTTELNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTFAXNO_C,
                                                                            LV_REC_PAN_APP_TG(I).V_AGENTEMAIL,
                                                                            LV_REC_PAN_APP_TG(I).V_SHIPEMAIL,
                                                                            LV_REC_PAN_APP_TG(I).V_ANCHDAYSSTAY_N,
                                                                            TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETA_DT, 'YYYYMMDD HH24:MI:SS'),                 
                                                                            TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETD_DT, 'YYYYMMDD HH24:MI:SS'),                 
                                                                            LV_REC_PAN_APP_TG(I).V_CARGO_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SHPSECPLAN_I), 'N', 0, 'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SECURITYLEVEL_C), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SECURITYPER_I), 'N', 0, 'Y', 1),
                                                                            'PROCESSED',                                            ---AS PER MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SLOPSLUDGE_I), 'N',0,'Y',1),
                                                                            TO_NUMBER (LV_REC_PAN_APP_TG(I).V_SLOPQTY_Q),
                                                                            TO_NUMBER(LV_REC_PAN_APP_TG(I).V_SLUDGEQTY_Q),
                                                                            LV_REC_PAN_APP_TG(I).V_SSCONTENT_X,
                                                                            LV_REC_PAN_APP_TG(I).V_SSREPFAC_X,
                                                                            0,                                              --ACCORDING TO MAPPING SHEET
                                                                            LV_REC_PAN_APP_TG(I).V_USERID_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_SAFETYREM_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_VSL_MMSI_N,
                                                                            LV_REC_PAN_APP_TG(I).V_CONAME_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVCONREM_I),'N',0,'Y',1),
                                                                            0,                                          --ACCORDING TO MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_FIREHZREM_I),'N',0,'Y',1),
                                                                            SUBSTR(LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRM_I, 1, 1),
                                                                            LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRMLOCN_X,
                                                                            LV_REC_PAN_APP_TG(I).V_MVREM_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVHMS_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_MVHMS_X,
                                                                            LV_GPP_C_I ,                            
                                                                            LV_BURNING_LNG_I,                                
                                                                            LV_BURNING_CLN_FUEL_I ,                                
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_IBWMC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCEXEMPTED_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_C,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD1_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD1REASON_X,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD1DISCHARGE_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD1DISCHARGE_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD2_I,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD2REASON_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_BWMCD2DISCHARGE_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD2DISCHARGE_Q,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMCD4_I,
                                                                            LV_REC_PAN_APP_TG(I).V_USERTITLE,
                                                                            LV_REC_PAN_APP_TG(I).V_LOCN_X,
                                                                            LV_REC_PAN_APP_TG(I).V_TIMESTAMP_DT,
                                                                            DECODE(LV_REC_PAN_APP_TG(I).V_ARMSAMMUNITION_I,'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_ARMSTYPE_X,         
                                                                            0,
                                                                            0,                                                --- ACCORDINGLY TO A MAPPING SHEET
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_DGCARGO_C),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_DGCARGOPC_I,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_CREWLST_I),'N',0,'Y',1),
                                                                            LV_REC_PAN_APP_TG(I).V_PAXLST_I,
                                                                            LV_REC_PAN_APP_TG(I).V_ETA_DT,
                                                                            LV_REC_PAN_APP_TG(I).V_ETD_DT,
                                                                            LV_REC_PAN_APP_TG(I).V_VSLGT_Q,
                                                                            0,
                                                                            'DM',                                            ---PENDING
                                                                            'DM',
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_ETA_DT,
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_VALIDBCC_I),'N',0,'Y',1),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MANREM_I),'N',0,'Y',1),
                                                                            0,
                                                                            'PAN',
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            LV_REC_PAN_APP_TG(I).V_USERID_X,
                                                                            DECODE(SUBSTR(TRIM(LV_REC_PAN_APP_TG(I).V_LOCNLATLONG_X),-1),'N','NORTH','S','SOUTH'),
                                                                            DECODE(SUBSTR(TRIM(LV_REC_PAN_APP_TG(I).V_LOCNLONG_X),-1),'W', 'WEST', 'E', 'EAST'),
                                                                            DECODE(TRIM(LV_REC_PAN_APP_TG(I).V_MVDIRNFR_C) , 'W', 'WEST', 'E', 'EAST','S', 'SOUTN', 'N', 'NORTH'),
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            'DATA MIGRATION',
                                                                            SYSDATE,
                                                                            'DATA MIGRATION',
                                                                            SYSDATE,
                                                                            0,
                                                                            0,
                                                                            LV_REC_PAN_APP_TG(I).V_SECRTY_REM_X,
                                                                            NULL,
                                                                            LV_REC_PAN_APP_TG(I).V_SUBMISSION_MODE,
                                                                            LV_REC_PAN_APP_TG(I).V_SHP_ARR_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_P_LOCN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_SECU_LVL_SG_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LATD_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_LONGD_DIRN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_COM_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_BWMC_D1_RSN_DESC_X,
                                                                            LV_REC_PAN_APP_TG(I).V_INTENDED_LOCN_DESC_X,
                                                                            0
                                                                          );



                                                    ------------------------------



                                                    EXCEPTION --INNER EXCEPTION FOR PAN_APPLICATION
                                                                    WHEN OTHERS THEN
                                                                    ---DELETING RECORDS FROM VESSEL_CALL AND APPLICATION_SUBMISSION  TABLE WHEN WE GET EXCEPTION WHILE INSERTING RECORDS IN PAN_APPLICATION
                                                                  --    DELETE FROM VESSEL_CALL     
                                                                   --     WHERE   VSL_CALL_ID_N = V_MSW_VSL_CALL_ID;

                                                                     --  DELETE FROM APPLICATION_SUBMISSION     
                                                                --  WHERE   VSL_CALL_ID_N = V_MSW_VSL_CALL_ID;

                                                                        V_ERR_CODE := SQLCODE;
                                                                        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                        V_SQLERRM := V_ERR_CODE
                                                                                     || V_ERR_MSG
                                                                                     || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;




                                                                        V_EXP_ROWS:=    'APPLN_REF_N :'	||SEQ_PAN_APP.CURRVAL||'<{||}>'||
                                                                                        'VSL_CALL_ID_N,:'|| V_VSL_CALL_ID||'<{||}>'||
                                                                                        'MSW_APPLN_REF_ID_X:'|| V_MSW_APPLN_REF_ID_X||'<{||}>'||
                                                                                        'EXTL_APPLN_REF_ID_X:'||LV_REC_PAN_APP_TG(I).V_PANSID_N	||'<{||}>'||
                                                                                        'MSW_VSL_ID_N:' ||LV_REC_PAN_APP_TG(I).V_MSW_VSL_ID_N||'<{||}>'||
                                                                                        'VOY_X:'		||LV_REC_PAN_APP_TG(I).V_MVVOYAGENO_X||'<{||}>'||
                                                                                        'APPLCNT_ID_X:'	||'D1'||'<{||}>'  ||           
                                                                                        'ARR_FWD_DFT_Q:'||LTRIM(LV_REC_PAN_APP_TG(I).V_MVFWDDFT_Q,'0')/10||'<{||}>'||
                                                                                        'ARR_MID_DFT_Q:'||LTRIM(LV_REC_PAN_APP_TG(I).V_MVMIDDFT_Q,'0')/10||'<{||}>'||
                                                                                        'ARR_AFT_DFT_Q:'||LTRIM(LV_REC_PAN_APP_TG(I).V_MVAFTDFT_Q,'0')/10||'<{||}>'||
                                                                                        'AIR_DFT_Q:'	||LV_REC_PAN_APP_TG(I).V_MVHGT_Q	||	'<{||}>'||
                                                                                        'VSL_IMS_CALL_NO_C:'||LV_REC_PAN_APP_TG(I).V_VSLIMSCALLNO_C	||'<{||}>'||
                                                                                        'CSO_M:'		||LV_REC_PAN_APP_TG(I).V_CSONAME_X||'<{||}>'||
                                                                                        'CSO_TEL_N:'	||LV_REC_PAN_APP_TG(I).V_CSOTELNO_C	||'<{||}>'||
                                                                                        'AGT_NM_M:'		||LV_REC_PAN_APP_TG(I).V_AGENTNAME_X||'<{||}>'||
                                                                                        'LOCN_LAT_N:'	||LV_REC_PAN_APP_TG(I).V_LOCNLATLONG_X||'<{||}>'||
                                                                                        'LOCN_LONG_N:'	||LV_REC_PAN_APP_TG(I).V_LOCNLONG_X	||'<{||}>'||
                                                                                        'AGT_TEL_N:'	||LV_REC_PAN_APP_TG(I).V_AGENTTELNO_C||'<{||}>'||
                                                                                        'AGT_FAX_N:'	||LV_REC_PAN_APP_TG(I).V_AGENTFAXNO_C||'<{||}>'||
                                                                                        'AGT_EMAIL_X:'	||LV_REC_PAN_APP_TG(I).V_AGENTEMAIL	||'<{||}>'||
                                                                                        'SHP_EMAIL_X:'	||LV_REC_PAN_APP_TG(I).V_SHIPEMAIL	||'<{||}>'||
                                                                                        'ANCH_DURN_N:'	||LV_REC_PAN_APP_TG(I).V_ANCHDAYSSTAY_N	||	'<{||}>'||
                                                                                        'ANCH_ETA_DT:'	||TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETA_DT ,'YYYYMMDD HH24:MI:SS')||'<{||}>'||
                                                                                        'ANCH_ETD_DT:'	||TO_TIMESTAMP(LV_REC_PAN_APP_TG(I).V_ANCHETD_DT ,'YYYYMMDD HH24:MI:SS')||'<{||}>'||
                                                                                        'CGO_DESC_X:'	||LV_REC_PAN_APP_TG(I).V_CARGO_X||'<{||}>'||									
                                                                                        'APPLN_ST_C:'	||'PROCESSED' ||	'<{||}>'||								
                                                                                        'SLOP_QTY_Q:'	||TO_NUMBER (LV_REC_PAN_APP_TG(I).V_SLOPQTY_Q)	||	'<{||}>'||
                                                                                        'SLUDGE_QTY_Q:'	||TO_NUMBER(LV_REC_PAN_APP_TG(I).V_SLUDGEQTY_Q)	||	'<{||}>'||
                                                                                        'SS_CONTENT_X:'	||LV_REC_PAN_APP_TG(I).V_SSCONTENT_X||	'<{||}>'||
                                                                                        'SS_REP_FAC_X:'	||LV_REC_PAN_APP_TG(I).V_SSREPFAC_X	||	'<{||}>'||									
                                                                                        'NAME_PER_REPORTING_X:'	||LV_REC_PAN_APP_TG(I).V_USERID_X	||	'<{||}>'||									
                                                                                        'VSL_MMSI_N:'	||LV_REC_PAN_APP_TG(I).V_VSL_MMSI_N	||	'<{||}>'||
                                                                                        'CO_NAME_X:'	||LV_REC_PAN_APP_TG(I).V_CONAME_X	||	'<{||}>'||			
                                                                                        'ARMS_STRONG_RM_I:'	|| SUBSTR(LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRM_I, 1 ,1)	||	'<{||}>'||
                                                                                        'ARMS_STRONG_RM_LOCN_X:'||	 LV_REC_PAN_APP_TG(I).V_ARMSSTRONGRMLOCN_X	||	'<{||}>'||
                                                                                        'MV_REM_X:'		||	 LV_REC_PAN_APP_TG(I).V_MVREM_X	||	'<{||}>'||									
                                                                                        'MV_HMS_X:'		||	 LV_REC_PAN_APP_TG(I).V_MVHMS_X	||	'<{||}>'||
                                                                                        'GPP_C_I:'		||	 LV_GPP_C_I||'<{||}>'||
                                                                                        'BURNING_LNG_I:'||	 LV_BURNING_LNG_I ||	'<{||}>'||
                                                                                        'BURNING_CLN_FUEL_I:'	||	 LV_BURNING_CLN_FUEL_I||'<{||}>'||									
                                                                                        'BWMC_COM_C:'	||	 LV_REC_PAN_APP_TG(I).V_BWMC_C	||	'<{||}>'||									
                                                                                        'BWMC_D1_REASON_X:'	|| LV_REC_PAN_APP_TG(I).V_BWMCD1REASON_X	||	'<{||}>'||								
                                                                                        'BWMC_D1_DISCHARGE_Q:'	||LV_REC_PAN_APP_TG(I).V_BWMCD1DISCHARGE_Q	||	'<{||}>'||
                                                                                        'BWMC_D2_I:'	||LV_REC_PAN_APP_TG(I).V_BWMCD2_I	||	'<{||}>'||								
                                                                                        'BWMC_D2_DISCHARGE_Q:'	||LV_REC_PAN_APP_TG(I).V_BWMCD2DISCHARGE_Q	||	'<{||}>'||
                                                                                        'BWMC_D4_I:'	||LV_REC_PAN_APP_TG(I).V_BWMCD4_I	||	'<{||}>'||
                                                                                        'USER_TITLE_X:'	||LV_REC_PAN_APP_TG(I).V_USERTITLE	||	'<{||}>'||
                                                                                        'LOCN_X:'		||LV_REC_PAN_APP_TG(I).V_LOCN_X	||	'<{||}>'||
                                                                                        'TIME_STAMP_DT:'|| LV_REC_PAN_APP_TG(I).V_TIMESTAMP_DT	||	'<{||}>'||
                                                                                        'ARMS_AMMUNITION_I:'||LV_REC_PAN_APP_TG(I).V_ARMSAMMUNITION_I	||	'<{||}>'||
                                                                                        'ARMS_TYPE_X:'	||LV_REC_PAN_APP_TG(I).V_ARMSTYPE_X        	||	'<{||}>'||																		
                                                                                        'DG_CGO_MANF_I:'||LV_REC_PAN_APP_TG(I).V_DGCARGOPC_I	||	'<{||}>'||									
                                                                                        'PASSN_LIST_ICA_I:'	||	 LV_REC_PAN_APP_TG(I).V_PAXLST_I	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETA_DT:'	||	 LV_REC_PAN_APP_TG(I).V_ETA_DT	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETD_DT:'	||	 LV_REC_PAN_APP_TG(I).V_ETD_DT	||	'<{||}>'||
                                                                                        'GRS_TNG_N:'	||	 LV_REC_PAN_APP_TG(I).V_VSLGT_Q	||	'<{||}>'||								
                                                                                        'ETA_DT:'		||	 LV_REC_PAN_APP_TG(I).V_BWMC_ETA_DT	||	'<{||}>'||
                                                                                        'VALID_BCC_I:'	||	 TO_NUMBER(LV_REC_PAN_APP_TG(I).V_VALIDBCC_I)	||	'<{||}>'||
                                                                                        'MAN_REM_I:'	||	 TO_NUMBER(LV_REC_PAN_APP_TG(I).V_MANREM_I)	||	'<{||}>'||									
                                                                                        'USER_ID_X:'	||	 LV_REC_PAN_APP_TG(I).V_USERID_X	||	'<{||}>'||				
                                                                                        'CRT_BY_N:'	||	 'DATA MIGRATION'	||	'<{||}>'||
                                                                                        'CRT_ON_DT:'||	 SYSDATE ||	'<{||}>'||
                                                                                        'UPT_BY_X:'|| 'DATA MIGRATION' ||	'<{||}>'||
                                                                                        'UPT_ON_DT:'|| SYSDATE ||	'<{||}>'||
                                                                                        'LOCK_VER_N:'||0 ||	'<{||}>'||
                                                                                        'DELETED_I:'|| 0    ||	'<{||}>'||
                                                                                        'SEC_REF_I:'||0 ||	'<{||}>'||
                                                                                        'SECRTY_REM_X: '||LV_REC_PAN_APP_TG(I).V_SECRTY_REM_X|| '<{||}>'||
                                                                                        'SUBMISSION_MODE: '||LV_REC_PAN_APP_TG(I).V_SUBMISSION_MODE|| '<{||}>'||
                                                                                        'SHP_ARR_DIRN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_SHP_ARR_DIRN_DESC_X|| '<{||}>'||
                                                                                        'P_LOCN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_P_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SECU_LVL_SG_DESC_X: '||LV_REC_PAN_APP_TG(I).V_SECU_LVL_SG_DESC_X|| '<{||}>'||
                                                                                        'LATD_DIRN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_LATD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'LONGD_DIRN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_LONGD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'BWMC_COM_DESC_X: '||LV_REC_PAN_APP_TG(I).V_BWMC_COM_DESC_X|| '<{||}>'||
                                                                                        'BWMC_D1_RSN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_BWMC_D1_RSN_DESC_X|| '<{||}>'||
                                                                                        'INTENDED_LOCN_DESC_X: '||LV_REC_PAN_APP_TG(I).V_INTENDED_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SEC_REF_I: '||NVL(LV_REC_PAN_APP_TG(I).V_SEC_REF_I,0)  ;


									I_EXCEP_CNT := I_EXCEP_CNT +1;
									IF I_EXCEP_CNT < 50000  THEN 

                                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                    PV_RUN_ID,SQLERRM, V_EXP_ROWS,'T');                                                                                       
									END IF; --IF I_EXCEP_CNT < 50000  THEN 

                                    CONTINUE;
									END;     ---BEGIN END FOR PAN APPLICATION
				END IF ; --LV_REC_PAN_APP_TG(I).V_MSW_APPLN_REF_ID_X2 IS  NULL



                                 /************************************************************************************************************************************

                                                                                               PURPOSE OF CALL  

                                 ******************************************************************************************************************************************/




            V_LEN:=   LENGTH(TRIM(LV_REC_PAN_APP_TG(I).V_PURPOSECALL_C));

            WHILE v_len > 0
            LOOP    --start while loop

                   ---logic for purposeof call---

                V_REGEX:=  NVL(SUBSTR(REGEXP_SUBSTR(TRIM(LV_REC_PAN_APP_TG(I).V_PURPOSECALL_C), '[0-9]+', 1, V_LEN), 1, 1), 0);

                IF V_REGEX <> 0 THEN

                    V_CNT_POC := V_CNT_POC + 1;

					IF V_REGEX = 1 THEN 

                        BEGIN 

                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) 
							VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Cargo Operation',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                                0
                            );
							EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Cargo Operation' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Cargo Operation' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

                            END IF;

                        END;

                        ELSIF V_REGEX = 2 THEN

                        BEGIN

                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) 
							VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Embarking/disembarking Passenger',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                               0
                            );

                            EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Embarking/disembarking Passenger' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Embarking/disembarking Passenger' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							 'T'
							 );

                            END IF;

                        END;


                        ELSIF V_REGEX = 3 THEN

                        BEGIN 


                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Taking Bunkers',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                            EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Taking Bunkers' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Taking Bunkers' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

                            END IF;

                        END;



                        ELSIF V_REGEX = 4 THEN

                        BEGIN 

                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            )
							VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Taking Suppliers',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                            EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Taking Suppliers' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Taking Suppliers' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

							END IF;

                        END;


                        ELSIF V_REGEX = 5 THEN

                        BEGIN

                            INSERT INTO PAN_PURPOSE_OF_CALL
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) 
							VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Changing Crew',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                                0
                            );

							EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Changing Crew' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Changing Crew' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

                            END IF;

                        END;


                        ELSIF V_REGEX = 6 THEN

                        BEGIN 

                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) 
							VALUES 
							(
								SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Repair/Docking/Outfitting',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
                                0
                            );


                            EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Repair/Docking/Outfitting' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Repair/Docking/Outfitting' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

                            END IF;

                        END;



                        ELSIF V_REGEX = 7 THEN

                        BEGIN 

                            INSERT INTO PAN_PURPOSE_OF_CALL (
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) VALUES (
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'Offshore Vessel',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
								0
                            );


                            EXCEPTION
							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'Offshore Vessel' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'Offshore Vessel' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0 ,
							'T'
							);

                            END IF;

                        END;



                        ELSIF v_regex = 9 THEN


                        BEGIN

                            INSERT INTO PAN_PURPOSE_OF_CALL 
							(
                                PAN_PURP_OF_CALL_ID_N,
                                APPLN_REF_N,
                                PURPCALL_C,
                                OTHERS_PURPOSE_X,
                                ARRIVAL_PURPSE_C,
                                LOCK_VER_N,
                                DELETED_I
                            ) 
							VALUES 
							(
                                SEQ_PAN_PURP.NEXTVAL,
                                SEQ_PAN_APP.CURRVAL,
                                'others',
                                LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X,
                                'PORT_FACILITY',
                                0,
								0
                            );


                            EXCEPTION

							WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                            I_EXCEP_CNT_POC := I_EXCEP_CNT_POC +1;

							IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							 'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || 'others' ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'PORT_FACILITY' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'others' ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'PORT_FACILITY' ||'<{||}>'||
							0 ||'<{||}>'||
							0 ,
							'T'
							);

                            END IF;

                            END;


                    END IF;

                END IF;

                    v_len := v_len - 1;
            END LOOP;    
                                           ----end while loop for purpose of call c




----transformation logic for anchpurpose-----

			V_LEN2:=  LENGTH(TRIM(LV_REC_PAN_APP_TG(I).V_ANCHPURPOSE_C));                   

			WHILE V_LEN2 > 0 LOOP    
                  ---START WHILE LOOP FOR ANCHORPURPOSE OF CALL
                V_REGEXX:=   NVL(SUBSTR(TRIM(REGEXP_SUBSTR(LV_REC_PAN_APP_TG(I).V_ANCHPURPOSE_C, '[0-9]+', 1,V_LEN2)), 1, 1), 0);
                --- DBMS_OUTPUT.PUT_LINE(' V_REGEXX : ' || V_REGEXX);

                    IF V_REGEXX <> 0 THEN
                        V_CNT_POC := V_CNT_POC + 1;
                    BEGIN 

                        INSERT INTO PAN_PURPOSE_OF_CALL (
                            PAN_PURP_OF_CALL_ID_N,
                            APPLN_REF_N,
                            PURPCALL_C,
                            OTHERS_PURPOSE_X,
                            ARRIVAL_PURPSE_C,
                            LOCK_VER_N,
                            DELETED_I
                        ) VALUES (
                            SEQ_PAN_PURP.NEXTVAL,
                            SEQ_PAN_APP.CURRVAL,
                            V_REGEXX,
                            LV_REC_PAN_APP_TG(I).V_ANCHPURPOSE_X,
                            'ANCHORAGE',
                            0,
                            0
                        );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                             IF I_EXCEP_CNT_POC < 50000  THEN 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							( 'PAN_PURPOSE_OF_CALL',
							'PROC_2_PAN_APP',
							'PAN_PURP_OF_CALL_ID_N:'||SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							'APPLN_REF_N:'||SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							'PURPCALL_C:' || V_REGEXX ||'<{||}>'||
							'OTHERS_PURPOSE_X:'||LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ARRIVAL_PURPSE_C:'||'ANCHORAGE' ||'<{||}>'||
							'LOCK_VER_N:'||0 ||'<{||}>'||
							'DELETED_I:'||0 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
							SEQ_PAN_PURP.CURRVAL ||'<{||}>'||
							SEQ_PAN_APP.CURRVAL ||'<{||}>'||
							 V_REGEXX ||'<{||}>'||
							LV_REC_PAN_APP_TG(I).V_OTHERSPURPOSE_X ||'<{||}>'||
							'ANCHORAGE' ||'<{||}>'||
							0 ||'<{||}>'||
							0,
							'T'
							);

                             END IF;

                    END;

                    END IF;

                V_LEN2 := V_LEN2 - 1;

            END LOOP;                   --END WHILE LOOP




		 COMMIT;

		EXCEPTION              -- INNER EXCEPTION  WHEN  ANY EXCEPTION OCCURS IN JSON OR SEQUENCE RESET

		WHEN OTHERS THEN
		V_ERR_CODE := SQLCODE;
		V_ERR_MSG := SQLERRM;
		V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| V_ERR_CODE || V_ERR_MSG||DBMS_UTILITY.FORMAT_CALL_STACK;

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('JSON_EXCEPTION' , 'PROC_2_PAN_APP', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE , 'ERROR',PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_STACK ||V_SQLERRM, V_EXP_ROWS_SI  ,'T');

		CONTINUE;

		END;  -- inner end which covers only JSON





      END LOOP;    ----END FOR LOOP
      COMMIT;

    END LOOP;     ---END CURSOR LOOP


CLOSE CUR_TG_PAN;  -- CLOSE CURSOR LOOP

 /****************************************************************************************/
---------------------------------------------------------------------------------------------------------------------------------------------


/************************************************************************************************************
CALLING A PROC TO REMOVE THE UNCOMMON RECORDS IN VC, AS , VR WHICH ARE NOT PRESENT IN PAN APPLICATION  STARTS
*************************************************************************************************************/

BEGIN 

PROC_PAN_VC_VR_AS_DEL;

END;

/**********************************************************************************************************
CALLING A PROC TO REMOVE THE UNCOMMON RECORDS IN VC, AS , VR WHICH ARE NOT PRESENT IN PAN APPLICATION  ENDS
***********************************************************************************************************/


---RECON LOGIC FOR SI PAN APPLICATION------------




	SELECT COUNT(*)
    INTO V_M_SRC_COUNT
    FROM
    ST_PANS_PANSINFOFRMRLOG    A,
    ST_PANS_PANSINFOFRMRLOG2   B,
    ST_PANS_PANSINFOFRMRLOG3   C,
    ST_PTMS_BWMC E,
    ST_PTMS_NOAFREFORM F,
    VESSEL   D
    WHERE
    A.PANSID_N = B.PANSID_N       
    AND A.PANSID_N = C.PANSID_N   
    AND A.PANSID_N = E.TRANSID_N(+)
    AND A.VSLRECID_N = E.VSLRECID_N(+)
    AND A.PANSID_N = F.PANSID_N(+)    
    AND A.VSLRECID_N = D.VSL_REC_ID_N;  --QUERY 




    SELECT COUNT(*)
    INTO V_SI_COUNT                     ----COUNT FOR SI PN SPPLICATION
    FROM
    SI_PAN_APPLICATION;



	IF (V_M_SRC_COUNT =  V_SI_COUNT ) AND V_M_SRC_COUNT <>  0  AND V_SI_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_PAN_APPLICATION TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        ELSIF V_M_SRC_COUNT  <> V_SI_COUNT AND V_M_SRC_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_PAN_APPLICATION TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


		ELSIF (V_M_SRC_COUNT  <> V_SI_COUNT OR V_M_SRC_COUNT  = V_SI_COUNT ) AND (V_M_SRC_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT || ' ROWS HAVE BEEN INSERTED INTO SI_PAN_APPLICATION TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

	END IF;



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_QUERY', V_M_SRC_COUNT, 'SI_PAN_APPLICATION', V_SI_COUNT, 'N');    





    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    SELECT   COUNT(*)
    INTO   V_M_SRC_COUNT                     ----COUNT FOR SI PN SPPLICATION
    FROM   SI_PAN_APPLICATION;

    SELECT COUNT(*)
	INTO V_SI_COUNT
	FROM PAN_APPLICATION;


	IF (V_M_SRC_COUNT =  V_SI_COUNT ) AND V_M_SRC_COUNT <>  0  AND V_SI_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO PAN_APPLICATION TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        ELSIF V_M_SRC_COUNT  <> V_SI_COUNT AND V_M_SRC_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO PAN_APPLICATION TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


		ELSIF (V_M_SRC_COUNT  <> V_SI_COUNT OR V_M_SRC_COUNT  = V_SI_COUNT ) AND (V_M_SRC_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT || ' ROWS HAVE BEEN INSERTED INTO PAN_APPLICATION  TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');


	END IF;



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_PAN_APPLICATION', V_M_SRC_COUNT, 'PAN_APPLICATION', V_SI_COUNT, 'N');     



   --------------------------------------------------------------------------------------------------------------------------------------------------------------



	SELECT  COUNT(*)
	INTO  V_M_SRC_COUNT
    FROM  ST_PANS_PANSINFOFRMRLOG ;    ----DRIVING TABLE COUNT


    SELECT COUNT(*)
    INTO V_SI_COUNT
    FROM PAN_APPLICATION;



    IF (V_M_SRC_COUNT =  V_SI_COUNT ) AND V_M_SRC_COUNT <>  0  AND V_SI_COUNT <> 0 THEN 

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO PAN_APPLICATION TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF V_M_SRC_COUNT  <> V_SI_COUNT AND V_M_SRC_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO PAN_APPLICATION TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    ELSIF (V_M_SRC_COUNT  <> V_SI_COUNT OR V_M_SRC_COUNT  = V_SI_COUNT ) AND (V_M_SRC_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT || ' ROWS HAVE BEEN INSERTED INTO PAN_APPLICATION  TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');


	END IF;



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PANS_PANSINFOFRMRLOG', V_M_SRC_COUNT, 'PAN_APPLICATION', V_SI_COUNT, 'Y');     



 ----------------------------------------------------------------------------------------------------------------------------------------------------------  





	V_M_SRC_COUNT :=  V_CNT_POC;



    SELECT COUNT(*)
    INTO V_SI_COUNT
    FROM PAN_PURPOSE_OF_CALL;



    IF (V_M_SRC_COUNT =  V_SI_COUNT ) AND V_M_SRC_COUNT <>  0  AND V_SI_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO PAN_PURPOSE_OF_CALL TABLE' ,'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        ELSIF V_M_SRC_COUNT  <> V_SI_COUNT AND V_M_SRC_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO PAN_PURPOSE_OF_CALL TABLE' ,'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


		ELSIF (V_M_SRC_COUNT  <> V_SI_COUNT OR V_M_SRC_COUNT  = V_SI_COUNT ) AND (V_M_SRC_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APP', 
		V_SI_COUNT ||' OUT OF ' ||V_M_SRC_COUNT || ' ROWS HAVE BEEN INSERTED INTO PAN_PURPOSE_OF_CALL  TABLE' , 'FAIL',PV_RUN_ID,NULL,NULL,'T');

	END IF;



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('COUNT OF POC ', V_M_SRC_COUNT, 'PAN_PURPOSE_OF_CALL', V_SI_COUNT, 'Y');     



/*
    pkg_datamigration_generic.proc_migration_recon('SI_pan_application', v_si_count, 'pan_application', v_m_tgt_count, 'N');

    pkg_datamigration_generic.proc_migration_recon('ST_PANS_pansInfoFrMRLog',v_dr_st_count, 'PAN_APPLICATION', v_m_tgt_count,'Y');

    pkg_datamigration_generic.proc_migration_recon('SI_pan_application',v_cnt_poc, 'PAN_PURPOSE_OF_CALL', v_m_tgt_count1, 'Y');   ---FOR PAN_PURPOSE_OF_CALLL
*/

--------outer exception-----


EXCEPTION
    WHEN OTHERS THEN
    V_ERR_CODE := SQLCODE;
    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
    V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_APPLICATION', 'PROC_2_PAN_APPABC', V_SQLERRM, 'ERROR',PV_RUN_ID,NULL,NULL,'T');

END PROC_2_PAN_APP;
/