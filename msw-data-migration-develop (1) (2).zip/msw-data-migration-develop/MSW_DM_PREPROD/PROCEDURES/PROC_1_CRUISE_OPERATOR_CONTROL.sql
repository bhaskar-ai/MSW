CREATE OR REPLACE PROCEDURE PROC_1_CRUISE_OPERATOR_CONTROL (PV_RUN_ID IN   NUMBER) IS  


/***********************************************************************************************************
PROCEDURE NAME : PROC_1_CRUISE_OPERATOR_CONTROL
CREATED BY     : C.N.BHASKAR , SOURANGSHU DHAR
DATE           : 15-JULY-2019
PURPOSE        : INSERTING DATA INTO CRUISE_OPERATOR_CONTROL
MODIFIED BY    : ROHIT KHOOL
MODIFIED DATE  : 29-AUG-2019

*************************************************************************************************************/

    TYPE REC_CRUISE_OPERATOR IS RECORD (
        V_INDX_N               SI_CV_CRUISEOPERCTRL.INDX_N%TYPE,
        V_VSLRECID_N           SI_CV_CRUISEOPERCTRL.VSLRECID_N%TYPE,
        V_CRUISEOPER_C         SI_CV_CRUISEOPERCTRL.CRUISEOPER_C%TYPE,
        V_POSID_C              SI_CV_CRUISEOPERCTRL.POSID_C%TYPE,
        V_REFID_N              SI_CV_CRUISEOPERCTRL.REFID_N%TYPE,
        V_CRTBY_M              SI_CV_CRUISEOPERCTRL.CRTBY_M%TYPE,
        V_CRTON_DT             SI_CV_CRUISEOPERCTRL.CRTON_DT%TYPE,
        V_UPDBY_M              SI_CV_CRUISEOPERCTRL.UPDBY_M%TYPE,
        V_UPDON_DT             SI_CV_CRUISEOPERCTRL.UPDON_DT%TYPE
    );
	
    TYPE TYPE_REC_CRUISE_OPERATOR IS    
	TABLE OF REC_CRUISE_OPERATOR;
	
    LV_CRUISE_OPERCTRL     TYPE_REC_CRUISE_OPERATOR;
    
    CURSOR CUR_CRUISE_OPERATOR IS
    SELECT  *
    FROM   
	SI_CV_CRUISEOPERCTRL;

    V_SRC_COUNT            NUMBER;
    V_TGT_COUNT            NUMBER;
    V_ERR_CODE             NUMBER;
    V_MSW_APPLN_REF_ID_X   VARCHAR2(2000);
    V_ERR_MSG              VARCHAR2(4000);
    V_SQLERRM              VARCHAR2(4000);
	
BEGIN --OUTER BEGIN FOR PROC_1_CRUISE_OPERATOR_CONTROL


/***********************************************************************************************************
INSERTION INTO SI_CV_CRUISEOPERCTRL STARTS 

*************************************************************************************************************/

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', 'INSERTION INTO SI_CV_CRUISEOPERCTRL STARTS'
    , 'START', NULL, NULL, NULL, 'T');

    FOR J IN (
        SELECT
            INDX_N,
            VSLRECID_N,
            CRUISEOPER_C,
            POSID_C,
            REFID_N,
            CRTBY_M,
            CRTON_DT,
            UPDBY_M,
            UPDON_DT
        FROM
            ST_CV_CRUISEOPERCTRL
            /* below condition added by rohit*/
            WHERE CRUISEOPER_C  IN ('CCS', 'CCT')
            AND POSID_C IN ('RF','IP','D')
			) 
	LOOP
		
        BEGIN
            
		INSERT INTO SI_CV_CRUISEOPERCTRL
		VALUES (
                J.INDX_N,
                J.VSLRECID_N,
                J.CRUISEOPER_C,
                J.POSID_C,
                J.REFID_N,
                J.CRTBY_M,
                J.CRTON_DT,
                J.UPDBY_M,
                J.UPDON_DT
				);

        EXCEPTION   -- INNER EXCEPTION   FOR SI_CV_CRUISEOPERCTRL
            WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_CV_CRUISEOPERCTRL', 'PROC_1_CRUISE_OPERATOR_CONTROL', /* 'INDX_N:'
                                                                                                                         || J.INDX_N
                                                                                                                         || '<{||}>'
                                                                                                                         || 'VSLRECID_N:'
                                                                                                                         || J.VSLRECID_N
                                                                                                                         || '<{||}>'
                                                                                                                         || 'CRUISEOPER_C:'
                                                                                                                         || J.CRUISEOPER_C
                                                                                                                         || '<{||}>'
                                                                                                                         || 'POSID_C:'
                                                                                                                         || J.POSID_C
                                                                                                                         || '<{||}>'
                                                                                                                         || 'REFID_N:'
                                                                                                                         || J.REFID_N
                                                                                                                         || '<{||}>'
                                                                                                                         || 'CRTBY_M:'
                                                                                                                         || J.CRTBY_M
                                                                                                                         || '<{||}>'
                                                                                                                         || 'CRTON_DT:'
                                                                                                                         || J.CRTON_DT
                                                                                                                         || '<{||}>'
                                                                                                                         || 'UPDBY_M:'
                                                                                                                         || J.UPDBY_M
                                                                                                                         || '<{||}>'
                                                                                                                         || 'UPDON_DT:'
                                                                                                                         || J.UPDON_DT  */ V_SQLERRM 
                                                                                                                         , 'ERROR'
                                                                                                                         , PV_RUN_ID
                                                                                                                         , SQLERRM ,
                                                                                                                        J.INDX_N		||'<{||}>' 	||
                                                                                                                        J . VSLRECID_N 	|| '<{||}>' || 
                                                                                                                        J . CRUISEOPER_C || '<{||}>' || 
                                                                                                                        J . POSID_C || '<{||}>' || 
                                                                                                                        J . REFID_N || '<{||}>' || 
                                                                                                                        J . CRTBY_M || '<{||}>' || 
                                                                                                                        J . CRTON_DT || '<{||}>' || 
                                                                                                                        J . UPDBY_M || '<{||}>' || 
                                                                                                                        J . UPDON_DT , 
                                                                                                                        'B' );

     -- INNER END   FOR SI_CV_CRUISEOPERCTRL

        END;
    END LOOP;

    COMMIT;
	
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', 'INSERTION INTO SI_CV_CRUISEOPERCTRL ENDS '
    , 'STOP', NULL, NULL, NULL, 'T'); 



/***********************************************************************************************************
INSERTION INTO SI_CRUISE_OPERATOR_CONTROL ENDS  

*************************************************************************************************************/


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', 'INSERTION INTO  CRUISE_OPERATOR_CONTROL STARTS'

    , 'START', NULL, NULL, NULL, 'T'); 




--V_MSW_APPLN_REF_ID_X := 'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.NEXTVAL,'FM00000' ) ;

    OPEN CUR_CRUISE_OPERATOR;
    LOOP   -- CURSOR LOOP STARTS 
	
        FETCH CUR_CRUISE_OPERATOR BULK COLLECT INTO LV_CRUISE_OPERCTRL LIMIT 10000;
        EXIT WHEN LV_CRUISE_OPERCTRL.COUNT = 0;
		
        FOR I IN LV_CRUISE_OPERCTRL.FIRST..LV_CRUISE_OPERCTRL.LAST LOOP     --   FOR LOOP STARTS  WHICH INSERT DATA INTO THE   TARGET TABLE 
            BEGIN
                INSERT INTO CRUISE_OPERATOR_CONTROL(MSW_CRUISE_OPER_CTRL_ID_N, 
                                                    CRUISE_OPER_CTRL_ID_N, 
                                                    VSL_ID, 
                                                    CRUISE_OPR_ID, 
                                                    POS_ID_C, 
                                                    REF_ID, 
                                                    CRT_ON_DT, 
                                                    CRT_BY_X, 
                                                    UPT_ON_DT, 
                                                    UPT_BY_X, 
                                                    LOCK_VER_N, 
                                                    DELETED_I
													)
											VALUES (
												SEQ_CRUISE_CNTRL.NEXTVAL,
												LV_CRUISE_OPERCTRL(I).V_INDX_N,
												LV_CRUISE_OPERCTRL(I).V_VSLRECID_N,
												LV_CRUISE_OPERCTRL(I).V_CRUISEOPER_C,
												LV_CRUISE_OPERCTRL(I).V_POSID_C,
												LV_CRUISE_OPERCTRL(I).V_REFID_N,
												LV_CRUISE_OPERCTRL(I).V_CRTON_DT,
												LV_CRUISE_OPERCTRL(I).V_CRTBY_M,
												LV_CRUISE_OPERCTRL(I).V_UPDON_DT,
												LV_CRUISE_OPERCTRL(I).V_UPDBY_M,
												0,
												0
												);

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)
                                 || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                    V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', 
                /*    'MSW_CRUISE_OPER_CTRL_ID_N:'||SEQ_CRUISE_CNTRL.CURRVAL||'<{||}>'||
                    'CRUISE_OPER_CTRL_ID_N:'||LV_CRUISE_OPERCTRL(I).V_INDX_N||'<{||}>'||
                    'VSL_ID	:'||LV_CRUISE_OPERCTRL(I).V_VSLRECID_N||'<{||}>'||
                    'CRUISE_OPR_ID:'||LV_CRUISE_OPERCTRL(I).V_CRUISEOPER_C||'<{||}>'||
                    'POS_ID_C:'||LV_CRUISE_OPERCTRL(I).V_POSID_C||'<{||}>'||
                    'REF_ID	:'||LV_CRUISE_OPERCTRL(I).V_REFID_N||'<{||}>'||
                    'CRT_ON_DT:'||LV_CRUISE_OPERCTRL(I).V_CRTON_DT||'<{||}>'||
                    'CRT_BY_X:'||LV_CRUISE_OPERCTRL(I).V_CRTBY_M||'<{||}>'||
                    'UPT_ON_DT:'||LV_CRUISE_OPERCTRL(I).V_UPDON_DT||'<{||}>'||
                    'UPT_BY_X:'||LV_CRUISE_OPERCTRL(I).V_UPDBY_M||'<{||}>'||
                    'LOCK_VER_N:'||0||'<{||}>'||
                    'DELETED_I:'||0 */ V_SQLERRM ,
                    'ERROR',
                    PV_RUN_ID,
                    SQLERRM,
                    SEQ_CRUISE_CNTRL.CURRVAL||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_INDX_N||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_VSLRECID_N||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_CRUISEOPER_C||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_POSID_C||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_REFID_N||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_CRTON_DT||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_CRTBY_M||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_UPDON_DT||'<{||}>'||
                    LV_CRUISE_OPERCTRL(I).V_UPDBY_M||'<{||}>'||
                    0||'<{||}>'||0,
                    'B');

            END;
        END LOOP;   -- END LOOP STARTS  OF  INNER FOR LOOP   INT THE TARGET TABLE 

    END LOOP;   -- CURSOR LOOP ENDS



/***********************************************************************************************************
RECONCILING THE COUNT OF STAGNG TABLE  AND SOURCE INTERMEDIATE TABLE 
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 

    SELECT
    COUNT(*) INTO V_SRC_COUNT
    FROM
    ST_CV_CRUISEOPERCTRL;

    SELECT
    COUNT(*) INTO V_TGT_COUNT
    FROM
    SI_CV_CRUISEOPERCTRL;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_CRUISEOPERCTRL', V_SRC_COUNT, 'SI_CV_CRUISEOPERCTRL', V_TGT_COUNT, 'N');
	
	
    IF ( V_TGT_COUNT = V_SRC_COUNT ) AND V_SRC_COUNT <> 0 AND V_TGT_COUNT <> 0 THEN
	
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS  HAVE BEEN INSERTED INTO SI_CV_CRUISEOPERCTRL TABLE'
                                                                                                                    , 'SUCCESS', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSIF V_TGT_COUNT <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SI_CV_CRUISEOPERCTRL TABLE'
                                                                                                                    , 'PARTIALLY SUCCESSFULL'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    ELSIF ( V_TGT_COUNT <> V_SRC_COUNT OR V_TGT_COUNT = V_SRC_COUNT ) AND ( V_TGT_COUNT = 0 ) THEN
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SI_CV_CRUISEOPERCTRL TABLE'
                                                                                                                    , 'FAIL', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSE
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SI_CV_CRUISEOPERCTRL TABLE'
                                                                                                                    , 'AMBIGIOUS'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    END IF;

/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCE QUERY AND SOURCE INTERMEDIATE TABLE   ENDS
*************************************************************************************************************/


/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCEINTERMEDIATE  TABLE  AND TARGET TABLE 
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 

    SELECT
        COUNT(*)
    INTO V_SRC_COUNT
    FROM
        SI_CV_CRUISEOPERCTRL;

    SELECT
        COUNT(*)
    INTO V_TGT_COUNT
    FROM
        CRUISE_OPERATOR_CONTROL;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_CV_CRUISEOPERCTRL', V_SRC_COUNT, 'CRUISE_OPERATOR_CONTROL', V_TGT_COUNT, 'N');
	
    IF ( V_TGT_COUNT = V_SRC_COUNT ) AND V_SRC_COUNT <> 0 AND V_TGT_COUNT <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS  HAVE BEEN INSERTED INTO CRUISE_OPERATOR_CONTROL TABLE'
                                                                                                                    , 'SUCCESS', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSIF V_TGT_COUNT <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO CRUISE_OPERATOR_CONTROL TABLE'
                                                                                                                    , 'PARTIALLY SUCCESSFULL'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    ELSIF ( V_TGT_COUNT <> V_SRC_COUNT OR V_TGT_COUNT = V_SRC_COUNT ) AND ( V_TGT_COUNT = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO CRUISE_OPERATOR_CONTROL TABLE'
                                                                                                                    , 'FAIL', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO CRUISE_OPERATOR_CONTROL TABLE'
                                                                                                                    , 'AMBIGIOUS'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    END IF;

/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCE QUERY AND SOURCE INTERMEDIATE TABLE   ENDS
*************************************************************************************************************/

/***********************************************************************************************************
RECONCILING THE COUNT OF STAGING   TABLE  AND TARGET  TABLE STARTS
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF TARGET

    SELECT
    COUNT(*)
    INTO V_SRC_COUNT
    FROM
    ST_CV_CRUISEOPERCTRL;

    SELECT
    COUNT(*)
    INTO V_TGT_COUNT
    FROM
    CRUISE_OPERATOR_CONTROL;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_CRUISEOPERCTRL', V_SRC_COUNT, 'CRUISE_OPERATOR_CONTROL', V_TGT_COUNT, 'Y');	  


/***********************************************************************************************************
RECONCILING THE COUNT OF STAGING   TABLE  AND SI  TABLE ENDS
*************************************************************************************************************/
EXCEPTION      --OUTER EXCEPTION FOR PROC_1_CRUISE_OPERATOR_CONTROL
    WHEN OTHERS THEN
    V_ERR_CODE := SQLCODE;
    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
	
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CRUISE_OPERATOR_CONTROL', 'PROC_1_CRUISE_OPERATOR_CONTROL', V_SQLERRM, 'FAIL', NULL, NULL, NULL, 'T');

END;                --OUTER END  FOR PROC_1_CRUISE_OPERATOR_CONTROL
/