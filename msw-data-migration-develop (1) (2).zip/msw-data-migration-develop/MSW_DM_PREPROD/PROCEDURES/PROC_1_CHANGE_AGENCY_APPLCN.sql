create or replace procedure PROC_1_CHANGE_AGENCY_APPLCN  (PV_RUN_ID  in number) IS  

/***********************************************************************************************************
procedure name : PROC_1_CHANGE_AGENCY_APPLCN
Created By     : C.N.BHASKAR
Date           : 10-May2019
Purpose        : Inserting data into CHANGE_AGENCY_APPLICATION
Modified by    :C.N.Bhaskar
Modified date  :09-july-2019

*************************************************************************************************************/



TYPE rec_tg_chgagtappln IS RECORD (

v_APPLNREF_N		si_cv_chgagtappln.APPLNREF_N%TYPE,
v_VSLRECID_N		si_cv_chgagtappln.VSLRECID_N%TYPE,
v_EFFVE_DT		    si_cv_chgagtappln.EFFVE_DT%TYPE,
v_TRANSTY_C		    si_cv_chgagtappln.TRANSTY_C%TYPE,
v_GDV_N		        si_cv_chgagtappln.GDV_N%TYPE,
v_FRPUID_N		    si_cv_chgagtappln.FRPUID_N%TYPE,
v_FRAGTDECLRAC_N	si_cv_chgagtappln.FRAGTDECLRAC_N%TYPE,
v_FRCONTACTPERS_M	si_cv_chgagtappln.FRCONTACTPERS_M%TYPE,
v_FROFFTEL_N		si_cv_chgagtappln.FROFFTEL_N%TYPE,
v_FRMOBILE_N		si_cv_chgagtappln.FRMOBILE_N%TYPE,
v_FREMAILADDR_X		si_cv_chgagtappln.FREMAILADDR_X%TYPE,
v_FRFAX_N		    si_cv_chgagtappln.FRFAX_N%TYPE,
v_TOPUID_N		    si_cv_chgagtappln.TOPUID_N%TYPE,
v_TOAGTDECLRAC_N	si_cv_chgagtappln.TOAGTDECLRAC_N%TYPE,
v_TOCONTACTPERS_M	si_cv_chgagtappln.TOCONTACTPERS_M%TYPE,
v_TOOFFTEL_N		si_cv_chgagtappln.TOOFFTEL_N%TYPE,
v_TOMOBILE_N		si_cv_chgagtappln.TOMOBILE_N%TYPE,
v_TOEMAILADDR_X		si_cv_chgagtappln.TOEMAILADDR_X%TYPE,
v_TOFAX_N		    si_cv_chgagtappln.TOFAX_N%TYPE,
v_EFFVEON_DT		si_cv_chgagtappln.EFFVEON_DT%TYPE,
v_REM_X		        si_cv_chgagtappln.REM_X%TYPE,
v_INTLREM_X		    si_cv_chgagtappln.INTLREM_X%TYPE,
v_FRAGTDOCIDATTH_N	si_cv_chgagtappln.FRAGTDOCIDATTH_N%TYPE,
v_TOAGTDOCIDATTH_N	si_cv_chgagtappln.TOAGTDOCIDATTH_N%TYPE,
v_AGTDECLR_M		si_cv_chgagtappln.AGTDECLR_M%TYPE,
v_AGTDECLRID_N		si_cv_chgagtappln.AGTDECLRID_N%TYPE,
v_AGTDECLRDESGN_M	si_cv_chgagtappln.AGTDECLRDESGN_M%TYPE,
v_CRTON_DT		    si_cv_chgagtappln.CRTON_DT%TYPE,
v_CRTBY_M		    si_cv_chgagtappln.CRTBY_M%TYPE,
v_UPDON_DT		    si_cv_chgagtappln.UPDON_DT%TYPE,
v_UPDBY_M		    si_cv_chgagtappln.UPDBY_M%TYPE

    );

TYPE type_tg_chgagtappln IS TABLE OF rec_tg_chgagtappln;
lv_tg_chgagtappln   type_tg_chgagtappln;



CURSOR CUR_CHANGEAGENCY
IS 
SELECT *
FROM SI_CV_CHGAGTAPPLN;


V_SRC_COUNT  NUMBER;  
V_TGT_COUNT   NUMBER;
V_ERR_CODE   NUMBER;
V_MSW_APPLN_REF_ID_X   VARCHAR2(2000);
V_ERR_MSG VARCHAR2(4000);
V_SQLERRM VARCHAR2(4000);


BEGIN --outer begin for proc_1_change_agency_applcn



/***********************************************************************************************************
Insertion into si_cv_chgagtappln starts 

*************************************************************************************************************/





PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN','Insertion into si_cv_chgagtappln starts' , 'START',null,null,null,'T'); 




FOR J IN
(
SELECT 
APPLNREF_N,
VSLRECID_N,
EFFVE_DT,
TRANSTY_C,
GDV_N,
FRPUID_N,
FRAGTDECLRAC_N,
FRCONTACTPERS_M,
FROFFTEL_N,
FRMOBILE_N,
FREMAILADDR_X,
FRFAX_N,
TOPUID_N,
TOAGTDECLRAC_N,
TOCONTACTPERS_M,
TOOFFTEL_N,
TOMOBILE_N,
TOEMAILADDR_X,
TOFAX_N,
EFFVEON_DT,
REM_X,
INTLREM_X,
FRAGTDOCIDATTH_N,
TOAGTDOCIDATTH_N,
AGTDECLR_M,
AGTDECLRID_N,
AGTDECLRDESGN_M,
CRTON_DT,
CRTBY_M,
UPDON_DT,
UPDBY_M

FROM ST_CV_CHGAGTAPPLN)


LOOP

	BEGIN 

	INSERT INTO SI_CV_CHGAGTAPPLN  

	values
	(J.APPLNREF_N,
	J.VSLRECID_N,
	J.EFFVE_DT,
	J.TRANSTY_C,
	J.GDV_N,
	J.FRPUID_N,
	J.FRAGTDECLRAC_N,
	J.FRCONTACTPERS_M,
	J.FROFFTEL_N,
	J.FRMOBILE_N,
	J.FREMAILADDR_X,
	J.FRFAX_N,
	J.TOPUID_N,
	J.TOAGTDECLRAC_N,
	J.TOCONTACTPERS_M,
	J.TOOFFTEL_N,
	J.TOMOBILE_N,
	J.TOEMAILADDR_X,
	J.TOFAX_N,
	J.EFFVEON_DT,
	J.REM_X,
	J.INTLREM_X,
	J.FRAGTDOCIDATTH_N,
	J.TOAGTDOCIDATTH_N,
	J.AGTDECLR_M,
	J.AGTDECLRID_N,
	J.AGTDECLRDESGN_M,
	J.CRTON_DT,
	J.CRTBY_M,
	J.UPDON_DT,
	J.UPDBY_M
	);



	EXCEPTION   -- INNER EXCEPTION   FOR SI_CV_CHGAGTAPPLN

	WHEN OTHERS    THEN 

	V_ERR_CODE := SQLCODE;
	V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
	V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
	( 'SI_CV_CHGAGTAPPLN','PROC_1_CHANGE_AGENCY_APPLCN',
	'APPLNREF_N:'||J.APPLNREF_N||'<{||}>'||
	'VSLRECID_N:'||J.VSLRECID_N||'<{||}>'||
	'EFFVE_DT:'	||J.EFFVE_DT||'<{||}>'||
	'TRANSTY_C:'|| J.TRANSTY_C||'<{||}>'||
	'GDV_N:'|| J.GDV_N||'<{||}>'||
	'FRPUID_N:'||J.FRPUID_N||'<{||}>'||
	'FRAGTDECLRAC_N	:'|| J.FRAGTDECLRAC_N||'<{||}>'||
	'FRCONTACTPERS_M:'|| J.FRCONTACTPERS_M||'<{||}>'||
	'FROFFTEL_N	:'|| J.FROFFTEL_N||'<{||}>'||
	'FRMOBILE_N	:'|| J.FRMOBILE_N||'<{||}>'||
	'FREMAILADDR_X:'|| J.FREMAILADDR_X||'<{||}>'||
	'FRFAX_N:'|| J.FRFAX_N||'<{||}>'||
	'TOPUID_N:'	|| J.TOPUID_N||'<{||}>'||
	'TOAGTDECLRAC_N	:' ||	J.TOAGTDECLRAC_N||'<{||}>'||
	'TOCONTACTPERS_M:' ||	J.TOCONTACTPERS_M||'<{||}>'||
	'TOOFFTEL_N:'|| J.TOOFFTEL_N||'<{||}>'||
	'TOMOBILE_N:'|| J.TOMOBILE_N||'<{||}>'||
	'TOEMAILADDR_X:'|| J.TOEMAILADDR_X||'<{||}>'||
	'TOFAX_N:'|| J.TOFAX_N||'<{||}>'||
	'EFFVEON_DT:'|| J.EFFVEON_DT||'<{||}>'||
	'REM_X:'|| J.REM_X||'<{||}>'||
	'INTLREM_X:'|| J.INTLREM_X||'<{||}>'||
	'FRAGTDOCIDATTH_N:'||	J.FRAGTDOCIDATTH_N||'<{||}>'||
	'TOAGTDOCIDATTH_N:'	|| J.TOAGTDOCIDATTH_N||'<{||}>'||
	'AGTDECLR_M:'|| J.AGTDECLR_M||'<{||}>'||
	'AGTDECLRID_N:'|| J.AGTDECLRID_N||'<{||}>'||
	'AGTDECLRDESGN_M:'|| J.AGTDECLRDESGN_M||'<{||}>'||
	'CRTON_DT:'	|| J.CRTON_DT||'<{||}>'||
	'CRTBY_M:'	|| J.CRTBY_M||'<{||}>'||
	'UPDON_DT:'	||J.UPDON_DT||'<{||}>'||
	'UPDBY_M:'	|| J.UPDBY_M
	  ,
	'ERROR',
	PV_RUN_ID,
	V_SQLERRM,
	J.APPLNREF_N||'<{||}>'||
	J.VSLRECID_N||'<{||}>'||
	J.EFFVE_DT||'<{||}>'||
	J.TRANSTY_C||'<{||}>'||
	J.GDV_N||'<{||}>'||
	J.FRPUID_N||'<{||}>'||
	J.FRAGTDECLRAC_N||'<{||}>'||
	J.FRCONTACTPERS_M||'<{||}>'||
	J.FROFFTEL_N||'<{||}>'||
	J.FRMOBILE_N||'<{||}>'||
	J.FREMAILADDR_X||'<{||}>'||
	J.FRFAX_N||'<{||}>'||
	J.TOPUID_N||'<{||}>'||
	J.TOAGTDECLRAC_N||'<{||}>'||
	J.TOCONTACTPERS_M||'<{||}>'||
	J.TOOFFTEL_N||'<{||}>'||
	J.TOMOBILE_N||'<{||}>'||
	J.TOEMAILADDR_X||'<{||}>'||
	J.TOFAX_N||'<{||}>'||
	J.EFFVEON_DT||'<{||}>'||
	J.REM_X||'<{||}>'||
	J.INTLREM_X||'<{||}>'||
	J.FRAGTDOCIDATTH_N||'<{||}>'||
	J.TOAGTDOCIDATTH_N||'<{||}>'||
	J.AGTDECLR_M||'<{||}>'||
	J.AGTDECLRID_N||'<{||}>'||
	J.AGTDECLRDESGN_M||'<{||}>'||
	J.CRTON_DT||'<{||}>'||
	J.CRTBY_M||'<{||}>'||
	J.UPDON_DT||'<{||}>'||
	J.UPDBY_M
	 ,
	 'B'
	 );

		 -- inner end   for si_cv_chgagtappln


     END;

END LOOP;

COMMIT;


PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN','INSERTION INTO SI_CV_CHGAGTAPPLN ENDS' , 'STOP',null,null,null,'T'); 

/***********************************************************************************************************
Insertion into si_cv_chgagtappln ends  

*************************************************************************************************************/



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------



PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN','INSERTION INTO  CHANGE_AGENCY_APPLICATION STARTS' , 'START',null,null,null,'T'); 






--V_MSW_APPLN_REF_ID_X := 'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.NEXTVAL,'FM00000' ) ;

OPEN CUR_CHANGEAGENCY;

LOOP   -- CURSOR LOOP STARTS 



FETCH CUR_CHANGEAGENCY  BULK COLLECT  INTO LV_TG_CHGAGTAPPLN  LIMIT 1000;

EXIT WHEN LV_TG_CHGAGTAPPLN.COUNT = 0;


    FOR I IN LV_TG_CHGAGTAPPLN.FIRST..LV_TG_CHGAGTAPPLN.LAST 
	LOOP     --   FOR LOOP STARTS  WHICH INSERT DATA INTO THE   TARGET TABLE 

        BEGIN 

        INSERT INTO CHANGE_AGENCY_APPLICATION  
                  (
                    APPLN_REF_N,
                    APPLCNT_ID_N,
                    MSW_APPLN_REF_N,
                    EXTL_APPLN_REF_N,
                    AUTHORITY_C,
                    VSL_REC_ID_N,
                    EFFVE_DT,
                    TRANS_TY_C,
                    GDV_N,
                    FT_AGENT_ID_N,
                    FT_AGT_DECLR_AC_N,
                    FR_CONTACT_PERS_M,
                    FR_OFF_TEL_N,
                    FR_MOBILE_N,
                    FR_EMAIL_ADDR_X,
                    FR_FAX_N,
                    TO_AGENT_ID_N,
                    TO_AGT_DECLR_AC_N,
                    TO_CONTACT_PERS_M,
                    TO_OFF_TEL_N,
                    TO_MOBILE_N,
                    TO_EMAIL_ADDR_X,
                    TO_FAX_N,
                    EFFVE_ON_DT,
                    REM_X,
                    INTL_REM_X,
                    FR_AGT_DOC_ID_ATTH_N,
                    TO_AGT_DOC_ID_ATTH_N,
                    AGT_DECLR_M,
                    AGT_DECLR_ID_N,
                    AGT_DECLR_DESGN_M,
                    CRT_ON_DT,
                    CRT_BY_N,
                    LAST_UPDATED_ON_DT,
                    LAST_UPDATED_BY_N)
        VALUES(
                    SEQ_CHAGTAPPL.NEXTVAL,
                     2 , --NEED TO CHANGE WHEN THE APROPRIATE MAPPING COMES
                    'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.NEXTVAL,'FM00000'),
                    LV_TG_CHGAGTAPPLN(I).V_APPLNREF_N,
                    'MPA',
                    LV_TG_CHGAGTAPPLN(I).V_VSLRECID_N	,
                    LV_TG_CHGAGTAPPLN(I).V_EFFVE_DT	,
                    LV_TG_CHGAGTAPPLN(I).V_TRANSTY_C	,
                    LV_TG_CHGAGTAPPLN(I).V_GDV_N	,
                    LV_TG_CHGAGTAPPLN(I).V_FRPUID_N	,
                    LV_TG_CHGAGTAPPLN(I).V_FRAGTDECLRAC_N	,
                    LV_TG_CHGAGTAPPLN(I).V_FRCONTACTPERS_M	,
                    LV_TG_CHGAGTAPPLN(I).V_FROFFTEL_N	,
                    LV_TG_CHGAGTAPPLN(I).V_FRMOBILE_N	,
                    LV_TG_CHGAGTAPPLN(I).V_FREMAILADDR_X	,
                    LV_TG_CHGAGTAPPLN(I).V_FRFAX_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOPUID_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOAGTDECLRAC_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOCONTACTPERS_M	,
                    LV_TG_CHGAGTAPPLN(I).V_TOOFFTEL_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOMOBILE_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOEMAILADDR_X	,
                    LV_TG_CHGAGTAPPLN(I).V_TOFAX_N	,
                    LV_TG_CHGAGTAPPLN(I).V_EFFVEON_DT	,
                    LV_TG_CHGAGTAPPLN(I).V_REM_X	,
                    LV_TG_CHGAGTAPPLN(I).V_INTLREM_X	,
                    LV_TG_CHGAGTAPPLN(I).V_FRAGTDOCIDATTH_N	,
                    LV_TG_CHGAGTAPPLN(I).V_TOAGTDOCIDATTH_N	,
                    LV_TG_CHGAGTAPPLN(I).V_AGTDECLR_M	,
                    LV_TG_CHGAGTAPPLN(I).V_AGTDECLRID_N	,
                    LV_TG_CHGAGTAPPLN(I).V_AGTDECLRDESGN_M	,
                    LV_TG_CHGAGTAPPLN(I).V_CRTON_DT	,
                    LV_TG_CHGAGTAPPLN(I).V_CRTBY_M	,
                    LV_TG_CHGAGTAPPLN(I).V_UPDON_DT	,
                    LV_TG_CHGAGTAPPLN(I).V_UPDBY_M	
                    );

		EXCEPTION

		WHEN OTHERS    THEN 

		V_ERR_CODE := SQLCODE;
		V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
		V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
		  ( 'CHANGE_AGENCY_APPLICATION',
		  'PROC_1_CHANGE_AGENCY_APPLCN',
		SEQ_CHAGTAPPL.CURRVAL	||'<{||}>'||
		 2  	||'<{||}>'|| --NEED TO CHANGE WHEN THE APROPRIATE MAOOING COMES
		'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.CURRVAL,'FM00000' )||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_APPLNREF_N	||'<{||}>'||
		'MPA'	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_VSLRECID_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_EFFVE_DT	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TRANSTY_C	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_GDV_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRPUID_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRAGTDECLRAC_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRCONTACTPERS_M	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FROFFTEL_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRMOBILE_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FREMAILADDR_X	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRFAX_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOPUID_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOAGTDECLRAC_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOCONTACTPERS_M	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOOFFTEL_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOMOBILE_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOEMAILADDR_X	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOFAX_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_EFFVEON_DT	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_REM_X	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_INTLREM_X	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_FRAGTDOCIDATTH_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_TOAGTDOCIDATTH_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_AGTDECLR_M	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_AGTDECLRID_N	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_AGTDECLRDESGN_M	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_CRTON_DT	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_CRTBY_M	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_UPDON_DT	||'<{||}>'||
		LV_TG_CHGAGTAPPLN(I).V_UPDBY_M	
		  ,
		'ERROR',
		PV_RUN_ID,
		V_SQLERRM,

			SEQ_CHAGTAPPL.CURRVAL	||'<{||}>'||
			2  	||'<{||}>'|| --NEED TO CHANGE WHEN THE APROPRIATE MAOOING COMES
			'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.CURRVAL,'FM00000' )	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).	V_APPLNREF_N	||'<{||}>'||
			'MPA'	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_VSLRECID_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_EFFVE_DT	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TRANSTY_C	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_GDV_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRPUID_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRAGTDECLRAC_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRCONTACTPERS_M	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FROFFTEL_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRMOBILE_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FREMAILADDR_X	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRFAX_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOPUID_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOAGTDECLRAC_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOCONTACTPERS_M	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOOFFTEL_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOMOBILE_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOEMAILADDR_X	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOFAX_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_EFFVEON_DT	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_REM_X	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_INTLREM_X	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_FRAGTDOCIDATTH_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_TOAGTDOCIDATTH_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_AGTDECLR_M	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_AGTDECLRID_N	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_AGTDECLRDESGN_M	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_CRTON_DT	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_CRTBY_M	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_UPDON_DT	||'<{||}>'||
			LV_TG_CHGAGTAPPLN(I).V_UPDBY_M	
		 ,
		 'B'
		 );



		END;





	END LOOP;   -- END LOOP STARTS  OF  INNER FOR LOOP   INT THE TARGET TABLE 


END LOOP;   -- CURSOR LOOP ENDS




/***********************************************************************************************************
RECONCILING THE COUNT OF STAGNG TABLE  AND SOURCE INTERMEDIATE TABLE 
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 


    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM  ST_CV_CHGAGTAPPLN;

    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM  SI_CV_CHGAGTAPPLN;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_CHGAGTAPPLN', V_SRC_COUNT, 'SI_CV_CHGAGTAPPLN', V_TGT_COUNT,'N');	  



    IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_CV_CHGAGTAPPLN TABLE' ,'SUCCESS',NULL,NULL,NULL,NULL);


    ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_CV_CHGAGTAPPLN TABLE','PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);



    ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_CV_CHGAGTAPPLN TABLE' ,'FAIL',NULL,NULL,NULL,NULL);


    ELSE 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_CV_CHGAGTAPPLN TABLE' ,'AMBIGIOUS',NULL,NULL,NULL,NULL);


	END IF;

/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCE QUERY AND SOURCE INTERMEDIATE TABLE   ENDS
*************************************************************************************************************/






/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCEINTERMEDIATE  TABLE  AND TARGET TABLE 
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 


	SELECT COUNT(*)
	INTO V_SRC_COUNT
	FROM  SI_CV_CHGAGTAPPLN;



    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM  CHANGE_AGENCY_APPLICATION;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_CV_CHGAGTAPPLN', V_SRC_COUNT, 'CHANGE_AGENCY_APPLICATION', V_TGT_COUNT,'N');	  



    IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO CHANGE_AGENCY_APPLICATION TABLE' ,'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO CHANGE_AGENCY_APPLICATION TABLE' ,'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO CHANGE_AGENCY_APPLICATION TABLE' ,'FAIL',NULL,NULL,NULL,NULL);

    ELSE 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', 
	V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO CHANGE_AGENCY_APPLICATION TABLE' ,'AMBIGIOUS',NULL,NULL,NULL,NULL);

	END IF;

/***********************************************************************************************************
RECONCILING THE COUNT OF SOURCE QUERY AND SOURCE INTERMEDIATE TABLE   ENDS
*************************************************************************************************************/


/***********************************************************************************************************
RECONCILING THE COUNT OF STAGING   TABLE  AND TARGET  TABLE STARTS
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 


    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM ST_CV_CHGAGTAPPLN ;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM  CHANGE_AGENCY_APPLICATION;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_CHGAGTAPPLN', V_SRC_COUNT, 'CHANGE_AGENCY_APPLICATION', V_TGT_COUNT,'Y');	  

/***********************************************************************************************************
RECONCILING THE COUNT OF STAGING   TABLE  AND SI  TABLE ENDS
*************************************************************************************************************/


EXCEPTION      --OUTER EXCEPTION FOR PROC_1_CHANGE_AGENCY_APPLCN
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;

V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END;                --outer end  for proc_1_change_agency_applcn
/