CREATE OR REPLACE PROCEDURE PROC_1_USR_DTLS (
    pv_run_id IN   NUMBER
) IS

    lv_cnt_st         NUMBER;
    lv_cnt_si         NUMBER;
    lv_cnt_tar        NUMBER;
    lv_cnt_tar_prof        NUMBER;
    lv_cnt_tar_priv        NUMBER;
    v_err_code        VARCHAR2(1000);
    v_err_msg         VARCHAR2(1000);
    v_sqlerrm         VARCHAR2(1000);
    v_exp_rows_si     VARCHAR2(4000);
    v_exp_rows_appl   VARCHAR2(4000);
    v_exp_rows_doc    VARCHAR2(4000);
    lv_v_nric_n       VARCHAR2(2);
    lv_usr_id_ty_c    VARCHAR2(10);
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_USR_DTLS
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-JUL-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :ROHIT KHOOL
   MODIFIED DATE  :10-SEP-2019, 30-SEP-2019

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR cr_si_usr_dtls IS
        
        SELECT
        xu.loginid_c,
        xu.nric_n,
        xu.loginid_m,
        xu.email_x,
        xu.mobile_n,
        xu.SUSPEND_I, xu.SUS_BY_ISC_I, 
        case
            WHEN xu.SUSPEND_I = 1 then 'SUSPENDED'
            WHEN xu.SUS_BY_ISC_I = 1 THEN 'DISABLED'
            ELSE 'ACTIVE'
        END ST_C ,    
        xc.UEN_N,
        xu.isc_i, xc.CO_REG_N
    FROM
        st_xr_usr   xu,
        st_xr_coreg xc
    WHERE
        xu.org_c = xc.org_c
        AND NOT EXISTS (SELECT  USR_LOGON_ID_N 
                        FROM USR_DTLS n WHERE   xu.loginid_c = n.USR_LOGON_ID_N  )   ;

------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------

    CURSOR cr_usr_dtls IS
    SELECT
        loginid_c,
        nric_n,
        loginid_m,
        email_x,
        mobile_n,
        USR_ST_C,UEN_N,
        isc_i,CO_REG_N
    FROM
        si_usr_dtls;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE rec_si_usr_dtls IS RECORD (
        v_loginid_c       st_xr_usr.loginid_c%TYPE,
        v_nric_n          st_xr_usr.nric_n%TYPE,
        v_loginid_m       st_xr_usr.loginid_m%TYPE,
        v_email_x         st_xr_usr.email_x%TYPE,
        v_mobile_n        st_xr_usr.mobile_n%TYPE,
        V_SUSPEND_I       st_xr_usr.SUSPEND_I%TYPE, 
        V_SUS_BY_ISC_I    st_xr_usr.SUS_BY_ISC_I%TYPE, 
        v_USR_ST_C         USR_DTLS.USR_ST_C%TYPE,
        v_UEN_N           st_xr_coreg.UEN_N%TYPE,
        v_isc_i           st_xr_usr.isc_i%TYPE,
        v_CO_REG_N        st_xr_coreg.CO_REG_N%TYPE
    );
    TYPE typ_si_usr_dtls IS
        TABLE OF rec_si_usr_dtls INDEX BY PLS_INTEGER;
    lv_si_usr_dtls    typ_si_usr_dtls;
    TYPE rec_usr_dtls IS RECORD (
        v_loginid_c       si_usr_dtls.loginid_c%TYPE,
        v_nric_n          si_usr_dtls.nric_n%TYPE,
        v_loginid_m       si_usr_dtls.loginid_m%TYPE,
        v_email_x         si_usr_dtls.email_x%TYPE,
        v_mobile_n        si_usr_dtls.mobile_n%TYPE,
        v_USR_ST_C         si_usr_dtls.USR_ST_C%TYPE,
        v_UEN_N             si_usr_dtls.UEN_N%TYPE,
        v_isc_i           si_usr_dtls.isc_i%TYPE,
        v_CO_REG_N         si_usr_dtls.CO_REG_N%TYPE
    );
    TYPE typ_usr_dtls IS
        TABLE OF rec_usr_dtls INDEX BY PLS_INTEGER;
    lv_usr_dtls       typ_usr_dtls;
BEGIN
    execute immediate 'truncate table SI_USR_DTLS';
    SELECT
        COUNT(*)
    INTO lv_cnt_st
    FROM
        st_xr_usr xu,
        st_xr_coreg xc
    WHERE
        xu.org_c = xc.org_c;   ---- DRIVING TABLE COUNT 

    OPEN cr_si_usr_dtls;
    pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE SI_USR_DTLS', 'START'
    , pv_run_id, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH cr_si_usr_dtls BULK COLLECT INTO lv_si_usr_dtls LIMIT 10000;
        EXIT WHEN lv_si_usr_dtls.count = 0;
        FOR i IN lv_si_usr_dtls.first..lv_si_usr_dtls.last LOOP
            BEGIN
                INSERT INTO si_usr_dtls (
                    loginid_c,
                    nric_n,
                    loginid_m,
                    email_x,
                    mobile_n,
                    USR_ST_C,UEN_N,
                    isc_i,CO_REG_N
                    
                ) VALUES (
                    lv_si_usr_dtls(i).v_loginid_c,
                    lv_si_usr_dtls(i).v_nric_n,
                    lv_si_usr_dtls(i).v_loginid_m,
                    lv_si_usr_dtls(i).v_email_x,
                    lv_si_usr_dtls(i).v_mobile_n,
                    lv_si_usr_dtls(i).v_USR_ST_C, lv_si_usr_dtls(i).v_UEN_N,
                    lv_si_usr_dtls(i).v_isc_i,lv_si_usr_dtls(i).v_CO_REG_N
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := dbms_utility.format_error_backtrace
                                 || v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows_si := lv_si_usr_dtls(i).v_loginid_c
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_nric_n
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_loginid_m
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_email_x
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_mobile_n
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_USR_ST_C
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_UEN_N
                                     || '<{||}>'
                                     || lv_si_usr_dtls(i).v_isc_i
                                     || '<{||}>'
                                     ||lv_si_usr_dtls(i).v_CO_REG_N;

                    pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', v_sqlerrm, 'ERROR', pv_run_id

                    , sqlerrm, v_exp_rows_si, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;
CLOSE cr_si_usr_dtls;
    SELECT
        COUNT(*)
    INTO lv_cnt_si
    FROM
        si_usr_dtls;   ---- INTERMIDATE TABLE COUNT 

    IF ( lv_cnt_si = lv_cnt_st ) AND lv_cnt_st <> 0 AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_si
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_st
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_si <> lv_cnt_st AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_si
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_st
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_si <> lv_cnt_st OR lv_cnt_si = lv_cnt_st ) AND ( lv_cnt_si = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_si
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_st
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('ST_XR_USR', lv_cnt_st, 'SI_USR_DTLS', lv_cnt_si, 'N');
    OPEN cr_usr_dtls;
    pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE USR_DTLS', 'START', pv_run_id
    , NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH cr_usr_dtls BULK COLLECT INTO lv_usr_dtls LIMIT 10000;
        EXIT WHEN lv_usr_dtls.count = 0;
        FOR j IN lv_usr_dtls.first..lv_usr_dtls.last LOOP
            BEGIN
          /*      SELECT
                    substr(lv_usr_dtls(j).v_nric_n, 1, 1)
                INTO lv_v_nric_n
                FROM
                    dual;

                IF lv_v_nric_n IN (
                    'S',
                    'T'
                ) THEN
                    lv_usr_id_ty_c := 'NRIC';
                ELSIF lv_v_nric_n IN (
                    'F',
                    'G'
                ) THEN
                    lv_usr_id_ty_c := 'FIN';
                ELSE
                    lv_usr_id_ty_c := 'PASSPORT';
                END IF;
            */
                INSERT INTO usr_dtls (
                    id_n,
                    usr_logon_id_n,
                    usr_id_ty_c,
                    usr_id_n,
                    usr_m,
                    usr_email_addr_x,
                    usr_tel_n,
                    usr_st_c,
                    usr_pswd_m,
                    co_uen_n,
                    lock_ver_n,
                    deleted_i,
                    crt_on_dt,
                    lst_upd_on_dt,
                    crt_by_n,
                    lst_upd_by_n
                ) VALUES (
                    syn_seq_usr_dts_id_n.NEXTVAL,       --SYN_SEQ_USR_SERV_ID.NEXTVAL,
                    lv_usr_dtls(j).v_loginid_c,
                  --  lv_usr_id_ty_c,         --'NRIC',
                    decode(substr(lv_usr_dtls(j).v_nric_n, 1, 1),'S','NRIC','T','NRIC','F','FIN','G','FIN','PASSPORT'),
                    lv_usr_dtls(j).v_nric_n,
                    lv_usr_dtls(j).v_loginid_m,
                    lv_usr_dtls(j).v_email_x,
                    lv_usr_dtls(j).v_mobile_n,
                    lv_usr_dtls(j).v_USR_ST_C,
                    NULL,
                    lv_usr_dtls(j).v_UEN_N,
                    0,
                    0,
                    SYSDATE,
                    SYSDATE,
                    'DATA MIGRATION',
                    'DATA MIGRATION'
                );

                IF lv_usr_dtls(j).v_co_reg_n IS NULL THEN
                    INSERT INTO auth_profile (
                        id_n,
                        refr_id,
                        profile_ty,
                        lock_ver_n
                    ) VALUES (
                        syn_seq_auth_profile_id_n.NEXTVAL,
                        syn_seq_usr_dts_id_n.CURRVAL,       --SYN_SEQ_USR_SERV_ID.CURRVAL,
                        'INDIVIDUAL',
                        0
                    );

                END IF;

                IF lv_usr_dtls(j).v_isc_i = 1 THEN
                    INSERT INTO usr_privileges (
                        usr_dtls_id_n,
                        usr_privilege_id_n
                    ) VALUES (
                        syn_seq_usr_dts_id_n.CURRVAL,
                        1       ----LV_USR_DTLS(J).V_LOGINID_C,
                    );

                END IF;

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := dbms_utility.format_error_backtrace
                                 || v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows_si := lv_usr_dtls(j).v_loginid_c
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_nric_n
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_loginid_m
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_email_x
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_mobile_n
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_USR_ST_C
                                     || '<{||}>'
                                     || lv_usr_dtls(j).v_co_reg_n;

                    pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', v_sqlerrm, 'ERROR', pv_run_id

                    , sqlerrm, v_exp_rows_si, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;
CLOSE cr_usr_dtls;
    SELECT
        COUNT(*)
    INTO lv_cnt_tar
    FROM
        usr_dtls;  ---- TARGET TABLE COUNT 

     SELECT
        COUNT(*)
    INTO lv_cnt_tar_prof
    FROM
        auth_profile where PROFILE_TY = 'INDIVIDUAL' ; 
        
      SELECT
        COUNT(*)
    INTO lv_cnt_tar_priv
    FROM
        usr_privileges; 
        
    IF ( lv_cnt_tar = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_tar
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_si
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_tar <> lv_cnt_si AND lv_cnt_tar <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_tar
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_si
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_tar <> lv_cnt_si OR lv_cnt_tar = lv_cnt_si ) AND ( lv_cnt_tar = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('USER_SERVICE', 'PROC_1_USR_DTLS', lv_cnt_tar
                                                                                          || ' OUT OF '
                                                                                          || lv_cnt_si
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('SI_USR_DTLS', lv_cnt_si, 'USR_DTLS', lv_cnt_tar, 'N');
    pkg_datamigration_generic.proc_migration_recon('ST_XR_USR', lv_cnt_st, 'USR_DTLS', lv_cnt_tar, 'Y');
    pkg_datamigration_generic.proc_migration_recon('ST_XR_USR', lv_cnt_st, 'AUTH_PROFILE', lv_cnt_tar_prof, 'Y');
    pkg_datamigration_generic.proc_migration_recon('ST_XR_USR', lv_cnt_st, 'USR_PRIVILEGES', lv_cnt_tar_priv, 'Y');

EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200)
                     || dbms_utility.format_error_backtrace;
        v_sqlerrm := v_err_code || v_err_msg;
        pkg_datamigration_generic.proc_trace_exception('USR_DTLS', 'PROC_1_USR_DTLS', v_sqlerrm, 'FAIL', NULL, NULL, NULL, 'T');

END PROC_1_USR_DTLS;
/