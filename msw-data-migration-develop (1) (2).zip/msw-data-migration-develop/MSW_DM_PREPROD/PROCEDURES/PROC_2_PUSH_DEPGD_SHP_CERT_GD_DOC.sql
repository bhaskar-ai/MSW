CREATE OR REPLACE PROCEDURE PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC IS
/***********************************************************************************************************
PROCEDURE NAME : PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC
CREATED BY     : SOURANGSHU DHAR
DATE           : 07-NOV-2019
PURPOSE        : PUSH DEPGD_SHP_CERT and GD_DOC RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO TARGET SCHEMA CVS_INTEGRATION
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/

---**** cursor for fetching data from target  Table ****

    CURSOR CUR_DEPGD_SHP_CERT IS
    SELECT
        ID,
        APPLN_REF_N,
        CERT_TY_C,
        ISS_DT,
        DUE_DT,
        ISS_AUTHY_CTRY_C,
        ISSG_CL_C,
        ST_C,
        DELETED_I,
        LOCK_VER_N,
        CRT_ON_DT,
        CRT_BY_N,
        LST_UPD_ON_DT,
        LST_UPD_BY_N,
        ISSG_CL_DESC_X,
        NO_PERS_ALLW_Q
    FROM
        DEP_GD_SHP_CERT;

    TYPE REC_DEPGD_SHP_CERT IS RECORD (
        ID                       DEP_GD_SHP_CERT.ID%TYPE,
        APPLN_REF_N              DEP_GD_SHP_CERT.APPLN_REF_N%TYPE,
        CERT_TY_C                DEP_GD_SHP_CERT.CERT_TY_C%TYPE,
        ISS_DT                   DEP_GD_SHP_CERT.ISS_DT%TYPE,
        DUE_DT                   DEP_GD_SHP_CERT.DUE_DT%TYPE,
        ISS_AUTHY_CTRY_C         DEP_GD_SHP_CERT.ISS_AUTHY_CTRY_C%TYPE,
        ISSG_CL_C                DEP_GD_SHP_CERT.ISSG_CL_C%TYPE,
        ST_C                     DEP_GD_SHP_CERT.ST_C%TYPE,
        DELETED_I                DEP_GD_SHP_CERT.DELETED_I%TYPE,
        LOCK_VER_N               DEP_GD_SHP_CERT.LOCK_VER_N%TYPE,
        CRT_ON_DT                DEP_GD_SHP_CERT.CRT_ON_DT%TYPE,
        CRT_BY_N                 DEP_GD_SHP_CERT.CRT_BY_N%TYPE,
        LST_UPD_ON_DT            DEP_GD_SHP_CERT.LST_UPD_ON_DT%TYPE,
        LST_UPD_BY_N             DEP_GD_SHP_CERT.LST_UPD_BY_N%TYPE,
        ISSG_CL_DESC_X           DEP_GD_SHP_CERT.ISSG_CL_DESC_X%TYPE,
        NO_PERS_ALLW_Q           DEP_GD_SHP_CERT.NO_PERS_ALLW_Q%TYPE
    );
    TYPE TYPE_DEPGD_SHP_CERT IS
        TABLE OF REC_DEPGD_SHP_CERT;
    LV_DEPGD_SHP_CERT        TYPE_DEPGD_SHP_CERT;
    CURSOR CUR_GD_DOC IS
    SELECT
        ID,
        GD_SHIP_CERTIFICATE_ID,
        DOC_TY_C,
        DOC_ID_N,
        SFTP_PATH_X,
        FILE_M,
        MIMI_TY_C,
        DELETED_I
    FROM
        GD_DOC;

    TYPE REC_GD_DOC IS RECORD (
        ID                       GD_DOC.ID%TYPE,
        GD_SHIP_CERTIFICATE_ID   GD_DOC.GD_SHIP_CERTIFICATE_ID%TYPE,
        DOC_TY_C                 GD_DOC.DOC_TY_C%TYPE,
        DOC_ID_N                 GD_DOC.DOC_ID_N%TYPE,
        SFTP_PATH_X              GD_DOC.SFTP_PATH_X%TYPE,
        FILE_M                   GD_DOC.FILE_M%TYPE,
        MIMI_TY_C                GD_DOC.MIMI_TY_C%TYPE,
        DELETED_I                GD_DOC.DELETED_I%TYPE
    );
    TYPE TYPE_GD_DOC IS
        TABLE OF REC_GD_DOC;
    LV_GD_DOC                TYPE_GD_DOC;
    LV_CNT_DEPGD_SHP_CRT     NUMBER;
    LV_CNT_DEPGD_SHP_CRT_T   NUMBER;
    LV_CNT_GD_DOC            NUMBER;
    LV_CNT_GD_DOC_T          NUMBER;
    V_ERR_CODE               NUMBER;
    V_ERR_MSG                VARCHAR2(500);
    V_SQLERRM                VARCHAR2(2500);
    V_BLKEXPTN_COUNT         NUMBER(20, 0);
    V_BLKEXPTN_DESC          VARCHAR2(3000);
    V_EXP_ROWS               VARCHAR2(4000);
BEGIN
    SELECT
        COUNT(*)
    INTO LV_CNT_DEPGD_SHP_CRT
    FROM
        DEP_GD_SHP_CERT;

    OPEN CUR_DEPGD_SHP_CERT;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPGD_SHP_CERT', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', 'Insertion into target Table DEPGD_SHP_CERT'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form DEPGD_SHP_CERT and Inserting into target table CVS_INTEGRATION.DEP_GD_SHP_CERT ************------------------        
        FETCH CUR_DEPGD_SHP_CERT BULK COLLECT INTO LV_DEPGD_SHP_CERT LIMIT 10000;
        EXIT WHEN LV_DEPGD_SHP_CERT.COUNT = 0;
			--FORALL i IN LV_ARRGD.first..LV_ARRGD.last SAVE EXCEPTIONS       
        FOR I IN LV_DEPGD_SHP_CERT.FIRST..LV_DEPGD_SHP_CERT.LAST LOOP
-------------************ SYN_DEP_GD_SHP_CERT is synonym of CVS_INTEGRATION.DEPGD_SHP_CERT  ************------------------  
            BEGIN
                INSERT INTO SYN_DEP_GD_SHP_CERT (
                    ID,
                    APPLN_REF_N,
                    CERT_TY_C,
                    ISS_DT,
                    DUE_DT,
                    ISS_AUTHY_CTRY_C,
                    ISSG_CL_C,
                    ST_C,
                    DELETED_I,
                    LOCK_VER_N,
                    CRT_ON_DT,
                    CRT_BY_N,
                    LST_UPD_ON_DT,
                    LST_UPD_BY_N,
                    ISSG_CL_DESC_X,
                    NO_PERS_ALLW_Q
                ) VALUES (
                    LV_DEPGD_SHP_CERT(I).ID,
                    LV_DEPGD_SHP_CERT(I).APPLN_REF_N,
                    LV_DEPGD_SHP_CERT(I).CERT_TY_C,
                    LV_DEPGD_SHP_CERT(I).ISS_DT,
                    LV_DEPGD_SHP_CERT(I).DUE_DT,
                    LV_DEPGD_SHP_CERT(I).ISS_AUTHY_CTRY_C,
                    LV_DEPGD_SHP_CERT(I).ISSG_CL_C,
                    LV_DEPGD_SHP_CERT(I).ST_C,
                    LV_DEPGD_SHP_CERT(I).DELETED_I,
                    LV_DEPGD_SHP_CERT(I).LOCK_VER_N,
                    LV_DEPGD_SHP_CERT(I).CRT_ON_DT,
                    LV_DEPGD_SHP_CERT(I).CRT_BY_N,
                    LV_DEPGD_SHP_CERT(I).LST_UPD_ON_DT,
                    LV_DEPGD_SHP_CERT(I).LST_UPD_BY_N,
                    LV_DEPGD_SHP_CERT(I).ISSG_CL_DESC_X,
                    LV_DEPGD_SHP_CERT(I).NO_PERS_ALLW_Q
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS := LV_DEPGD_SHP_CERT(I).ID
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).APPLN_REF_N
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).CERT_TY_C
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).ISS_DT
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).DUE_DT
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).ISS_AUTHY_CTRY_C
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).ISSG_CL_C
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).ST_C
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).DELETED_I
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).LOCK_VER_N
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).CRT_ON_DT
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).CRT_BY_N
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).LST_UPD_ON_DT
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).LST_UPD_BY_N
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).ISSG_CL_DESC_X
                                  || '<{||}>'
                                  || LV_DEPGD_SHP_CERT(I).NO_PERS_ALLW_Q;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPGD_SHP_CERT', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', V_ERR_MSG

                    , 'ERROR', NULL, V_SQLERRM, V_EXP_ROWS, 'T');

            END;
        END LOOP;
    COMMIT ;
    END LOOP;

    CLOSE CUR_DEPGD_SHP_CERT;
    SELECT
        COUNT(*)
    INTO LV_CNT_DEPGD_SHP_CRT_T
    FROM
        SYN_DEP_GD_SHP_CERT;

    IF ( LV_CNT_DEPGD_SHP_CRT = LV_CNT_DEPGD_SHP_CRT_T ) AND LV_CNT_DEPGD_SHP_CRT <> 0 AND LV_CNT_DEPGD_SHP_CRT_T <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPGD_SHP_CERT', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', LV_CNT_DEPGD_SHP_CRT_T
                                                                                                              || ' OUT OF '
                                                                                                              || LV_CNT_DEPGD_SHP_CRT
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_SHP_CERT'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF LV_CNT_DEPGD_SHP_CRT <> LV_CNT_DEPGD_SHP_CRT_T AND LV_CNT_DEPGD_SHP_CRT <> 0 AND LV_CNT_DEPGD_SHP_CRT_T <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPGD_SHP_CERT', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', LV_CNT_DEPGD_SHP_CRT_T
                                                                                                              || ' OUT OF '
                                                                                                              || LV_CNT_DEPGD_SHP_CRT
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_SHP_CERT'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF LV_CNT_DEPGD_SHP_CRT <> 0 AND LV_CNT_DEPGD_SHP_CRT_T = 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPGD_SHP_CERT', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', LV_CNT_DEPGD_SHP_CRT_T
                                                                                                              || ' OUT OF '
                                                                                                              || LV_CNT_DEPGD_SHP_CRT
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_SHP_CERT'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEPGD_SHP_CERT', LV_CNT_DEPGD_SHP_CRT, 'SYN_DEP_GD_SHP_CERT', LV_CNT_DEPGD_SHP_CRT_T

    , 'Y');

    /***********************************************************************************************************
	Pushing records into CVS_INTEGRATION.GD_DOC
    ***********************************************************************************************************/
    SELECT
        COUNT(*)
    INTO LV_CNT_GD_DOC
    FROM
        GD_DOC;

    OPEN CUR_GD_DOC;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', 'Insertion into SYN_GD_DOC'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form GD_DOC and inseting into target table CVS_INTEGRATION.GD_DOC ************------------------        
        FETCH CUR_GD_DOC BULK COLLECT INTO LV_GD_DOC LIMIT 10000;
        EXIT WHEN LV_GD_DOC.COUNT = 0;
        FOR J IN LV_GD_DOC.FIRST..LV_GD_DOC.LAST LOOP
-------------************ SYN_GD_DOC is synonym of CVS_INTEGRATION.GD_DOC  ************------------------  
            BEGIN
                INSERT INTO SYN_GD_DOC (
                    ID,
                    GD_SHIP_CERTIFICATE_ID,
                    DOC_TY_C,
                    DOC_ID_N,
                    SFTP_PATH_X,
                    FILE_M,
                    MIMI_TY_C,
                    DELETED_I
                ) VALUES (
                    LV_GD_DOC(J).ID,
                    LV_GD_DOC(J).GD_SHIP_CERTIFICATE_ID,
                    LV_GD_DOC(J).DOC_TY_C,
                    LV_GD_DOC(J).DOC_ID_N,
                    LV_GD_DOC(J).SFTP_PATH_X,
                    LV_GD_DOC(J).FILE_M,
                    LV_GD_DOC(J).MIMI_TY_C,
                    LV_GD_DOC(J).DELETED_I
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS := LV_GD_DOC(J).ID
                                  || '<{||}>'
                                  || LV_GD_DOC(J).GD_SHIP_CERTIFICATE_ID
                                  || '<{||}>'
                                  || LV_GD_DOC(J).DOC_TY_C
                                  || '<{||}>'
                                  || LV_GD_DOC(J).DOC_ID_N
                                  || '<{||}>'
                                  || LV_GD_DOC(J).SFTP_PATH_X
                                  || '<{||}>'
                                  || LV_GD_DOC(J).FILE_M
                                  || '<{||}>'
                                  || LV_GD_DOC(J).MIMI_TY_C
                                  || '<{||}>'
                                  || LV_GD_DOC(J).DELETED_I;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC', V_ERR_MSG, 'ERROR'

                    , NULL, V_SQLERRM, V_EXP_ROWS, 'T');

            END;
        END LOOP;
    COMMIT ;
    END LOOP;

    CLOSE CUR_GD_DOC;
    SELECT
        COUNT(*)
    INTO LV_CNT_GD_DOC_T
    FROM
        SYN_GD_DOC;

    IF ( LV_CNT_GD_DOC = LV_CNT_GD_DOC_T ) AND LV_CNT_GD_DOC_T <> 0 AND LV_CNT_GD_DOC <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD', LV_CNT_GD_DOC_T
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_GD_DOC
                                                                                          || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.GD_DOC'
                                                                                          , 'SUCCESS', NULL, NULL, NULL, NULL);
    ELSIF LV_CNT_GD_DOC <> LV_CNT_GD_DOC_T AND LV_CNT_GD_DOC_T <> 0 AND LV_CNT_GD_DOC <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD', LV_CNT_GD_DOC_T
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_GD_DOC
                                                                                          || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.GD_DOC'
                                                                                          , 'PARTIALLY SUCCESSFULL', NULL, NULL, NULL
                                                                                          , NULL);
    ELSIF LV_CNT_GD_DOC <> 0 AND LV_CNT_GD_DOC_T = 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD', LV_CNT_GD_DOC_T
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_GD_DOC
                                                                                          || ' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.GD_DOC'
                                                                                          , 'FAIL', NULL, NULL, NULL, NULL);
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('GD_DOC', LV_CNT_GD_DOC, 'SYN_GD_DOC', LV_CNT_GD_DOC_T, 'Y');
END PROC_2_PUSH_DEPGD_SHP_CERT_GD_DOC;
/