create or replace PROCEDURE PROC_1_ICA_USR_REQUEST(PV_RUN_ID IN NUMBER) IS

/*************************************************************************************************************************************************************************	
			PROCEDURE NAME : PROC_1_ICA_USR_REQUEST
			CREATED BY     : Rohit Khool
			DATE           : 03-OCT-2019
			PURPOSE        : INSERTING  THE DATA FROM ST_ICA_USERROLES TO ICA_USR_REQUEST
			MODIFIED BY    : TIYASHA DATTA
			MODIFIED DATE  : 28-NOV-2019
*************************************************************************************************************************************************************************/

	CURSOR CR_ICA IS
    
    SELECT 
	COY_RCB,
	USER_ID,
	ROLES
	FROM ST_ICA_USERROLES
    WHERE NOT EXISTS (SELECT  USR_ID_N FROM USR_DTLS_PROD_BKP n WHERE   USER_ID = n.USR_ID_N  )  ; --Changed table name by Tiyasha 28/11
    
    CURSOR CR_USR_PRIV IS
    
    SELECT 
    REPLACE(A.ROLES, CHR(13), '')ROLES,
   -- A.ROLES,
	B.ID_N
	FROM ST_ICA_USERROLES A , USR_DTLS_PROD_BKP B 
    WHERE A.USER_ID = B.USR_ID_N ; --Changed table name by Tiyasha 28/11
    
   	TYPE REC_ICA IS RECORD 
	(
    V_COY_RCB            ST_ICA_USERROLES.COY_RCB%TYPE,
    V_USER_ID            ST_ICA_USERROLES.USER_ID%TYPE,
    V_ROLES              ST_ICA_USERROLES.ROLES%TYPE
    );

    TYPE TYP_REC_ICA IS
	TABLE OF REC_ICA INDEX BY PLS_INTEGER;
    LV_ICA       TYP_REC_ICA;
    
    TYPE REC_USR_PRIV IS RECORD 
	(
    V_ROLES           ST_ICA_USERROLES.ROLES%TYPE,
    V_ID_N            USR_DTLS.ID_N%TYPE
    );

    TYPE TYP_USR_PRIV IS
	TABLE OF REC_USR_PRIV INDEX BY PLS_INTEGER;
    LV_USR_PRIV       TYP_USR_PRIV;

	LV_CNT_ST         NUMBER;
    LV_CNT_TAR        NUMBER;
    LV_CNT_USR_PRIV         NUMBER ;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    J                 NUMBER := 1 ;
    LV_V_ROLE         NUMBER := 0 ;
    LV_V_ROLE_DESC    VARCHAR2(20);

BEGIN
   
    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
	ST_ICA_USERROLES;
    
    /****Added by Tiyasha 28-Nov****/
    
    EXECUTE IMMEDIATE 'TRUNCATE TABLE USR_DTLS_PROD_BKP';
    
    EXECUTE IMMEDIATE 'INSERT INTO USR_DTLS_PROD_BKP SELECT * FROM SYN_USR_DTLS ';
    
    /****Added by Tiyasha 28-Nov****/

    OPEN CR_ICA;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', 'INSERTION INTO TABLE ICA_USR_REQUEST', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO TARGET  TABLE ***********************---------------
        FETCH CR_ICA BULK COLLECT INTO LV_ICA LIMIT 10000;
        EXIT WHEN LV_ICA.COUNT = 0;

        FOR I IN LV_ICA.FIRST..LV_ICA.LAST LOOP

        BEGIN
                INSERT INTO ICA_USR_REQUEST (
											ID_N,
											CO_UEN_N, 
											USR_ID_TY_C,
											USR_ID_N, 
											CRT_BY_N,
											CRT_ON_DT,
											ST_C 
											) 
								VALUES (
										SEQ_USR_REQ.NEXTVAL,
										LV_ICA(I).V_COY_RCB,		
										'NRIC',		
										LV_ICA(I).V_USER_ID,		
										'DATA MIGRATION'	,	
										SYSDATE,		
										NULL		
										);

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG        || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := 'ID_N: '||SEQ_USR_REQ.NEXTVAL || 
									' CO_UEN_N: '||LV_ICA(I).V_COY_RCB || 
									' USR_ID_TY_C: '||'NRIC' ||		
									' USR_ID_N: '||LV_ICA(I).V_USER_ID || 
									' CRT_BY_N: '||'DATA MIGRATION'	||
									' CRT_ON_DT: '||SYSDATE	 ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', V_SQLERRM, 'ERROR', PV_RUN_ID , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;
	CLOSE CR_ICA;
----------------------------------------------------------
 OPEN CR_USR_PRIV;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_PRIVILEDGE', 'PROC_1_ICA_USR_REQUEST', 'INSERTION INTO TABLE USR_PRIVILEGES', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO TARGET  TABLE ***********************---------------
        FETCH CR_USR_PRIV BULK COLLECT INTO LV_USR_PRIV LIMIT 10000;
        EXIT WHEN LV_USR_PRIV.COUNT = 0;

        FOR K IN LV_USR_PRIV.FIRST..LV_USR_PRIV.LAST 
        LOOP
            J := 1 ;
            WHILE J <= LENGTH(LV_USR_PRIV(K).V_ROLES)
            LOOP
     /*
            SELECT DECODE(SUBSTR(LV_USR_PRIV(K).V_ROLES,J,1),'A','4','P','3','D','6','J','5','X','7')
                INTO LV_V_ROLE
            FROM DUAL;
       */     
            SELECT DECODE(SUBSTR(LV_USR_PRIV(K).V_ROLES,J,1),'A','SA','P','TP','D','MJLP-D','J','F-MJLP','X','E-MJLP')
                INTO LV_V_ROLE_DESC
            FROM DUAL;
            
            SELECT ID_N INTO LV_V_ROLE
            FROM SYS_PRIVILEGE_TY
            WHERE PRIVILEGE_TY_C = LV_V_ROLE_DESC
            AND AGENCY_X = 'ICA' ;
     
                INSERT INTO USR_PRIVILEGES (
											USR_DTLS_ID_N, 
                                            USR_PRIVILEGE_ID_N 
											) 
								VALUES (
										LV_USR_PRIV(K).V_ID_N,		
										LV_V_ROLE
										);
                 J := J + 1 ;
                
            END LOOP ;
             COMMIT ;
        END LOOP;
      
    END LOOP;
	CLOSE CR_USR_PRIV ;
--------------------------------------------------------

    SELECT  COUNT(*)
    INTO LV_CNT_TAR
    FROM ICA_USR_REQUEST;   ---- INTERMIDATE TABLE COUNT 
    
    SELECT COUNT(*)INTO LV_CNT_USR_PRIV
    FROM (
    SELECT USR_DTLS_ID_N,COUNT(*) 
    FROM USR_PRIVILEGES
    GROUP BY USR_DTLS_ID_N );

    IF ( LV_CNT_TAR = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_ST AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_ST OR LV_CNT_TAR = LV_CNT_ST ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_ICA_USERROLES', LV_CNT_ST, 'ICA_USR_REQUEST', LV_CNT_TAR, 'Y');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_ICA_USERROLES', LV_CNT_ST, 'USR_PRIVILEGES', LV_CNT_USR_PRIV, 'Y');



EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA_USR_REQUEST', 'PROC_1_ICA_USR_REQUEST', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ICA_USR_REQUEST;

/
