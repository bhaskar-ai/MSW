create or replace PROCEDURE PROC_1_PUSH_USR_PRIVILEGES  IS
    
/***********************************************************************************************************
PROCEDURE NAME : PROC_1_PUSH_USR_PRIVILEGES
CREATED BY     : ROHIT KHOOL
DATE           : 10-SEP-2019
PURPOSE        : TO PUSH USR_DTL TABLE RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO RESPECTIVE TARGET SCHEMAS AUTHENTICATION_SERVICE.USR_DTL
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****

	CURSOR cr_usr_privledge IS
    SELECT
        usr_dtls_id_n,
        usr_privilege_id_n
    FROM
        usr_privileges;

	TYPE rec_usr_priviledges IS RECORD (
        usr_dtls_id_n         usr_privileges.usr_dtls_id_n%TYPE,
        usr_privilege_id_n    usr_privileges.usr_privilege_id_n%TYPE
    );

    TYPE type_usr_priviledges IS
        TABLE OF rec_usr_priviledges;
    lv_usr_priviledges    type_usr_priviledges;

    lv_cnt_dm_ud_priv     NUMBER;
    lv_cnt_tt_ud_priv     NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);	
    V_EXP_ROWS          VARCHAR2(1000);


BEGIN

	SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_priv
    FROM
        usr_privileges;



	OPEN cr_usr_privledge;
    pkg_datamigration_generic.proc_trace_exception('DM_USR_PRIVILEGES', 'PROC_1_PUSH_USR_PRIVILEGES', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.USR_PRIVLEDGE'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
-------------************ Fetching records form DM_ORG_PRIVLEDGE and inseting into target table AUTHENTICATION_SERVICE.ORG_PRIVLEDGE ************------------------        
        FETCH cr_usr_privledge BULK COLLECT INTO lv_usr_priviledges LIMIT 10000;
        EXIT WHEN lv_usr_priviledges.count = 0;
        FOR k IN lv_usr_priviledges.first..lv_usr_priviledges.last LOOP			
-------------************ SYN_ORG_PRIVLEDGE is synonym of AUTHENTICATION_SERVICE.ORG_PRIVLEDGE  ************------------------  
            BEGIN
                INSERT INTO syn_usr_privileges (
                    usr_dtls_id_n,
                    usr_privilege_id_n
                ) VALUES (
                    lv_usr_priviledges(k).usr_dtls_id_n,
                    lv_usr_priviledges(k).usr_privilege_id_n
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' USR_DTLS_ID_N: '
                                  || lv_usr_priviledges(k).usr_dtls_id_n
                                  || ' USR_PRIVILEGE_ID_N: '
                                  || lv_usr_priviledges(k).usr_privilege_id_n;

                    pkg_datamigration_generic.proc_trace_exception('DM_USR_PRIVILEGES', 'PROC_1_PUSH_USR_PRIVILEGES',v_err_msg,'ERROR',NULL,
                    v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_usr_privledge;

	 SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_priv
    FROM
        syn_usr_privileges;

	IF ( lv_cnt_tt_ud_priv = lv_cnt_dm_ud_priv ) AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DM_USR_PRIVLEDGE', 'PROC_1_PUSH_USR_PRIVILEGES', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF lv_cnt_dm_ud_priv <> lv_cnt_tt_ud_priv AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DM_USR_PRIVILEGES', 'PROC_1_PUSH_USR_PRIVILEGES', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DM_USR_PRIVILEGES', 'PROC_1_PUSH_USR_PRIVILEGES', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;

   pkg_datamigration_generic.proc_migration_recon('DM_USR_PRIVILEGES', lv_cnt_dm_ud_priv, 'USR_PRIVILEGES', lv_cnt_tt_ud_priv, 'Y');

	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_USR_PRIVILEGES', 'PROC_1_PUSH_USR_PRIVILEGES', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_1_PUSH_USR_PRIVILEGES;
/