CREATE OR REPLACE PROCEDURE PROC_1_ORG_PRIVILEGES ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_SI         NUMBER;
    LV_CNT_SI_Y         NUMBER ;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    LV_ORG_LVL_X       VARCHAR2(5)  ;
    LV_ORG_U_N        VARCHAR2(10) ;
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_ORG_PRIVILEGES
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-NOV-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_SI_ORG_PRIVILEGES IS
	/*
    SELECT C.ID_N, A.WLYPCC_I, A.EPC_I, A.CRUISEOPER_I, A.RFOPER_I 
    FROM ST_PU_PORTCLRCESCHMMSTR A, ST_PU_USRORG B, ORG_DTLS C
    WHERE A.PUID_N = B.PUID_N 
    AND B.UEN_N = C.CO_UEN_N ;*/
    --Stanley: we link by PUID and Org Code instead
    SELECT C.ID_N, A.WLYPCC_I, A.EPC_I, A.CRUISEOPER_I, A.RFOPER_I 
    FROM ST_PU_PORTCLRCESCHMMSTR a
    INNER JOIN ST_PU_USRORG b ON a.PUID_N = b.PUID_N
    INNER JOIN ORG_DTLS c ON b.ORG_C = c.ORG_C;


------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
   CURSOR CR_ORG_PRIVILEGES IS
    SELECT
        *
    FROM
        SI_ORG_PRIVILEGES;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE REC_SI_ORG_PRIVILEGES IS RECORD (

        ID_N_R                ORG_DTLS.ID_N%TYPE,
        WLYPCC_I_R            ST_PU_PORTCLRCESCHMMSTR.WLYPCC_I%TYPE,
        EPC_I_R               ST_PU_PORTCLRCESCHMMSTR.EPC_I%TYPE,
        CRUISEOPER_I_R        ST_PU_PORTCLRCESCHMMSTR.CRUISEOPER_I%TYPE,
        RFOPER_I_R            ST_PU_PORTCLRCESCHMMSTR.RFOPER_I%TYPE
    );

    TYPE TYP_SI_ORG_PRIVILEGES IS
    TABLE OF REC_SI_ORG_PRIVILEGES INDEX BY PLS_INTEGER;

    LV_SI_ORG_PRIVILEGES    TYP_SI_ORG_PRIVILEGES;

    TYPE REC_ORG_PRIVILEGES IS RECORD (

        ID_N_R                ORG_DTLS.ID_N%TYPE,
        WLYPCC_I_R            ST_PU_PORTCLRCESCHMMSTR.WLYPCC_I%TYPE,
        EPC_I_R               ST_PU_PORTCLRCESCHMMSTR.EPC_I%TYPE,
        CRUISEOPER_I_R        ST_PU_PORTCLRCESCHMMSTR.CRUISEOPER_I%TYPE,
        RFOPER_I_R            ST_PU_PORTCLRCESCHMMSTR.RFOPER_I%TYPE
    );

    TYPE TYP_ORG_PRIVILEGES IS
    TABLE OF REC_ORG_PRIVILEGES INDEX BY PLS_INTEGER;

    LV_ORG_PRIVILEGES       TYP_ORG_PRIVILEGES;

BEGIN

execute immediate 'truncate table SI_ORG_PRIVILEGES';

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
        ST_PU_PORTCLRCESCHMMSTR ;    ---- DRIVING TABLE COUNT 

    OPEN CR_SI_ORG_PRIVILEGES;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', 'INSERTION INTO TABLE SI_ORG_PRIVILEGES', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH CR_SI_ORG_PRIVILEGES BULK COLLECT INTO LV_SI_ORG_PRIVILEGES LIMIT 10000;
        EXIT WHEN LV_SI_ORG_PRIVILEGES.COUNT = 0;

        FOR I IN LV_SI_ORG_PRIVILEGES.FIRST..LV_SI_ORG_PRIVILEGES.LAST LOOP

        BEGIN
                INSERT INTO SI_ORG_PRIVILEGES (
                    ID_N,
                    WLYPCC_I,
                    EPC_I,
                    CRUISEOPER_I,
                    RFOPER_I
                ) VALUES (
                    LV_SI_ORG_PRIVILEGES(I).ID_N_R ,
                    LV_SI_ORG_PRIVILEGES(I).WLYPCC_I_R,
                    LV_SI_ORG_PRIVILEGES(I).EPC_I_R,
                    LV_SI_ORG_PRIVILEGES(I).CRUISEOPER_I_R,
                    LV_SI_ORG_PRIVILEGES(I).RFOPER_I_R
                );

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_SI_ORG_PRIVILEGES(I).ID_N_R
                                     || '<{||}>'
                                     || LV_SI_ORG_PRIVILEGES(I).WLYPCC_I_R
                                     || '<{||}>'
                                     || LV_SI_ORG_PRIVILEGES(I).EPC_I_R
                                     || '<{||}>'
                                     || LV_SI_ORG_PRIVILEGES(I).CRUISEOPER_I_R
                                     || '<{||}>'
                                     || LV_SI_ORG_PRIVILEGES(I).RFOPER_I_R
                                     ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;
 CLOSE CR_SI_ORG_PRIVILEGES;
   -- COMMIT;

    SELECT  COUNT(*)
    INTO LV_CNT_SI
    FROM SI_ORG_PRIVILEGES;   ---- INTERMIDATE TABLE COUNT 
    
    SELECT COUNT(*) into LV_CNT_SI_Y
    FROM
    (
    SELECT * FROM SI_ORG_PRIVILEGES WHERE WLYPCC_I      = 'Y'
    UNION ALL
    SELECT * FROM SI_ORG_PRIVILEGES WHERE EPC_I         = 'Y'
    UNION ALL
    SELECT * FROM SI_ORG_PRIVILEGES WHERE CRUISEOPER_I  = 'Y'
    UNION ALL
    SELECT * FROM SI_ORG_PRIVILEGES WHERE RFOPER_I      = 'Y'
    ) ;                 --- Y count in SI Table

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PORTCLRCESCHMMSTR', LV_CNT_ST, 'SI_ORG_PRIVILEGES', LV_CNT_SI, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_ORG_PRIVILEGES', LV_CNT_SI, 'No.of Y counts in SI Table ', LV_CNT_SI_Y, 'N');

    OPEN CR_ORG_PRIVILEGES;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', 'INSERTION INTO TABLE ORG_PRIVILEGES', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_PRIVILEGES BULK COLLECT INTO LV_ORG_PRIVILEGES LIMIT 10000;
        EXIT WHEN LV_ORG_PRIVILEGES.COUNT = 0;

        FOR J IN LV_ORG_PRIVILEGES.FIRST..LV_ORG_PRIVILEGES.LAST LOOP
            BEGIN   

            IF LV_ORG_PRIVILEGES(J).WLYPCC_I_R = 'Y' THEN

                        INSERT INTO ORG_PRIVILEGES (
                            ORG_DTLS_ID_N,
                            CODEORG_PRIVILEGES_ID_N
                        ) VALUES (
                            LV_ORG_PRIVILEGES(J).ID_N_R ,
                            8
                        );
            END IF ;

            IF LV_ORG_PRIVILEGES(J).EPC_I_R = 'Y' THEN

                        INSERT INTO ORG_PRIVILEGES (
                            ORG_DTLS_ID_N,
                            CODEORG_PRIVILEGES_ID_N
                        ) VALUES (
                            LV_ORG_PRIVILEGES(J).ID_N_R ,
                            9
                        );
            END IF ;

            IF LV_ORG_PRIVILEGES(J).CRUISEOPER_I_R = 'Y' THEN

                        INSERT INTO ORG_PRIVILEGES (
                            ORG_DTLS_ID_N,
                            CODEORG_PRIVILEGES_ID_N
                        ) VALUES (
                            LV_ORG_PRIVILEGES(J).ID_N_R ,
                            10
                        );
            END IF ;

            IF LV_ORG_PRIVILEGES(J).RFOPER_I_R = 'Y' THEN

                        INSERT INTO ORG_PRIVILEGES (
                            ORG_DTLS_ID_N,
                            CODEORG_PRIVILEGES_ID_N
                        ) VALUES (
                            LV_ORG_PRIVILEGES(J).ID_N_R ,
                            11
                        );
            END IF ;

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                  /*  V_EXP_ROWS_SI :=    LV_ORG_PRIVILEGES(J).ID_N_R 
                                     || '<{||}>'
                                     || NULL
                                      ;
                */
                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, NULL , 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_ORG_PRIVILEGES;
  --  COMMIT;

    SELECT
    --COUNT(distinct ORG_DTLS_ID_N)
    COUNT(*)
    INTO LV_CNT_TAR
    FROM ORG_PRIVILEGES ;  ---- TARGET TABLE COUNT 

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('No.of Y counts in SI Table ', LV_CNT_SI_Y, 'ORG_PRIVILEGES', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PORTCLRCESCHMMSTR', LV_CNT_ST, 'ORG_PRIVILEGES', LV_CNT_TAR, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEGES', 'PROC_1_ORG_PRIVILEGES', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ORG_PRIVILEGES ;

/