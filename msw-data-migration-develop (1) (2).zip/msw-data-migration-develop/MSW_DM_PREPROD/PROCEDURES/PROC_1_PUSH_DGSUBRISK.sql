create or replace PROCEDURE PROC_1_PUSH_DGSUBRISK  IS

    
    
/***********************************************************************************************************
procedure name : PROC_1_PUSH_DGSUBRISK
Created By     : Rohit Khool
Date           : 07-SEP-2019
Purpose        : TO PUSH DG_CHEM AND DG_PSN TABLE RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO RESPECTIVE TARGET SCHEMAS DGDS_INTEGRATION.
Modified by    :
Modified date  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****

	CURSOR CR_DG_SUBRISK IS
	SELECT
		DSR.SUBRISK_ID, 
        DSR.SUBRISKINDX_N, 
        DSR.SUBRISK_C, 
        DSR.CHEMINDX_N, 
        DSR.CRTBY_M, 
        DSR.CRTON_DT, 
        DSR.UPT_BY_X, 
        DSR.UPT_ON_DT, 
        DSR.LOCK_VER_N, 
        DSR.DELETED_I
    FROM 
		DG_SUBRISK DSR;

	TYPE REC_DSR IS RECORD
	(
	V_SUBRISK_ID        DG_SUBRISK.SUBRISK_ID%TYPE, 
    V_SUBRISKINDX_N     DG_SUBRISK.SUBRISKINDX_N%TYPE, 
    V_SUBRISK_C         DG_SUBRISK.SUBRISK_C%TYPE, 
    V_CHEMINDX_N        DG_SUBRISK.CHEMINDX_N%TYPE, 
    V_CRTBY_M           DG_SUBRISK.CRTBY_M%TYPE, 
    V_CRTON_DT          DG_SUBRISK.CRTON_DT%TYPE, 
    V_UPT_BY_X          DG_SUBRISK.UPT_BY_X%TYPE, 
    V_UPT_ON_DT         DG_SUBRISK.UPT_ON_DT%TYPE, 
    V_LOCK_VER_N        DG_SUBRISK.LOCK_VER_N%TYPE, 
    V_DELETED_I         DG_SUBRISK.DELETED_I%TYPE
	);

    TYPE TYPE_DSR  IS TABLE OF REC_DSR;
	LV_DSR				TYPE_DSR ;

	LV_CNT_DM_DC       	NUMBER:=0;
	LV_CNT_TT_DC		NUMBER;
	LV_CNT_DM_PSN      	NUMBER;
	LV_CNT_TT_PSN		NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);	
    V_EXP_ROWS          VARCHAR2(1000);


BEGIN

	SELECT
    COUNT(*) INTO LV_CNT_DM_DC
    FROM 
    DG_SUBRISK;


	OPEN CR_DG_SUBRISK;
	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK', 'INSERTION INTO TARGET TABLE DG_SUBRISK', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.DG_CHEM and inseting into target table DGDS_INTEGRATION.DG_CHEM ************------------------        

			FETCH CR_DG_SUBRISK BULK COLLECT INTO LV_DSR LIMIT 10000;
            EXIT WHEN LV_DSR.count = 0;
			--FORALL i IN LV_DSR.first..LV_DSR.last SAVE EXCEPTIONS 
			FOR i IN LV_DSR.first..LV_DSR.last
			LOOP			
-------------************ SYN_DG_SUBRISK IS SYNONYM OF DGDS_INTEGRATION.DG_SUBRISK  ************------------------  
			BEGIN
			INSERT INTO SYN_DG_SUBRISK (
								SUBRISK_ID, SUBRISKINDX_N, SUBRISK_C, 
                                CHEMINDX_N, CRTBY_M, CRTON_DT, UPT_BY_X, UPT_ON_DT, LOCK_VER_N, DELETED_I
                                )
						VALUES (
                                        LV_DSR(i).V_SUBRISK_ID      ,
                                        LV_DSR(i).V_SUBRISKINDX_N   ,
                                        LV_DSR(i).V_SUBRISK_C       ,
                                        LV_DSR(i).V_CHEMINDX_N   ,   
                                        'DATA MIGRATION',   --LV_DSR(i).V_CRTBY_M         ,
                                        SYSDATE,    --LV_DSR(i).V_CRTON_DT        ,
                                        'DATA MIGRATION',   --LV_DSR(i).V_UPT_BY_X    ,
                                        SYSDATE,    --LV_DSR(i).V_UPT_ON_DT   ,
                                        0,    --LV_DSR(i).V_LOCK_VER_N  ,
                                        0     -- LV_DSR(i).V_DELETED_I
                        );
                        LV_CNT_TT_DC :=LV_CNT_TT_DC+1;
			        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                V_EXP_ROWS := 	' SUBRISK_ID: '       ||LV_DSR(i).V_SUBRISK_ID||
								' SUBRISKINDX_N: '    ||LV_DSR(i).V_SUBRISKINDX_N||
								' SUBRISK_C: '        ||LV_DSR(i).V_SUBRISK_C||
								' CHEMINDX_N: '       ||LV_DSR(i).V_CHEMINDX_N||
								' CRTBY_M: '          ||LV_DSR(i).V_CRTBY_M||
								' CRTON_DT: '         ||LV_DSR(i).V_CRTON_DT||
								' UPT_BY_X: '         ||LV_DSR(i).V_UPT_BY_X||
								' UPT_ON_DT: '        ||LV_DSR(i).V_UPT_ON_DT||
								' LOCK_VER_N: '       ||LV_DSR(i).V_LOCK_VER_N||
								' DELETED_I: '        ||LV_DSR(i).V_DELETED_I ;


             PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK',  V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,V_EXP_ROWS,'T');
		END;
        
		END LOOP;
COMMIT;

    END LOOP;
	CLOSE CR_DG_SUBRISK;	

	SELECT
    COUNT(*)
    INTO LV_CNT_TT_DC
    FROM
    SYN_DG_SUBRISK ;

	IF( LV_CNT_TT_DC =  LV_CNT_DM_DC ) AND LV_CNT_DM_DC <>  0  AND  LV_CNT_TT_DC <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK',
        LV_CNT_DM_DC||' OUT OF ' || LV_CNT_TT_DC ||' ROWS  HAVE BEEN INSERTED INTO DGDS_INTEGRATION.DG_SUBRISK' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_DC  <> LV_CNT_TT_DC AND  LV_CNT_DM_DC <> 0 AND  LV_CNT_TT_DC <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK',
        LV_CNT_DM_DC||' OUT OF ' || LV_CNT_TT_DC ||' ROWS  HAVE BEEN INSERTED INTO DGDS_INTEGRATION.DG_SUBRISK' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_DC  <> 0 AND  LV_CNT_TT_DC = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK',
        LV_CNT_DM_DC||' OUT OF ' || LV_CNT_TT_DC ||' ROWS  HAVE BEEN INSERTED INTO DGDS_INTEGRATION.DG_SUBRISK' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DM_DG_SUBRISK', LV_CNT_DM_DC, 'DG_SUBRISK', LV_CNT_TT_DC,'Y');

	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_DG_SUBRISK', 'PROC_1_PUSH_DGSUBRISK', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_1_PUSH_DGSUBRISK ;
/