create or replace PROCEDURE PROC_DG_VR_VC_AS_DEL IS

    v_err_code             NUMBER;
    v_sqlerrm              VARCHAR2(2000);
    v_err_msg              VARCHAR2(2000);

/*******************************************************************
cursor to delete  data from vessel call starts
*****************************************************************/
    CURSOR cur_dg_vslcal_del IS
    SELECT 
        vc.vsl_call_id_n
    FROM
        vessel_call vc,
        application_submission apsub
    WHERE
        vc.vsl_call_id_n = apsub.vsl_call_id_n
        AND vc.vsl_call_id_n NOT IN (
            SELECT vsl_call_id_n
            FROM
                dangerous_goods_application
        )
        AND apsub.appln_ty_c = 'DGD';

    TYPE rec_v_vsl_call_id_n IS RECORD (
        v_vsl_call_id_n        vessel_call.vsl_call_id_n%TYPE
    );
    TYPE type_v_vsl_call_id_n IS
        TABLE OF rec_v_vsl_call_id_n INDEX BY PLS_INTEGER;
    lv_v_vsl_call_id_n     type_v_vsl_call_id_n;

/*******************************************************************
cursor to delete  data from vessel call   ends
*****************************************************************/

/*******************************************************************
cursor to delete  data from application submission starts
*****************************************************************/
    CURSOR cur_dg_appsub_del IS
    SELECT 
        vsl_call_id_n
    FROM
        application_submission
    WHERE
        vsl_call_id_n NOT IN (
            SELECT 
                vsl_call_id_n
            FROM
                dangerous_goods_application
        )
        AND appln_ty_c = 'DGD';

    TYPE rec_v_app_sub_id_n IS RECORD (
        v_app_sub_vslcallidn   application_submission.vsl_call_id_n%TYPE
    );
    TYPE type_v_app_sub_id_n IS
        TABLE OF rec_v_app_sub_id_n INDEX BY PLS_INTEGER;
    lv_v_app_sub_id_n      type_v_app_sub_id_n;

/*******************************************************************
cursor to delete  data from application submission   ends
*****************************************************************/

/*******************************************************************
cursor to delete  data from vessel reference starts
*****************************************************************/
    CURSOR cur_dg_vsl_ref IS
    SELECT 
        vsl_ref_id_n
    FROM
        application_submission
    WHERE
        appln_ty_c = 'DGD'
        AND vsl_call_id_n NOT IN (
            SELECT 
                vsl_call_id_n
            FROM
                dangerous_goods_application
        );

    TYPE rec_vslref IS RECORD (
        v_vsl_ref_id_n         vessel_reference.vsl_ref_id_n%TYPE
    );
    TYPE type_rec_vslref IS
        TABLE OF rec_vslref INDEX BY PLS_INTEGER;
    lv_rec_vslref          type_rec_vslref;

/*******************************************************************
cursor to delete  data from vessel reference  ends
*****************************************************************/
BEGIN 

/************************************
DELETE FROM Vessel Reference Starts
*******************************************/
    OPEN cur_dg_vsl_ref;
    LOOP
        FETCH cur_dg_vsl_ref BULK COLLECT INTO lv_rec_vslref LIMIT 10000;
        EXIT WHEN lv_rec_vslref.count = 0;
        FORALL i IN lv_rec_vslref.first..lv_rec_vslref.last
            DELETE FROM vessel_reference
            WHERE
                vsl_ref_id_n = lv_rec_vslref(i).v_vsl_ref_id_n;
     COMMIT ;       
    END LOOP;

    CLOSE cur_dg_vsl_ref;

/************************************
DELETE FROM Vessel Reference Ends
*******************************************/

/*************************************
DELETE FROM Vessel_Call  starts 
****************************************/
    OPEN cur_dg_vslcal_del;
    LOOP
        FETCH cur_dg_vslcal_del BULK COLLECT INTO lv_v_vsl_call_id_n LIMIT 10000;
        EXIT WHEN lv_v_vsl_call_id_n.count = 0;
        FORALL i IN lv_v_vsl_call_id_n.first..lv_v_vsl_call_id_n.last
            DELETE FROM vessel_call
            WHERE
                vsl_call_id_n = lv_v_vsl_call_id_n(i).v_vsl_call_id_n;
    COMMIT;
    END LOOP;


    CLOSE cur_dg_vslcal_del;


/*************************************
DELETE FROM Vessel_Call  Ends 
****************************************/  

/*************************************
DELETE FROM Application Submission
****************************************/
    OPEN cur_dg_appsub_del;
    LOOP
        FETCH cur_dg_appsub_del BULK COLLECT INTO lv_v_app_sub_id_n LIMIT 10000;
        EXIT WHEN lv_v_app_sub_id_n.count = 0;
        FORALL i IN lv_v_app_sub_id_n.first..lv_v_app_sub_id_n.last
            DELETE FROM application_submission
            WHERE
                vsl_call_id_n = lv_v_app_sub_id_n(i).v_app_sub_vslcallidn;

    END LOOP;

    COMMIT;
    CLOSE cur_dg_appsub_del;


/*************************************
DELETE FROM Application Submission Ends
****************************************/
EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200)
                     || dbms_utility.format_error_backtrace;
        v_sqlerrm := v_err_code || v_err_msg;
        pkg_datamigration_generic.proc_trace_exception('DG_DELETE', 'PROC_DG_VR_VC_AS_DEL', v_sqlerrm, 'FAIL', NULL, NULL, NULL, 'T'
        );

END;
/