create or replace PROCEDURE PROC_1_PAN_JSON IS

    lval_poc                  CLOB;
    lval_psa                  CLOB;
    lval_pan                  CLOB;
    lval                      CLOB;
    lval_psc                  CLOB;
    lval_ppc                  CLOB;
    lval_123                  CLOB;
    v_lat1                    VARCHAR2(10);
    v_lat2                    VARCHAR2(10);
    v_long1                   VARCHAR2(10);
    v_long2                   VARCHAR2(10);
    v_pan_purp_of_call_id_n   pan_purpose_of_call.pan_purp_of_call_id_n%TYPE;
    v_psa                     pan_ship_activity.appln_ref_n%TYPE;
    v_psc                     pan_ship_certificate.appln_ref_n%TYPE;
    v_ppc                     past_port_calls.appln_ref_n%TYPE;
    v_msw_ref_id              pan_application.msw_appln_ref_id_x%TYPE;
    v_err_code                NUMBER;
    v_err_msg                 VARCHAR2(2000);
    v_sqlerrm                 VARCHAR2(2000);
    LV_arr_fwd_dft_q          VARCHAR2(10) ; 
    LV_arr_mid_dft_q            VARCHAR2(10)  ;
    LV_ARR_AFT_DFT_Q            VARCHAR2(10) ;
    
    CURSOR cr_pan_appl IS
    SELECT
        *
    FROM
        pan_application;

    TYPE rec_pan_appl IS RECORD (
        APPLN_REF_N               pan_application.APPLN_REF_N%TYPE,
        VSL_CALL_ID_N               pan_application.VSL_CALL_ID_N%TYPE,
        MSW_APPLN_REF_ID_X               pan_application.MSW_APPLN_REF_ID_X%TYPE,
        EXTL_APPLN_REF_ID_X               pan_application.EXTL_APPLN_REF_ID_X%TYPE,
        MSW_VSL_ID_N               pan_application.MSW_VSL_ID_N%TYPE,
        VOY_X               pan_application.VOY_X%TYPE,
        APPLCNT_ID_X               pan_application.APPLCNT_ID_X%TYPE,
        ARR_FWD_DFT_Q               pan_application.ARR_FWD_DFT_Q%TYPE,
        ARR_MID_DFT_Q               pan_application.ARR_MID_DFT_Q%TYPE,
        ARR_AFT_DFT_Q               pan_application.ARR_AFT_DFT_Q%TYPE,
        AIR_DFT_Q               pan_application.AIR_DFT_Q%TYPE,
        VSL_IMS_CALL_NO_C               pan_application.VSL_IMS_CALL_NO_C%TYPE,
        CSO_M               pan_application.CSO_M%TYPE,
        CSO_TEL_N               pan_application.CSO_TEL_N%TYPE,
        AGT_NM_M               pan_application.AGT_NM_M%TYPE,
        LOCN_LAT_N               pan_application.LOCN_LAT_N%TYPE,
        LOCN_LONG_N               pan_application.LOCN_LONG_N%TYPE,
        AGT_TEL_N               pan_application.AGT_TEL_N%TYPE,
        AGT_FAX_N               pan_application.AGT_FAX_N%TYPE,
        AGT_EMAIL_X               pan_application.AGT_EMAIL_X%TYPE,
        SHP_EMAIL_X               pan_application.SHP_EMAIL_X%TYPE,
        ANCH_DURN_N               pan_application.ANCH_DURN_N%TYPE,
        ANCH_ETA_DT               pan_application.ANCH_ETA_DT%TYPE,
        ANCH_ETD_DT               pan_application.ANCH_ETD_DT%TYPE,
        CGO_DESC_X               pan_application.CGO_DESC_X%TYPE,
        SHP_SECU_PLAN_I               pan_application.SHP_SECU_PLAN_I%TYPE,
        SECU_LVL_SG_C               pan_application.SECU_LVL_SG_C%TYPE,
        SECU_PERS_I               pan_application.SECU_PERS_I%TYPE,
        APPLN_ST_C               pan_application.APPLN_ST_C%TYPE,
        SLOP_SLUDGE_I               pan_application.SLOP_SLUDGE_I%TYPE,
        SLOP_QTY_Q               pan_application.SLOP_QTY_Q%TYPE,
        SLUDGE_QTY_Q               pan_application.SLUDGE_QTY_Q%TYPE,
        SS_CONTENT_X               pan_application.SS_CONTENT_X%TYPE,
        SS_REP_FAC_X               pan_application.SS_REP_FAC_X%TYPE,
        HEIGHT_N               pan_application.HEIGHT_N%TYPE,
        NAME_PER_REPORTING_X               pan_application.NAME_PER_REPORTING_X%TYPE,
        SAFETY_SEC_AFFECT_I               pan_application.SAFETY_SEC_AFFECT_I%TYPE,
        VSL_MMSI_N               pan_application.VSL_MMSI_N%TYPE,
        CO_NAME_X               pan_application.CO_NAME_X%TYPE,
        MV_CON_REM_I               pan_application.MV_CON_REM_I%TYPE,
        SAFETY_REM_I               pan_application.SAFETY_REM_I%TYPE,
        FIRE_HZ_REM_I               pan_application.FIRE_HZ_REM_I%TYPE,
        ARMS_STRONG_RM_I               pan_application.ARMS_STRONG_RM_I%TYPE,
        ARMS_STRONG_RM_LOCN_X               pan_application.ARMS_STRONG_RM_LOCN_X%TYPE,
        MV_REM_X               pan_application.MV_REM_X%TYPE,
        MV_HMS_I               pan_application.MV_HMS_I%TYPE,
        MV_HMS_X               pan_application.MV_HMS_X%TYPE,
        GPP_C_I               pan_application.GPP_C_I%TYPE,
        BURNING_LNG_I               pan_application.BURNING_LNG_I%TYPE,
        BURNING_CLN_FUEL_I               pan_application.BURNING_CLN_FUEL_I%TYPE,
        BWMC_I               pan_application.BWMC_I%TYPE,
        IBWMC_I               pan_application.IBWMC_I%TYPE,
        BWMC_EXEMPTED_I               pan_application.BWMC_EXEMPTED_I%TYPE,
        BWMC_COM_C               pan_application.BWMC_COM_C%TYPE,
        BWMC_D1_I               pan_application.BWMC_D1_I%TYPE,
        BWMC_D1_REASON_X               pan_application.BWMC_D1_REASON_X%TYPE,
        BWMC_D1_DISCHARGE_I               pan_application.BWMC_D1_DISCHARGE_I%TYPE,
        BWMC_D1_DISCHARGE_Q               pan_application.BWMC_D1_DISCHARGE_Q%TYPE,
        BWMC_D2_I               pan_application.BWMC_D2_I%TYPE,
        BWMC_D2_REASON_I               pan_application.BWMC_D2_REASON_I%TYPE,
        BWMC_D2_DISCHARGE_I               pan_application.BWMC_D2_DISCHARGE_I%TYPE,
        BWMC_D2_DISCHARGE_Q               pan_application.BWMC_D2_DISCHARGE_Q%TYPE,
        BWMC_D4_I               pan_application.BWMC_D4_I%TYPE,
        USER_TITLE_X               pan_application.USER_TITLE_X%TYPE,
        LOCN_X               pan_application.LOCN_X%TYPE,
        TIME_STAMP_DT               pan_application.TIME_STAMP_DT%TYPE,
        ARMS_AMMUNITION_I               pan_application.ARMS_AMMUNITION_I%TYPE,
        ARMS_TYPE_X               pan_application.ARMS_TYPE_X%TYPE,
        ARMS_QTY_Q               pan_application.ARMS_QTY_Q%TYPE,
        HNS_I               pan_application.HNS_I%TYPE,
        DG_ON_BOARD_I               pan_application.DG_ON_BOARD_I%TYPE,
        DG_CGO_MANF_I               pan_application.DG_CGO_MANF_I%TYPE,
        CR_LIST_I               pan_application.CR_LIST_I%TYPE,
        PASSN_LIST_ICA_I               pan_application.PASSN_LIST_ICA_I%TYPE,
        PORT_FACILITY_ETA_DT               pan_application.PORT_FACILITY_ETA_DT%TYPE,
        PORT_FACILITY_ETD_DT               pan_application.PORT_FACILITY_ETD_DT%TYPE,
        GRS_TNG_N               pan_application.GRS_TNG_N%TYPE,
        IS_NOA_I               pan_application.IS_NOA_I%TYPE,
        DRAFT_X               pan_application.DRAFT_X%TYPE,
        LAST_PORT_X               pan_application.LAST_PORT_X%TYPE,
        ETA_DT               pan_application.ETA_DT%TYPE,
        VALID_BCC_I               pan_application.VALID_BCC_I%TYPE,
        MAN_REM_I               pan_application.MAN_REM_I%TYPE,
        SAFETY_SECURITY_I               pan_application.SAFETY_SECURITY_I%TYPE,
        LOCATION_X               pan_application.LOCATION_X%TYPE,
        OTHER_LOCATION_X               pan_application.OTHER_LOCATION_X%TYPE,
        MV_STM_DT               pan_application.MV_STM_DT%TYPE,
        LOCN_TO_X               pan_application.LOCN_TO_X%TYPE,
        MARPOL_I               pan_application.MARPOL_I%TYPE,
        OTERM_FAC_C               pan_application.OTERM_FAC_C%TYPE,
        OTERM_FAC_X               pan_application.OTERM_FAC_X%TYPE,
        TRANS_ID_N               pan_application.TRANS_ID_N%TYPE,
        NEW_NOA_I               pan_application.NEW_NOA_I%TYPE,
        PAGER_X               pan_application.PAGER_X%TYPE,
        SESS_X               pan_application.SESS_X%TYPE,
        OTH_REM_I               pan_application.OTH_REM_I%TYPE,
        ARMS_SRC_I               pan_application.ARMS_SRC_I%TYPE,
        SOURCE_I               pan_application.SOURCE_I%TYPE,
        USER_ID_X               pan_application.USER_ID_X%TYPE,
        LATD_DIRCN_C               pan_application.LATD_DIRCN_C%TYPE,
        LONGD_DIRCN_C               pan_application.LONGD_DIRCN_C%TYPE,
        SHP_ARVL_DIRCN_C               pan_application.SHP_ARVL_DIRCN_C%TYPE,
        SUBR_EMAIL_I               pan_application.SUBR_EMAIL_I%TYPE,
        SUBR_SMS_I               pan_application.SUBR_SMS_I%TYPE,
        PROCESSING_REM_X               pan_application.PROCESSING_REM_X%TYPE,
        PROCESSED_BY_X               pan_application.PROCESSED_BY_X%TYPE,
        PROCESSED_ON_DT               pan_application.PROCESSED_ON_DT%TYPE,
        CRT_BY_N               pan_application.CRT_BY_N%TYPE,
        CRT_ON_DT               pan_application.CRT_ON_DT%TYPE,
        UPT_BY_X               pan_application.UPT_BY_X%TYPE,
        UPT_ON_DT               pan_application.UPT_ON_DT%TYPE,
        LOCK_VER_N               pan_application.LOCK_VER_N%TYPE,
        DELETED_I               pan_application.DELETED_I%TYPE,
        SECRTY_REM_X               pan_application.SECRTY_REM_X%TYPE,
        ETD_DT               pan_application.ETD_DT%TYPE,
        SUBMISSION_MODE               pan_application.SUBMISSION_MODE%TYPE,
        SHP_ARR_DIRN_DESC_X               pan_application.SHP_ARR_DIRN_DESC_X%TYPE,
        P_LOCN_DESC_X               pan_application.P_LOCN_DESC_X%TYPE,
        SECU_LVL_SG_DESC_X               pan_application.SECU_LVL_SG_DESC_X%TYPE,
        LATD_DIRN_DESC_X               pan_application.LATD_DIRN_DESC_X%TYPE,
        LONGD_DIRN_DESC_X               pan_application.LONGD_DIRN_DESC_X%TYPE,
        BWMC_COM_DESC_X               pan_application.BWMC_COM_DESC_X%TYPE,
        BWMC_D1_RSN_DESC_X               pan_application.BWMC_D1_RSN_DESC_X%TYPE,
        INTENDED_LOCN_DESC_X               pan_application.INTENDED_LOCN_DESC_X%TYPE,
        SEC_REF_I               pan_application.SEC_REF_I%TYPE
    );
    TYPE typ_pan_appl IS
        TABLE OF rec_pan_appl INDEX BY PLS_INTEGER;
    lv_pan_appl               typ_pan_appl;
    
    LV_CNT_ST_JSON  number;
    LV_CNT_TT_JSON  number;
    
BEGIN
LV_CNT_ST_JSON :=0;
 -- start loop of pan_application       
    OPEN cr_pan_appl;
    LOOP
        FETCH cr_pan_appl BULK COLLECT INTO lv_pan_appl LIMIT 10000;
        EXIT WHEN lv_pan_appl.count = 0;
        FOR i IN lv_pan_appl.first..lv_pan_appl.last LOOP
        
        SELECT  nvl(trim(decode(substr(lv_pan_appl(i).arr_fwd_dft_q,1,1),'.',0||lv_pan_appl(i).arr_fwd_dft_q,lv_pan_appl(i).arr_fwd_dft_q)),'null')LV_arr_fwd_dft_q ,
                nvl(trim(decode(substr(lv_pan_appl(i).arr_mid_dft_q,1,1),'.',0||lv_pan_appl(i).arr_mid_dft_q,lv_pan_appl(i).arr_mid_dft_q)),'null')LV_arr_mid_dft_q ,
                nvl(trim(decode(substr(lv_pan_appl(i).ARR_AFT_DFT_Q,1,1),'.',0||lv_pan_appl(i).ARR_AFT_DFT_Q,lv_pan_appl(i).ARR_AFT_DFT_Q)),'null')LV_ARR_AFT_DFT_Q 
            INTO LV_arr_fwd_dft_q , LV_arr_mid_dft_q , LV_ARR_AFT_DFT_Q 
        FROM  DUAL ;
                        
                        
                        
            v_msw_ref_id := lv_pan_appl(i).msw_appln_ref_id_x;
            lval_pan := '{"mswApplicationReference":"'
                        || trim(lv_pan_appl(i).msw_appln_ref_id_x)
                        || '",';

            lval_pan := lval_pan
                        || '"vesselId":'
                        || nvl(trim(lv_pan_appl(i).msw_vsl_id_n), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"voyageNumber":"'
                        || nvl(trim(lv_pan_appl(i).voy_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"expectedTimeOfArrival":"'
                        || nvl(trim(lv_pan_appl(i).anch_eta_dt), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"expectedTimeOfDeparature":"'
                        || nvl(trim(lv_pan_appl(i).anch_etd_dt), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"applicantId":"'
                        || nvl(trim('null'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"arrivalDraftsForward":'
                        || LV_arr_fwd_dft_q
                        || ',';

            lval_pan := lval_pan
                        || '"arrivalDraftsMid":'
                        || LV_arr_mid_dft_q
                        || ',';

            lval_pan := lval_pan
                        || '"arrivalDraftsAfter":'
                        || LV_ARR_AFT_DFT_Q  
                        || ',';

            lval_pan := lval_pan
                        || '"airDraft":'
                        || nvl(trim(lv_pan_appl(i).air_dft_q), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"inmarsatNumber":"'
                        || nvl(trim(NULL), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"companySecurityOfficer":"'
                        || nvl(trim(lv_pan_appl(i).cso_m), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"csoPhoneNumber":"'
                        || nvl(trim(lv_pan_appl(i).cso_tel_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"agentName":"'
                        || nvl(trim(lv_pan_appl(i).agt_nm_m), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"agentPhoneNumber":"'
                        || nvl(trim(lv_pan_appl(i).agt_tel_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"agentFaxNumber":"'
                        || nvl(trim(lv_pan_appl(i).agt_fax_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"agentEmailAddress":"'
                        || nvl(trim(lv_pan_appl(i).agt_email_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"latitude":"'
                        || nvl(trim(lv_pan_appl(i).locn_lat_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"longitude":"'
                        || nvl(trim(lv_pan_appl(i).locn_long_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"shipEmailAddress":"'
                        || nvl(trim(lv_pan_appl(i).shp_email_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"anchorageDuration":'
                        || nvl(trim(lv_pan_appl(i).anch_durn_n), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"anchorageExpectedTimeOfArrival":"'
                        || nvl(trim(lv_pan_appl(i).anch_eta_dt), ' null')
                        || '",';

            lval_pan := lval_pan
                        || '"anchorageExpectedTimeOfDeparature":"'
                        || nvl(trim(lv_pan_appl(i).anch_etd_dt), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"grossTonnage":'
                        || nvl(trim(lv_pan_appl(i).grs_tng_n), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"cargoDescription":"'
                        || nvl(trim(lv_pan_appl(i).cgo_desc_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"securityPlanExists":"'
                        || nvl(trim(lv_pan_appl(i).shp_secu_plan_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"sgSecurityLevel":"'
                        || nvl(trim(lv_pan_appl(i).safety_security_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"panSubmissionMode":"'
                        || nvl(trim('AGENT'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"slopSludgeOnBoard":"'
                        || nvl(trim(lv_pan_appl(i).slop_sludge_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"slopQuantity":'
                        || nvl(trim(lv_pan_appl(i).slop_qty_q), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"sludgeQuantity":'
                        || nvl(trim(lv_pan_appl(i).sludge_qty_q), 'null')
                        || ',';

            lval_pan := lval_pan
                        || '"slopSludgeContent":"'
                        || nvl(trim(lv_pan_appl(i).ss_content_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"slopSludgeReceptionFacility":"'
                        || nvl(trim(lv_pan_appl(i).ss_rep_fac_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"isSafetyAndSecurityAffected":"'
                        || nvl(trim(lv_pan_appl(i).safety_sec_affect_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"isCarryingHns":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"anyDangerousGoodsOnBoard":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"crewForwaredToIca":"'
                        || nvl(trim('true'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"securityPersonnelOnboard":"'
                        || nvl(trim('Y'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"passengersForwaredToIca":"'
                        || nvl(trim('Y'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"vesselStrongRoom":"'
                        || nvl(trim('Y'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"burningLng":"'
                        || nvl(trim('true'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"userTitle":"'
                        || nvl(trim('Testing'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"shipArrivalDirection":"'
                        || nvl(trim('EAST'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"latitudeDirection":"'
                        || nvl(trim(lv_pan_appl(i).locn_lat_n), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"longitudeDirection":"'
                        || nvl(trim('EAST'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"isNOA":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"vesselMmsiNo":"'
                        || nvl(trim(287731232), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"navigationAffected":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"safetyRemarks":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"securityRefugee":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"securityRemarks":"'
                        || nvl(trim('Testing'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"fireHazards":"'
                        || nvl(trim('false'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"remarks":"'
                        || nvl(trim('Hazard material carrying'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"vesselStrongRoomLocation":"'
                        || nvl(trim('West'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"cargoResidues":"'
                        || nvl(trim('true'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"cargoTypeAndAmount":"'
                        || nvl(trim('Testing'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"fuelType":"'
                        || nvl(trim('true'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmc":"'
                        || nvl(trim('true'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcD1":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_d1_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"ibwmc":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcExempted":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_exempted_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcComplying":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_com_c), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcD1Conducted":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_d1_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcD1NotConductedReason":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_d1_reason_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcD1Discharge":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_d1_discharge_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"bwmcD1DischargeQuantity":"'
                        || nvl(trim(lv_pan_appl(i).bwmc_d1_discharge_q), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"portLocation":"'
                        || nvl(trim('Singapore'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"armsAmmunitionOnBoard":"'
                        || nvl(trim(lv_pan_appl(i).arms_ammunition_i), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"armsType":"'
                        || nvl(trim(lv_pan_appl(i).arms_type_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"subscribeEmail":'
                        || nvl(trim(lv_pan_appl(i).subr_email_i), 'false')
                        || ',';

            lval_pan := lval_pan
                        || '"subscribeSms":'
                        || nvl(trim(lv_pan_appl(i).subr_sms_i), 'false')
                        || ',';

            lval_pan := lval_pan
                        || '"intendedLocation":"'
                        || nvl(trim('OTH'), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"otherLocation":"'
                        || nvl(trim(lv_pan_appl(i).other_location_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"userId":"'
                        || nvl(trim(lv_pan_appl(i).user_id_x), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"createdOn":"'
                        || nvl(trim(lv_pan_appl(i).crt_on_dt), 'null')
                        || '",';

            lval_pan := lval_pan
                        || '"createdBy":"'
                        || nvl(trim(lv_pan_appl(i).crt_by_n), 'null')
                        || '",';


/*******************************************************************
                      pan_purpose_of_call  starts

*******************************************************************/

            FOR j IN (
                SELECT
                    pan_purp_of_call_id_n,
                    arrival_purpse_c
                FROM
                    pan_purpose_of_call
                WHERE
                    appln_ref_n = lv_pan_appl(i).appln_ref_n
            ) LOOP    -- loop  to generatate poc json 
                v_pan_purp_of_call_id_n := j.pan_purp_of_call_id_n;
                lval_poc := lval_poc
                            || '{"purposeOfCall":"'
                            || nvl(trim(j.pan_purp_of_call_id_n), 'null')
                            || '",';

                lval_poc := lval_poc
                            || '"arrivalVoyageInformation":"'
                            || nvl(trim(j.arrival_purpse_c), 'null')
                            || '"},';

            END LOOP; --end loop of poc json 

            lval_poc := rtrim(lval_poc, ',');
            lval_poc := '"panPurposeOfCalls":[' || lval_poc;
            lval_poc := lval_poc || '],';



  /*******************************************************************
                      pan_purpose_of_call  ends

*******************************************************************/


/***************************************************************************
                        panShipActivities  starts
*******************************************************************************/
            FOR k IN (
                SELECT
                    *
                FROM
                    pan_ship_activity
                WHERE
                    appln_ref_n = lv_pan_appl(i).appln_ref_n
            ) LOOP    -- loop of pan_ship_activity starts
                lval_psa := lval_psa
                            || '{"fromDate":"'
                            || trim(k.act_fr_d)
                            || '",';

                lval_psa := lval_psa
                            || '"toDate":"'
                            || trim(k.act_till_d)
                            || '",';

                lval_psa := lval_psa
                            || '"location":"'
                            || NULL
                            || '",';
                lval_psa := lval_psa
                            || '"activity":"'
                            || NULL
                            || '",';
                lval_psa := lval_psa
                            || '"latitude":"'
                            || trim(k.locn_lat_n)
                            || '","';

                SELECT
                    substr(TRIM(k.locn_lat_n), 1, 2)
                INTO v_lat1
                FROM
                    dual;

                SELECT
                    substr(TRIM(k.locn_lat_n), 4, 2)
                INTO v_lat2
                FROM
                    dual;

                lval_psa := lval_psa
                            || 'latitude1":"'
                            || trim(v_lat1)
                            || '",';
                lval_psa := lval_psa
                            || '"latitude2":"'
                            || trim(v_lat2)
                            || '",';
                lval_psa := lval_psa
                            || '"latitudeDirection":"'
                            || nvl(trim(k.latd_dircn_c), 'null')
                            || '",';

                lval_psa := lval_psa
                            || '"longitude":"'
                            || nvl(trim(k.locn_long_n), 'null')
                            || '",';

                SELECT
                    substr(k.locn_long_n, 1, 3)
                INTO v_long1
                FROM
                    dual;

                SELECT
                    substr(k.locn_lat_n, 5, 2)
                INTO v_long2
                FROM
                    dual;

                lval_psa := lval_psa
                            || '"longitude1":"'
                            || trim(v_long1)
                            || '",';
                lval_psa := lval_psa
                            || '"longitude2":"'
                            || trim(v_long2)
                            || '",';
                lval_psa := lval_psa
                            || '"longitudeDirection":"'
                            || nvl(trim(k.longd_dircn_c), 'null')
                            || '",';

                lval_psa := lval_psa
                            || '"securityMeasure":"'
                            || nvl(trim(k.secu_msr_x), 'null')
                            || '",';

                lval_psa := lval_psa
                            || '"createdBy":"'
                            || nvl(trim(k.crt_by_n), 'null')
                            || '",';

                lval_psa := lval_psa
                            || '"createdOn":"'
                            || nvl(trim(k.crt_on_dt), 'null')
                            || '",';

                lval_psa := lval_psa
                            || '"sequenceNumber":'
                            || nvl(trim(k.seq_n), 'null');

                lval_psa := lval_psa || '},';
            END LOOP; -- loop of pan_ship_activity ends 

            lval_psa := rtrim(lval_psa, ',');
            lval_psa := '"panShipActivities":['
                        || lval_psa
                        || '],';
            lval := lval_poc || lval_psa;



 /***************************************************************************
                        panShipActivities  ends
*******************************************************************************/

  /*******************************************************************************************************************************

                                    panShipCertificates  starts
  **********************************************************************************************************************************/
            FOR m IN (
                SELECT
                    *
                FROM
                    pan_ship_certificate
                WHERE
                    appln_ref_n = lv_pan_appl(i).appln_ref_n
            ) LOOP
                v_psc := m.appln_ref_n;
                lval_psc := lval_psc
                            || '{"certificateType":"'
                            || nvl(trim(m.cert_ty_c), 'null')
                            || '",';

                lval_psc := lval_psc
                            || '"certificateIsApplicable":"'
                            || NULL
                            || '",';
                lval_psc := lval_psc
                            || '"issuingAuthority":"'
                            || nvl(trim(m.iss_authy_ctry_c), 'null')
                            || '",';

                lval_psc := lval_psc
                            || '"dueDate":"'
                            || nvl(trim(m.due_d), 'null')
                            || '",';

                lval_psc := lval_psc
                            || '"isMandatoryCertificate":'
                            || nvl(trim(m.mandt_cert_i), 'false')
                            || ',';

                lval_psc := lval_psc
                            || '"createdBy":"'
                            || nvl(trim(m.crt_by_n), 'null')
                            || '",';

                lval_psc := lval_psc
                            || '"createdOn":"'
                            || nvl(trim(m.crt_on_dt), 'null')
                            || '"';

                lval_psc := lval_psc || '},';
            END LOOP;

            lval_psc := rtrim(lval_psc, ',');
            lval_psc := '"pan_ship_certificate":[' || lval_psc;
            lval_psc := lval_psc || '],';



    /*******************************************************************************************************************************

                                    panShipCertificates  ends
  **********************************************************************************************************************************/



      /*******************************************************************************************************************************

                                                   pastPortCalls  starts
  **********************************************************************************************************************************/
            FOR n IN (
                SELECT
                    *
                FROM
                    past_port_calls
                WHERE
                    appln_ref_n = lv_pan_appl(i).appln_ref_n
            ) LOOP
                lval_ppc := lval_ppc
                            || '{"fromDate":"'
                            || nvl(trim(n.last_port_fr_dt), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"tillDate":"'
                            || nvl(trim(n.last_port_till_dt), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"portName":"'
                            || nvl(trim(n.last_port_c), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"portFacility":"'
                            || nvl(trim(n.last_port_fac_x), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"securityLevel":"'
                            || nvl(trim(n.secu_lvl_c), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"additionalSecurityMeasures":"'
                            || nvl(trim(n.secu_msr_x), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"createdBy":"'
                            || nvl(trim(n.crt_by_x), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"createdOn":"'
                            || nvl(trim(n.crt_on_dt), 'null')
                            || '",';

                lval_ppc := lval_ppc
                            || '"sequenceNumber":'
                            || nvl(trim(n.seq_n), 'null')
                            || ',';

                lval_ppc := lval_ppc
                            || '"vesselId":'
                            || nvl(trim(lv_pan_appl(i).msw_vsl_id_n), 'null');

                lval_ppc := lval_ppc || '},';
            END LOOP;

            lval_ppc := rtrim(lval_ppc, ',');
            lval_ppc := '"pastPortCalls":[' || lval_ppc;
            lval_ppc := lval_ppc || '],';

  --end if;

 /*******************************************************************************************************************************

                                                   pastPortCalls  ends
  **********************************************************************************************************************************/
            lval_123 := '"panApplicationDocuments":[],';
            lval_123 := lval_123 || '"panPurposes":[],';
            lval_123 := lval_123
                        || '"othersPurpose":"'
                        || trim('Testing only')
                        || '",';
            lval_123 := lval_123
                        || '"anchorageOthersPurpose":"'
                        || trim('Testing only')
                        || '",';
            lval_123 := lval_123
                        || '"declaredLatitude1":"'
                        || trim(50)
                        || '",';
            lval_123 := lval_123
                        || '"declaredLatitude2":"'
                        || trim(5)
                        || '",';
            lval_123 := lval_123
                        || '"declaredLongitude1":"'
                        || trim(120)
                        || '",';
            lval_123 := lval_123
                        || '"declaredLongitude2":"'
                        || trim(5)
                        || '",';
            lval_123 := lval_123
                        || '"lastUpdatedOn":"'
                        || trim(lv_pan_appl(i).upt_on_dt)
                        || '",';

            lval_123 := lval_123
                        || '"lastUpdatedBy":"'
                        || trim(lv_pan_appl(i).upt_by_x)
                        || '",';

            lval_123 := lval_123
                        || ' "lockVersion":'
                        || trim(lv_pan_appl(i).lock_ver_n)
                        || ',';

            lval_123 := lval_123
                        || '"vesselCallId":'
                        || trim(lv_pan_appl(i).vsl_call_id_n)
                        || '}';

            lval := lval_pan
                    || lval_poc
                    || lval_psa
                    || lval_psc
                    || lval_ppc
                    || lval_123;

            INSERT INTO si_json VALUES (
                NULL,
                lval,
                SYSDATE,
                'PAN',
                v_msw_ref_id
            );
            LV_CNT_ST_JSON:=LV_CNT_ST_JSON+1;

            lval_pan := NULL;
            lval_poc := NULL;
            lval_psa := NULL;
            lval_psc := NULL;
            lval_ppc := NULL;
            lval_123 := NULL;
        END LOOP;   -- end  loop of pan_application 

        COMMIT;
    END LOOP;
    
    
    
    	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_JSON
     FROM
     SI_JSON where trim(appln_type) = 'PAN';

pkg_datamigration_generic.proc_migration_recon('JSON_PAN', LV_CNT_ST_JSON, 'SI_JSON', LV_CNT_TT_JSON,'Y');
    

EXCEPTION  --- exception of   outer begin 
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 2000);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;
        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'proc_1_pan_json', v_sqlerrm, 'ERROR', NULL, NULL, NULL
        , 'T');

END; -- end of outer begin
/