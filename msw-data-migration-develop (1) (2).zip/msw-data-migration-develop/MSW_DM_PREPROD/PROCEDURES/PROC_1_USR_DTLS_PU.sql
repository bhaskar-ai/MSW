CREATE OR REPLACE NONEDITIONABLE PROCEDURE "PROC_1_USR_DTLS_PU" ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_SI_USR_DTLS_PU         NUMBER;
    LV_CNT_TAR        NUMBER;
    lv_cnt_tar_prof        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    LV_USR_LOGON_ID_N   VARCHAR2(255); 
    LV_USR_ID_TY_C      VARCHAR2(255); 
    LV_USR_ID_N         VARCHAR2(255);


   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_USR_DTLS_PU
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-JUL-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
/*    CURSOR CR_SI_USR_DTLS IS
    SELECT
        XU.LOGINID_C,
		XU.NRIC_N,
		XU.LOGINID_M,
		XU.EMAIL_X,
		XU.MOBILE_N,
		XU.ACTIVATED_I,
		XC.CO_REG_N
    FROM
        XR_USR XU,
		XR_COREG XC
    WHERE
	XU.ORG_C = XC.ORG_C;
*/
------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
    CURSOR CR_USR_DTLS IS

   SELECT  id_n, passpt_n, idTy_c, indv_m, 
            Emailaddr_X, Mobile_N
            FROM(
        SELECT  C.id_n, C.passpt_n, C.idTy_c, C.indv_m, 
            E.Emailaddr_X, E.Mobile_N,
            case
                WHEN c.idTy_c = 'P' THEN c.passpt_n
                ELSE c.id_n
            END LV_USR_LOGON_ID_N
    FROM
        st_pu_profile a,   st_pu_usrindv c,
        (SELECT puid_n, MAX(CONTACTID_N) CONTACTID_N
        FROM  st_pu_profilecontactmapper
        GROUP BY  puid_n ) d,
        st_pu_usrcontact e
    WHERE
        a.puid_n = c.puid_n (+) AND a.puid_n = d.puid_n (+)
        AND d.contactid_n = e.contactid_n (+) 
        and c.puID_n is not null 
        )
        WHERE NOT EXISTS (SELECT  USR_LOGON_ID_N FROM USR_DTLS n WHERE   LV_USR_LOGON_ID_N = n.USR_LOGON_ID_N  )   ;

---------------------***************** DECLARING TYPES ****************----------------------------
    TYPE REC_USR_DTLS IS RECORD (
        id_n_r          st_pu_usrindv.id_n%TYPE , 
        passpt_n_r      st_pu_usrindv.passpt_n%TYPE, 
        idTy_c_r        st_pu_usrindv.idTy_c%TYPE, 
        indv_m_r        st_pu_usrindv.indv_m%TYPE, 
        Emailaddr_X_R   st_pu_usrcontact.Emailaddr_X%TYPE, 
        Mobile_N_R      st_pu_usrcontact.Mobile_N%TYPE
    );
    TYPE TYP_USR_DTLS IS
    TABLE OF REC_USR_DTLS INDEX BY PLS_INTEGER;

    LV_USR_DTLS       TYP_USR_DTLS;

BEGIN
/*
    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
       st_pu_profile ;   ---- DRIVING TABLE COUNT 
     */  
       select COUNT(*)
            INTO LV_CNT_ST
       from st_pu_usrindv where puID_n is not null;          ---- DRIVING TABLE COUNT 
       
       SELECT COUNT(*) INTO LV_SI_USR_DTLS_PU
       FROM(
         SELECT  id_n, passpt_n, idTy_c, indv_m, 
                    Emailaddr_X, Mobile_N
                    FROM(
                SELECT  C.id_n, C.passpt_n, C.idTy_c, C.indv_m, 
                    E.Emailaddr_X, E.Mobile_N,
                    case
                        WHEN c.idTy_c = 'P' THEN c.passpt_n
                        ELSE c.id_n
                    END LV_USR_LOGON_ID_N
            FROM
                st_pu_profile a,   st_pu_usrindv c,
                (SELECT puid_n, MAX(CONTACTID_N) CONTACTID_N
                FROM  st_pu_profilecontactmapper
                GROUP BY  puid_n ) d,
                st_pu_usrcontact e
            WHERE
                a.puid_n = c.puid_n (+) AND a.puid_n = d.puid_n (+)
                AND d.contactid_n = e.contactid_n (+) 
                and c.puID_n is not null 
                )
                WHERE NOT EXISTS (SELECT  USR_LOGON_ID_N FROM USR_DTLS n WHERE   LV_USR_LOGON_ID_N = n.USR_LOGON_ID_N  )  ) ;   ------ SI Table count  

    OPEN CR_USR_DTLS;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_DTLS', 'PROC_1_USR_DTLS_PU', 'INSERTION INTO TABLE USR_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_USR_DTLS BULK COLLECT INTO LV_USR_DTLS LIMIT 10000;
        EXIT WHEN LV_USR_DTLS.COUNT = 0;

        FOR J IN LV_USR_DTLS.FIRST..LV_USR_DTLS.LAST LOOP
            BEGIN

                     SELECT DECODE(LV_USR_DTLS(J).idTy_c_r,'P',LV_USR_DTLS(J).passpt_n_r,LV_USR_DTLS(J).id_n_r)LV_USR_LOGON_ID_N,
							DECODE(LV_USR_DTLS(J).idTy_c_r,'N','NRIC','F','FIN','P','PASSPORT')LV_USR_ID_TY_C,
                            DECODE(LV_USR_DTLS(J).idTy_c_r,'P',LV_USR_DTLS(J).passpt_n_r,LV_USR_DTLS(J).id_n_r)LV_USR_ID_N
                        INTO LV_USR_LOGON_ID_N, LV_USR_ID_TY_C, LV_USR_ID_N
                    FROM DUAL ;


                INSERT INTO USR_DTLS (
										ID_N,
										USR_LOGON_ID_N,
										USR_ID_TY_C,
										USR_ID_N,
										USR_M,
										USR_EMAIL_ADDR_X,
										USR_TEL_N,
										USR_ST_C,
										USR_PSWD_M,
										CO_UEN_N,
										LOCK_VER_N,
										DELETED_I,
										CRT_ON_DT,
										LST_UPD_ON_DT,
										CRT_BY_N,
										LST_UPD_BY_N,
                                        FAILED_ATTEMPTS_I
										)
								VALUES (    
										SYN_SEQ_USR_DTS_ID_N.NEXTVAL,
                                        LV_USR_LOGON_ID_N,
										LV_USR_ID_TY_C,
                                        LV_USR_ID_N,
                                        LV_USR_DTLS(J).indv_m_r,
                                        LV_USR_DTLS(J).Emailaddr_X_R,
                                        LV_USR_DTLS(J).Mobile_N_R,
                                        'ACTIVE',
                                        Null,
                                        Null,
                                        0,
                                        0,
                                        Sysdate,
                                        Sysdate,
                                        'DATA MIGRATION',
                                        'DATA MIGRATION',
                                        0
                                );
            
                INSERT INTO AUTH_PROFILE (
                        ID_N,
                        REFR_ID,
                        PROFILE_TY,
                        LOCK_VER_N
                    ) VALUES (
                        SYN_SEQ_AUTH_PROFILE_ID_N.NEXTVAL,
                        SYN_SEQ_USR_DTS_ID_N.CURRVAL,
                        'INDIVIDUAL',
                        0 
                    );

            EXCEPTION                   
                WHEN OTHERS THEN        
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;

                    V_EXP_ROWS_SI :=
                                        LV_USR_LOGON_ID_N
                                        ||'<{||}>'||	
                                        LV_USR_ID_TY_C
                                        || '<{||}>'||		
                                        LV_USR_ID_N
                                        || '<{||}>'||	
                                        LV_USR_DTLS(J).indv_m_r	
                                        || '<{||}>'||		
                                        LV_USR_DTLS(J).Emailaddr_X_R	
                                        || '<{||}>'||	
                                        LV_USR_DTLS(J).Mobile_N_R;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_DTLS', 'PROC_1_USR_DTLS_PU', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

            END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_USR_DTLS;


    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM USR_DTLS;  ---- TARGET TABLE COUNT 
    
    SELECT
        COUNT(*)
    INTO lv_cnt_tar_prof
    FROM
        auth_profile where PROFILE_TY = 'INDIVIDUAL' ;

    IF ( LV_CNT_TAR = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTLS', 'PROC_1_USR_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_ST AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTLS', 'PROC_1_USR_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_ST OR LV_CNT_TAR = LV_CNT_ST ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTLS', 'PROC_1_USR_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_USRINDV', LV_CNT_ST, 'SI_USR_DTLS_PU_Q', LV_SI_USR_DTLS_PU, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_USRINDV', LV_CNT_ST, 'USR_DTLS', LV_CNT_TAR, 'Y');
    pkg_datamigration_generic.proc_migration_recon('ST_PU_USRINDV', lv_cnt_st, 'AUTH_PROFILE', lv_cnt_tar_prof, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTLS', 'PROC_1_USR_DTLS_PU', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_USR_DTLS_PU;

/
