CREATE OR REPLACE PROCEDURE PROC_1_ORG_CODE_UPDATE ( PV_RUN_ID IN   NUMBER) IS

   -- LV_SI_ORG_CODE         NUMBER;
    LV_SI_ORG_CODE      NUMBER;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
   -- V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    
   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_ORG_CODE_UPDATE
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 09-DEC-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/

   CURSOR CR_ORG_CODE IS
    SELECT
        ORG_C
    FROM
        ST_XR_COREG 
    WHERE ORG_C IS NOT NULL AND UEN_N IS  NULL
    UNION
    SELECT
        ORG_C
    FROM
        ST_PU_USRORG
    WHERE ORG_C IS NOT NULL AND UEN_N IS  NULL;
    

---------------------***************** DECLARING TYPES ****************----------------------------
    TYPE REC_ORG_CODE IS RECORD (
        ORG_C_R       ST_XR_COREG.ORG_C%TYPE
      );

    TYPE TYP_ORG_CODE IS
    TABLE OF REC_ORG_CODE INDEX BY PLS_INTEGER;

    LV_ORG_CODE       TYP_ORG_CODE;

BEGIN
    /*
    SELECT COUNT(*)
        INTO LV_SI_ORG_CODE
    FROM ST_XR_COREG ;
    */
    SELECT COUNT(*) INTO LV_SI_ORG_CODE
    FROM (
    SELECT
        ORG_C
    FROM
        ST_XR_COREG 
        WHERE ORG_C IS NOT NULL AND UEN_N IS  NULL
    UNION
    SELECT
        ORG_C
    FROM
        ST_PU_USRORG
        WHERE ORG_C IS NOT NULL AND UEN_N IS  NULL ) ;
        
    OPEN CR_ORG_CODE;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', 'INSERTION INTO TABLE ORG_CODE', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_CODE BULK COLLECT INTO LV_ORG_CODE LIMIT 10000;
        EXIT WHEN LV_ORG_CODE.COUNT = 0;

        FOR J IN LV_ORG_CODE.FIRST..LV_ORG_CODE.LAST LOOP
            BEGIN   
       
                INSERT INTO ORG_CODE (
                    ID_N,
                    CODE,
                    CRT_BY_N,
                    ST_C,
                    CRT_ON_DT,
                    DELETED_I
                ) VALUES (
                    SYN_SEQ_ORG_CODE_ID_N.NEXTVAL ,
                    LV_ORG_CODE(J).ORG_C_R,
                    'DATA MIGRATION',
                    'USED',
                    SYSDATE,
                    0                    
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, NULL , 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;
    CLOSE CR_ORG_CODE;
  --  COMMIT;

    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM ORG_CODE;  ---- TARGET TABLE COUNT 

    IF ( LV_CNT_TAR = LV_SI_ORG_CODE ) AND LV_SI_ORG_CODE <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_SI_ORG_CODE
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_SI_ORG_CODE AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_SI_ORG_CODE
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_SI_ORG_CODE OR LV_CNT_TAR = LV_SI_ORG_CODE ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_SI_ORG_CODE
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;
  --  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_XR_COREG', LV_SI_ORG_CODE, 'SI_ORG_CODE_Q', LV_SI_ORG_CODE, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_ORG_CODE_Q', LV_SI_ORG_CODE, 'ORG_CODE', LV_CNT_TAR, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_CODE', 'PROC_1_ORG_CODE_UPDATE', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ORG_CODE_UPDATE ;

/
