CREATE OR REPLACE  PROCEDURE "PROC_1_VSL_CERT_ATTR" (PV_RUN_ID IN NUMBER)IS


/***********************************************************************************************************
DECLARING VARIABLES FOR TARGET TABLE
*************************************************************************************************************/

CURSOR CUR_VSLCRTATTR IS

    SELECT
       VSLCERTID_N,
       REGST_C,
       PERSALLW_Q,
       SOPEPSMPEPONBD_I,
       INCOMPLYMARPOLREGU19_I,
       INCOMPLYMARPOLREGU20_I,
       INCOMPLYMARPOLREGU21_I,
       INCOMPLYMARPOLREGU20_DT,
       INCOMPLYMARPOLREGU21_DT,
       CRT_ON_DT,
       CRT_BY_X,
       UPT_ON_DT,
       UPT_BY_X
    FROM  SI_VESSEL_CERTIFICATE_ATTRIBUTE;

-- DEFINING THE 'RECORD TYPE'  TYPE TO SERVE AS THE DATATYPE OF COLLECTION VARIABLE  OF MAIN TABLE

    TYPE REC_VSLCRT_ATTR IS RECORD (
      V_VSLCERTID_N				SI_VESSEL_CERTIFICATE_ATTRIBUTE.VSLCERTID_N%TYPE,
      V_REGST_C					SI_VESSEL_CERTIFICATE_ATTRIBUTE.REGST_C%TYPE,
      V_PERSALLW_Q				SI_VESSEL_CERTIFICATE_ATTRIBUTE.PERSALLW_Q%TYPE,
      V_SOPEPSMPEPONBD_I		SI_VESSEL_CERTIFICATE_ATTRIBUTE.SOPEPSMPEPONBD_I%TYPE,
      V_INCOMPLYMARPOLREGU19_I	SI_VESSEL_CERTIFICATE_ATTRIBUTE.INCOMPLYMARPOLREGU19_I%TYPE,
      V_INCOMPLYMARPOLREGU20_I	SI_VESSEL_CERTIFICATE_ATTRIBUTE.INCOMPLYMARPOLREGU20_I%TYPE,
      V_INCOMPLYMARPOLREGU21_I	SI_VESSEL_CERTIFICATE_ATTRIBUTE.INCOMPLYMARPOLREGU21_I%TYPE,
      V_INCOMPLYMARPOLREGU20_DT	SI_VESSEL_CERTIFICATE_ATTRIBUTE.INCOMPLYMARPOLREGU20_DT%TYPE,
      V_INCOMPLYMARPOLREGU21_DT	SI_VESSEL_CERTIFICATE_ATTRIBUTE.INCOMPLYMARPOLREGU21_DT%TYPE,
      V_CRT_ON_DT               SI_VESSEL_CERTIFICATE_ATTRIBUTE.CRT_ON_DT%TYPE,
      V_CRT_BY_X                SI_VESSEL_CERTIFICATE_ATTRIBUTE.CRT_BY_X%TYPE,
      V_UPT_ON_DT               SI_VESSEL_CERTIFICATE_ATTRIBUTE.UPT_ON_DT%TYPE,
      V_UPT_BY_X                SI_VESSEL_CERTIFICATE_ATTRIBUTE.UPT_BY_X%TYPE
 );


    TYPE TYPE_VSLCRT_ATTR IS TABLE OF REC_VSLCRT_ATTR;

    LV_VSL_CERT        TYPE_VSLCRT_ATTR;

    V_SQ_VSLCRTID      INTEGER;
    V_SRC_COUNT        INTEGER;
    V_TGT_COUNT        INTEGER;
    V_ERR_CODE         NUMBER;
    V_ERR_MSG          VARCHAR2(2000);
    V_SQLERRM          VARCHAR2(4000);
    V_BLKEXPTN_COUNT   NUMBER(20,0);
    V_BLKEXPTN_DESC    VARCHAR2(4000);
    V_EXP_ROWS         VARCHAR2(4000);
    V_EXP_ROWS1        VARCHAR2(1000);
    V_EXP_ROWS2        VARCHAR2(1000);
    V_EXP_ROWS3        VARCHAR2(1000);
    V_EXP_ROWS4        VARCHAR2(1000);
    V_EXP_ROWS5        VARCHAR2(1000);
    V_EXP_ROWS6        VARCHAR2(1000);
    V_EXP_ROWS7        VARCHAR2(1000);
    V_EXP_ROWS8        VARCHAR2(1000);
    V_EXP_ROWS9        VARCHAR2(1000);
    V_ERR_ROW          VARCHAR2(4000);

    I_EXCEP_CNT_TGT   NUMBER := 0;

    I_EXCEP_CNT_SI   NUMBER := 0;


BEGIN

/***********************************************************************************************************
PROCEDURE NAME : PROC_1_VSL_CERT_ATTR
CREATED BY     : C.N.BHASKAR
DATE           : 26-MAR-2019
PURPOSE        : INSERTING  THE DATA FROM STAGING TABLE (ST_CV_VSLCERT A,ST_CV_VSL B ,VESSEL_CERTIFICATE) INTO  SI_VESSEL_CERTIFICATE_ATTRIBUTE(INTERMEDIATE TABLE) TO VESSEL_CERTIFICATE_ATTRIBUTES(TARGET TABLE)
MODIFIED BY    : R.M.KHOOL
MODIFIED DATE  : 04-OCT-2019

*************************************************************************************************************/

/***********************************************************************************************************
INSERTING DATA FROM STAGING TABLE INTO INTERMEDIATE TABLE
*************************************************************************************************************/

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR','INSERTION INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE STARTS' , 'START',NULL,NULL,NULL,'T');


FOR I IN (SELECT C.VSL_CERT_ID_N,
                 A.REGST_C,
                 A.PERSALLW_Q,
                 A.SOPEPSMPEPONBD_I,
                 B.INCOMPLYMARPOLREGU19_I,
                 A.INCOMPLYMARPOLREGU20_I,
                 A.INCOMPLYMARPOLREGU21_I,
                 A.INCOMPLYMARPOLREGU20_DT,
                 A.INCOMPLYMARPOLREGU21_DT,
                 A.CRTON_DT,
                 A.CRTBY_M,
                 A.UPDON_DT,
                 A.UPDBY_M


            FROM
                 ST_CV_VSLCERT A,
                 ST_CV_VSL B ,
                 VESSEL_CERTIFICATE C,
                 VESSEL V

            WHERE

                V.VSL_REC_ID_N = A.VSLRECID_N
				AND  V.MSW_VSL_ID_N=C.MSW_VSL_ID_N
                AND C.CERT_TY_C = A.CERTTY_C
				AND B.VSLRECID_N = A.VSLRECID_N
               --AND B.VSLRECID_N = C.VSL_REC_ID_N
               )

LOOP

BEGIN
INSERT INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE (VSLCERTID_N,
                                            REGST_C,
                                            PERSALLW_Q,
                                            SOPEPSMPEPONBD_I,
                                            INCOMPLYMARPOLREGU19_I,
                                            INCOMPLYMARPOLREGU20_I,
                                            INCOMPLYMARPOLREGU21_I,
                                            INCOMPLYMARPOLREGU20_DT,
                                            INCOMPLYMARPOLREGU21_DT,
                                            CRT_ON_DT,
                                            CRT_BY_X,
                                            UPT_ON_DT,
                                            UPT_BY_X
                                            )
                                            VALUES (I.VSL_CERT_ID_N,
                                                    I.REGST_C,
                                                    I.PERSALLW_Q,
                                                    I.SOPEPSMPEPONBD_I,
                                                    I.INCOMPLYMARPOLREGU19_I,
                                                    I.INCOMPLYMARPOLREGU20_I,
                                                    I.INCOMPLYMARPOLREGU21_I,
                                                    I.INCOMPLYMARPOLREGU20_DT,
                                                    I.INCOMPLYMARPOLREGU21_DT,
                                                    I.CRTON_DT,
                                                    I.CRTBY_M,
                                                    I.UPDON_DT,
                                                    I.UPDBY_M
                                                    );

EXCEPTION
    WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

V_ERR_ROW :=' VSLCERTID_N: '||I.VSL_CERT_ID_N||
			' REGST_C: '||I.REGST_C||
			' PERSALLW_Q: '||I.PERSALLW_Q||
			' SOPEPSMPEPONBD_I: '||I.SOPEPSMPEPONBD_I||
			' INCOMPLYMARPOLREGU19_I: '||I.INCOMPLYMARPOLREGU19_I||
			' INCOMPLYMARPOLREGU20_I: '||I.INCOMPLYMARPOLREGU20_I||
			' INCOMPLYMARPOLREGU21_I: '||I.INCOMPLYMARPOLREGU21_I||
			' INCOMPLYMARPOLREGU20_DT: '||I.INCOMPLYMARPOLREGU20_DT||
			' INCOMPLYMARPOLREGU21_DT: '||I.INCOMPLYMARPOLREGU21_DT||
			' CRT_ON_DT: '||I.CRTON_DT||
			' CRT_BY_X: '||I.CRTBY_M||
			' UPT_ON_DT: '||I.UPDON_DT||
			' UPT_BY_X: '||I.UPDBY_M;



I_EXCEP_CNT_SI := I_EXCEP_CNT_SI +1;

	IF I_EXCEP_CNT_SI < 50000  THEN 

			PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',V_ERR_ROW, 'ERROR',PV_RUN_ID,
					V_SQLERRM,
					I.VSL_CERT_ID_N||'<{||}>'||
					I.REGST_C||'<{||}>'||
					I.PERSALLW_Q||'<{||}>'||
					I.SOPEPSMPEPONBD_I||'<{||}>'||
					I.INCOMPLYMARPOLREGU19_I||'<{||}>'||
					I.INCOMPLYMARPOLREGU20_I||'<{||}>'||
					I.INCOMPLYMARPOLREGU21_I||'<{||}>'||
					I.INCOMPLYMARPOLREGU20_DT||'<{||}>'||
					I.INCOMPLYMARPOLREGU21_DT||'<{||}>'||
					I.CRTON_DT||'<{||}>'||
					I.CRTBY_M||'<{||}>'||
					I.UPDON_DT||'<{||}>'||
					I.UPDBY_M||'<{||}>'
					,'T');


	END IF;
END;
END LOOP;

COMMIT;

--RECONCILING THE STAGING TABLE CNT  AND INTERMEDIATE  TABLE COUNT
        SELECT COUNT(*)
        INTO V_SRC_COUNT
        FROM ST_CV_VSLCERT ;



        SELECT COUNT(*)
        INTO V_TGT_COUNT
        FROM SI_VESSEL_CERTIFICATE_ATTRIBUTE;

        PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_VSLCERT', V_SRC_COUNT, 'SI_VESSEL_CERTIFICATE_ATTRIBUTE',V_TGT_COUNT,'N');


        IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE TABLE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

        ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE TABLE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


		ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

        ELSE

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_VESSEL_CERTIFICATE_ATTRIBUTE TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

		END IF;





/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSLCERT   STARTS
******************************************************************************************************************************************************/
/*

BEGIN

FOR I IN (
SELECT
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT
FROM ST_CV_VSLCERT
WHERE VSLRECID_N NOT IN (   SELECT VSLRECID_N FROM ST_CV_VSL )

)
LOOP


 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'PROC_1_VSL_CERT_ATTR',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_VSLCERT AND ST_CV_VSL DUE TO JOIN CONDITION FAILURE',
                                                NULL,
                                                 PV_RUN_ID,
                                                  NULL,
                                                   I.CERTTY_C	||'*|'|| I.VSLRECID_N	||'*|'|| I.ISSD_DT	||'*|'||  I.DUE_DT	||'*|'||   I.REGST_C	||'*|'|| I.ISSDBY_C	||'*|'||
                                                   I.ISSAUTHYCTRY_C	||'*|'|| I.ISSGCL_C	||'*|'|| I.PERSALLW_Q	||'*|'|| I.SOPEPSMPEPONBD_I	||'*|'|| I.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   I.INCOMPLYMARPOLREGU21_I	||'*|'|| I.BCCAPPLN_N	||'*|'||
                                                   I.BCCAPPLNST_C	||'*|'|| I.BCCISSD_DT	||'*|'|| I.INSURTY_C	||'*|'|| I.INSURVALTILL_DT	||'*|'|| I.DOCIDATTH_N	||'*|'||
                                                   I.CERTST_C	||'*|'||I.LASTAPPRBY_N	||'*|'|| I.LASTAPPRBY_M	||'*|'|| I.CRTBY_N	||'*|'|| I.CRTBY_M	||'*|'|| I.CRTBYDEPT_M	||'*|'||
                                                   I.CRTON_DT	||'*|'|| I.UPDBY_N	||'*|'|| I.UPDBY_M	||'*|'|| I.UPDBYDEPT_M	||'*|'|| I.UPDON_DT	||'*|'|| I.INTLREM_X	||'*|'||
                                                   I.ISSGCL_M	||'*|'|| I.INCOMPLYMARPOLREGU20_DT	||'*|'|| I.INCOMPLYMARPOLREGU21_DT    ,
                                               'D');



END LOOP;


EXCEPTION  WHEN OTHERS THEN NULL;
END;
*/

/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSLCERT   ENDS
******************************************************************************************************************************************************/







/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSL   STARTS
******************************************************************************************************************************************************/

/*
BEGIN

FOR I IN (
SELECT
VSLRECID_N	,
VSL_M	,
VSLFLAG_C	,
VSLTY_C	,
VSLIMO_N	,
VSLGT_Q	,
VSLNT_Q	,
VSLLEN_Q	,
VSLBRE_Q	,
VSLPREV_M	,
VSLCALLSIGN_N	,
VSLRECST_I	,
VSLCRAFTTY_C	,
VSLACCT_N	,
VSLDWT_N	,
VSLCRAFTLIC_N	,
VSLCRAFTLICVALYFR_D	,
VSLCRAFTLICVALYTO_D	,
VSLCRAFTLICDELIC_D	,
VSLCRAFTLICST_C	,
VSLCRAFTLICUSES_X	,
VSLATTAINABLEHGT_Q	,
USERVEFID_N	,
SYSALLW_I	,
VSLMMSI_N	,
CLCEXP_DT	,
VSLYRBLT_N	,
VSLDELVY_D	,
ISSCVALIDTILL_D	,
ISSCISSGAUTHY_C	,
SOCVALIDTILL_D	,
SOCISSGAUTHY_C	,
PSCVALIDTILL_D	,
PSCISSGAUTHY_C	,
PSCPERSALLW_N	,
BCCEXP_DT	,
PUID_N	,
AGT_M	,
CRAFTGT_Q	,
PORTOFREGY_C	,
PORT_N	,
OFFICIAL_N	,
BUILDER_M	,
OWNR_M	,
OWNRCTRY_C	,
VSLPLBLT_C	,
UNOFFICIALVSL_M	,
UPDUNOFFICIALVSLM_DT	,
UNOFFICIALVSLCALLSIGN_N	,
UNOFFICIALVSLTY_C	,
UNOFFICIALVSLFLAG_C	,
UNOFFICIALVSLGT_Q	,
CRAFTBRE_Q	,
LEN_Q	,
LOA_Q	,
LOAUPDON_DT	,
VSLDEPTH_Q	,
BOWBRIDGE_Q	,
BOWTHRUSTER_N	,
STERNTHRUSTER_N	,
HULLMAKE_C	,
DBLHULLCONSTRUCT_I	,
APPRFORSEATRIAL_I	,
INCOMPLYMARPOLREGU19_I	,
MECHANICPROPEL_I	,
GTEPAN_Q	,
GTEPAN_DT	,
LAUNCHON_DT	,
BARTERTRADE_I	,
BAREBOATCHARTEROUT_I	,
RECVRF_I	,
TRANSIT_I	,
INTLREM_X	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
MERGEFRTOVSLRECID_N	,
EDISENT_I	,
CRAFTHGT_Q

FROM ST_CV_VSL
WHERE VSLRECID_N NOT IN (   SELECT VSLRECID_N FROM ST_CV_VSLCERT )

)



LOOP


 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'PROC_1_VSL_CERT_ATTR',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_VSL AND ST_VSL_CERT DUE TO JOIN CONDITION FAILURE',
                                                NULL,
                                                 PV_RUN_ID,
                                                  NULL,
                                                  I.VSLRECID_N	||'*|'||I.VSL_M	||'*|'||I.VSLFLAG_C	||'*|'||I.VSLTY_C	||'*|'||I.VSLIMO_N	||'*|'||
I.VSLGT_Q	||'*|'||I.VSLNT_Q	||'*|'||I.VSLLEN_Q	||'*|'||I.VSLBRE_Q	||'*|'||I.VSLPREV_M	||'*|'||I.VSLCALLSIGN_N	||'*|'||I.VSLRECST_I	||'*|'||I.VSLCRAFTTY_C	||'*|'||
I.VSLACCT_N	||'*|'||I.VSLDWT_N	||'*|'||I.VSLCRAFTLIC_N	||'*|'||I.VSLCRAFTLICVALYFR_D	||'*|'||I.VSLCRAFTLICVALYTO_D	||'*|'||I.VSLCRAFTLICDELIC_D	||'*|'||
I.VSLCRAFTLICST_C	||'*|'||I.VSLCRAFTLICUSES_X	||'*|'||I.VSLATTAINABLEHGT_Q	||'*|'||I.USERVEFID_N	||'*|'||I.SYSALLW_I	||'*|'||I.VSLMMSI_N	||'*|'||I.CLCEXP_DT	||'*|'||I.VSLYRBLT_N	||'*|'||I.VSLDELVY_D	||'*|'||I.ISSCVALIDTILL_D	||'*|'||
I.ISSCISSGAUTHY_C	||'*|'||I.SOCVALIDTILL_D	||'*|'||I.SOCISSGAUTHY_C	||'*|'||I.PSCVALIDTILL_D	||'*|'||I.PSCISSGAUTHY_C	||'*|'||I.PSCPERSALLW_N	||'*|'||I.BCCEXP_DT	||'*|'||
I.PUID_N	||'*|'||I.AGT_M	||'*|'||I.CRAFTGT_Q	||'*|'||I.PORTOFREGY_C	||'*|'||I.PORT_N	||'*|'||I.OFFICIAL_N	||'*|'||I.BUILDER_M	||'*|'||
I.OWNR_M	||'*|'||I.OWNRCTRY_C	||'*|'||I.VSLPLBLT_C	||'*|'||I.UNOFFICIALVSL_M	||'*|'||I.UPDUNOFFICIALVSLM_DT	||'*|'||
I.UNOFFICIALVSLCALLSIGN_N	||'*|'||I.UNOFFICIALVSLTY_C	||'*|'||I.UNOFFICIALVSLFLAG_C	||'*|'||I.UNOFFICIALVSLGT_Q	||'*|'||I.CRAFTBRE_Q	||'*|'||
I.LEN_Q	||'*|'||I.LOA_Q	||'*|'||I.LOAUPDON_DT	||'*|'||I.VSLDEPTH_Q	||'*|'||I.BOWBRIDGE_Q	||'*|'||I.BOWTHRUSTER_N	||'*|'||I.STERNTHRUSTER_N	||'*|'||I.HULLMAKE_C	||'*|'||I.DBLHULLCONSTRUCT_I	||'*|'||I.APPRFORSEATRIAL_I	||'*|'||I.INCOMPLYMARPOLREGU19_I	||'*|'||I.MECHANICPROPEL_I	||'*|'||I.GTEPAN_Q	||'*|'||I.GTEPAN_DT	||'*|'||
I.LAUNCHON_DT	||'*|'||I.BARTERTRADE_I	||'*|'||I.BAREBOATCHARTEROUT_I
||'*|'||I.RECVRF_I	||'*|'||I.TRANSIT_I	||'*|'||I.INTLREM_X	||'*|'||I.LASTAPPRBY_N	||'*|'||I.LASTAPPRBY_M	||'*|'||I.CRTBY_N	||'*|'||I.CRTBY_M	||'*|'||I.CRTBYDEPT_M	||'*|'||I.CRTON_DT	||'*|'||I.UPDBY_N	||'*|'||I.UPDBY_M	||'*|'||I.UPDBYDEPT_M	||'*|'||I.UPDON_DT	||'*|'||I.MERGEFRTOVSLRECID_N	||'*|'||I.EDISENT_I	||'*|'||I.CRAFTHGT_Q
    ,
                                               'D');



END LOOP;


EXCEPTION  WHEN OTHERS THEN NULL;
END;
*/

/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSL   ENDS
******************************************************************************************************************************************************/

/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSLCERT AND QUERY STARTS
******************************************************************************************************************************************************/

/*

BEGIN

FOR I IN
(
SELECT
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT

FROM ST_CV_VSLCERT WHERE VSLRECID_N NOT IN (    SELECT A.VSLRECID_N
                                                 FROM ST_CV_VSLCERT A,
                                                 ST_CV_VSL B ,
                                                 VESSEL_CERTIFICATE C,
                                                 VESSEL V
                                                WHERE V.VSL_REC_ID_N = A.VSLRECID_N
                                                AND  V.MSW_VSL_ID_N=C.MSW_VSL_ID_N
                                                AND C.CERT_TY_C = A.CERTTY_C
                                                AND B.VSLRECID_N = A.VSLRECID_N)

)


LOOP


 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'PROC_1_VSL_CERT_ATTR',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_VSLCERT AND WHOLE QUERY DUE TO JOIN CONDITION FAILURE',
                                                NULL,
                                                 PV_RUN_ID,
                                                  NULL,
                                                   I.CERTTY_C	||'*|'|| I.VSLRECID_N	||'*|'|| I.ISSD_DT	||'*|'||  I.DUE_DT	||'*|'||   I.REGST_C	||'*|'|| I.ISSDBY_C	||'*|'||
                                                   I.ISSAUTHYCTRY_C	||'*|'|| I.ISSGCL_C	||'*|'|| I.PERSALLW_Q	||'*|'|| I.SOPEPSMPEPONBD_I	||'*|'|| I.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   I.INCOMPLYMARPOLREGU21_I	||'*|'|| I.BCCAPPLN_N	||'*|'||
                                                   I.BCCAPPLNST_C	||'*|'|| I.BCCISSD_DT	||'*|'|| I.INSURTY_C	||'*|'|| I.INSURVALTILL_DT	||'*|'|| I.DOCIDATTH_N	||'*|'||
                                                   I.CERTST_C	||'*|'||I.LASTAPPRBY_N	||'*|'|| I.LASTAPPRBY_M	||'*|'|| I.CRTBY_N	||'*|'|| I.CRTBY_M	||'*|'|| I.CRTBYDEPT_M	||'*|'||
                                                   I.CRTON_DT	||'*|'|| I.UPDBY_N	||'*|'|| I.UPDBY_M	||'*|'|| I.UPDBYDEPT_M	||'*|'|| I.UPDON_DT	||'*|'|| I.INTLREM_X	||'*|'||
                                                   I.ISSGCL_M	||'*|'|| I.INCOMPLYMARPOLREGU20_DT	||'*|'|| I.INCOMPLYMARPOLREGU21_DT    ,
                                               'B');



END LOOP;


EXCEPTION  WHEN OTHERS THEN NULL;
END;

*/
/**************************************************************************************************************************************************
LISTING OUT THE UN COMMON RECORDS FROM THE JOINING CONDITION FROM ST_CV_VSLCERT AND QUERY ENDS
******************************************************************************************************************************************************/




















/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/
   --FIND THE COUNT OF INTERMEDIATE TABLE(SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF TARGET TABLE




    OPEN CUR_VSLCRTATTR;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR','INSERTION INTO VESSEL_CERTIFICATE_ATTRIBUTES STARTS' , 'START',NULL,NULL,NULL,NULL);

    LOOP

            FETCH CUR_VSLCRTATTR BULK COLLECT INTO LV_VSL_CERT LIMIT 10000;
            EXIT WHEN LV_VSL_CERT.COUNT = 0;
   -- INSERTING THE DATA FROM THE COLLECTION VARIABLE INTO THE TARGET TABLE IN THE BATCHES OF THE VALUE SPECIFIED IN LIMIT

                FOR I IN LV_VSL_CERT.FIRST..LV_VSL_CERT.LAST 
				LOOP

				BEGIN
                   INSERT INTO VESSEL_CERTIFICATE_ATTRIBUTES
                               (
                                VSL_CERT_ATTRB_ID_N,
                                VSL_CERT_ID_N,
                                REG_ST_C,
                                PERS_ALLW_Q,
                                SOPEP_SMPEP_ONBD_I,
                                IN_COMPLY_MARPOL_REGU19_I,
                                IN_COMPLY_MARPOL_REGU20_I,
                                IN_COMPLY_MARPOL_REGU21_I,
                                CRT_ON_DT,
                                CRT_BY_X	,
                                UPT_ON_DT,
                                UPT_BY_X,
                                LOCK_VER_N,
                                DELETED_I,
                                IN_COMPLY_MARPOL_REGU20_DT,
                                IN_COMPLY_MARPOL_REGU21_DT)

                  VALUES (SEQ_VSL_CERT_ATT.NEXTVAL,
                          LV_VSL_CERT(I).V_VSLCERTID_N,
                          DECODE(LV_VSL_CERT(I).V_REGST_C,1,'PERMANENT',2,'PROVISIONAL'),
                          LV_VSL_CERT(I).V_PERSALLW_Q,
                          DECODE(LV_VSL_CERT(I).V_SOPEPSMPEPONBD_I,'Y',1,'N',0),
                          DECODE(LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU19_I,'Y',1,'N',0),
                          DECODE(LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_I,'Y',1,'N',0),
                          DECODE(LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_I,'Y',1,'N',0),
						  NVL(LV_VSL_CERT(I).V_CRT_ON_DT,SYSDATE),
						  NVL(LV_VSL_CERT(I).V_CRT_BY_X,'DATA MIGRATION'),
						  NVL(LV_VSL_CERT(I).V_UPT_ON_DT,SYSDATE),
						  NVL(LV_VSL_CERT(I).V_UPT_BY_X,'DATA MIGRATION'),
                          0,
                          0,
                          LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_DT,
                          LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_DT);

    -- DEFINING THE INNER EXCEPTION TO PREVENT THE CONTROL BREAKING OUT OF LOOP ABRUPTLY IN CASE OF FAILURE
				EXCEPTION


					 WHEN OTHERS THEN

						V_ERR_CODE := SQLCODE;
						V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
						V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


						V_EXP_ROWS := 	' VSL_CERT_ATTRB_ID_N: '||SEQ_VSL_CERT_ATT.CURRVAL||
										' VSL_CERT_ID_N: '||LV_VSL_CERT(I).V_VSLCERTID_N||
										' REG_ST_C: '||LV_VSL_CERT(I).V_REGST_C||
										' PERS_ALLW_Q: '||LV_VSL_CERT(I).V_PERSALLW_Q||
										' SOPEP_SMPEP_ONBD_I: '||LV_VSL_CERT(I).V_SOPEPSMPEPONBD_I||
										' IN_COMPLY_MARPOL_REGU19_I: '||LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU19_I||
										' IN_COMPLY_MARPOL_REGU20_I: '||LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_I||
										' IN_COMPLY_MARPOL_REGU21_I: '||LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_I||
										' CRT_ON_DT: '||NVL(LV_VSL_CERT(I).V_CRT_ON_DT,SYSDATE)||
										' CRT_BY_X: '||NVL(LV_VSL_CERT(I).V_CRT_BY_X,'DATA MIGRATION')||
										' UPT_ON_DT: '||NVL(LV_VSL_CERT(I).V_UPT_ON_DT,SYSDATE)||
										' UPT_BY_X: '||NVL(LV_VSL_CERT(I).V_UPT_BY_X,'DATA MIGRATION')||
										' LOCK_VER_N: '||0||
										' DELETED_I: '||0||
										' IN_COMPLY_MARPOL_REGU20_DT: '||LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_DT||
										' IN_COMPLY_MARPOL_REGU21_DT: '||LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_DT;


					I_EXCEP_CNT_TGT := I_EXCEP_CNT_TGT +1;

					IF I_EXCEP_CNT_TGT < 50000  THEN 

					PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
								('VESSEL_CERTIFICATE_ATTRIBUTES',
								'PROC_1_VSL_CERT_ATTR',
								V_EXP_ROWS,
								'ERROR',
								PV_RUN_ID,
								V_SQLERRM,
								SEQ_VSL_CERT_ATT.CURRVAL||'<{||}>'||
								LV_VSL_CERT(I).V_VSLCERTID_N||'<{||}>'||
								LV_VSL_CERT(I).V_REGST_C||'<{||}>'||
								LV_VSL_CERT(I).V_PERSALLW_Q||'<{||}>'||
								LV_VSL_CERT(I).V_SOPEPSMPEPONBD_I||'<{||}>'||
								LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU19_I||'<{||}>'||
								LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_I||'<{||}>'||
								LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_I||'<{||}>'||
								NVL(LV_VSL_CERT(I).V_CRT_ON_DT,SYSDATE)||'<{||}>'||
								NVL(LV_VSL_CERT(I).V_CRT_BY_X,'DATA MIGRATION')||'<{||}>'||
								NVL(LV_VSL_CERT(I).V_UPT_ON_DT,SYSDATE)||'<{||}>'||
								NVL(LV_VSL_CERT(I).V_UPT_BY_X,'DATA MIGRATION')||'<{||}>'||
								0||'<{||}>'||
								0||'<{||}>'||
								LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU20_DT||'<{||}>'||
								LV_VSL_CERT(I).V_INCOMPLYMARPOLREGU21_DT||'<{||}>',
								'T'
								);

					END IF;
			END;

            END LOOP;

            COMMIT;




    END LOOP;
    CLOSE CUR_VSLCRTATTR;

    --TAKING COUNT OF EACH AND IMDIVIDUAL SOURCE AND TARGET TABLE FOR RECONCIALATION PURPOSE

    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM SI_VESSEL_CERTIFICATE_ATTRIBUTE;


    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM VESSEL_CERTIFICATE_ATTRIBUTES;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_VESSEL_CERTIFICATE_ATTRIBUTE', V_SRC_COUNT, 'VESSEL_CERTIFICATE_ATTRIBUTES', V_TGT_COUNT,'N');


    IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE_ATTRIBUTES TABLE' ,'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE_ATTRIBUTES TABLE' ,'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


	ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE_ATTRIBUTES TABLE' ,
        'FAIL',NULL,NULL,NULL,NULL);

    ELSE

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR',
		V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE_ATTRIBUTES TABLE' ,
        'AMBIGIOUS',NULL,NULL,NULL,NULL);

	END IF;

    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM ST_CV_VSLCERT;

    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM VESSEL_CERTIFICATE_ATTRIBUTES;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_VSLCERT', V_SRC_COUNT, 'VESSEL_CERTIFICATE_ATTRIBUTES', V_TGT_COUNT,'Y');





EXCEPTION
    WHEN OTHERS THEN
    V_ERR_CODE := SQLCODE;
	V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
	V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE_ATTRIBUTES', 'PROC_1_VSL_CERT_ATTR', V_SQLERRM||
        'ERROR'||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 'ERROR',NULL,NULL,NULL,'T');
END;

/