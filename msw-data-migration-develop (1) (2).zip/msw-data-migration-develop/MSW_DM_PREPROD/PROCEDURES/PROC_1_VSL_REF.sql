create or replace PROCEDURE PROC_1_VSL_REF (
V_MSW_VSL_ID_N IN NUMBER,
V_VSL_REC_ID_N IN NUMBER,
V_VSL_M IN VARCHAR2,
V_PORT_OF_REGY_C IN VARCHAR2,
V_VSL_IMO_N IN VARCHAR2,
V_VSL_CALL_SIGN_N IN VARCHAR2,
V_VSL_CRAFT_LIC_N IN VARCHAR2,
V_VSL_GT_Q IN NUMBER,
V_VSL_NT_Q IN NUMBER,
V_VSL_FLAG_C IN VARCHAR2,
V_VSL_TY_C IN VARCHAR2,
V_VSL_REF_ID_OUT OUT NUMBER,
V_FLAG_OUT OUT VARCHAR2
)
IS
/***********************************************************************************************************
PROCEDURE NAME : PROC_MSW_VSL_CALL
CREATED BY     : R.M.KHOOL
DATE           : 24-JUL-2019
PURPOSE        : INSERTING THE RECORD INTO VESSEL_REFERENCE TABLE
MODIFIED BY    : 
MODIFIED DATE  : 08-NOV-2019

*************************************************************************************************************/
V_VSL_REF_ID_N NUMBER;
V_ERR_CODE         NUMBER;
V_EXP_ROWS         VARCHAR2(4000);
V_ERR_MSG          VARCHAR2(500);
V_SQLERRM          VARCHAR2(2500);
V_VSL_TY           VARCHAR2(10);
LV_VSL_DATA        VESSEL%ROWTYPE;
BEGIN
V_ERR_CODE := NULL;



SELECT VSL_REF_SEQ.NEXTVAL INTO V_VSL_REF_ID_N FROM DUAL;

V_VSL_REF_ID_OUT :=V_VSL_REF_ID_N;

---Getting value for V_VSL_TY_C
     IF V_VSL_TY_C IS NULL
        THEN
        BEGIN

			SELECT VT.VSL_TY_C INTO V_VSL_TY  FROM VESSEL V, VESSEL_TYPE VT
			WHERE VT.VSL_TYPE_ID_N = V.VSL_TYPE_ID_N
			AND V.MSW_VSL_ID_N =V_MSW_VSL_ID_N;

        EXCEPTION
		WHEN NO_DATA_FOUND THEN
		V_VSL_TY :='MSW_DM';
		WHEN OTHERS THEN
		V_VSL_TY := 'MSW_DM';

        END;
    ELSE
    V_VSL_TY:=V_VSL_TY_C;           

    END IF;

--Fetching Vessel Data 
BEGIN
 SELECT V.* INTO LV_VSL_DATA
 FROM VESSEL V
 WHERE V.MSW_VSL_ID_N =V_MSW_VSL_ID_N;
 EXCEPTION 
 WHEN OTHERS THEN 
 LV_VSL_DATA:=NULL;
END;

--INSERTING DATA INTO TABLE VESSEL_REFERENCE---
				BEGIN

				INSERT INTO VESSEL_REFERENCE(VSL_REF_ID_N,
											MSW_VSL_ID_N,
											VSL_REC_ID_N,
											VSL_M,
											PORT_OF_REGY_C,
											VSL_IMO_N,
											VSL_CALL_SIGN_N,
											VSL_CRAFT_LIC_N,
											VSL_GT_Q,
											VSL_NT_Q,
											VSL_FLAG_C,
											VSL_TY_C,
											LOA_Q,
											DELETED_I,
											LOCK_VER_N )
									VALUES (V_VSL_REF_ID_N,
											V_MSW_VSL_ID_N,
											V_VSL_REC_ID_N,
											V_VSL_M,
											V_PORT_OF_REGY_C,
											V_VSL_IMO_N,
											V_VSL_CALL_SIGN_N,
											V_VSL_CRAFT_LIC_N,
											NVL(V_VSL_GT_Q,LV_VSL_DATA.VSL_GT_Q),
											V_VSL_NT_Q,
											V_VSL_FLAG_C,
											V_VSL_TY,
											NULL,
											0,
											0									
											);   


					 EXCEPTION
				       WHEN OTHERS THEN

                       V_FLAG_OUT:= 'F';

						V_ERR_CODE := SQLCODE;	

						V_EXP_ROWS :=  'VSL_REF_ID_N: '||V_VSL_REF_ID_N ||' MSW_VSL_ID_N: '||V_MSW_VSL_ID_N ||' VSL_REC_ID_N: '||V_VSL_REC_ID_N ||' VSL_M: '||V_VSL_M ||
                        'PORT_OF_REGY_C: '||V_PORT_OF_REGY_C||' VSL_IMO_N: '||V_VSL_IMO_N||' VSL_CALL_SIGN_N: '||V_VSL_CALL_SIGN_N || 
                         ' VSL_CRAFT_LIC_N: '||V_VSL_CRAFT_LIC_N||' VSL_GT_Q: '||V_VSL_GT_Q ||' VSL_NT_Q: '||V_VSL_NT_Q||' VSL_FLAG_C: '||V_VSL_FLAG_C||' VSL_TY_C: '||V_VSL_TY_C;                        

						V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

						V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

                        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_REFERENCE', 'PROC_1_VSL_REF',V_SQLERRM, 'ERROR',NULL,V_ERR_MSG,V_EXP_ROWS,'T');

						COMMIT;


				END;		




	EXCEPTION
    WHEN OTHERS THEN

                V_FLAG_OUT:= 'F';

                V_ERR_CODE := SQLCODE;

                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||dbms_utility.format_error_backtrace;

                V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_REFERENCE', 'PROC_1_VSL_REF', V_SQLERRM, 'ERROR',NULL,V_ERR_MSG,NULL,'T');
END;
/