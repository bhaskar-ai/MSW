CREATE OR REPLACE PROCEDURE PROC_1_ORG_ST_AUDIT ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_SI         NUMBER;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    LV_ORG_ST_C       VARCHAR2(20);
    LV_RSN_X          VARCHAR2(256);
    LV_EFFVE_FR_D     TIMESTAMP;
    LV_EFFVE_TO_D     TIMESTAMP;
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_ORG_ST_AUDIT
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-NOV-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_SI_ORG_ST_AUDIT IS

    SELECT A.PUID_N ,A.BLACKLISTEDON_DT,A.SUSPDFR_DT,A.SUSPDTO_DT,A.BLACKLISTEDRSN_X,A.SUSPDRSN_X, B.UEN_N 
    FROM ST_PU_PORTCLRCESCHMMSTR A, ST_PU_USRORG B 
    WHERE A.PUID_N = B.PUID_N AND B.UEN_N IS NOT NULL;

------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
   CURSOR CR_ORG_ST_AUDIT IS
    SELECT
        *
    FROM
        SI_ORG_ST_AUDIT;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE REC_SI_ORG_ST_AUDIT IS RECORD (

        PUID_N_R                  ST_PU_PORTCLRCESCHMMSTR.PUID_N%TYPE,
        BLACKLISTEDON_DT_R        ST_PU_PORTCLRCESCHMMSTR.BLACKLISTEDON_DT%TYPE,
        SUSPDFR_DT_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDFR_DT%TYPE,
        SUSPDTO_DT_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDTO_DT%TYPE,
        BLACKLISTEDRSN_X_R        ST_PU_PORTCLRCESCHMMSTR.BLACKLISTEDRSN_X%TYPE,
        SUSPDRSN_X_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDRSN_X%TYPE,
        UEN_N_R                   ST_PU_USRORG.UEN_N%TYPE
    );

    TYPE TYP_SI_ORG_ST_AUDIT IS
    TABLE OF REC_SI_ORG_ST_AUDIT INDEX BY PLS_INTEGER;

    LV_SI_ORG_ST_AUDIT    TYP_SI_ORG_ST_AUDIT;

    TYPE REC_ORG_ST_AUDIT IS RECORD (
        PUID_N_R                  ST_PU_PORTCLRCESCHMMSTR.PUID_N%TYPE,
        BLACKLISTEDON_DT_R        ST_PU_PORTCLRCESCHMMSTR.BLACKLISTEDON_DT%TYPE,
        SUSPDFR_DT_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDFR_DT%TYPE,
        SUSPDTO_DT_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDTO_DT%TYPE,
        BLACKLISTEDRSN_X_R        ST_PU_PORTCLRCESCHMMSTR.BLACKLISTEDRSN_X%TYPE,
        SUSPDRSN_X_R              ST_PU_PORTCLRCESCHMMSTR.SUSPDRSN_X%TYPE,
        UEN_N_R                   ST_PU_USRORG.UEN_N%TYPE
    );

    TYPE TYP_ORG_ST_AUDIT IS
    TABLE OF REC_ORG_ST_AUDIT INDEX BY PLS_INTEGER;

    LV_ORG_ST_AUDIT       TYP_ORG_ST_AUDIT;

BEGIN

execute immediate 'truncate table SI_ORG_ST_AUDIT';

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
        ST_PU_PORTCLRCESCHMMSTR ;    ---- DRIVING TABLE COUNT 

    OPEN CR_SI_ORG_ST_AUDIT;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', 'INSERTION INTO TABLE SI_ORG_ST_AUDIT', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH CR_SI_ORG_ST_AUDIT BULK COLLECT INTO LV_SI_ORG_ST_AUDIT LIMIT 10000;
        EXIT WHEN LV_SI_ORG_ST_AUDIT.COUNT = 0;

        FOR I IN LV_SI_ORG_ST_AUDIT.FIRST..LV_SI_ORG_ST_AUDIT.LAST LOOP

        BEGIN
                INSERT INTO SI_ORG_ST_AUDIT (
                    PUID_N ,
                    BLACKLISTEDON_DT,
                    SUSPDFR_DT,
                    SUSPDTO_DT,
                    BLACKLISTEDRSN_X,
                    SUSPDRSN_X,
                    UEN_N
                ) VALUES (
                    LV_SI_ORG_ST_AUDIT(I).PUID_N_R ,
                    LV_SI_ORG_ST_AUDIT(I).BLACKLISTEDON_DT_R,
                    LV_SI_ORG_ST_AUDIT(I).SUSPDFR_DT_R,
                    LV_SI_ORG_ST_AUDIT(I).SUSPDTO_DT_R,
                    LV_SI_ORG_ST_AUDIT(I).BLACKLISTEDRSN_X_R,
                    LV_SI_ORG_ST_AUDIT(I).SUSPDRSN_X_R,
                    LV_SI_ORG_ST_AUDIT(I).UEN_N_R
                );

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_SI_ORG_ST_AUDIT(I).PUID_N_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).BLACKLISTEDON_DT_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).SUSPDFR_DT_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).SUSPDTO_DT_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).BLACKLISTEDRSN_X_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).SUSPDRSN_X_R
                                     || '<{||}>'
                                     || LV_SI_ORG_ST_AUDIT(I).UEN_N_R
                                     ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_SI_ORG_ST_AUDIT;
  ---  COMMIT;

    SELECT  COUNT(*)
    INTO LV_CNT_SI
    FROM SI_ORG_ST_AUDIT;   ---- INTERMIDATE TABLE COUNT 

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PORTCLRCESCHMMSTR', LV_CNT_ST, 'SI_ORG_ST_AUDIT', LV_CNT_SI, 'N');

    OPEN CR_ORG_ST_AUDIT;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', 'INSERTION INTO TABLE ORG_ST_AUDIT', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_ST_AUDIT BULK COLLECT INTO LV_ORG_ST_AUDIT LIMIT 10000;
        EXIT WHEN LV_ORG_ST_AUDIT.COUNT = 0;

        FOR J IN LV_ORG_ST_AUDIT.FIRST..LV_ORG_ST_AUDIT.LAST LOOP
            BEGIN   

                    LV_ORG_ST_C     := NULL ;
                    LV_RSN_X        := NULL ;
                    LV_EFFVE_FR_D   := NULL ;
                    LV_EFFVE_TO_D   := NULL ;

                 IF   LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R   IS NOT NULL
                    THEN

                    LV_ORG_ST_C     := 'BLACKLISTED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDRSN_X_R  ;
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R  ;
                    LV_EFFVE_TO_D   :=  NULL;

                ELSIF   LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS NOT NULL
                    THEN

                    LV_ORG_ST_C     := 'SUSPENDED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).SUSPDRSN_X_R  ;
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R  ;
                    LV_EFFVE_TO_D   :=  LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R ;
                ELSE
                    continue; --Not to add if the record is not suspended nor blacklisted
                END IF ;    

               /*
                IF      LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R   IS NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R         IS NOT NULL   THEN

                    LV_ORG_ST_C     := 'BLACKLISTED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDRSN_X_R  ;
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R  ;
                    LV_EFFVE_TO_D   := NULL;

                ELSIF   LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R         IS NOT NULL   
                    AND LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R   IS NULL     
                    THEN

                    LV_ORG_ST_C     := 'SUSPENDED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).SUSPDRSN_X_R  ;
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R  ;
                    LV_EFFVE_TO_D   :=  LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R ;

               ELSIF    LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R IS   NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R         IS NULL   THEN

                    LV_ORG_ST_C     := 'BLACKLISTED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDRSN_X_R  ;   
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R  ;
                    LV_EFFVE_TO_D   := NULL;

               ELSIF    LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R       IS  NOT NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS  NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R         IS  NOT NULL  THEN

                    LV_ORG_ST_C     := 'BLACKLISTED' ;
                    LV_RSN_X        :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDRSN_X_R  ;   
                    LV_EFFVE_FR_D   :=  LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R  ;
                    LV_EFFVE_TO_D   := NULL;     

                ELSIF ( LV_ORG_ST_AUDIT(J).BLACKLISTEDON_DT_R   IS  NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDFR_DT_R         IS  NULL 
                    AND LV_ORG_ST_AUDIT(J).SUSPDTO_DT_R         IS  NULL   ) 

                    THEN

                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', 
                'Insertion Failed since Suspend related Fields and Blacklist related Fields don’t have data', null , 
                PV_RUN_ID, SQLERRM, null, 'T') ;

                continue ;

                END IF ;
                */
                INSERT INTO ORG_ST_AUDIT (
                    ID_N,
                    CO_UEN_N,
                    ORG_ST_C,
                    RSN_X,
                    EFFVE_FR_D,
                    EFFVE_TO_D
                ) VALUES (
                    SYN_SEQ_ORG_ST_AUDIT_ID.NEXTVAL,
                    LV_ORG_ST_AUDIT(J).UEN_N_R,
                    LV_ORG_ST_C ,
                    LV_RSN_X,
                    LV_EFFVE_FR_D,
                    LV_EFFVE_TO_D
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI :=    LV_ORG_ST_AUDIT(J).UEN_N_R
                                     || '<{||}>'
                                     || LV_ORG_ST_C
                                     || '<{||}>'
                                     || LV_RSN_X
                                     || '<{||}>'
                                     || LV_EFFVE_FR_D
                                     || '<{||}>'
                                     || LV_EFFVE_TO_D ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_ORG_ST_AUDIT;
   --- COMMIT;

    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM ORG_ST_AUDIT;  ---- TARGET TABLE COUNT 

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_ORG_ST_AUDIT', LV_CNT_SI, 'ORG_ST_AUDIT', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PORTCLRCESCHMMSTR', LV_CNT_ST, 'ORG_ST_AUDIT', LV_CNT_TAR, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_ORG_ST_AUDIT', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ORG_ST_AUDIT ;

/