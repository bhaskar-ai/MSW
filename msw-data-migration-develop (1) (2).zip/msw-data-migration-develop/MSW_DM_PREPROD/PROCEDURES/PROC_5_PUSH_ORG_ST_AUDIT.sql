CREATE OR REPLACE PROCEDURE PROC_5_PUSH_ORG_ST_AUDIT IS

/***********************************************************************************************************
PROCEDURE NAME : PROC_5_PUSH_ORG_ST_AUDIT
CREATED BY     : CONSTANTINE NGUYEN
DATE           : 25-NOV-2019
PURPOSE        : TO PUSH ORG_ST_AUDIT TABLE RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO RESPECTIVE TARGET SCHEMA AUTHENTICATION_SERVICE.ORG_ST_AUDIT
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****

    CURSOR cr_org_st_audit IS
    SELECT
        id_n,
        co_uen_n,
        org_st_c,
        rsn_x,
       	EFFVE_FR_D,
       	EFFVE_TO_D
    FROM
        ORG_ST_AUDIT;

    TYPE rec_org_st_audit IS RECORD (
        id_n                      ORG_ST_AUDIT.id_n%TYPE,
        co_uen_n                  ORG_ST_AUDIT.co_uen_n%TYPE,
        org_st_c                  ORG_ST_AUDIT.org_st_c%TYPE,
        rsn_x                     ORG_ST_AUDIT.rsn_x%TYPE,
        EFFVE_FR_D                ORG_ST_AUDIT.EFFVE_FR_D%TYPE,
        EFFVE_TO_D                ORG_ST_AUDIT.EFFVE_TO_D%TYPE
    );
   
    TYPE type_org_st_audit IS
        TABLE OF rec_org_st_audit;
    lv_org_st_audit           type_org_st_audit;
    

    lv_cnt_dm_ud_st_audit         NUMBER;
    lv_cnt_tt_ud_st_audit         NUMBER;
    v_err_code                NUMBER;
    v_err_msg                 VARCHAR2(500);
    v_sqlerrm                 VARCHAR2(2500);
    v_exp_rows                VARCHAR2(1000);
BEGIN
    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_st_audit
    FROM
        ORG_ST_AUDIT;

    OPEN cr_org_st_audit;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.ORG_ST_AUDIT'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.ORG_ST_AUDIT and inseting into target table AUTHENTICATION_SERVICE.ORG_ST_AUDIT ************------------------
        FETCH cr_org_st_audit BULK COLLECT INTO lv_org_st_audit LIMIT 10000;
        EXIT WHEN lv_org_st_audit.count = 0;
        FOR j IN lv_org_st_audit.first..lv_org_st_audit.last LOOP
-------------************ SYN_ORG_ST_AUDIT is synonym of AUTHENTICATION_SERVICE.ORG_ST_AUDIT  ************------------------
            BEGIN
                INSERT INTO syn_org_st_audit (
					id_n,
			        co_uen_n,
			        org_st_c,
			        rsn_x,
			       	EFFVE_FR_D,
			       	EFFVE_TO_D
                ) VALUES (
                    lv_org_st_audit(j).id_n,
			        lv_org_st_audit(j).co_uen_n,
			        lv_org_st_audit(j).org_st_c,
			        lv_org_st_audit(j).rsn_x,
			       	lv_org_st_audit(j).EFFVE_FR_D,
			       	lv_org_st_audit(j).EFFVE_TO_D
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ID_N: '
                                 ||lv_org_st_audit(j).id_n
                                 ||' CO_UEN_N: '
                                 ||lv_org_st_audit(j).co_uen_n
                                 ||' ORG_ST_C: '
                                 ||lv_org_st_audit(j).org_st_c
								 ||' RSN_X: '
                                 ||lv_org_st_audit(j).rsn_x
                                 ||' EFFVE_FR_D: '
                                 ||lv_org_st_audit(j).EFFVE_FR_D
                                 ||' EFFVE_TO_D: '
                                 ||lv_org_st_audit(j).EFFVE_TO_D;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', v_err_msg

                    , 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_org_st_audit;
    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_st_audit
    FROM
        syn_org_st_audit;

    IF ( lv_cnt_tt_ud_st_audit = lv_cnt_dm_ud_st_audit ) AND lv_cnt_dm_ud_st_audit <> 0 AND lv_cnt_tt_ud_st_audit <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', lv_cnt_dm_ud_st_audit
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_st_audit
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_ST_AUDIT'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF lv_cnt_dm_ud_st_audit <> lv_cnt_tt_ud_st_audit AND lv_cnt_dm_ud_st_audit <> 0 AND lv_cnt_tt_ud_st_audit <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', lv_cnt_dm_ud_st_audit
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_st_audit
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_ST_AUDIT'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF lv_cnt_dm_ud_st_audit <> 0 AND lv_cnt_tt_ud_st_audit = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', lv_cnt_dm_ud_st_audit
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_st_audit
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_ST_AUDIT'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;
    pkg_datamigration_generic.proc_migration_recon('MSW_DATA_MIGRATION.ORG_ST_AUDIT', lv_cnt_dm_ud_st_audit, 'AUTHENTICATION_SERVICE.ORG_ST_AUDIT', lv_cnt_tt_ud_st_audit, 'Y');
EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200)
                     || dbms_utility.format_error_backtrace;
        v_sqlerrm := v_err_code || v_err_msg;
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_ST_AUDIT', 'PROC_5_PUSH_ORG_ST_AUDIT', v_sqlerrm, 'ERROR', NULL, NULL, NULL, 'T');
END PROC_5_PUSH_ORG_ST_AUDIT;

/