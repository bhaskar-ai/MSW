create or replace PROCEDURE PROC_2_HNS_APPL_VSLCALL(PV_RUN_ID IN NUMBER)  IS


/***********************************************************************************************************
procedure name : PROC_2_HNS_APPL_VSLCALL
Created By     : R.M.KHOOL
Date           : 19-JUL-2019
Purpose        : Inserting  the data from ST_HN_NTCEHDR,ST_HN_NTCEDTL
                 SI_HNS_APP(Intermediate table) to HNS_APPLICATION & HNS_APPLICATION_SUBSTANCE(Target Table)
Modified by    :09-Aug_2019
Modified date  :

*************************************************************************************************************/
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARING VARIABLES FOR MAIN TABLE (CSV LOADED TABLE)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

 CURSOR CUR_HNSAP1 IS
       SELECT
                HDR.NTCE_N,
                HDR.NTCEVOY_N,
                HDR.NTCEVSLESTARR_DT,
                HDR.NTCEVSLESTDEP_DT,
                HDR.NTCECNTCT_M,
                HDR.NTCECO_M,
                HDR.NTCEEMLADDR_X,
                HDR.NTCECNTCT_N,
                HDR.NTCELSTPORTDESC_X,
                HDR.NTCELSTPORT_C,
                HDR.NTCECRAFTLIC_N,
                HDR.NTCECGOTY_C,
                HDR.CRTN_DT,
                HDR.CRTNBY_M  as hdr_crtby_m, --newly added 
                HDR.NTCEAPPLNT_M,
                HDR.UPDT_DT,
                HDR.UPDT_BY,
                HDR.NTCEINFRNGMNT,
                HDR.INFRNGMNTACTN_X,
                HDR.INFUSER,
                HDR.INFPROCESS_DT,
                HDR.INFREASON_X,
                HDR.INFREPORT_N,
                DTL.NTCEDTLSNO_N,
                DTL.NTCESUBST_C,
                DTL.NTCESUBST_M,
                DTL.NTCEUN_N,
                DTL.NTCEPOLLNCAT_X,
                DTL.NTCECGOGRP_C,
                DTL.NTCEFLASHPT,
                DTL.NTCEHZIBC_X,
                DTL.NTCEVSLCARRYQTY_Q,
                DTL.NTCESTWONBD,
                DTL.NTCEACTN_X,
                DTL.NTCELOCN_C,
                DTL.NTCEOPERN_DT,
                DTL.CRTN_DT AS DTLCRTN_DT,
                DTL.CRTNBY_M ,
                DTL.UPDT_DT AS DTLUPDT_DT,
                DTL.UPDT_BY AS DTLUPDT_BY ,
                DTL.NTCELOCN_M,
                HDR.NTCEVSLRECID_N,
                V.MSW_VSL_ID_N,
               'DM' as APPLCNT_ID_X , --ud.id_n as APPLCNT_ID_X ,-- UD.ID APPLCNT_ID_X
                HDR.NTCEVSL_M,
                HDR.NTCEVSLIMO_N,
                HDR.NTCECALLSIGN_M,
                HDR.NTCEVSLGT_Q,
                HDR.NTCEFLAG_C,
                HDR.NTCEVSLTY_C,
                HDR.NTCEORG_C,
                V.PORT_OF_REGY_C,
                V.VSL_CRAFT_LIC_N,
                V.VSL_NT_Q


            FROM
                ST_HN_NTCEHDR HDR,
                ST_HN_NTCEDTL DTL,
             --   USR_DTLS UD, (need to be added again when the the data is given)
                VESSEL V
            WHERE
                HDR.NTCE_N = DTL.NTCE_N
              AND
               HDR.NTCEVSLRECID_N=V.VSL_REC_ID_N
          --    and HDR.NTCE_N in('2003030051','2002080003')
          --    AND UD.PUID_N = HDR.ntceLoginid_c
              ORDER BY HDR.CRTN_DT;

        V_ST_COUNT             INTEGER; 
        V_ST_COUNT1            NUMBER;
        V_SRC_COUNT            NUMBER;
        V_TGT_COUNT            NUMBER;
        V_TGT_COUNT1           NUMBER;
		V_CNT_VR			   NUMBER;
		V_CNT_VC				NUMBER;
		V_CNT_AS			    NUMBER;
        V_ERR_CODE             NUMBER;
        V_ERR_MSG              VARCHAR2(2000);
        V_SQLERRM              VARCHAR2(2500);
        V_BLKEXPTN_COUNT       NUMBER(20, 0);
        V_BLKEXPTN_DESC        VARCHAR2(3000);
        V_MSG                  VARCHAR2(200);
        V_MSW_VSL_CALL_ID_OUT  NUMBER;
        V_FLAG                 VARCHAR2(1);
        V_EXP_ROWS_SI          VARCHAR2(3000);
        V_FLAG_VSL_REF         VARCHAR2(1);
        V_VSL_REF_ID_OUT       NUMBER;
        V_vslcall          number;
       V_vslrefid   number;
       v_cnt_vsllcall   number;
      v_tag   number;
  --    v_prev_ntce   varchar2(10) := null ;
      v_hns number;
      v_substance number;
      v_noticeid  number;
      v_hns_appssub  number;
      v_notice_id   varchar2(20);
      V_FLAG_OUT  VARCHAR2(20);



cursor CUR_HNSAP2 is 


select 

SI.	NTCE_N	,
SI.	NTCEVOY_N	,
SI.	NTCEVSLESTARR_DT	,
SI.	NTCEVSLESTDEP_DT	,
SI.	NTCECNTCT_M	,
SI.	NTCECO_M	,
SI.	NTCEEMLADDR_X	,
SI.	NTCECNTCT_N	,
SI.	NTCELSTPORTDESC_X	,
SI.	NTCELSTPORT_C	,
SI.	NTCECRAFTLIC_N	,
SI.	NTCECGOTY_C	,
SI.	CRTN_DT	,
SI.	NTCEAPPLNT_M	,
SI.	UPDT_DT	,
SI.	UPDT_BY	,
SI.	NTCEINFRNGMNT	,
SI.	INFRNGMNTACTN_X	,
SI.	INFUSER	,
SI.	INFPROCESS_DT	,
SI.	INFREASON_X	,
SI.	INFREPORT_N	,
SI.	NTCEDTLSNO_N	,
SI.	NTCESUBST_C	,
SI.	NTCESUBST_M	,
SI.	NTCEUN_N	,
SI.	NTCEPOLLNCAT_X	,
SI.	NTCECGOGRP_C	,
SI.	NTCEFLASHPT	,
SI.	NTCEHZIBC_X	,
SI.	NTCEVSLCARRYQTY_Q	,
SI.	NTCESTWONBD	,
SI.	NTCEACTN_X	,
SI.	NTCELOCN_C	,
SI.	NTCEOPERN_DT	,
SI.	DTLCRTN_DT	,
SI.	DTLCRTNBY_M	,
SI.	DTLUPDT_DT	,
SI.	DTLUPDT_BY	,
SI.	NTCELOCN_M	,
SI.	NTCEVSLRECID_N	,
SI.	MSW_VSL_ID_N	,
SI.	APPLCNT_ID_X	,
SI.	NTCEVSL_M	,
SI.	NTCEVSLIMO_N	,
SI.	NTCECALLSIGN_M	,
SI.	NTCEVSLGT_Q	,
SI.	NTCEFLAG_C	,
SI.	NTCEVSLTY_C	,
SI.	NTCEORG_C	,
tag.VSLRECID_N,
tag.VSLMVID_N,
tag.VSLRPTETA_DT,
tag.VSLRPTETD_DT,
tag.VSLRPTARR_DT,
tag.VSLRPTDEP_DT,
SI2.MSW_APPLN_REF_ID_N,
SI.CRTBY_M,-- newly added 
SI2.VSL_CALL_ID_N,
SI.PORT_OF_REGY_C, --newly added 
SI.VSL_CRAFT_LIC_N,--newly added 
SI.VSL_NT_Q --newly added 


from 


(
select d.ntce_n,d.NTCEVSLESTARR_DT,d.VSLRPTARR_DT , d.VSLRPTDEP_DT,d.VSLRECID_N, d.VSLMVID_N,d.VSLRPTETA_DT,d.VSLRPTETD_DT,d.myrank

from 


(
select c.ntce_n,c.NTCEVSLESTARR_DT,c.VSLRPTARR_DT , c.VSLRPTDEP_DT, c.VSLRECID_N,c.VSLMVID_N,c.VSLRPTETA_DT,c.VSLRPTETD_DT,RANK() OVER (PARTITION BY c.ntce_n ORDER BY c.VSLMVID_N) AS myrank


from 

(
select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, 
     st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT
AND b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT



union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and a.NTCEVSLESTARR_DT between  b.VSLRPTARR_DT and b.VSLRPTDEP_DT 
AND a.NTCEVSLESTDEP_DT between b.VSLRPTARR_DT and b.VSLRPTDEP_DT 

) c

order by c.ntce_n 
)d

where d. myrank = 1
)tag , 
     SI_HNS_APP  SI,
     SI_AS_VC_VR  SI2

where si.NTCE_N = tag.NTCE_N
and SI.	NTCE_N = SI2.EXTL_APPLN_REF_ID_X(+)
AND SI.MSW_VSL_ID_N   = SI2.MSW_VSL_ID_N(+)
--and si.ntce_n in ('2007039756')
--and si.ntce_n in ('2006098551','2007039756','2014090162')
ORDER BY SI.CRTN_DT,si.NTCE_N ;   




TYPE REC_HNS_APP_TG IS RECORD (

        V_NTCE_N		        SI_HNS_APP.NTCE_N%TYPE	,
        V_NTCEVOY_N		        SI_HNS_APP.NTCEVOY_N%TYPE	,
        V_NTCEVSLESTARR_DT		SI_HNS_APP.NTCEVSLESTARR_DT%TYPE	,
        V_NTCEVSLESTDEP_DT		SI_HNS_APP.NTCEVSLESTDEP_DT%TYPE	,
        V_NTCECNTCT_M		    SI_HNS_APP.NTCECNTCT_M%TYPE	,
        V_NTCECO_M		        SI_HNS_APP.NTCECO_M%TYPE	,
        V_NTCEEMLADDR_X		    SI_HNS_APP.NTCEEMLADDR_X%TYPE	,
        V_NTCECNTCT_N		    SI_HNS_APP.NTCECNTCT_N%TYPE	,
        V_NTCELSTPORTDESC_X		SI_HNS_APP.NTCELSTPORTDESC_X%TYPE	,
        V_NTCELSTPORT_C		    SI_HNS_APP.NTCELSTPORT_C%TYPE	,
        V_NTCECRAFTLIC_N		SI_HNS_APP.NTCECRAFTLIC_N%TYPE	,
        V_NTCECGOTY_C		    SI_HNS_APP.NTCECGOTY_C%TYPE	,
        V_CRTN_DT		        SI_HNS_APP.CRTN_DT%TYPE	,
        V_NTCEAPPLNT_M		    SI_HNS_APP.NTCEAPPLNT_M%TYPE	,
        V_UPDT_DT		        SI_HNS_APP.UPDT_DT%TYPE	,
        V_UPDT_BY		        SI_HNS_APP.UPDT_BY%TYPE	,
        V_NTCEINFRNGMNT		    SI_HNS_APP.NTCEINFRNGMNT%TYPE	,
        V_INFRNGMNTACTN_X		SI_HNS_APP.INFRNGMNTACTN_X%TYPE	,
        V_INFUSER		        SI_HNS_APP.INFUSER%TYPE	,
        V_INFPROCESS_DT		    SI_HNS_APP.INFPROCESS_DT%TYPE	,
        V_INFREASON_X		    SI_HNS_APP.INFREASON_X%TYPE	,
        V_INFREPORT_N		    SI_HNS_APP.INFREPORT_N%TYPE	,
        V_NTCEDTLSNO_N		    SI_HNS_APP.NTCEDTLSNO_N%TYPE	,
        V_NTCESUBST_C		    SI_HNS_APP.NTCESUBST_C%TYPE	,
        V_NTCESUBST_M		    SI_HNS_APP.NTCESUBST_M%TYPE	,
        V_NTCEUN_N		        SI_HNS_APP.NTCEUN_N%TYPE	,
        V_NTCEPOLLNCAT_X		SI_HNS_APP.NTCEPOLLNCAT_X%TYPE	,
        V_NTCECGOGRP_C		    SI_HNS_APP.NTCECGOGRP_C%TYPE	,
        V_NTCEFLASHPT		    SI_HNS_APP.NTCEFLASHPT%TYPE	,
        V_NTCEHZIBC_X		    SI_HNS_APP.NTCEHZIBC_X%TYPE	,
        V_NTCEVSLCARRYQTY_Q		SI_HNS_APP.NTCEVSLCARRYQTY_Q%TYPE	,
        V_NTCESTWONBD		    SI_HNS_APP.NTCESTWONBD%TYPE	,
        V_NTCEACTN_X		    SI_HNS_APP.NTCEACTN_X%TYPE	,
        V_NTCELOCN_C		    SI_HNS_APP.NTCELOCN_C%TYPE	,
        V_NTCEOPERN_DT		    SI_HNS_APP.NTCEOPERN_DT%TYPE	,
        V_DTLCRTN_DT		    SI_HNS_APP.DTLCRTN_DT%TYPE	,
        V_DTLCRTNBY_M		    SI_HNS_APP.DTLCRTNBY_M%TYPE	,
        V_DTLUPDT_DT		    SI_HNS_APP.DTLUPDT_DT%TYPE	,
        V_DTLUPDT_BY		    SI_HNS_APP.DTLUPDT_BY%TYPE	,
        V_NTCELOCN_M		    SI_HNS_APP.NTCELOCN_M%TYPE	,
        V_NTCEVSLRECID_N		SI_HNS_APP.NTCEVSLRECID_N%TYPE	,
        V_MSW_VSL_ID_N		    SI_HNS_APP.MSW_VSL_ID_N%TYPE,
        V_APPLCNT_ID_X          SI_HNS_APP.APPLCNT_ID_X%TYPE,
        V_NTCEVSL_M				SI_HNS_APP.NTCEVSL_M%TYPE	,
        V_NTCEVSLIMO_N          SI_HNS_APP.NTCEVSLIMO_N%TYPE	,
        V_NTCECALLSIGN_M        SI_HNS_APP.NTCECALLSIGN_M%TYPE	,
        V_NTCEVSLGT_Q           SI_HNS_APP.NTCEVSLGT_Q%TYPE	,
        V_NTCEFLAG_C            SI_HNS_APP.NTCEFLAG_C%TYPE	,
        V_NTCEVSLTY_C           SI_HNS_APP.NTCEVSLTY_C%TYPE	,
        V_NTCEORG_C             SI_HNS_APP.NTCEORG_C%TYPE,
        pv_VSLRECID_N           st_ptms_vslcall.VSLRECID_N%type,
        pv_VSLMVID_N            st_ptms_vslcall.VSLMVID_N%type,
        pv_VSLRPTETA_DT         st_ptms_vslcall.VSLRPTETA_DT%type,
        pv_VSLRPTETD_DT         st_ptms_vslcall.VSLRPTETD_DT%type,
        pv_VSLRPTARR_DT         st_ptms_vslcall.VSLRPTARR_DT%type,
        pv_VSLRPTDEP_DT         st_ptms_vslcall.VSLRPTDEP_DT%type,
        V_MSW_APPLN_REF_ID_X2   SI_AS_VC_VR.MSW_APPLN_REF_ID_N%TYPE,
         V_CRTBY_M              SI_HNS_APP.CRTBY_M%type, -- newly added 
        v_VSL_CALL_ID_N         SI_AS_VC_VR.VSL_CALL_ID_N%type,
       V_PORT_OF_REGY_C         SI_HNS_APP.PORT_OF_REGY_C%type,
        V_VSL_CRAFT_LIC_N        SI_HNS_APP.VSL_CRAFT_LIC_N%type,
       V_VSL_NT_Q                 SI_HNS_APP.VSL_NT_Q%type);


    TYPE TYPE_HNS_APP_TG IS TABLE OF REC_HNS_APP_TG;

    LV_HNS_APP_TG              TYPE_HNS_APP_TG;


    V_MSW_APPLN_REF_ID_X   	   VARCHAR2(20); 			 ---VALUE SHOULD BE 15 ONLY
    V_SUBR_EMAIL               VARCHAR2(2);
    V_SUBR_SMS_I               VARCHAR2(2);
    LV_HNS_APP_SEQ             HNS_APPLICATION.APPLN_REF_N%TYPE;   
    LV_HNS_APPSUB_SEQ          HNS_APPLICATION_SUBSTANCE.HNS_APPLN_SUBST_ID_N%TYPE;
    PV_HNS_APPL                HNS_APPLICATION%ROWTYPE;
    PV_HNS_APPL_SUB            HNS_APPLICATION_SUBSTANCE%ROWTYPE;
    LV_DATA_DUMP               CLOB;
    V_APPLN_DATA               CLOB;
    L_VAL               	   NUMBER(6);
    V_YEAR_MONTH        	   VARCHAR2(5);
    P_YYMM              	   VARCHAR2(5);
    v_si_untagged              number;
    v_prev_ntce                varchar2(10) ;
    
    V_ST_COUNT2  number;



/********OPENING THE CURSOR FOR INTERMEDIATE TABLE*******/

BEGIN    

execute immediate 'truncate table SI_HNS_APP';  


execute immediate 'truncate table SI_HNS_APP_UNTAGGED';


 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 'INSERTION INTO SI_HNS_APP STARTS', 'START',PV_RUN_ID, NULL, NULL,'T' );

FOR I IN CUR_HNSAP1 

  LOOP

		BEGIN

			INSERT INTO SI_HNS_APP
                (
				NTCE_N	,
				NTCEVOY_N	,
				NTCEVSLESTARR_DT	,
				NTCEVSLESTDEP_DT	,
				NTCECNTCT_M	,
				NTCECO_M	,
				NTCEEMLADDR_X	,
				NTCECNTCT_N	,
				NTCELSTPORTDESC_X	,
				NTCELSTPORT_C	,
				NTCECRAFTLIC_N	,
				NTCECGOTY_C	,
				CRTN_DT	,
				NTCEAPPLNT_M	,
				UPDT_DT	,
				UPDT_BY	,
				NTCEINFRNGMNT	,
				INFRNGMNTACTN_X	,
				INFUSER	,
				INFPROCESS_DT	,
				INFREASON_X	,
				INFREPORT_N	,
				NTCEDTLSNO_N	,
				NTCESUBST_C	,
				NTCESUBST_M	,
				NTCEUN_N	,
				NTCEPOLLNCAT_X	,
				NTCECGOGRP_C	,
				NTCEFLASHPT	,
				NTCEHZIBC_X	,
				NTCEVSLCARRYQTY_Q	,
				NTCESTWONBD	,
				NTCEACTN_X	,
				NTCELOCN_C	,
				NTCEOPERN_DT	,
				DTLCRTN_DT	,
				DTLCRTNBY_M	,
				DTLUPDT_DT	,
				DTLUPDT_BY	,
				NTCELOCN_M	,
				NTCEVSLRECID_N	,
				MSW_VSL_ID_N,
                APPLCNT_ID_X,
                NTCEVSL_M,
                NTCEVSLIMO_N,
                NTCECALLSIGN_M,
                NTCEVSLGT_Q,
                NTCEFLAG_C,
                NTCEVSLTY_C,
                NTCEORG_C,
                CRTBY_M,
                PORT_OF_REGY_C,
                VSL_CRAFT_LIC_N,
                VSL_NT_Q--newly added,
                
				)
			VALUES
				(
            	I.NTCE_N	,
				I.NTCEVOY_N	,
				I.NTCEVSLESTARR_DT	,
				I.NTCEVSLESTDEP_DT	,
				I.NTCECNTCT_M	,
				I.NTCECO_M	,
				I.NTCEEMLADDR_X	,
				I.NTCECNTCT_N	,
				I.NTCELSTPORTDESC_X	,
				I.NTCELSTPORT_C	,
				I.NTCECRAFTLIC_N	,
				I.NTCECGOTY_C	,
				I.CRTN_DT	,
				I.NTCEAPPLNT_M	,
				I.UPDT_DT	,
				I.UPDT_BY	,
				I.NTCEINFRNGMNT	,
				I.INFRNGMNTACTN_X	,
				I.INFUSER	,
				I.INFPROCESS_DT	,
				I.INFREASON_X	,
				I.INFREPORT_N	,
				I.NTCEDTLSNO_N	,
				I.NTCESUBST_C	,
				I.NTCESUBST_M	,
				I.NTCEUN_N	,
				I.NTCEPOLLNCAT_X	,
				I.NTCECGOGRP_C	,
				I.NTCEFLASHPT	,
				I.NTCEHZIBC_X	,
				I.NTCEVSLCARRYQTY_Q	,
				I.NTCESTWONBD	,
				I.NTCEACTN_X	,
				I.NTCELOCN_C	,
				I.NTCEOPERN_DT	,
				I.DTLCRTN_DT	,
				I.crtnby_m ,
				I.DTLUPDT_DT	,
				I.DTLUPDT_BY	,
				I.NTCELOCN_M	,
				I.NTCEVSLRECID_N	,
				I.MSW_VSL_ID_N,
                I.APPLCNT_ID_X,
                I.NTCEVSL_M,
                I.NTCEVSLIMO_N,
                I.NTCECALLSIGN_M,
                I.NTCEVSLGT_Q,
                I.NTCEFLAG_C,
                I.NTCEVSLTY_C,
                I.NTCEORG_C,
                I.hdr_crtby_m,
                I.PORT_OF_REGY_C,
                I.VSL_CRAFT_LIC_N,
                I.VSL_NT_Q
				); 

			EXCEPTION
				WHEN OTHERS THEN            
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE||SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;

				V_EXP_ROWS_SI:=  I.NTCE_N||'<{||}>'||
								I.NTCEVOY_N||'<{||}>'||
								I.NTCEVSLESTARR_DT||'<{||}>'||
								I.NTCEVSLESTDEP_DT||'<{||}>'||
								I.NTCECNTCT_M||'<{||}>'||
								I.NTCECO_M||'<{||}>'||
								I.NTCEEMLADDR_X||'<{||}>'||
								I.NTCECNTCT_N||'<{||}>'||
								I.NTCELSTPORTDESC_X||'<{||}>'||
								I.NTCELSTPORT_C||'<{||}>'||
								I.NTCECRAFTLIC_N||'<{||}>'||
								I.NTCECGOTY_C||'<{||}>'||
								I.CRTN_DT||'<{||}>'||
								I.NTCEAPPLNT_M||'<{||}>'||
								I.UPDT_DT||'<{||}>'||
								I.UPDT_BY||'<{||}>'||
								I.NTCEINFRNGMNT||'<{||}>'||
								I.INFRNGMNTACTN_X||'<{||}>'||
								I.INFUSER||'<{||}>'||
								I.INFPROCESS_DT||'<{||}>'||
								I.INFREASON_X||'<{||}>'||
								I.INFREPORT_N||'<{||}>'||
								I.NTCEDTLSNO_N||'<{||}>'||
								I.NTCESUBST_C||'<{||}>'||
								I.NTCESUBST_M||'<{||}>'||
								I.NTCEUN_N||'<{||}>'||
								I.NTCEPOLLNCAT_X||'<{||}>'||
								I.NTCECGOGRP_C||'<{||}>'||
								I.NTCEFLASHPT||'<{||}>'||
								I.NTCEHZIBC_X||'<{||}>'||
								I.NTCEVSLCARRYQTY_Q||'<{||}>'||
								I.NTCESTWONBD||'<{||}>'||
								I.NTCEACTN_X||'<{||}>'||
								I.NTCELOCN_C||'<{||}>'||
								I.NTCEOPERN_DT||'<{||}>'||
								I.DTLCRTN_DT||'<{||}>'||
								I.crtnby_m||'<{||}>'||
								I.DTLUPDT_DT||'<{||}>'||
								I.DTLUPDT_BY||'<{||}>'||
								I.NTCELOCN_M||'<{||}>'||
								I.NTCEVSLRECID_N||'<{||}>'||
								I.MSW_VSL_ID_N||'<{||}>'||
                                I.APPLCNT_ID_X||'<{||}>'||
                                I.NTCEVSL_M||'<{||}>'||
                                I.NTCEVSLIMO_N||'<{||}>'||
                                I.NTCECALLSIGN_M||'<{||}>'||
                                I.NTCEVSLGT_Q||'<{||}>'||
                                I.NTCEFLAG_C||'<{||}>'||
                                I.NTCEVSLTY_C||'<{||}>'||
                                I.NTCEORG_C||'<{||}>'||
                                I.hdr_crtby_m ||'<{||}>'||
                                I.PORT_OF_REGY_C||'<{||}>'||
                                I.VSL_CRAFT_LIC_N||'<{||}>'||
                                I.VSL_NT_Q 
                                ;




                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', V_ERR_MSG,  'ERROR', PV_RUN_ID, V_SQLERRM , V_EXP_ROWS_SI ,'T');


		END;           -- begin of       CUR_HNSAP1                                                                                

    END LOOP;  -- end loop of cursor CUR_HNSAP1 




    COMMIT;    


/***********************************************************************************************************
Reconciling the count of staging table  ST_HN_NTCEHDR and SI  table of HNS starts
*************************************************************************************************************/




 SELECT
              count(*)
    into V_ST_COUNT

            FROM
                ST_HN_NTCEHDR HDR,
                ST_HN_NTCEDTL DTL,
               -- USR_DTLS UD,
                VESSEL V


            WHERE
                HDR.NTCE_N = DTL.NTCE_N
              AND
               HDR.NTCEVSLRECID_N=V.VSL_REC_ID_N;
          --    AND UD.PUID_N = HDR.ntceLoginid_c



--------------COUNT OF INTERMEDIATE TABLE


    SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM SI_HNS_APP;



 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_HNS_APP' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_HNS_APP' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO SI_HNS_APP TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT ||' rows have been inserted into SI_HNS_APP table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;



/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 
 pkg_datamigration_generic.proc_migration_recon('SI_QUERY_CNT', V_ST_COUNT, 'SI_HNS_APP', V_SRC_COUNT, 'N');     

 OPEN CUR_HNSAP2; 
    
  --  v_prev_ntce  := '0' ;
    v_notice_id  := '0';

   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION ( 'HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 'HNS_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T' );

   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION( 'HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', 'HNS_APPLICATION_SUBSTANCE' , 'START' ,PV_RUN_ID,NULL,NULL,'T');

     LOOP   -- cursor loop of CUR_HNSAP2



            FETCH CUR_HNSAP2 BULK COLLECT INTO LV_HNS_APP_TG LIMIT 10000 ;

            EXIT WHEN LV_HNS_APP_TG.COUNT = 0;

			-- INSERTING THE DATA FROM THE COLLECTION VARIABLE INTO THE TARGET TABLE 

            FOR I IN LV_HNS_APP_TG.FIRST..LV_HNS_APP_TG.LAST 

			LOOP
            
                           
              
                   
                        if v_notice_id  = '0' or v_notice_id  <>  LV_HNS_APP_TG(I).V_NTCE_N  then 
                        
                                        LV_HNS_APP_SEQ := HNS_APP_SEQ.NEXTVAL;              ----SEQUENCE FOR HNS APPLICATIN
                                        LV_HNS_APPSUB_SEQ := HNS_APPSUB_SEQ.NEXTVAL;        ----SEQUENCE FOR HNS APPLICATIN SUBSTANCE
                        
                        
                        else
                        
                        
                                       LV_HNS_APP_SEQ := HNS_APP_SEQ.currval;              ----SEQUENCE FOR HNS APPLICATIN
                                       LV_HNS_APPSUB_SEQ := HNS_APPSUB_SEQ.NEXTVAL;        ----SEQUENCE FOR HNS APPLICATIN SUBSTANCE
                        
                        
                        end if;



                      IF  LV_HNS_APP_TG(I).V_MSW_APPLN_REF_ID_X2  IS NULL THEN   -- check if the  MSW_ref id is already present or  not  

                                         if   v_notice_id  = '0' or   v_notice_id <> LV_HNS_APP_TG(I).V_NTCE_N then  --check if its a new recors or not the duplicate notice id 
                                         
                                         
                                   
                
                                                      SELECT TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT,'YY')|| TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT,'MM') 
                                                        INTO V_YEAR_MONTH 
                                                        FROM DUAL;
                                        
                                               
                                        
                                        
                                                     /*Reset the sequence if the current year month doesnot match with the previous year and month  */ 
                
                                                            IF V_YEAR_MONTH != P_YYMM  AND P_YYMM IS NOT NULL 
                                                            THEN
                                            
                                                                    EXECUTE IMMEDIATE 'SELECT APP_SUB_HNS_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                                                                    EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_HNS_SEQ INCREMENT BY -'|| L_VAL || ' MINVALUE 0';
                                                    
                                                                    EXECUTE IMMEDIATE 'SELECT APP_SUB_HNS_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                                                                    EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_HNS_SEQ INCREMENT BY 1000 MINVALUE 0';
                                                                    EXECUTE IMMEDIATE 'SELECT APP_SUB_HNS_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                                                                    EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_HNS_SEQ INCREMENT BY 1 MINVALUE 0';
                                                    
                                                           END IF; -- END IF OF  THE SEQUENCE RESET 
                        
                                                            P_YYMM := V_YEAR_MONTH ;
                                            
                                                            V_MSW_APPLN_REF_ID_X := 'MSW'
                                                                                    || 'HNS'
                                                                                    || TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT, 'YY')
                                                                                    || TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT, 'MM') 
                                                                                    || TO_CHAR(APP_SUB_HNS_SEQ.NEXTVAL, 'FM00000');
                                                                                    
                                           
                                           
                                                            
                                               -----------------------FOR DECODE PUT THIS VALUE IN VARIABLE-----------
                                            
                                                               SELECT DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1) 
                                                               INTO V_SUBR_EMAIL
                                                               FROM DUAL;
                                            
                                            
                                            
                                                               SELECT  DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]'), '0'), 0, 0, 1)
                                                               INTO V_SUBR_SMS_I 
                                                               FROM DUAL;
                                            
                                            
                                            
                                            ----ASSISGNING THE JSON-------   
                                            
                                                                PV_HNS_APPL.APPLN_REF_N := LV_HNS_APP_SEQ;
                                                                PV_HNS_APPL.MSW_APPLN_REF_ID_X := V_MSW_APPLN_REF_ID_X ;
                                                                PV_HNS_APPL.EXTL_APPLN_REF_ID_X :=  LV_HNS_APP_TG(I).V_NTCE_N;       --NULL
                                                                PV_HNS_APPL.MSW_VSL_ID_N := LV_HNS_APP_TG(I).V_MSW_VSL_ID_N;
                                                                PV_HNS_APPL.VOY_N_X := LV_HNS_APP_TG(I).V_NTCEVOY_N;
                                                                PV_HNS_APPL.ETA_DT := LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT;
                                                                PV_HNS_APPL.ETD_DT := LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT;
                                                                PV_HNS_APPL.APPLCNT_ID_X := LV_HNS_APP_TG(I).V_APPLCNT_ID_X;--'PENDING';
                                                                PV_HNS_APPL.CONT_PERS_M := LV_HNS_APP_TG(I).V_NTCECNTCT_M;
                                                                PV_HNS_APPL.CO_M := LV_HNS_APP_TG(I).V_NTCECO_M;
                                                                PV_HNS_APPL.SUBR_EMAIL_I := V_SUBR_EMAIL ;   
                                                                PV_HNS_APPL.EMAIL_X := LV_HNS_APP_TG(I).V_NTCEEMLADDR_X;
                                                                PV_HNS_APPL.SUBR_SMS_I := V_SUBR_SMS_I;                                
                                                                PV_HNS_APPL.MOBILE_N := REGEXP_SUBSTR(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[0-9]+');
                                                                PV_HNS_APPL.LST_PORT_CTRY_X := LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X;
                                                                PV_HNS_APPL.LAST_PORT_C := LV_HNS_APP_TG(I).V_NTCELSTPORT_C;
                                                                PV_HNS_APPL.CFT_LIC_N := LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N;
                                                                PV_HNS_APPL.CGO_TY_C := LV_HNS_APP_TG(I).V_NTCECGOTY_C;
                                                                PV_HNS_APPL.APPLN_ST_C := 'APPROVED';
                                                                PV_HNS_APPL.PROCESSED_BY_X := NULL;
                                                                PV_HNS_APPL.PROCESSED_ON_DT := NULL;
                                                                PV_HNS_APPL.PROCESSING_REM_X := NULL;
                                                                PV_HNS_APPL.DELETED_I := 0;
                                                                PV_HNS_APPL.LOCK_VER_N := 0;
                                                                PV_HNS_APPL.CRT_ON_DT := LV_HNS_APP_TG(I).V_CRTN_DT;
                                                                PV_HNS_APPL.CRT_BY_X := 'MSW_DM';
                                                                PV_HNS_APPL.UPT_ON_DT := LV_HNS_APP_TG(I).V_UPDT_DT;
                                                                PV_HNS_APPL.UPT_BY_X := NVL(LV_HNS_APP_TG(I).V_UPDT_BY,'DATA MIGRATION');
                                                                PV_HNS_APPL.INFRNGMNT_C := LV_HNS_APP_TG(I).V_NTCEINFRNGMNT;
                                            
                                            ------------------ HNS SUBSTANCE ---------------------                    
                                            
                                                                PV_HNS_APPL_SUB.APPLN_REF_N := LV_HNS_APP_SEQ;
                                                                PV_HNS_APPL_SUB.DELETED_I := 0;
                                                                PV_HNS_APPL_SUB.SEQ_N := LV_HNS_APP_TG(I).V_NTCEDTLSNO_N;
                                                                PV_HNS_APPL_SUB.SUBST_C := LV_HNS_APP_TG(I).V_NTCESUBST_C;
                                                                PV_HNS_APPL_SUB.SUBST_M := LV_HNS_APP_TG(I).V_NTCESUBST_M;
                                                                PV_HNS_APPL_SUB.UN_N := LV_HNS_APP_TG(I).V_NTCEUN_N;
                                                                PV_HNS_APPL_SUB.POLLN_CAT_C := LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X;
                                                                PV_HNS_APPL_SUB.CGO_GRP_C := LV_HNS_APP_TG(I).V_NTCECGOGRP_C;
                                                                PV_HNS_APPL_SUB.FLASH_PT_N := LV_HNS_APP_TG(I).V_NTCEFLASHPT;
                                                                PV_HNS_APPL_SUB.HZ_IBC_C := LV_HNS_APP_TG(I).V_NTCEHZIBC_X;
                                                                PV_HNS_APPL_SUB.SUBST_QTY_Q := LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q;
                                                                PV_HNS_APPL_SUB.STW_ONBD_X := LV_HNS_APP_TG(I).V_NTCESTWONBD;
                                                                PV_HNS_APPL_SUB.OPERN_C := LV_HNS_APP_TG(I).V_NTCEACTN_X;
                                                                PV_HNS_APPL_SUB.LOCN_C := LV_HNS_APP_TG(I).V_NTCELOCN_C;
                                                                PV_HNS_APPL_SUB.OPERN_DT := LV_HNS_APP_TG(I).V_NTCEOPERN_DT;
                                                                PV_HNS_APPL_SUB.CRT_ON_DT := LV_HNS_APP_TG(I).V_DTLCRTN_DT;
                                                                PV_HNS_APPL_SUB.CRT_BY_X := LV_HNS_APP_TG(I).V_DTLCRTNBY_M;
                                                                PV_HNS_APPL_SUB.UPT_ON_DT := LV_HNS_APP_TG(I).V_DTLUPDT_DT;
                                                                PV_HNS_APPL_SUB.UPT_BY_X := LV_HNS_APP_TG(I).V_DTLUPDT_BY;
                                                                PV_HNS_APPL_SUB.LOCK_VER_N := '0';
                                            
                                                ------------**** JSON FUNC ***------------------------
                                                                LV_DATA_DUMP := FNC_JSON_VAL_HNS(PV_HNS_APPL, PV_HNS_APPL_SUB); 
                                                                
                                                                
                                                                 select count(*)
                                                                   into v_cnt_vsllcall
                                                                   from vessel_call
                                                                  where  MVMT_ID_N = trim(LV_HNS_APP_TG(I).pv_VSLMVID_N);
                                                                  
                                                       
                                                            
                                                                  if  v_cnt_vsllcall <> 0 then 
                                                                  
                                                                  
                                                                        select    VSL_CALL_ID_N,
                                                                                  VSL_REF_ID_N
                                                                          into    V_vslcall,
                                                                                  V_vslrefid
                                                                          from    vessel_call
                                                                    
                                                                        where  MVMT_ID_N = trim(LV_HNS_APP_TG(I).pv_VSLMVID_N) ;
                                                                        
                                                                        
                                                                        
                                                                        
                                                                         V_APPLN_DATA := '{"vesselCallId":'||V_vslcall||','||LV_DATA_DUMP;
                                                                         
                                                                                       insert into application_submission (
                                                                                                APPLN_SUBMISSN_ID_N,--done 
                                                                                                MSW_APPLN_REF_ID_X,--done 
                                                                                                VSL_CALL_ID_N, --done 
                                                                                                EXTL_APPLN_REF_ID_X,--done 
                                                                                                MSW_VSL_ID_N,--done 
                                                                                                ETA_DT,--done 
                                                                                                ETD_DT, --done 
                                                                                                APPLN_TY_C,--done 
                                                                                                APPLN_DATA_X,--done 
                                                                                                ST_C,--done
                                                                                                PROCESSING_REM_X,--done
                                                                                                PROCESSED_BY_X, --done
                                                                                                PROCESSED_ON_DT, --done
                                                                                                CUTOFF_DT, --done
                                                                                                LOCK_VER_N, --done 
                                                                                                CRT_ON_DT,--done 
                                                                                                CRT_BY_X, --done 
                                                                                                UPT_ON_DT, --done 
                                                                                                UPT_BY_X, --done 
                                                                                                DELETED_I, --done 
                                                                                                ORG_C,
                                                                                                VSL_REF_ID_N,
                                                                                                REASON)
                                                                        
                                                                                                values(APP_SUB_SEQ.NEXTVAL,
                                                                                                V_MSW_APPLN_REF_ID_X,
                                                                                                V_vslcall,
                                                                                                LV_HNS_APP_TG(I).V_NTCE_N,
                                                                                                LV_HNS_APP_TG(I).V_MSW_VSL_ID_N,
                                                                                                LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT, 
                                                                                               LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT,
                                                                                               'HNS',
                                                                                               V_APPLN_DATA,
                                                                                                 'PROCESSED',
                                                                                                 NULL,
                                                                                                  NULL,
                                                                                                  NULL,
                                                                                                 NULL,
                                                                                                 0,
                                                                                            LV_HNS_APP_TG(I).V_CRTN_DT,
                                                                                            LV_HNS_APP_TG(I).V_CRTBY_M,
                                                                                             LV_HNS_APP_TG(I).V_UPDT_DT,
                                                                                            LV_HNS_APP_TG(I).V_UPDT_BY,
                                                                                              0,
                                                                                              'MSW',
                                                                                              V_vslrefid,
                                                                                              null
                                                                        
                                                                                               );
                                                              
                                                                                            
                                                                                        
                                                                                                 BEGIN --BEGIN END FOR HNS_APPLICATI

                                                                              INSERT INTO HNS_APPLICATION (
                                                                                                    APPLN_REF_N,
                                                                                                    MSW_APPLN_REF_ID_X,
                                                                                                    VSL_CALL_ID_N,
                                                                                                    EXTL_APPLN_REF_ID_X,
                                                                                                    MSW_VSL_ID_N,
                                                                                                    VOY_N_X,
                                                                                                    ETA_DT,
                                                                                                    ETD_DT,
                                                                                                    APPLCNT_ID_X,
                                                                                                    CONT_PERS_M,
                                                                                                    CO_M,
                                                                                                    SUBR_EMAIL_I,
                                                                                                    EMAIL_X,
                                                                                                    SUBR_SMS_I,
                                                                                                    MOBILE_N,
                                                                                                    LST_PORT_CTRY_X,
                                                                                                    LAST_PORT_C,
                                                                                                    CFT_LIC_N,
                                                                                                    CGO_TY_C,
                                                                                                    APPLN_ST_C,
                                                                                                    PROCESSED_BY_X,
                                                                                                    PROCESSED_ON_DT,
                                                                                                    PROCESSING_REM_X,
                                                                                                    DELETED_I,
                                                                                                    LOCK_VER_N,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    INFRNGMNT_C,
                                                                                                    INFRNGMNT_ACTN_X,
                                                                                                    INFRNGMNT_USR_M,
                                                                                                    INFRNGMNT_PROCESS_DT,
                                                                                                    INFRNGMNT_PROCESS_RSN_X,
                                                                                                    INFRNGMNT_RPT_N
                                                                                                ) 
                                                                                        
                                                                                        VALUES (
                                                                                                    LV_HNS_APP_SEQ, --done 
                                                                                                    V_MSW_APPLN_REF_ID_X , 	--done 					--------- V_MSW_APPLN_REF_ID_X ,    
                                                                                                    LV_HNS_APP_TG(I).v_VSL_CALL_ID_N,	--done 					
                                                                                                    LV_HNS_APP_TG(I).V_NTCE_N,                
                                                                                                    LV_HNS_APP_TG(I).V_MSW_VSL_ID_N,                               
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVOY_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT,
                                                                                                    LV_HNS_APP_TG(I).V_APPLCNT_ID_X,--'PENDING',
                                                                                                    LV_HNS_APP_TG(I).V_NTCECNTCT_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECO_M,                   
                                                                                                    DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1),  ---- V_SUBR_EMAIL_I
                                                                                                    LV_HNS_APP_TG(I).V_NTCEEMLADDR_X,
                                                                                                    DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''), '0'), 0, 0, 1), ---SUBR_SMS_I
                                                                                                    REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''),                  
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORT_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOTY_C,
                                                                                                    'APPROVED',
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    0,
                                                                                                    0,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION'   , ----THIS COL NOT CONTAINS THE NULL VALUES  'APPLICANT'                          
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    LV_HNS_APP_TG(I).V_NTCEINFRNGMNT,
                                                                                                    LV_HNS_APP_TG(I).V_INFRNGMNTACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFUSER,
                                                                                                    LV_HNS_APP_TG(I).V_INFPROCESS_DT,
                                                                                                    LV_HNS_APP_TG(I).V_INFREASON_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFREPORT_N
                                                                                                );  
                                                                
                                                                
                                                                
                                                                            EXCEPTION -- --BEGIN END FOR HNS_APPLICATION
                                                                            WHEN OTHERS THEN
                                                                            V_ERR_CODE := SQLCODE;
                                                                                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                V_SQLERRM := V_ERR_CODE
                                                                                             || V_ERR_MSG
                                                                                             || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                    PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                    NULL,
                                                                                                                                                                                    'T'                                                                                                                    
                                                                                                                                                                                    );
                                                                
                                                                
                                                                
                                                                
                                                                                     v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                
                                                                
                                                                               CONTINUE; ----exception continue  
                                                                
                                                  END;-- --BEGIN END FOR HNS_APPLICATION
                                                  
                                              /*  
                                                  
                                                   BEGIN --HNS_APPLICATION_SUBSTANCE
                                                                                                
                                                                                                INSERT INTO HNS_APPLICATION_SUBSTANCE (
                                                                                                    HNS_APPLN_SUBST_ID_N,
                                                                                                    APPLN_REF_N,
                                                                                                    DELETED_I,
                                                                                                    SEQ_N,
                                                                                                    SUBST_C,
                                                                                                    SUBST_M,
                                                                                                    UN_N,
                                                                                                    POLLN_CAT_C,
                                                                                                    CGO_GRP_C,
                                                                                                    FLASH_PT_N,
                                                                                                    HZ_IBC_C,
                                                                                                    SUBST_QTY_Q,
                                                                                                    STW_ONBD_X,
                                                                                                    OPERN_C,
                                                                                                    LOCN_C,
                                                                                                    OPERN_DT,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    LOCK_VER_N,
                                                                                                    LOCN_M				
                                                                                                )
                                                                                                VALUES (
                                                                                                    LV_HNS_APPSUB_SEQ,
                                                                                                    LV_HNS_APP_SEQ,
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEUN_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESTWONBD,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                );
                                                                            
                                                                            
                                                                            
                                                                                               -- COMMIT;
                                                                                            EXCEPTION
                                                                                            WHEN OTHERS THEN
                                                                                            V_ERR_CODE := SQLCODE;
                                                                                            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                            V_SQLERRM := V_ERR_CODE
                                                                                                         || V_ERR_MSG
                                                                                                         || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                                        PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                                        'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
                                                                                                                                                                                                        'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
                                                                                                                                                                                                        'DELETED_I  :'||0||'<{||}>'||
                                                                                                                                                                                                        'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
                                                                                                                                                                                                        'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
                                                                                                                                                                                                        'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
                                                                                                                                                                                                        'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
                                                                                                                                                                                                        'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
                                                                                                                                                                                                        'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
                                                                                                                                                                                                        'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
                                                                                                                                                                                                        'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
                                                                                                                                                                                                        'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
                                                                                                                                                                                                        'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
                                                                                                                                                                                                        'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
                                                                                                                                                                                                        'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
                                                                                                                                                                                                        'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLCRTN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLCRTNBY_M||'<{||}>'||
                                                                                                                                                                                                        'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLUPDT_DT||'<{||}>'||
                                                                                                                                                                                                        'UPT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLUPDT_BY||'<{||}>'||
                                                                                                                                                                                                        'LOCK_VER_N  :'||0||'<{||}>'||
                                                                                                                                                                                                        'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                                                                                                        , 'T'
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                       
                                                                                                                                                            
                                                                                                                                                             v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                            
                                                                                                                               continue;  --exception continue  
                                                                            
                                                                            
                                                                                             END;--HNS_APPLICATION_SUBSTANCE


                                                             
                                                                        */                       
                                                                                               
                                                                                               
                                                                                               
                                                                                               
                                                                          else  --if  v_cnt_vsllcall <> 0 then
                                                                          
                                                                          
                                                                           PROC_1_VSL_REF(LV_HNS_APP_TG(i).V_MSW_VSL_ID_N,--V_MSW_VSL_ID_N 
                                                                                LV_HNS_APP_TG(i).V_NTCEVSLRECID_N,--V_VSL_REC_ID_N 
                                                                                null,--V_VSL_M  done 
                                                                                LV_HNS_APP_TG(i).V_PORT_OF_REGY_C,--V_PORT_OF_REGY_C  done 
                                                                                null,--V_VSL_IMO_N
                                                                                null,--V_VSL_CALL_SIGN_N  done
                                                                                LV_HNS_APP_TG(i).V_VSL_CRAFT_LIC_N,--V_VSL_CRAFT_LIC_N  V_VSL_CRAFT_LIC_N
                                                                                null,--V_VSL_GT_Q  done 
                                                                                LV_HNS_APP_TG(i).V_VSL_NT_Q,--V_VSL_NT_Q
                                                                                null,--V_VSL_FLAG_C  done
                                                                                null,--VSLTY_C  done
                                                                                V_VSL_REF_ID_OUT,
                                                                                V_FLAG_OUT);
                                                                                
                                                                                
                                                                                if v_flag_out is not null then 
                                                                                
                                                                                delete from VESSEL_REFERENCE where VSL_REF_ID_N = V_VSL_REF_ID_OUT;
                                                                                
                                                                                continue;
                                                                                
                                                                                else   --if v_flag_out is  null then 
                                                                                
                                                                                
                                                                                PROC_2_VC_AS  (LV_HNS_APP_TG(I).V_MSW_VSL_ID_N, 
                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT, 
                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT, 
                                                                                    NULL, 
                                                                                    NULL,
		                                                                            NULL,
                                                                                    V_MSW_APPLN_REF_ID_X, 
                                                                                    LV_HNS_APP_TG(I).V_NTCE_N, 
                                                                                    'HNS',
                                                                                    LV_DATA_DUMP, 
                                                                                    PV_RUN_ID,
                                                                                    'HNS_APPLICATION',
                                                                                    V_MSW_VSL_CALL_ID_OUT ,
                                                                                    V_FLAG,
                                                                                    'MSW',
                                                                                    V_VSL_REF_ID_OUT,
                                                                                    'PROCESSED',
                                                                                   LV_HNS_APP_TG(i).V_CRTN_DT,
                                                                                    LV_HNS_APP_TG(i).V_CRTBY_M,
                                                                                    LV_HNS_APP_TG(i).V_UPDT_DT,
                                                                                    LV_HNS_APP_TG(i).V_UPDT_BY);
                                                                                
                                                                                  
                                                                                
                                                                                
                                                                                end if ; --  if v_flag_out is not null then 
                                                                                
                                                                                
                                                                                if V_FLAG is  not null then
                                                                                
                                                                             --   delete from vessel_Call where 
                                                                          --      delete from appliation_submission where 
                                                                                continue;
                                                                                else
                                                                                    BEGIN --BEGIN END FOR HNS_APPLICATI

                                                                              INSERT INTO HNS_APPLICATION (
                                                                                                    APPLN_REF_N,
                                                                                                    MSW_APPLN_REF_ID_X,
                                                                                                    VSL_CALL_ID_N,
                                                                                                    EXTL_APPLN_REF_ID_X,
                                                                                                    MSW_VSL_ID_N,
                                                                                                    VOY_N_X,
                                                                                                    ETA_DT,
                                                                                                    ETD_DT,
                                                                                                    APPLCNT_ID_X,
                                                                                                    CONT_PERS_M,
                                                                                                    CO_M,
                                                                                                    SUBR_EMAIL_I,
                                                                                                    EMAIL_X,
                                                                                                    SUBR_SMS_I,
                                                                                                    MOBILE_N,
                                                                                                    LST_PORT_CTRY_X,
                                                                                                    LAST_PORT_C,
                                                                                                    CFT_LIC_N,
                                                                                                    CGO_TY_C,
                                                                                                    APPLN_ST_C,
                                                                                                    PROCESSED_BY_X,
                                                                                                    PROCESSED_ON_DT,
                                                                                                    PROCESSING_REM_X,
                                                                                                    DELETED_I,
                                                                                                    LOCK_VER_N,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    INFRNGMNT_C,
                                                                                                    INFRNGMNT_ACTN_X,
                                                                                                    INFRNGMNT_USR_M,
                                                                                                    INFRNGMNT_PROCESS_DT,
                                                                                                    INFRNGMNT_PROCESS_RSN_X,
                                                                                                    INFRNGMNT_RPT_N
                                                                                                ) 
                                                                                        VALUES (
                                                                                                    LV_HNS_APP_SEQ, --done 
                                                                                                    V_MSW_APPLN_REF_ID_X , 	--done 					--------- V_MSW_APPLN_REF_ID_X ,    
                                                                                                    V_MSW_VSL_CALL_ID_OUT,	--done 					
                                                                                                    LV_HNS_APP_TG(I).V_NTCE_N,                
                                                                                                    LV_HNS_APP_TG(I).V_MSW_VSL_ID_N,                               
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVOY_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT,
                                                                                                    LV_HNS_APP_TG(I).V_APPLCNT_ID_X,--'PENDING',
                                                                                                    LV_HNS_APP_TG(I).V_NTCECNTCT_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECO_M,                   
                                                                                                    DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1),  ---- V_SUBR_EMAIL_I
                                                                                                    LV_HNS_APP_TG(I).V_NTCEEMLADDR_X,
                                                                                                    DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''), '0'), 0, 0, 1), ---SUBR_SMS_I
                                                                                                    REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''),                  
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORT_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOTY_C,
                                                                                                    'APPROVED',
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    0,
                                                                                                    0,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION'   , ----THIS COL NOT CONTAINS THE NULL VALUES  'APPLICANT'                          
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    LV_HNS_APP_TG(I).V_NTCEINFRNGMNT,
                                                                                                    LV_HNS_APP_TG(I).V_INFRNGMNTACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFUSER,
                                                                                                    LV_HNS_APP_TG(I).V_INFPROCESS_DT,
                                                                                                    LV_HNS_APP_TG(I).V_INFREASON_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFREPORT_N
                                                                                                );  
                                                                
                                                                
                                                                
                                                                            EXCEPTION -- --BEGIN END FOR HNS_APPLICATION
                                                                            WHEN OTHERS THEN
                                                                            V_ERR_CODE := SQLCODE;
                                                                                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                V_SQLERRM := V_ERR_CODE
                                                                                             || V_ERR_MSG
                                                                                             || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                    PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                    NULL,
                                                                                                                                                                                    'T'                                                                                                                    
                                                                                                                                                                                    );
                                                                                                                                                                                    
                                                                                                                                                                                    
                                                                                                                                     v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                               CONTINUE; ----exception continue  
                                                                
                                                  END;-- --BEGIN END FOR HNS_APPLICATION
                                                  
                                                  /*
                                                      BEGIN --HNS_APPLICATION_SUBSTANCE
                                                                                                INSERT INTO HNS_APPLICATION_SUBSTANCE (
                                                                                                    HNS_APPLN_SUBST_ID_N,
                                                                                                    APPLN_REF_N,
                                                                                                    DELETED_I,
                                                                                                    SEQ_N,
                                                                                                    SUBST_C,
                                                                                                    SUBST_M,
                                                                                                    UN_N,
                                                                                                    POLLN_CAT_C,
                                                                                                    CGO_GRP_C,
                                                                                                    FLASH_PT_N,
                                                                                                    HZ_IBC_C,
                                                                                                    SUBST_QTY_Q,
                                                                                                    STW_ONBD_X,
                                                                                                    OPERN_C,
                                                                                                    LOCN_C,
                                                                                                    OPERN_DT,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    LOCK_VER_N,
                                                                                                    LOCN_M				
                                                                                                )
                                                                                                VALUES (
                                                                                                    LV_HNS_APPSUB_SEQ,
                                                                                                    LV_HNS_APP_SEQ,
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEUN_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESTWONBD,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                );
                                                                            
                                                                            
                                                                            
                                                                                               -- COMMIT;
                                                                                            EXCEPTION
                                                                                            WHEN OTHERS THEN
                                                                                            V_ERR_CODE := SQLCODE;
                                                                                            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                            V_SQLERRM := V_ERR_CODE
                                                                                                         || V_ERR_MSG
                                                                                                         || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                                        PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                                        'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
                                                                                                                                                                                                        'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
                                                                                                                                                                                                        'DELETED_I  :'||0||'<{||}>'||
                                                                                                                                                                                                        'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
                                                                                                                                                                                                        'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
                                                                                                                                                                                                        'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
                                                                                                                                                                                                        'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
                                                                                                                                                                                                        'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
                                                                                                                                                                                                        'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
                                                                                                                                                                                                        'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
                                                                                                                                                                                                        'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
                                                                                                                                                                                                        'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
                                                                                                                                                                                                        'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
                                                                                                                                                                                                        'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
                                                                                                                                                                                                        'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
                                                                                                                                                                                                        'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLCRTN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLCRTNBY_M||'<{||}>'||
                                                                                                                                                                                                        'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLUPDT_DT||'<{||}>'||
                                                                                                                                                                                                        'UPT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLUPDT_BY||'<{||}>'||
                                                                                                                                                                                                        'LOCK_VER_N  :'||0||'<{||}>'||
                                                                                                                                                                                                        'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                                                                                                        , 'T'
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                            
                                                                                                                               continue;  --exception continue  
                                                                            
                                                                            
                                                                                             END;--HNS_APPLICATION_SUBSTANCE



                                                  
                                                  */
                                                  
                                                     end if;
                                                             end if; --if  v_cnt_vsllcall <> 0 then
                                                                           
                                                               else  --  if   v_notice_id  = '0' or   v_notice_id <> LV_HNS_APP_TG(I).V_NTCE_N then
                                                                        BEGIN --HNS_APPLICATION_SUBSTANCE
                                                                                                 INSERT INTO HNS_APPLICATION_SUBSTANCE (
                                                                                                    HNS_APPLN_SUBST_ID_N,
                                                                                                    APPLN_REF_N,
                                                                                                    DELETED_I,
                                                                                                    SEQ_N,
                                                                                                    SUBST_C,
                                                                                                    SUBST_M,
                                                                                                    UN_N,
                                                                                                    POLLN_CAT_C,
                                                                                                    CGO_GRP_C,
                                                                                                    FLASH_PT_N,
                                                                                                    HZ_IBC_C,
                                                                                                    SUBST_QTY_Q,
                                                                                                    STW_ONBD_X,
                                                                                                    OPERN_C,
                                                                                                    LOCN_C,
                                                                                                    OPERN_DT,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    LOCK_VER_N,
                                                                                                    LOCN_M				
                                                                                                )
                                                                                                VALUES (
                                                                                                    LV_HNS_APPSUB_SEQ,
                                                                                                    LV_HNS_APP_SEQ,
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEUN_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESTWONBD,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                );
                                                                            
                                                                            
                                                                            
                                                                                               -- COMMIT;
                                                                                            EXCEPTION
                                                                                            WHEN OTHERS THEN
                                                                                            V_ERR_CODE := SQLCODE;
                                                                                            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                            V_SQLERRM := V_ERR_CODE
                                                                                                         || V_ERR_MSG
                                                                                                         || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                                        PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                                        'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
                                                                                                                                                                                                        'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
                                                                                                                                                                                                        'DELETED_I  :'||0||'<{||}>'||
                                                                                                                                                                                                        'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
                                                                                                                                                                                                        'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
                                                                                                                                                                                                        'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
                                                                                                                                                                                                        'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
                                                                                                                                                                                                        'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
                                                                                                                                                                                                        'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
                                                                                                                                                                                                        'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
                                                                                                                                                                                                        'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
                                                                                                                                                                                                        'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
                                                                                                                                                                                                        'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
                                                                                                                                                                                                        'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
                                                                                                                                                                                                        'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
                                                                                                                                                                                                        'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLCRTN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLCRTNBY_M||'<{||}>'||
                                                                                                                                                                                                        'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLUPDT_DT||'<{||}>'||
                                                                                                                                                                                                        'UPT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLUPDT_BY||'<{||}>'||
                                                                                                                                                                                                        'LOCK_VER_N  :'||0||'<{||}>'||
                                                                                                                                                                                                        'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                                                                                                        , 'T'
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                            
                                                                                                                               continue;  --exception continue  
                                                                            
                                                                            
                                                                                             END;--HNS_APPLICATION_SUBSTANCE ;-- hns appsub
                                                                  
                                           
                                                                end if;    --v_notice_id  = '0' or   v_notice_id <> LV_HNS_APP_TG(I).V_NTCE_N    
                             
                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                   
         ELSE   --LV_HNS_APP_TG(I).V_MSW_APPLN_REF_ID_X2  IS not  NULL THEN 
                           
                           
                                          V_MSW_APPLN_REF_ID_X := LV_HNS_APP_TG(I).V_MSW_APPLN_REF_ID_X2;

                                             
                              
                           -- insert the same into HNS_APPLICATION
                              
                                          if  v_notice_id <> LV_HNS_APP_TG(I).V_NTCE_N  or v_notice_id = 0 then 
      
      
      
                                                     BEGIN --BEGIN END FOR HNS_APPLICATI

                                                                              INSERT INTO HNS_APPLICATION (
                                                                                                    APPLN_REF_N,
                                                                                                    MSW_APPLN_REF_ID_X,
                                                                                                    VSL_CALL_ID_N,
                                                                                                    EXTL_APPLN_REF_ID_X,
                                                                                                    MSW_VSL_ID_N,
                                                                                                    VOY_N_X,
                                                                                                    ETA_DT,
                                                                                                    ETD_DT,
                                                                                                    APPLCNT_ID_X,
                                                                                                    CONT_PERS_M,
                                                                                                    CO_M,
                                                                                                    SUBR_EMAIL_I,
                                                                                                    EMAIL_X,
                                                                                                    SUBR_SMS_I,
                                                                                                    MOBILE_N,
                                                                                                    LST_PORT_CTRY_X,
                                                                                                    LAST_PORT_C,
                                                                                                    CFT_LIC_N,
                                                                                                    CGO_TY_C,
                                                                                                    APPLN_ST_C,
                                                                                                    PROCESSED_BY_X,
                                                                                                    PROCESSED_ON_DT,
                                                                                                    PROCESSING_REM_X,
                                                                                                    DELETED_I,
                                                                                                    LOCK_VER_N,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    INFRNGMNT_C,
                                                                                                    INFRNGMNT_ACTN_X,
                                                                                                    INFRNGMNT_USR_M,
                                                                                                    INFRNGMNT_PROCESS_DT,
                                                                                                    INFRNGMNT_PROCESS_RSN_X,
                                                                                                    INFRNGMNT_RPT_N
                                                                                                ) 
                                                                                        VALUES (
                                                                                                    LV_HNS_APP_SEQ, --done 
                                                                                                    V_MSW_APPLN_REF_ID_X , 	--done 					--------- V_MSW_APPLN_REF_ID_X ,    
                                                                                                    LV_HNS_APP_TG(I).v_VSL_CALL_ID_N,	--done 					
                                                                                                    LV_HNS_APP_TG(I).V_NTCE_N,                
                                                                                                    LV_HNS_APP_TG(I).V_MSW_VSL_ID_N,                               
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVOY_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT,
                                                                                                    LV_HNS_APP_TG(I).V_APPLCNT_ID_X,--'PENDING',
                                                                                                    LV_HNS_APP_TG(I).V_NTCECNTCT_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECO_M,                   
                                                                                                    DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1),  ---- V_SUBR_EMAIL_I
                                                                                                    LV_HNS_APP_TG(I).V_NTCEEMLADDR_X,
                                                                                                    DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''), '0'), 0, 0, 1), ---SUBR_SMS_I
                                                                                                    REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''),                  
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELSTPORT_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOTY_C,
                                                                                                    'APPROVED',
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    NULL,
                                                                                                    0,
                                                                                                    0,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION'   , ----THIS COL NOT CONTAINS THE NULL VALUES  'APPLICANT'                          
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    LV_HNS_APP_TG(I).V_NTCEINFRNGMNT,
                                                                                                    LV_HNS_APP_TG(I).V_INFRNGMNTACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFUSER,
                                                                                                    LV_HNS_APP_TG(I).V_INFPROCESS_DT,
                                                                                                    LV_HNS_APP_TG(I).V_INFREASON_X,
                                                                                                    LV_HNS_APP_TG(I).V_INFREPORT_N
                                                                                                );  
                                                                
                                                                
                                                                
                                                                            EXCEPTION -- --BEGIN END FOR HNS_APPLICATION
                                                                            WHEN OTHERS THEN
                                                                            V_ERR_CODE := SQLCODE;
                                                                                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                V_SQLERRM := V_ERR_CODE
                                                                                             || V_ERR_MSG
                                                                                             || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                    PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                    NULL,
                                                                                                                                                                                    'T'                                                                                                                    
                                                                                                                                                                                    );
                                                                                                                                                                                    
                                                                                                                                                                                     v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                
                                                                    CONTINUE; ----exception continue  
                                                                
                                                  END;-- --BEGIN END FOR HNS_APPLICATION
                                                  
                                      /*            
                                                     BEGIN --HNS_APPLICATION_SUBSTANCE
                                                                                                INSERT INTO HNS_APPLICATION_SUBSTANCE (
                                                                                                    HNS_APPLN_SUBST_ID_N,
                                                                                                    APPLN_REF_N,
                                                                                                    DELETED_I,
                                                                                                    SEQ_N,
                                                                                                    SUBST_C,
                                                                                                    SUBST_M,
                                                                                                    UN_N,
                                                                                                    POLLN_CAT_C,
                                                                                                    CGO_GRP_C,
                                                                                                    FLASH_PT_N,
                                                                                                    HZ_IBC_C,
                                                                                                    SUBST_QTY_Q,
                                                                                                    STW_ONBD_X,
                                                                                                    OPERN_C,
                                                                                                    LOCN_C,
                                                                                                    OPERN_DT,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    LOCK_VER_N,
                                                                                                    LOCN_M				
                                                                                                )
                                                                                                VALUES (
                                                                                                    LV_HNS_APPSUB_SEQ,
                                                                                                    LV_HNS_APP_SEQ,
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEUN_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESTWONBD,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                );
                                                                            
                                                                            
                                                                            
                                                                                               -- COMMIT;
                                                                                            EXCEPTION
                                                                                            WHEN OTHERS THEN
                                                                                            V_ERR_CODE := SQLCODE;
                                                                                            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                            V_SQLERRM := V_ERR_CODE
                                                                                                         || V_ERR_MSG
                                                                                                         || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                                        PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                                        'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
                                                                                                                                                                                                        'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
                                                                                                                                                                                                        'DELETED_I  :'||0||'<{||}>'||
                                                                                                                                                                                                        'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
                                                                                                                                                                                                        'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
                                                                                                                                                                                                        'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
                                                                                                                                                                                                        'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
                                                                                                                                                                                                        'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
                                                                                                                                                                                                        'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
                                                                                                                                                                                                        'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
                                                                                                                                                                                                        'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
                                                                                                                                                                                                        'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
                                                                                                                                                                                                        'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
                                                                                                                                                                                                        'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
                                                                                                                                                                                                        'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
                                                                                                                                                                                                        'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLCRTN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLCRTNBY_M||'<{||}>'||
                                                                                                                                                                                                        'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLUPDT_DT||'<{||}>'||
                                                                                                                                                                                                        'UPT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLUPDT_BY||'<{||}>'||
                                                                                                                                                                                                        'LOCK_VER_N  :'||0||'<{||}>'||
                                                                                                                                                                                                        'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                                                                                                        , 'T'
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                            
                                                                                                                               continue;  --exception continue  
                                                                            
                                                                            
                                                                                             END;--HNS_APPLICATION_SUBSTANCE

                                                  */
                                                 
                                                 
                                                 
                                                 
                                                 
                                                 
                                                 
                                                  else
                                                  
                                                         BEGIN --HNS_APPLICATION_SUBSTANCE
                                                                                                INSERT INTO HNS_APPLICATION_SUBSTANCE (
                                                                                                    HNS_APPLN_SUBST_ID_N,
                                                                                                    APPLN_REF_N,
                                                                                                    DELETED_I,
                                                                                                    SEQ_N,
                                                                                                    SUBST_C,
                                                                                                    SUBST_M,
                                                                                                    UN_N,
                                                                                                    POLLN_CAT_C,
                                                                                                    CGO_GRP_C,
                                                                                                    FLASH_PT_N,
                                                                                                    HZ_IBC_C,
                                                                                                    SUBST_QTY_Q,
                                                                                                    STW_ONBD_X,
                                                                                                    OPERN_C,
                                                                                                    LOCN_C,
                                                                                                    OPERN_DT,
                                                                                                    CRT_ON_DT,
                                                                                                    CRT_BY_X,
                                                                                                    UPT_ON_DT,
                                                                                                    UPT_BY_X,
                                                                                                    LOCK_VER_N,
                                                                                                    LOCN_M				
                                                                                                )
                                                                                                VALUES (
                                                                                                    LV_HNS_APPSUB_SEQ,
                                                                                                    LV_HNS_APP_SEQ,
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESUBST_M,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEUN_N,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                                                                                                    LV_HNS_APP_TG(I).V_NTCESTWONBD,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEACTN_X,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_C,
                                                                                                    LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    sysdate,
                                                                                                    'DATA MIGRATION',
                                                                                                    0,
                                                                                                    LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                );
                                                                            
                                                                            
                                                                            
                                                                                               -- COMMIT;
                                                                                            EXCEPTION
                                                                                            WHEN OTHERS THEN
                                                                                            V_ERR_CODE := SQLCODE;
                                                                                            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                                                                                            V_SQLERRM := V_ERR_CODE
                                                                                                         || V_ERR_MSG
                                                                                                         || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                                                                            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL_VSLCALL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                                                                                                        PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                                                                                                        'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
                                                                                                                                                                                                        'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
                                                                                                                                                                                                        'DELETED_I  :'||0||'<{||}>'||
                                                                                                                                                                                                        'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
                                                                                                                                                                                                        'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
                                                                                                                                                                                                        'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
                                                                                                                                                                                                        'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
                                                                                                                                                                                                        'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
                                                                                                                                                                                                        'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
                                                                                                                                                                                                        'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
                                                                                                                                                                                                        'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
                                                                                                                                                                                                        'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
                                                                                                                                                                                                        'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
                                                                                                                                                                                                        'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
                                                                                                                                                                                                        'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
                                                                                                                                                                                                        'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
                                                                                                                                                                                                        'CRT_ON_DT  :'||sysdate||'<{||}>'||
                                                                                                                                                                                                        'CRT_BY_X  :'||'DATA MIGRATION'||'<{||}>'||
                                                                                                                                                                                                        'UPT_ON_DT  :'||sysdate||'<{||}>'||
                                                                                                                                                                                                        'UPT_BY_X  :'||'DATA MIGRATION'||'<{||}>'||
                                                                                                                                                                                                        'LOCK_VER_N  :'||0||'<{||}>'||
                                                                                                                                                                                                        'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                                                                                                        , 'T'
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
                                                                            
                                                                                                                               continue;  --exception continue  
                                                                            
                                                                            
                                                                                             END;--HNS_APPLICATION_SUBSTANCE

                                end if;--if  v_noticeid <> LV_HNS_APP_TG(I).V_NTCE_N  or v_noticeid = 0 then      
           
               end if; --LV_HNS_APP_TG(I).V_MSW_APPLN_REF_ID_X2  IS not  NULL THEN
                    
                         v_notice_id :=  LV_HNS_APP_TG(I).V_NTCE_N ;
             
       end loop;  -- for end loop
              
    end loop ;-- cursor loop
    
    
     close CUR_HNSAP2; 
     
     SELECT COUNT(*)INTO V_ST_COUNT FROM ST_HN_NTCEHDR;
     
    select count(distinct(NTCE_N)) into V_SRC_COUNT from SI_HNS_APP;
     
     pkg_datamigration_generic.proc_migration_recon('ST_HN_NTCEHDR', V_ST_COUNT, 'DSTINT NTCE_N SI_HNS_APP', V_SRC_COUNT, 'Y');   

    
     ---TAGGED----
     
     
select 

count(*)

into V_ST_COUNT


from 


(
select d.ntce_n,d.NTCEVSLESTARR_DT,d.VSLRPTARR_DT , d.VSLRPTDEP_DT,d.VSLRECID_N, d.VSLMVID_N,d.VSLRPTETA_DT,d.VSLRPTETD_DT,d.myrank

from 


(
select c.ntce_n,c.NTCEVSLESTARR_DT,c.VSLRPTARR_DT , c.VSLRPTDEP_DT, c.VSLRECID_N,c.VSLMVID_N,c.VSLRPTETA_DT,c.VSLRPTETD_DT,RANK() OVER (PARTITION BY c.ntce_n ORDER BY c.VSLMVID_N) AS myrank


from 

(
select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, 
     st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT
AND b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT



union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and a.NTCEVSLESTARR_DT between  b.VSLRPTARR_DT and b.VSLRPTDEP_DT 
AND a.NTCEVSLESTDEP_DT between b.VSLRPTARR_DT and b.VSLRPTDEP_DT 

) c

order by c.ntce_n 
)d

where d. myrank = 1
)tag , 
     SI_HNS_APP  SI,
     SI_AS_VC_VR  SI2

where si.NTCE_N = tag.NTCE_N
and SI.	NTCE_N = SI2.EXTL_APPLN_REF_ID_X(+)
AND SI.MSW_VSL_ID_N   = SI2.MSW_VSL_ID_N(+)
--and si.ntce_n in ('2006098551','2007039756')
--and si.ntce_n in ('2006098551','2007039756','2014090162')
ORDER BY si.NTCE_N,SI.CRTN_DT ;   


V_ST_COUNT2 := V_ST_COUNT;

--------------COUNT OF INTERMEDIATE TABLE


    SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM HNS_APPLICATION;



 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT ||' rows have been inserted into HNS_APPLICATION table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;



/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 
 pkg_datamigration_generic.proc_migration_recon('SECOND_SI_QUERY_TAGGED_CNT', V_ST_COUNT, 'HNS_APPLICATION', V_SRC_COUNT, 'N');   
 
 
 
 
     
select 

count(distinct(tag.ntce_n))

into V_ST_COUNT


from 


(
select d.ntce_n,d.NTCEVSLESTARR_DT,d.VSLRPTARR_DT , d.VSLRPTDEP_DT,d.VSLRECID_N, d.VSLMVID_N,d.VSLRPTETA_DT,d.VSLRPTETD_DT,d.myrank

from 


(
select c.ntce_n,c.NTCEVSLESTARR_DT,c.VSLRPTARR_DT , c.VSLRPTDEP_DT, c.VSLRECID_N,c.VSLMVID_N,c.VSLRPTETA_DT,c.VSLRPTETD_DT,RANK() OVER (PARTITION BY c.ntce_n ORDER BY c.VSLMVID_N) AS myrank


from 

(
select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, 
     st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT
AND b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT



union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and a.NTCEVSLESTARR_DT between  b.VSLRPTARR_DT and b.VSLRPTDEP_DT 
AND a.NTCEVSLESTDEP_DT between b.VSLRPTARR_DT and b.VSLRPTDEP_DT 

) c

order by c.ntce_n 
)d

where d. myrank = 1
)tag , 
     SI_HNS_APP  SI,
     SI_AS_VC_VR  SI2

where si.NTCE_N = tag.NTCE_N
and SI.	NTCE_N = SI2.EXTL_APPLN_REF_ID_X(+)
AND SI.MSW_VSL_ID_N   = SI2.MSW_VSL_ID_N(+)
--and si.ntce_n in ('2006098551','2007039756')
--and si.ntce_n in ('2006098551','2007039756','2014090162')
ORDER BY si.NTCE_N,SI.CRTN_DT ;   


    SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM HNS_APPLICATION;
    
 
 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT ||' rows have been inserted into HNS_APPLICATION table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;



/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 
 pkg_datamigration_generic.proc_migration_recon('DISTINCT_TAGGED_RECORDS', V_ST_COUNT, 'HNS_APPLICATION', V_SRC_COUNT, 'N');   
 
 
 
 
 
 
 
 
 
--------------COUNT OF INTERMEDIATE TABLE


    SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM HNS_APPLICATION_SUBSTANCE;



 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT2 ) AND V_ST_COUNT2 <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT2 ||' ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT2 AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT2 ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT2 OR  V_SRC_COUNT  = V_ST_COUNT2 ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT2||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT2 ||' rows have been inserted into HNS_APPLICATION_SUBSTANCE table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;



/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 
 pkg_datamigration_generic.proc_migration_recon('SECOND_SI_QUERY_TAGGED_CNT', V_ST_COUNT2, 'HNS_APPLICATION_SUBSTANCE', V_SRC_COUNT, 'N');   
 

 
 ----------------
 
 
    SELECT COUNT(*)
	INTO V_ST_COUNT
    FROM ST_HN_NTCEHDR;
 
 

     SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM HNS_APPLICATION;

 
 
 
 
 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT ||' rows have been inserted into HNS_APPLICATION table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;



/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 
 pkg_datamigration_generic.proc_migration_recon('ST_HN_NTCEHDR', V_ST_COUNT, 'HNS_APPLICATION', V_SRC_COUNT, 'Y');  
 
 

 
 
 ------------------------------------
 
 
    SELECT COUNT(*)
	INTO V_ST_COUNT
    FROM ST_HN_NTCEHDR;
    

 
     SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM HNS_APPLICATION_SUBSTANCE;
 
 
  
 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

              else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL_VSLCALL', 
 V_SRC_COUNT ||' out of ' ||V_ST_COUNT ||' rows have been inserted into HNS_APPLICATION_SUBSTANCE table' ,
        'AMBIGIOUS',null,null,null,null);

    END IF;
    
    
     pkg_datamigration_generic.proc_migration_recon('ST_HN_NTCEHDR', V_ST_COUNT, 'HNS_APPLICATION_SUBSTANCE', V_SRC_COUNT, 'Y'); 
    
  ------------------
  
  
  --untagged
 
 insert into  SI_HNS_APP_UNTAGGED  

select * from SI_HNS_APP where ntce_n in (
(
select NTCE_N  

from SI_HNS_APP

minus 

select d.ntce_n

from 
(
select c.ntce_n, c.VSLRECID_N,RANK() OVER (PARTITION BY c.ntce_n ORDER BY c.VSLMVID_N) AS myrank


from 

(
select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, 
     st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT

union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT,b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and b.VSLRPTDEP_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT
AND b.VSLRPTARR_DT between a.NTCEVSLESTARR_DT and a.NTCEVSLESTDEP_DT



union 

select a.ntce_n,a.NTCEVSLESTARR_DT,b.VSLRPTARR_DT , b.VSLRPTDEP_DT, b.VSLMVID_N,b.VSLRECID_N,b.VSLRPTETA_DT,b.VSLRPTETD_DT
from st_hn_ntcehdr a, st_ptms_vslcall b
where a.NTCEVSLRECID_N = b.vslrecid_n
and a.NTCEVSLESTARR_DT between  b.VSLRPTARR_DT and b.VSLRPTDEP_DT 
AND a.NTCEVSLESTDEP_DT between b.VSLRPTARR_DT and b.VSLRPTDEP_DT 

) c
)d

where d.myrank = 1

)

);


 --Recon of untagged
 
     SELECT COUNT(*)
	INTO V_ST_COUNT
    FROM ST_HN_NTCEHDR;
 
 
select count(distinct(NTCE_N)) into V_SRC_COUNT from SI_HNS_APP_UNTAGGED;


    pkg_datamigration_generic.proc_migration_recon('ST_HN_NTCEHDR', V_ST_COUNT, 'DISTINCT_NTCEID_UNTAGGED', V_SRC_COUNT, 'Y'); 

end ;   -- outer begin
/