create or replace PROCEDURE PROC_1_PSA (pv_run_id in  number )IS
    
    
    
    cursor cr_pan1_shp is
     
    SELECT 
              
                pan3.APPLN_REF_N,
                pan1.seq_n,
                pan1.arr_dt,
                pan1.dep_dt,
                pan1.locn_x,
                pan1.locnLat,
                pan1.locnLong,		
                pan1.shpToShpAct,
                pan2.addMeasures,
                pan1.userId_n,
                pan1.TIMESTAMP_DT ,	
                pan1.pansid_n
                from 
                
                ST_PANS_last10ShpToShpActFrMRLog pan1 , 
                ST_PANS_last10ShpToShpSecFrMRLog pan2 ,
                pan_application pan3
               
                where 
                pan1.PANSID_N = pan2.PANSID_N 
                and pan1.PANSID_N= pan3.EXTL_APPLN_REF_ID_X;


    ------ defining the 'record type'  type to serve as the datatype of collection variable  of main table (csv loaded table )--



            v_dr_st_count           number;
            V_TGT_CNT             INTEGER;
            V_M_SRC_CNT              INTEGER;
            v_tgt_count             INTEGER;
            v_err_code              NUMBER;
            v_err_msg               VARCHAR2(200);
            v_sqlerrm               VARCHAR2(2500);
            v_blkexptn_count        NUMBER(20, 0);
            v_blkexptn_desc         VARCHAR2(3000);
            v_exp_rows              VARCHAR2(1000);
            v_exp_rows1             VARCHAR2(1000);
            v_exp_rows2             VARCHAR2(1000);
            v_exp_rows3             VARCHAR2(1000);
            v_exp_rows4             VARCHAR2(1000);
            v_exp_rows5             VARCHAR2(1000);
            v_exp_rows6             VARCHAR2(1000);
            v_exp_rows7             VARCHAR2(1000);
            v_exp_rows8             VARCHAR2(1000);
            v_exp_rows9             VARCHAR2(1000);
            v_exp_rows10            VARCHAR2(1000);
            v_exp_rows11            VARCHAR2(1000);

            i_excep_cnt_tgt   number := 0;
            i_excep_cnt_si   number := 0;

     ----       lv_SEQ_PAN_SHP_ACT  PAN_SHIP_ACTIVITY.PAN_SHIP_ACT_ID_N%type;




    /************************************************************************************************************************************
                procedure name : PROC_PAN_SHIP_ACTIVITY
                Created By     : V. R. Yembarwar
                Date           : 17-APR-2019
                Purpose        : Inserting  the data from "ST_PANS_last10ShpToShpActFrMRLog",
                                 "ST_PANS_last10ShpToShpSecFrMRLog"  to "SI_PAN_SHIP_ACTIVITY" to            
                                 Target table "PAN_SHIP_ACTIVITY".
                Modified by    : C.N.Bhaskar
                Modified date  :9-aug-2019
    *********************************************************************************************************************************************/

    cursor pan2_shp is

     SELECT 

        applnRef_n,
        seq_n ,
        arr_dt,
        dep_dt,
        locn_x,
        locnLat,
        locnLong,	
        shpToShpAct,
        addMeasures,
        userId_n,
        timeStamp_dt,
        pansid_n

        from 

        SI_PAN_SHIP_ACTIVITY  ;


        TYPE rec_pan_shpct1 IS RECORD (

                v_applnRef_n   	SI_PAN_SHIP_ACTIVITY.applnRef_n%TYPE,
                v_seq_n 		SI_PAN_SHIP_ACTIVITY.seq_n%TYPE,
                v_arr_dt        SI_PAN_SHIP_ACTIVITY.arr_dt%TYPE,
                v_dep_dt        SI_PAN_SHIP_ACTIVITY.dep_dt%TYPE,
                v_locn_x        SI_PAN_SHIP_ACTIVITY.locn_x%TYPE,
                v_locnLat       SI_PAN_SHIP_ACTIVITY.locnLat%TYPE,
                v_locnLong		SI_PAN_SHIP_ACTIVITY.locnLong%TYPE,
                v_shpToShpAct	SI_PAN_SHIP_ACTIVITY.shpToShpAct%TYPE,
                v_addMeasures	SI_PAN_SHIP_ACTIVITY.addMeasures%TYPE,
                v_userId_n		SI_PAN_SHIP_ACTIVITY.userId_n%TYPE,
                v_timeStamp_dt  SI_PAN_SHIP_ACTIVITY.timeStamp_dt%TYPE,
                 v_pansid_n     SI_PAN_SHIP_ACTIVITY.pansid_n%TYPE

        );

        TYPE type_pan_ship_act1  IS Table of rec_pan_shpct1;

        lv_pan_act_tg     	type_pan_ship_act1;

            lv_SEQ_PAN_SHP_ACT   PAN_SHIP_ACTIVITY.PAN_SHIP_ACT_ID_N%type;
            v_LATD_DIRCN_C       char(2);
            v_LONGD_DIRCN_C      char(2);
            lv_data_dump         CLOB;
            v_applnRef_n         VARCHAR2(100);
            v_poc                PAN_SHIP_ACTIVITY%rowtype;  



    BEGIN    

	execute immediate 'truncate table SI_PAN_SHIP_ACTIVITY';

    ------------------insertion in si panship activity-------------


        pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 'SI_PAN_SHIP_ACTIVITY', 'START',pv_run_id,null,null,'T');


       FOR  i IN cr_pan1_shp  loop

        begin


        INSERT INTO SI_PAN_SHIP_ACTIVITY 
                (   
                applnRef_n,
                seq_n,
                arr_dt,
                dep_dt,
                locn_x,
                locnLat,
                locnLong,		
                shpToShpAct,
                addMeasures,
                userId_n,
                TIMESTAMP_DT,
                pansid_n
                )	
        values
                (
                i.APPLN_REF_N ,  
                i.seq_n ,
                i.arr_dt       ,
                i.dep_dt        ,
                i.locn_x       ,
                i.locnLat       ,
                i.locnLong,
                i.shpToShpAct,
                i.addMeasures,
                i.userId_n,
                i.TIMESTAMP_DT,
                i.pansid_n

               );

       EXCEPTION
            WHEN OTHERS THEN
               	V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
				V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                i_excep_cnt_si := i_excep_cnt_si +1;  
                if i_excep_cnt_si  < 50000  then 

             pkg_datamigration_generic.proc_trace_exception('SI_PAN_SHIP_ACTIVITY', 
                                                            'proc_1_PSA', 
                                                            'applnRef_n:'||i.APPLN_REF_N ||'<{||}>'||
							                                'seq_n:'||i.seq_n ||'<{||}>'||
							                                'arr_dt:' || i.arr_dt ||'<{||}>'||
							                                'dep_dt:'||i.dep_dt  ||'<{||}>'||
                                                            'locn_x:'||i.locn_x ||'<{||}>'||
							                                'locnLat:'||i.locnLat  ||'<{||}>'||
                                                            'locnLong:'||i.locnLong ||'<{||}>'||
                                                            'shpToShpAct:' ||i.shpToShpAct||'<{||}>'||
                                                            'addMeasures:' ||i.addMeasures ||'<{||}>'||
                                                            'userId_n:' ||i.userId_n||'<{||}>'||
                                                            'TIMESTAMP_DT:' ||i.TIMESTAMP_DT||'<{||}>'||
                                                            'pansid_n:' ||i.pansid_n ,
							                                'ERROR',

						                                  	PV_RUN_ID,

							                                V_SQLERRM,

                                                            i.APPLN_REF_N ||'<{||}>'||
							                                i.seq_n ||'<{||}>'||
							                                i.arr_dt ||'<{||}>'||
							                                i.dep_dt  ||'<{||}>'||
                                                            i.locn_x ||'<{||}>'||
							                                i.locnLat  ||'<{||}>'||
                                                            i.locnLong ||'<{||}>'||
                                                            i.shpToShpAct||'<{||}>'||
                                                            i.addMeasures ||'<{||}>'||
                                                            i.userId_n||'<{||}>'||
                                                            i.TIMESTAMP_DT||'<{||}>'||
                                                            i.pansid_n  ,

							                                'T'
                                                            );

     end if;



        END; 
      END LOOP;           
    COMMIT; 






    /**************************************************************************************************************
    INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
    *************************************************************************************************************/  

     open  pan2_shp;

          pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA','PAN_SHIP_ACTIVITY' , 'START',PV_RUN_ID,NULL,NULL,'T');

    LOOP    --CURSOR LOOP

      BEGIN

        -- lv_SEQ_PAN_SHP_ACT:= SEQ_PAN_SHP_ACT.NEXTVAL;

         FETCH pan2_shp BULK COLLECT INTO lv_pan_act_tg  LIMIT 3000;
         EXIT WHEN lv_pan_act_tg.count = 0;	
         FOR i IN lv_pan_act_tg.first..lv_pan_act_tg .last 

         LOOP            --for loop 
           BEGIN	

      /*   
                select DECODE(trim(lv_pan_act_tg(i).v_locnLat) ,'N','NORTH','S','SOUTH')
                  into v_LATD_DIRCN_C from dual ;


                 select DECODE(trim(lv_pan_act_tg(i).v_locn_x) ,'E','EAST','W','WEST')
                  into v_LONGD_DIRCN_C from dual;

    -------------------------------json

                v_poc.APPLN_REF_N:= lv_pan_act_tg(i).v_applnRef_n;
                v_poc.SEQ_N:= lv_pan_act_tg(i).v_seq_n ;
                v_poc.ACT_FR_D:= lv_pan_act_tg(i).v_arr_dt;
                v_poc.ACT_TILL_D:=  lv_pan_act_tg(i).v_dep_dt;
                v_poc.SHP_LOCN_X:= lv_pan_act_tg(i).v_locn_x;
                v_poc.LOCN_LAT_N:=  lv_pan_act_tg(i).v_locnLat;
                v_poc.LOCN_LONG_N:= lv_pan_act_tg(i).v_locnLong;
                v_poc.SHP_ACT_X:=  lv_pan_act_tg(i).v_shpToShpAct;
                v_poc.SECU_MSR_X:= lv_pan_act_tg(i).v_addMeasures;
                v_poc.CRT_ON_DT:= lv_pan_act_tg(i).v_timeStamp_dt;
                v_poc.CRT_BY_N:= lv_pan_act_tg(i).v_userId_n;
                v_poc.LATD_DIRCN_C:= v_LATD_DIRCN_C;
                v_poc.LONGD_DIRCN_C:= v_LONGD_DIRCN_C;


    -------------------------------------

         lv_data_dump := FNC_JSON_VAL_PAN( v_applnRef_n); 

      --------------------   
    */


          INSERT INTO  PAN_SHIP_ACTIVITY
                  (    
                          PAN_SHIP_ACT_ID_N,
                            APPLN_REF_N,
                            SEQ_N,
                            ACT_FR_D,
                            ACT_TILL_D,
                            SHP_LOCN_X,
                            LOCN_LAT_N,
                            LOCN_LONG_N,
                            SHP_ACT_X,
                            SECU_MSR_X,
                            LATD_DIRCN_C,
                            LONGD_DIRCN_C,
                            DELETED_I,
                            LOCK_VER_N,
                            CRT_ON_DT,
                            CRT_BY_N,
                            LAST_UPTIMESTAMPD_BY_N,
                            LAST_UPTIMESTAMPD_ON_DT

                            )
           VALUES
            (
             SEQ_PAN_SHP_ACT.NEXTVAL,	
             lv_pan_act_tg(i).v_applnRef_n ,	
             lv_pan_act_tg(i).v_seq_n,	
             lv_pan_act_tg(i).v_arr_dt,	
             lv_pan_act_tg(i).v_dep_dt,	
             lv_pan_act_tg(i).v_locn_x,	
             lv_pan_act_tg(i).v_locnLat,	
             lv_pan_act_tg(i).v_locnLong,	
             lv_pan_act_tg(i).v_shpToShpAct,	
             lv_pan_act_tg(i).v_addMeasures,	
             DECODE(trim(lv_pan_act_tg(i).v_locnLat) ,'N','NORTH','S','SOUTH'),	
             DECODE(trim(lv_pan_act_tg(i).v_locn_x) ,'E','EAST','W','WEST')	,
                           0,	
                           0,	
                      sysdate,	
                     'DATA MIGRATION',	
                     'DATA MIGRATION',	
                      sysdate

             );

    /***********************************************************************************
    EXCEPTION HANDLING
    **************************************************************************************/
      EXCEPTION         ---inner block

                  WHEN OTHERS THEN
               	V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
				V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                i_excep_cnt_tgt := i_excep_cnt_tgt +1;

                     if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 
                                                            'proc_1_PSA', 
                                                            'PAN_SHIP_ACT_ID_N:' ||	 SEQ_PAN_SHP_ACT.currval   ||'<{||}>'||
                                                            'APPLN_REF_N:' ||lv_pan_act_tg(i).v_applnRef_n  ||'<{||}>'||
                                                            'SEQ_N:' ||lv_pan_act_tg(i).v_seq_n ||'<{||}>'||
                                                            'ACT_FR_D:' || lv_pan_act_tg(i).v_arr_dt  ||'<{||}>'||
                                                            'ACT_TILL_D:' || lv_pan_act_tg(i).v_dep_dt  ||'<{||}>'||
                                                            'SHP_LOCN_X:' || lv_pan_act_tg(i).v_locn_x ||'<{||}>'||
                                                            'LOCN_LAT_N:' ||lv_pan_act_tg(i).v_locnLat  ||'<{||}>'||
                                                            'LOCN_LONG_N:' ||lv_pan_act_tg(i).v_locnLong  ||'<{||}>'||
                                                            'SHP_ACT_X:' ||	lv_pan_act_tg(i).v_shpToShpAct  ||'<{||}>'||
                                                            'SECU_MSR_X:' ||lv_pan_act_tg(i).v_addMeasures  ||'<{||}>'||
                                                            'LATD_DIRCN_C:' ||lv_pan_act_tg(i).v_locnLat ||'<{||}>'||
                                                            'LONGD_DIRCN_C:' ||	lv_pan_act_tg(i).v_locn_x  ||'<{||}>'||
                                                            'DELETED_I:' ||	  0 ||'<{||}>'||
                                                            'LOCK_VER_N:' ||  0  ||'<{||}>'||
                                                            'CRT_ON_DT:' ||sysdate  ||'<{||}>'||
                                                            'CRT_BY_N:' || 'DATA MIGRATION' ||'<{||}>'||
                                                            'LAST_UPTIMESTAMPD_BY_N:' || 'DATA MIGRATION'  ||'<{||}>'||
                                                            'LAST_UPTIMESTAMPD_ON_DT:' ||sysdate,

							                                'ERROR',

						                                  	PV_RUN_ID,

							                                V_SQLERRM,

                                                             SEQ_PAN_SHP_ACT.currval   ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_applnRef_n  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_seq_n ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_arr_dt  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_dep_dt  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_locn_x ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_locnLat  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_locnLong  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_shpToShpAct  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_addMeasures  ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_locnLat ||'<{||}>'||
                                                            lv_pan_act_tg(i).v_locn_x  ||'<{||}>'||
                                                            0 ||'<{||}>'||
                                                            0  ||'<{||}>'||
                                                            sysdate  ||'<{||}>'||
                                                            'DATA MIGRATION' ||'<{||}>'||
                                                            'DATA MIGRATION' ||'<{||}>'||
                                                            sysdate,


							                                'T'
                                                            );


  end if;

         end;

        END LOOP;
     commit;
       END;

      END LOOP;





    -----------------------recon logic for si table--------------


    select count(*)
     into  v_dr_st_count 
     from ST_PANS_last10ShpToShpActFrMRLog;      ----count of driving table



    select COUNT(*)
          INTO  V_M_SRC_CNT
           from 
                ST_PANS_last10ShpToShpActFrMRLog pan1 ,
                ST_PANS_last10ShpToShpSecFrMRLog pan2 ,
                pan_application pan3                                      ------      COUNT OF SORCE TABLE
                where 
                pan1.PANSID_N = pan2.PANSID_N 
                and pan1.PANSID_N= pan3.EXTL_APPLN_REF_ID_X;




    SELECT COUNT(*)
                INTO V_TGT_CNT                         --COUNT OF INTERMEDIATE TABLE
                FROM SI_PAN_SHIP_ACTIVITY; 



     if( V_M_SRC_CNT =  V_TGT_CNT ) and V_TGT_CNT <>  0  and  V_M_SRC_CNT <> 0 then     ----condition for trace migration table

             pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
            V_TGT_CNT||' out of ' || V_M_SRC_CNT ||' rows  have been inserted into SI_PAN_SHIP_ACTIVITY' ,
            'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

     elsif  V_M_SRC_CNT  <> V_TGT_CNT and  V_M_SRC_CNT <> 0 then 

           pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
            V_TGT_CNT ||' out of ' ||V_M_SRC_CNT||' rows have been inserted into SI_PAN_SHIP_ACTIVITY' ,
            'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


     elsif ( V_M_SRC_CNT  <>V_TGT_CNT or  V_M_SRC_CNT  = V_TGT_CNT) and ( V_M_SRC_CNT = 0) then 

            pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
             V_TGT_CNT ||' out of ' ||V_M_SRC_CNT||' rows have been inserted into SI_PAN_SHIP_ACTIVITY table' ,
            'FAIL',PV_RUN_ID,NULL,NULL,'T');

        END IF;


    -----recon for target table----




      pkg_datamigration_generic.proc_migration_recon('QUERY_CNT',V_M_SRC_CNT, 'SI_PAN_SHIP_ACTIVITY',V_TGT_CNT ,'N'); 






    --------------------------------------------------------------------------------------------------------------------------------------------------------------




    SELECT COUNT(*)
                INTO V_M_SRC_CNT                         --COUNT OF INTERMEDIATE TABLE
                FROM SI_PAN_SHIP_ACTIVITY; 




               SELECT COUNT(*)
                INTO V_TGT_COUNT                        --COUNT OF TARGET TABLE
                FROM PAN_SHIP_ACTIVITY; 


     if( V_TGT_COUNT =  V_M_SRC_CNT ) and  V_M_SRC_CNT  <>  0  and  V_TGT_COUNT <> 0 then     ----condition for migration table

             pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
             V_TGT_COUNT ||' out of ' ||  V_M_SRC_CNT  ||' rows  have been inserted into PAN_SHIP_ACTIVITY' ,
            'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

     elsif  V_TGT_COUNT  <> V_M_SRC_CNT and  V_TGT_COUNT  <> 0 then 

           pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
            V_TGT_COUNT ||' out of ' ||V_M_SRC_CNT||' rows have been inserted into PAN_SHIP_ACTIVITY' ,
            'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


     elsif (V_TGT_COUNT  <> V_M_SRC_CNT or V_TGT_COUNT  = V_M_SRC_CNT) and ( V_M_SRC_CNT = 0) then 

            pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', 
              V_TGT_COUNT ||' out of ' ||V_M_SRC_CNT||' rows have been inserted into PAN_SHIP_ACTIVITY table' ,
            'FAIL',PV_RUN_ID,NULL,NULL,'T');

        END IF;



    ----recon logic



         pkg_datamigration_generic.proc_migration_recon ( 'SI_PAN_SHIP_ACTIVITY', V_M_SRC_CNT, 'PAN_SHIP_ACTIVITY',V_TGT_COUNT,'N');

        pkg_datamigration_generic.proc_migration_recon ( 'ST_PANS_last10ShpToShpActFrMRLog',v_dr_st_count, 'PAN_SHIP_ACTIVITY', v_tgt_count, 'Y');


    -----outer exception----------









       /******************buisness error starts ***************************/

    --------uncommon records from staging and intemediate table-----
/*

     begin
     for i in
     (select pan1.* from 
          ST_PANS_last10ShpToShpActFrMRLog pan1
      where pan1.PANSID_N not in
       (select pansid_n from si_pan_ship_activity))

     loop

     pkg_datamigration_generic.proc_trace_exception('SI_PAN_SHIP_ACTIVITY', 'proc_1_PSA','Uncommon records from ST_PANS_last10ShpToShpActFrMRLog',
                                                                   null,PV_RUN_ID,null, 
                                                                    'VSLRECID_N:'||	i.VSLRECID_N	||'<{||}>'||
                                                                    'PANSID_N:'	||	i.PANSID_N	||'<{||}>'||
                                                                    'LOCNLAT:'	||	i.LOCNLAT	||'<{||}>'||
                                                                    'LOCNLONG:'	||	i.LOCNLONG	||'<{||}>'||
                                                                    'SHPTOSHPACT:'	||	i.SHPTOSHPACT	||'<{||}>'||
                                                                    'ARR_DT:'	||	i.ARR_DT	||'<{||}>'||
                                                                    'DEP_DT:'	||	i.DEP_DT	||'<{||}>'||
                                                                    'SEQ_N:'	||	i.SEQ_N	||'<{||}>'||
                                                                    'USERID_N:'	||	i.USERID_N	||'<{||}>'||
                                                                    'TIMESTAMP_DT:'	||	i.TIMESTAMP_DT	||'<{||}>'||
                                                                    'LOCN_X:'	||	i.LOCN_X,
                                                                    'B');


    end loop;

    -------------uncommon records ST_PANS_LAST10SHPTOSHPSECFRMRLOG---

     for j in
     (
        select pan2.* from 
           ST_PANS_LAST10SHPTOSHPSECFRMRLOG pan2
             where pan2.PANSID_N not in
       (select pansid_n from si_pan_ship_activity))

     loop

     pkg_datamigration_generic.proc_trace_exception('SI_PAN_SHIP_ACTIVITY', 'proc_1_PSA','Uncommon Records from ST_PANS_LAST10SHPTOSHPSECFRMRLOG',
                                                                   null,PV_RUN_ID,null, 
                                                                     'VSLRECID_N:'||j.VSLRECID_N||'<{||}>'||
                                                                    'PANSID_N:'  ||j.PANSID_N||'<{||}>'||
                                                                    'ADDMEASURES:'||j.ADDMEASURES||'<{||}>'||
                                                                    'SHPTOSHPACT:'||j.SHPTOSHPACT||'<{||}>'||
                                                                    'ARR_DT:'	||j.ARR_DT||'<{||}>'||
                                                                    'DEP_DT:'	||j.DEP_DT||'<{||}>'||
                                                                    'SEQ_N:'	||j.SEQ_N||'<{||}>'	||
                                                                    'USERID_N:'	||j.USERID_N||'<{||}>'||
                                                                    'TIMESTAMP_DT:'||j.TIMESTAMP_DT	,
                                                                    'D');


    end loop;
    exception  when others then 


          v_err_code := sqlcode;
                v_err_msg := substr(sqlerrm, 1, 200);
                v_sqlerrm := v_err_code
                             || v_err_msg
                             || dbms_utility.format_error_stack;

    end;




*/



    /********************end buisness error*******************************/






    EXCEPTION
          WHEN OTHERS THEN

            v_err_code := sqlcode;

                    v_err_msg := substr(sqlerrm, 1, 200)||dbms_utility.format_error_backtrace||'ERROR_PAN';

                    v_sqlerrm := v_err_code || v_err_msg;

            pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_ACTIVITY', 'proc_1_PSA', v_sqlerrm , 'FAIL',PV_RUN_ID,NULL,NULL,'T');


    END PROC_1_PSA;
    /