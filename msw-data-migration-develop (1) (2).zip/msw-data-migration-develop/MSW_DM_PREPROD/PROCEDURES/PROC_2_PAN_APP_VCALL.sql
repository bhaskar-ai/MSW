create or replace PROCEDURE PROC_2_PAN_APP_VCALL(PV_RUN_ID IN NUMBER) IS 


/***********************************************************************************************************
procedure name : PROC_2_PAN_APP_VCALL
Created By     : V. R. Yembarwar
Date           : 10-MAY-2019
Purpose        : Inserting  the data from , ST_pans_pansinfofrmrlog ,ST_pans_pansinfofrmrlog2,
                 ST_pans_pansinfofrmrlog3, ST_PTMS_BWMC,ST_PTMS_NOAFREFORMHIST (staging table) to 
                 SI_PAN_APPLICATION(Intermediate table) to 
				 Target Table PAN_APPLICATION AND PAN_PURPOSE_OF_CALLS.
Modified by    :  C.N.Bhaskar, Rohit Khool
Modified date  :  8-Aug-2019, 12-Aug-2019,13-Aug-2019,17-AUG-2019

*************************************************************************************************************/


 ---**** cursor for fetching data from Source Staging Table ****Z

    CURSOR cur_si_pan IS
    SELECT 
		d.VSL_REC_ID_N,
        a.pansid_n,
        d.msw_vsl_id_n,
        b.mvvoyageno_x,
        b.mvfwddft_q,
        b.mvmiddft_q,
        b.mvaftdft_q,
        f.MVHGT_Q,
        a.vslimscallno_c,
        a.csoname_x,
        a.csotelno_c,
        a.agentname_x,
        a.locnlatlong_x,
        a.locnlong_x,
        a.agenttelno_c,
        a.agentfaxno_c,
        f.agentEmail,
        f.shipEmail,
        b.anchdaysstay_n,
        b.ancheta_dt,
        b.anchetd_dt,
        a.cargo_x,
        a.shpsecplan_i,
        a.securitylevel_c,
        b.securityper_i,
        f.slopSludge_i,
        f.slopQty_q,
        f.sludgeQty_q,
        f.SSContent_x,
        f.SSRepFac_x,
        a.userid_x,
        f.safetyRem_i,
        d.vsl_mmsi_n,
        a.coname_x,
        f.mvConRem_i,
        f.fireHzRem_i,
        b.armsstrongrm_i,
        b.armsstrongrmlocn_x,
        f.mvRem_x,
        b.mvhms_i,
        b.mvhms_x,
        f.GPP_c,
        e.bwmc_i,
        e.ibwmc_i,
        e.bwmcExempted_i,
        e.bwmc_c,
        e.bwmcD1_i,
        e.bwmcD1Reason_x,
        e.bwmcD1Discharge_i,
        e.bwmcD1Discharge_q,
        e.bwmcD2_i,
        e.bwmcD2Reason_i,
        e.bwmcD2Discharge_i,
        e.bwmcD2Discharge_q,
        e.bwmcD4_i,
        a.usertitle,
        a.locn_x,
        a.timestamp_dt,
        b.armsammunition_i,
        b.armstype_x,
        a.dgcargo_c,
        a.dgcargopc_i,
        a.crewlst_i,
        a.paxlst_i,
        e.eta_dt,
        b.etd_dt,
        a.vslgt_q,
        e.ETA_DT  as BWMC_ETA_DT ,
        c.validbcc_i,
        f.manRem_i,
        f. mvDirnFr_c,
        a.reportdate_dt,
        b.userid_n,
        a.purposecall_c,
        a.otherspurpose_x,
        b.anchpurpose_c,
        b.anchpurpose_x,
		a.VSLMVID_N,
        d.PORT_OF_REGY_C,
        d.VSL_CRAFT_LIC_N,
        d.VSL_NT_Q

    FROM
        st_pans_pansinfofrmrlog    a,
        st_pans_pansinfofrmrlog2   b,
        st_pans_pansinfofrmrlog3   c,
        ST_PTMS_BWMC e,
        ST_PTMS_NOAFREFORM f,
        VESSEL   d
      WHERE
        a.pansid_n = b.pansid_n       
        AND a.pansid_n = c.pansid_n   
        and a.pansID_n = e.transID_n(+)
        and a.vslRecID_n = e.vslRecID_n(+)
        and a.pansID_n = f.pansID_n(+)    
        AND a.vslrecid_n = d.vsl_rec_id_n;



-- de claring the 'record type'  type to serve as the datatype of collection variable  of main table 

    v_dr_st_count          NUMBER;
    v_m_tgt_count1         NUMBER;
    v_m_src_count          NUMBER;
    v_si_count             NUMBER;
    v_m_tgt_count          NUMBER;
    v_m_err_code           NUMBER;
    v_exp_rows_si          VARCHAR2(2500);
    v_m_err_msg            VARCHAR2(200);
    v_m_sqlerrm            VARCHAR2(2500);
    v_err_code             VARCHAR2(1000);
    v_err_msg              VARCHAR2(1000);
    v_sqlerrm              VARCHAR2(1000);
    v_blkexptn_count       VARCHAR2(10000);
    v_blkexptn_desc        VARCHAR2(10000);
    v_src_count            NUMBER;  
    v_len                  VARCHAR2(10);
    v_len2                 VARCHAR2(20);
    v_regex                VARCHAR2(20);
    v_regexx               VARCHAR2(20); 
    v_cnt_poc              NUMBER := 0;
    l_val                  NUMBER;
    p_yymm                 VARCHAR2(20);
    V_YEAR_MONTH           VARCHAR2(20) ;
    lv_data_lump           CLOB;
    V_FLAG                 VARCHAR2(1);
    V_VSL_REF_ID_OUT    number;
    v_si_untagged   number;

    V_FLAG_OUT   varchar2(100);

    i_excep_cnt   number := 0;

    i_excep_cnt_poc   number := 0;

    i_excep_cnt_si   number := 0;

	V_VSL_CALL_ID NUMBER:=null;
	V_VSL_REF_ID_N	NUMBER:=null;

    V_VSLRECID_N    ST_PTMS_VSLCALL.VSLRECID_N%TYPE:=NULL;
    V_VSLMVID_N_PT     ST_PTMS_VSLCALL.VSLMVID_N%TYPE;
    V_VSLRPTETA_DT  ST_PTMS_VSLCALL.VSLRPTETA_DT%TYPE;
    V_VSLRPTETD_DT  ST_PTMS_VSLCALL.VSLRPTETD_DT%TYPE;
    V_VSLRPTARR_DT  ST_PTMS_VSLCALL.VSLRPTARR_DT%TYPE;
    V_VSLRPTDEP_DT  ST_PTMS_VSLCALL.VSLRPTDEP_DT%TYPE;



   CURSOR cur_tg_pan IS

    SELECT 
			SI.VSL_REC_ID_N,
			SI.PANSID_N	,
			SI.MSW_VSL_ID_N	,
			SI.MVVOYAGENO_X	,
			SI.MVFWDDFT_Q	,
			SI.MVMIDDFT_Q	,
			SI.MVAFTDFT_Q	,
			SI.MVHGT_Q	,
			SI.VSLIMSCALLNO_C	,
			SI.CSONAME_X	,
			SI.CSOTELNO_C	,
			SI.AGENTNAME_X	,
			SI.LOCNLATLONG_X	,
			SI.LOCNLONG_X	,
			SI.AGENTTELNO_C	,
			SI.AGENTFAXNO_C	,
			SI.AGENTEMAIL	,
			SI.SHIPEMAIL	,
			SI.ANCHDAYSSTAY_N	,
			SI.ANCHETA_DT	,
			SI.ANCHETD_DT	,
			SI.CARGO_X	,
			SI.SHPSECPLAN_I	,
			SI.SECURITYLEVEL_C	,
			SI.SECURITYPER_I	,
			SI.SLOPSLUDGE_I	,
			SI.SLOPQTY_Q	,
			SI.SLUDGEQTY_Q	,
			SI.SSCONTENT_X	,
			SI.SSREPFAC_X	,
			SI.USERID_X	,
			SI.SAFETYREM_I	,
			SI.VSL_MMSI_N	,
			SI.CONAME_X	,
			SI.MVCONREM_I	,
			SI.FIREHZREM_I	,
			SI.ARMSSTRONGRM_I	,
			SI.ARMSSTRONGRMLOCN_X	,
			SI.MVREM_X	,
			SI.MVHMS_I	,
			SI.MVHMS_X	,
			SI.GPP_C	,
			SI.BWMC_I	,
			SI.IBWMC_I	,
			SI.BWMCEXEMPTED_I	,
			SI.BWMC_C	,
			SI.BWMCD1_I	,
			SI.BWMCD1REASON_X	,
			SI.BWMCD1DISCHARGE_I	,
			SI.BWMCD1DISCHARGE_Q	,
			SI.BWMCD2_I	,
			SI.BWMCD2REASON_I	,
			SI.BWMCD2DISCHARGE_I	,
			SI.BWMCD2DISCHARGE_Q	,
			SI.BWMCD4_I	,
			SI.USERTITLE	,
			SI.LOCN_X	,
			SI.TIMESTAMP_DT	,
			SI.ARMSAMMUNITION_I	,
			SI.ARMSTYPE_X	,
			SI.DGCARGO_C	,
			SI.DGCARGOPC_I	,
			SI.CREWLST_I	,
			SI.PAXLST_I	,
			SI.ETA_DT	,
			SI.ETD_DT	,
			SI.VSLGT_Q	,
			SI.BWMC_ETA_DT	,
			SI.VALIDBCC_I	,
			SI.MANREM_I	,
			SI.REPORTDATE_DT	,
			SI.USERID_N	,
			SI.MVDIRNFR_C	,
			SI.PURPOSECALL_C	,
			SI.OTHERSPURPOSE_X	,
			SI.anchpurpose_c ,
			SI.anchpurpose_x,
			SI.VSLMVID_N,
			VC.VSL_CALL_ID_N,
			VC.VSL_REF_ID_N,
			PTMS.VSLRECID_N AS PTMS_VSLRECID_N ,
			PTMS.VSLMVID_N AS PTMS_VSLMVID_N,
			PTMS.VSLRPTETA_DT AS PTMS_VSLRPTETA,
			PTMS.VSLRPTETD_DT AS PTMS_VSLRPTETD_DT,
			PTMS.VSLRPTARR_DT AS PTMS_VSLRPTARR_DT,
			PTMS.VSLRPTDEP_DT AS PTMS_VSLRPTDEP_DT,
            si2.MSW_APPLN_REF_ID_N as MSW_APPLN_REF_ID_X,
            si.PORT_OF_REGY_C,    --newly added for vessel reference 
            si.VSL_CRAFT_LIC_N, -- newly added for vessel referencee 
            si.VSL_NT_Q       ,        -- newly added for vessel reference
            SI.SECRTY_REM_X,     --newly added below columns for target PAN APPLICATION TBALE
            SI.SUBMISSION_MODE,
            SI.SHP_ARR_DIRN_DESC_X,
            SI.P_LOCN_DESC_X,
            SI.SECU_LVL_SG_DESC_X,
            SI.LATD_DIRN_DESC_X,
            SI.LONGD_DIRN_DESC_X,
            SI.BWMC_COM_DESC_X,
            SI.BWMC_D1_RSN_DESC_X,
            SI.INTENDED_LOCN_DESC_X,
            SI.SEC_REF_I


			FROM
			SI_PAN_APPLICATION SI, VESSEL_CALL VC ,ST_PTMS_VSLCALL PTMS,SI_AS_VC_VR  SI2
			WHERE SI.VSLMVID_N      = VC.MVMT_ID_N(+)
			AND SI.VSLMVID_N        = PTMS.VSLMVID_N(+)
			AND SI.VSL_REC_ID_N     = PTMS.VSLRECID_N(+) 
            and to_char(si.pansid_n)= SI2.EXTL_APPLN_REF_ID_X(+)
            AND  SI.MSW_VSL_ID_N    = SI2.MSW_VSL_ID_N(+)
			ORDER BY REPORTDATE_DT,MSW_APPLN_REF_ID_N;

    TYPE rec_pan_app_tg IS RECORD (

        v_VSL_REC_ID_N         si_pan_application.VSL_REC_ID_N%TYPE,	
        v_pansid_n             si_pan_application.pansid_n%TYPE,	
        v_msw_vsl_id_n         si_pan_application.msw_vsl_id_n%TYPE,	
        v_mvvoyageno_x         si_pan_application.mvvoyageno_x%TYPE,	
        v_mvfwddft_q           si_pan_application.mvfwddft_q%TYPE,	
        v_mvmiddft_q           si_pan_application.mvmiddft_q%TYPE,	
        v_mvaftdft_q           si_pan_application.mvaftdft_q%TYPE,	
        v_mvhgt_q              si_pan_application.mvhgt_q%TYPE,	
        v_vslimscallno_c       si_pan_application.vslimscallno_c%TYPE,	
        v_csoname_x            si_pan_application.csoname_x%TYPE,	
        v_csotelno_c           si_pan_application.csotelno_c%TYPE,	
        v_agentname_x          si_pan_application.agentname_x%TYPE,	
        v_locnlatlong_x        si_pan_application.locnlatlong_x%TYPE,	
        v_locnlong_x           si_pan_application.locnlong_x%TYPE,	
        v_agenttelno_c         si_pan_application.agenttelno_c%TYPE,	
        v_agentfaxno_c         si_pan_application.agentfaxno_c%TYPE,	
        v_agentemail           si_pan_application.agentemail%TYPE,	
        v_shipemail            si_pan_application.shipemail%TYPE,	
        v_anchdaysstay_n       si_pan_application.anchdaysstay_n%TYPE,	
        v_ancheta_dt           si_pan_application.ancheta_dt%TYPE,	
        v_anchetd_dt           si_pan_application.anchetd_dt%TYPE,	
        v_cargo_x              si_pan_application.cargo_x%TYPE,	
        v_shpsecplan_i         si_pan_application.shpsecplan_i%TYPE,	
        v_securitylevel_c      si_pan_application.securitylevel_c%TYPE,	
        v_securityper_i        si_pan_application.securityper_i%TYPE,	
        v_slopsludge_i         si_pan_application.slopsludge_i%TYPE,	
        v_slopqty_q            si_pan_application.slopqty_q%TYPE,	
        v_sludgeqty_q          si_pan_application.sludgeqty_q%TYPE,	
        v_sscontent_x          si_pan_application.sscontent_x%TYPE,	
        v_ssrepfac_x           si_pan_application.ssrepfac_x%TYPE,	
        v_userid_x             si_pan_application.userid_x%TYPE,	
        v_safetyrem_i          si_pan_application.safetyrem_i%TYPE,	
        v_vsl_mmsi_n           si_pan_application.vsl_mmsi_n%TYPE,	
        v_coname_x             si_pan_application.coname_x%TYPE,	
        v_mvconrem_i           si_pan_application.mvconrem_i%TYPE,	
        v_firehzrem_i          si_pan_application.firehzrem_i%TYPE,	
        v_armsstrongrm_i       si_pan_application.armsstrongrm_i%TYPE,	
        v_armsstrongrmlocn_x   si_pan_application.armsstrongrmlocn_x%TYPE,	
        v_mvrem_x              si_pan_application.mvrem_x%TYPE,	
        v_mvhms_i              si_pan_application.mvhms_i%TYPE,	
        v_mvhms_x              si_pan_application.mvhms_x%TYPE,	
        v_gpp_c                si_pan_application.gpp_c%TYPE,	
        v_bwmc_i               si_pan_application.bwmc_i%TYPE,	
        v_ibwmc_i              si_pan_application.ibwmc_i%TYPE,	
        v_bwmcexempted_i       si_pan_application.bwmcexempted_i%TYPE,	
        v_bwmc_c               si_pan_application.bwmc_c%TYPE,	
        v_bwmcd1_i             si_pan_application.bwmcd1_i%TYPE,	
        v_bwmcd1reason_x       si_pan_application.bwmcd1reason_x%TYPE,	
        v_bwmcd1discharge_i    si_pan_application.bwmcd1discharge_i%TYPE,	
        v_bwmcd1discharge_q    si_pan_application.bwmcd1discharge_q%TYPE,	
        v_bwmcd2_i             si_pan_application.bwmcd2_i%TYPE,	
        v_bwmcd2reason_i       si_pan_application.bwmcd2reason_i%TYPE,	
        v_bwmcd2discharge_i    si_pan_application.bwmcd2discharge_i%TYPE,	
        v_bwmcd2discharge_q    si_pan_application.bwmcd2discharge_q%TYPE,	
        v_bwmcd4_i             si_pan_application.bwmcd4_i%TYPE,	
        v_usertitle            si_pan_application.usertitle%TYPE,	
        v_locn_x               si_pan_application.locn_x%TYPE,	
        v_timestamp_dt         si_pan_application.timestamp_dt%TYPE,	
        v_armsammunition_i     si_pan_application.armsammunition_i%TYPE,	
        v_armstype_x           si_pan_application.armstype_x%TYPE,	
        v_dgcargo_c            si_pan_application.dgcargo_c%TYPE,	
        v_dgcargopc_i          si_pan_application.dgcargopc_i%TYPE,	
        v_crewlst_i            si_pan_application.crewlst_i%TYPE,	
        v_paxlst_i             si_pan_application.paxlst_i%TYPE,	
        v_eta_dt               si_pan_application.eta_dt%TYPE,	
        v_etd_dt               si_pan_application.etd_dt%TYPE,	
        v_vslgt_q              si_pan_application.vslgt_q%TYPE,	
        v_BWMC_ETA_DT          si_pan_application.BWMC_ETA_DT%TYPE,	
        v_validbcc_i           si_pan_application.validbcc_i%TYPE,	
        v_MANREM_I             si_pan_application.MANREM_I%type,	
        v_reportdate_dt        si_pan_application.reportdate_dt%TYPE,	
        v_userid_n             si_pan_application.userid_n%TYPE,
        v_MVDIRNFR_C           si_pan_application.MVDIRNFR_C%TYPE,
        v_purposecall_c        si_pan_application.purposecall_c%TYPE,	
        v_otherspurpose_x      si_pan_application.otherspurpose_x%TYPE,	
        v_anchpurpose_c        si_pan_application.anchpurpose_c%TYPE,	
        v_anchpurpose_x        si_pan_application.anchpurpose_x%TYPE,
		V_VSLMVID_N            si_pan_application.VSLMVID_N%TYPE,
		V_VSL_CALL_ID_N			VESSEL_CALL.VSL_CALL_ID_N%TYPE,
		V_VSL_REF_ID_N_VC		VESSEL_CALL.VSL_REF_ID_N%TYPE,
		V_PTMS_VSLRECID_N		ST_PTMS_VSLCALL.VSLRECID_N%TYPE,
		V_PTMS_VSLMVID_N		ST_PTMS_VSLCALL.VSLMVID_N%TYPE,
		V_PTMS_VSLRPTETA		ST_PTMS_VSLCALL.VSLRPTETA_DT%TYPE,
		V_PTMS_VSLRPTETD_DT		ST_PTMS_VSLCALL.VSLRPTETD_DT%TYPE,
		V_PTMS_VSLRPTARR_DT		ST_PTMS_VSLCALL.VSLRPTARR_DT%TYPE,
		V_PTMS_VSLRPTDEP_DT		ST_PTMS_VSLCALL.VSLRPTDEP_DT%TYPE,
        V_MSW_APPLN_REF_ID_X2    SI_AS_VC_VR.MSW_APPLN_REF_ID_N%TYPE,
        V_PORT_OF_REGY_C         si_pan_application.PORT_OF_REGY_C%TYPE,
        V_VSL_CRAFT_LIC_N        si_pan_application.VSL_CRAFT_LIC_N%TYPE,
        V_VSL_NT_Q               si_pan_application.VSL_NT_Q%TYPE,
        V_SECRTY_REM_X		        si_pan_application.SECRTY_REM_X%TYPE,
        V_SUBMISSION_MODE		    si_pan_application.SUBMISSION_MODE%TYPE,
        V_SHP_ARR_DIRN_DESC_X		si_pan_application.SHP_ARR_DIRN_DESC_X%TYPE,
        V_P_LOCN_DESC_X		        si_pan_application.P_LOCN_DESC_X%TYPE,
        V_SECU_LVL_SG_DESC_X		si_pan_application.SECU_LVL_SG_DESC_X%TYPE,
        V_LATD_DIRN_DESC_X		    si_pan_application.LATD_DIRN_DESC_X%TYPE,
        V_LONGD_DIRN_DESC_X		    si_pan_application.LONGD_DIRN_DESC_X%TYPE,
        V_BWMC_COM_DESC_X		    si_pan_application.BWMC_COM_DESC_X%TYPE,
        V_BWMC_D1_RSN_DESC_X		si_pan_application.BWMC_D1_RSN_DESC_X%TYPE,
        V_INTENDED_LOCN_DESC_X		si_pan_application.INTENDED_LOCN_DESC_X%TYPE,
        V_SEC_REF_I		            si_pan_application.SEC_REF_I%TYPE

    );

    TYPE TYPE_PAN_APP_TG IS   
    TABLE OF REC_PAN_APP_TG INDEX BY PLS_INTEGER;

    LV_REC_PAN_APP_TG        TYPE_PAN_APP_TG;
    LV_SEQ_PAN_APP           PAN_APPLICATION.APPLN_REF_N%TYPE;
    LV_SEQ_PAN_PURP          PAN_PURPOSE_OF_CALL.PAN_PURP_OF_CALL_ID_N%TYPE;


    LVAL                     CLOB;
    V_MSW_APPLN_REF_ID_X     VARCHAR2(20);            
    V_MSW_VSL_CALL_ID        VARCHAR2(250);
    V_EXP_ROWS               VARCHAR2(3500);
    LV_GPP_C_I               CHAR(1);
    LV_BURNING_LNG_I         CHAR(1);
    LV_BURNING_CLN_FUEL_I    CHAR(1);

BEGIN		-- outer begin 

execute immediate 'truncate table si_pan_application';

execute immediate 'truncate table SI_PAN_UNTAGGED';

 ---------find the count of main table(source table) to compare the count with the that of intermediate table for reconcialation purpose




 ------insertig the rcords into the si intermediate table---------------



    pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 'PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


        FOR i IN cur_si_pan      -- for loop to insert data into si_pan_application table 

        loop                     -- for loop to insert data into si_pan_application table 

        BEGIN                    -- inner begin of si_pan_application

            INSERT INTO si_pan_application (
            VSL_REC_ID_N,
            PANSID_N	,
            MSW_VSL_ID_N	,
            MVVOYAGENO_X	,
            MVFWDDFT_Q	,
            MVMIDDFT_Q	,
            MVAFTDFT_Q	,
            MVHGT_Q	,
            VSLIMSCALLNO_C	,
            CSONAME_X	,
            CSOTELNO_C	,
            AGENTNAME_X	,
            LOCNLATLONG_X	,
            LOCNLONG_X	,
            AGENTTELNO_C	,
            AGENTFAXNO_C	,
            AGENTEMAIL	,
            SHIPEMAIL	,
            ANCHDAYSSTAY_N	,
            ANCHETA_DT	,
            ANCHETD_DT	,
            CARGO_X	,
            SHPSECPLAN_I	,
            SECURITYLEVEL_C	,
            SECURITYPER_I	,
            SLOPSLUDGE_I	,
            SLOPQTY_Q	,
            SLUDGEQTY_Q	,
            SSCONTENT_X	,
            SSREPFAC_X	,
            USERID_X	,
            SAFETYREM_I	,
            VSL_MMSI_N	,
            CONAME_X	,
            MVCONREM_I	,
            FIREHZREM_I	,
            ARMSSTRONGRM_I	,
            ARMSSTRONGRMLOCN_X	,
            MVREM_X	,
            MVHMS_I	,
            MVHMS_X	,
            GPP_C	,
            BWMC_I	,
            IBWMC_I	,
            BWMCEXEMPTED_I	,
            BWMC_C	,
            BWMCD1_I	,
            BWMCD1REASON_X	,
            BWMCD1DISCHARGE_I	,
            BWMCD1DISCHARGE_Q	,
            BWMCD2_I	,
            BWMCD2REASON_I	,
            BWMCD2DISCHARGE_I	,
            BWMCD2DISCHARGE_Q	,
            BWMCD4_I	,
            USERTITLE	,
            LOCN_X	,
            TIMESTAMP_DT	,
            ARMSAMMUNITION_I	,
            ARMSTYPE_X	,
            DGCARGO_C	,
            DGCARGOPC_I	,
            CREWLST_I	,
            PAXLST_I	,
            ETA_DT	,
            ETD_DT	,
            VSLGT_Q	,
            BWMC_ETA_DT	,
            VALIDBCC_I	,
            MANREM_I	,
            REPORTDATE_DT	,
            USERID_N	,
            MVDIRNFR_C	,
            PURPOSECALL_C	,
            OTHERSPURPOSE_X	,
            anchpurpose_c ,
            anchpurpose_x,
			VSLMVID_N,
            PORT_OF_REGY_C,
            VSL_CRAFT_LIC_N,
             VSL_NT_Q,
             SECRTY_REM_X,
            SUBMISSION_MODE,
            SHP_ARR_DIRN_DESC_X,
            P_LOCN_DESC_X,
            SECU_LVL_SG_DESC_X,
            LATD_DIRN_DESC_X,
            LONGD_DIRN_DESC_X,
            BWMC_COM_DESC_X,
            BWMC_D1_RSN_DESC_X,
            INTENDED_LOCN_DESC_X,
            SEC_REF_I
            ) 

            VALUES (

                i.VSL_REC_ID_N	,
                i.pansid_n	,
                i.msw_vsl_id_n	,
                i.mvvoyageno_x	,
                i.mvfwddft_q	,
                i.mvmiddft_q	,
                i.mvaftdft_q	,
                i.MVHGT_Q	,
                i.vslimscallno_c	,
                i.csoname_x	,
                i.CSOTELNO_C	,
                i.AGENTNAME_X	,
                i.locnlatlong_x	,
                i.locnlong_x	,
                i.agenttelno_c	,
                i.agentfaxno_c	,
                i.AGENTEMAIL	,
                i.SHIPEMAIL	,
                i.anchdaysstay_n	,
                i.ancheta_dt	,
                i.anchetd_dt	,
                i.cargo_x	,
                i.shpsecplan_i	,
                i.securitylevel_c	,
                i.securityper_i	,
                i.SLOPSLUDGE_I	,
                TRIM(i.SLOPQTY_Q),
                TRIM(i.SLUDGEQTY_Q),
                i.SSCONTENT_X	,
                i.SSREPFAC_X	,
                i.userid_x	,
                i.SAFETYREM_I	,
                i.vsl_mmsi_n	,
                i.coname_x	,
                i.MVCONREM_I	,
                i.FIREHZREM_I	,
                i.armsstrongrm_i	,
                i.armsstrongrmlocn_x	,
                i.MVREM_X                         	,
                i.mvhms_i	,
                i.MVHMS_X	,
                i.GPP_C	,
                i.bwmc_i	,
                i.ibwmc_i	,
                i.bwmcexempted_i	,
                i.bwmc_c	,
                i.bwmcd1_i	,
                i.bwmcd1reason_x	,
                i.bwmcd1discharge_i	,
                i.bwmcd1discharge_q	,
                i.bwmcd2_i	,
                i.bwmcd2reason_i	,
                i.bwmcd2discharge_i	,
                i.bwmcd2discharge_q	,
                i.bwmcd4_i	,
                i.usertitle	,
                i.locn_x	,
                i.timestamp_dt	,
                i.armsammunition_i	,
                i.armstype_x	,
                i.dgcargo_c	,
                i.dgcargopc_i	,
                i.crewlst_i	,
                i.paxlst_i	,
                i.eta_dt	,
                i.etd_dt ,   --to_timestamp(i.etd_dt,'yyyy mm dd''hh24:mi:ss')	,   --date format needs to be check accoding to data 
                i.vslgt_q	,
                i.BWMC_ETA_DT 	,
                i.validbcc_i	,
                i.MANREM_I	,
                i.reportdate_dt	,
                substr(i.userid_n,1,20),
                i.MVDIRNFR_C	,
                i.purposecall_c	,
                i.otherspurpose_x	,
                i.anchpurpose_c	,
                i.anchpurpose_x	,
				i.VSLMVID_N,
                i.PORT_OF_REGY_C,
                i.VSL_CRAFT_LIC_N,
                i.VSL_NT_Q,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
            );

    EXCEPTION                                             -- inner exception of si_pan_application
        WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := sqlerrm;
            v_sqlerrm := dbms_utility.format_error_backtrace|| v_err_code || v_err_msg||dbms_utility.format_call_stack;
             v_exp_rows_si := 
                        ' VSL_REC_ID_N:'||	i.VSL_REC_ID_N||'<{||}>'||
						' PANSID_N:'	||i.pansid_n||'<{||}>'||
						' MSW_VSL_ID_N:'||i.msw_vsl_id_n||'<{||}>'||
						' MVVOYAGENO_X:'||i.mvvoyageno_x||'<{||}>'||
						' MVFWDDFT_Q:'  ||i.mvfwddft_q||'<{||}>'||
						' MVMIDDFT_Q:'  ||i.mvmiddft_q||'<{||}>'||
						' MVAFTDFT_Q:'  ||i.mvaftdft_q||'<{||}>'||
						' MVHGT_Q:'		||i.MVHGT_Q||'<{||}>'||
						' VSLIMSCALLNO_C:'||i.vslimscallno_c||'<{||}>'||
						' CSONAME_X:'	||i.csoname_x||'<{||}>'||
						' CSOTELNO_C:'	||i.CSOTELNO_C||'<{||}>'||
						' AGENTNAME_X:'	||i.AGENTNAME_X||'<{||}>'||
						' LOCNLATLONG_X:'||i.locnlatlong_x||'<{||}>'||
						' LOCNLONG_X:'	||i.locnlong_x||'<{||}>'||
						' AGENTTELNO_C:'||i.agenttelno_c||'<{||}>'||
						' AGENTFAXNO_C:'||i.agentfaxno_c||'<{||}>'||
						' AGENTEMAIL:'	||i.AGENTEMAIL||'<{||}>'||
						' SHIPEMAIL:'	||i.SHIPEMAIL||'<{||}>'||
						' ANCHDAYSSTAY_N:'||i.anchdaysstay_n||'<{||}>'||
						' ANCHETA_DT:'	||i.ancheta_dt||'<{||}>'||
						' ANCHETD_DT:'	||i.anchetd_dt||'<{||}>'||
						' CARGO_X:'		||i.cargo_x||'<{||}>'||
						' SHPSECPLAN_I:'||i.shpsecplan_i||'<{||}>'||
						' SECURITYLEVEL_C:'	||i.securitylevel_c||'<{||}>'||
						' SECURITYPER_I:'||i.securityper_i||'<{||}>'||
						' SLOPSLUDGE_I:'||i.SLOPSLUDGE_I||'<{||}>'||
						' SLOPQTY_Q:'	||i.SLOPQTY_Q||'<{||}>'||
						' SLUDGEQTY_Q:'	||i.SLUDGEQTY_Q||'<{||}>'||
						' SSCONTENT_X:'	||i.SSCONTENT_X||'<{||}>'||
						' SSREPFAC_X:'	||i.SSREPFAC_X||'<{||}>'||
						' USERID_X:'	||i.userid_x||'<{||}>'||
						' SAFETYREM_I:'	||i.SAFETYREM_I||'<{||}>'||
						' VSL_MMSI_N:'	||i.vsl_mmsi_n||'<{||}>'||
						' CONAME_X:'	||i.coname_x||'<{||}>'||
						' MVCONREM_I:'	||i.MVCONREM_I||'<{||}>'||
						' FIREHZREM_I:'	||i.FIREHZREM_I||'<{||}>'||
						' ARMSSTRONGRM_I:'||i.armsstrongrm_i||'<{||}>'||
						' ARMSSTRONGRMLOCN_X:'||i.armsstrongrmlocn_x||'<{||}>'||
						' MVREM_X:'	||i.MVREM_X ||'<{||}>'||
						' MVHMS_I:'	||i.mvhms_i||'<{||}>'||
						' MVHMS_X:'	||i.MVHMS_X||'<{||}>'||
						' GPP_C:'	||i.GPP_C||'<{||}>'||
						' BWMC_I:'	||i.bwmc_i||'<{||}>'||
						' IBWMC_I:'	||i.ibwmc_i||'<{||}>'||
						' BWMCEXEMPTED_I:'||i.bwmcexempted_i||'<{||}>'||
						' BWMC_C:'||i.bwmc_c||'<{||}>'||
						' BWMCD1_I:'||i.bwmcd1_i||'<{||}>'||
						' BWMCD1REASON_X:'||i.bwmcd1reason_x||'<{||}>'||
						' BWMCD1DISCHARGE_I:'||i.bwmcd1discharge_i||'<{||}>'||
						' BWMCD1DISCHARGE_Q:'||i.bwmcd1discharge_q||'<{||}>'||
						' BWMCD2_I:'	||i.bwmcd2_i||'<{||}>'||
						' BWMCD2REASON_I:'	||i.bwmcd2reason_i||'<{||}>'||
						' BWMCD2DISCHARGE_I:'	||i.bwmcd2discharge_i||'<{||}>'||
						' BWMCD2DISCHARGE_Q:'	||i.bwmcd2discharge_q||'<{||}>'||
						' BWMCD4_I:'	||i.bwmcd4_i||'<{||}>'||
						' USERTITLE:'	||i.usertitle||'<{||}>'||
						' LOCN_X:'	|| i.locn_x||'<{||}>'||
						' TIMESTAMP_DT:'||i.timestamp_dt||'<{||}>'||
						' ARMSAMMUNITION_I:'|| i.armsammunition_i||'<{||}>'||
						' ARMSTYPE_X:'	||i.armstype_x||'<{||}>'||
						' DGCARGO_C:'	||i.dgcargo_c||'<{||}>'||
						' DGCARGOPC_I:'	||i.dgcargopc_i||'<{||}>'||
						' CREWLST_I:'	||i.crewlst_i||'<{||}>'||
						' PAXLST_I:'	||i.paxlst_i||'<{||}>'||
						' ETA_DT:'	||i.eta_dt||'<{||}>'||
						' ETD_DT:'	||i.etd_dt||'<{||}>'||
						' VSLGT_Q:'	||i.vslgt_q||'<{||}>'||
						' BWMC_ETA_DT:'	||i.BWMC_ETA_DT||'<{||}>'||
						' VALIDBCC_I:'	||i.validbcc_i||'<{||}>'||
						' MANREM_I:'	||i.MANREM_I||'<{||}>'||
						' REPORTDATE_DT:'	||i.reportdate_dt||'<{||}>'||
						' USERID_N:'	||i.userid_n||'<{||}>'||
						' MVDIRNFR_C:'	||i.MVDIRNFR_C||'<{||}>'||
						' PURPOSECALL_C:'	||i.purposecall_c||'<{||}>'||
						' OTHERSPURPOSE_X:'	||i.otherspurpose_x||'<{||}>'||
						' anchpurpose_c ,:'	||i.anchpurpose_c||'<{||}>'||
						' anchpurpose_x:'	||i.anchpurpose_x||'<{||}>'||
						' VSLMVID_N:'	||i.VSLMVID_N;


          i_excep_cnt_si := i_excep_cnt_si +1;

                           if i_excep_cnt_si < 50000  then 

         pkg_datamigration_generic.proc_trace_exception('SI_PAN_APLICATION', 
         'PROC_2_PAN_APP_VCALL',
         dbms_utility.format_error_backtrace , 
         'ERROR',
         PV_RUN_ID,
         dbms_utility.format_error_stack ||v_sqlerrm,
         v_exp_rows_si  ,
         'T');

end if;





    END;     -- inner end of si_pan_application
  END LOOP;   -- inner end loop of  si_pan_application table
 COMMIT;
 
 
---Records Missed in the Business Logic
-------------------------------------------------------------------------------------------------------------------------------------------------------------








/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/

 OPEN cur_tg_pan;     -- cursor loop  to insert data into PAN_APPLICATION and PAN_POC table 

    pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 'Insertion begins into PAN_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T');


    LOOP                 ---loop to start  cursor loop  to insert data into PAN_APPLICATION and PAN_POC table 

        FETCH cur_tg_pan
        BULK COLLECT INTO
        lv_rec_pan_app_tg LIMIT 10000;

        EXIT WHEN lv_rec_pan_app_tg.count = 0;

        FOR i IN lv_rec_pan_app_tg.first..lv_rec_pan_app_tg.last 

           LOOP           ---for loop

      --      lv_seq_pan_app := seq_pan_app.nextval;

     --       lv_seq_pan_purp := seq_pan_purp.nextval;

                BEGIN                                   -- inner begin when  any exception occurs in JSON or sequence reset

if lv_rec_pan_app_tg(i).V_MSW_APPLN_REF_ID_X2 is  null then
                          V_YEAR_MONTH:= TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'YY')|| TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt,'MM') ;




--------------logic for sequence reset------------

                                    IF V_YEAR_MONTH != p_yymm  AND p_yymm IS NOT NULL                       
                                     THEN

                                             EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual'
                                             INTO l_val;
                                              EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by -'|| l_val || ' minvalue 0';

                                              EXECUTE IMMEDIATE 'select APP_SUB_PAN_SEQ.NEXTVAL from dual'
                                                 INTO l_val;

                                              EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_PAN_SEQ INCREMENT BY 1000 MINVALUE 0';
                                              EXECUTE IMMEDIATE 'SELECT APP_SUB_PAN_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                                              EXECUTE IMMEDIATE 'alter sequence APP_SUB_PAN_SEQ increment by 1 minvalue 0';

                                      end if; --V_YEAR_MONTH != p_yymm  AND p_yymm IS NOT NULL  

                                            p_yymm := V_YEAR_MONTH ;

                                    v_msw_appln_ref_id_x := 'MSW'
                                            || 'PAN'
                                            || TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt, 'YY')
                                            || TO_CHAR(lv_rec_pan_app_tg(i).v_reportdate_dt, 'MM') 
                                            || TO_CHAR(APP_SUB_PAN_SEQ.nextval, 'FM00000');




  ---------- TRANSFORMATION DECODE LOGIC FOR FUEL TOOK IN VARIBLE---

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'N',0,'L',1,1) 
                                                                   INTO LV_GPP_c_i FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',1,'Y',0,NULL) 
                                                                   INTO LV_BURNING_LNG_I FROM DUAL;

                                                                   SELECT 
                                                                   DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',0,'Y',1,NULL)
                                                                   INTO LV_BURNING_CLN_FUEL_I FROM DUAL;


                                                                   IF LV_REC_PAN_APP_TG(I).V_VSLMVID_N IS NOT NULL THEN
					                                                         V_VSL_CALL_ID :=LV_REC_PAN_APP_TG(I).V_VSL_CALL_ID_N;
					                                                          V_VSL_REF_ID_N	:=LV_REC_PAN_APP_TG(I).V_VSL_REF_ID_N_VC;

                                                                             IF V_VSL_CALL_ID IS NULL  THEN
                                                                                   V_VSLRECID_N :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLRECID_N;
                                                                                   V_VSLMVID_N_PT :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLMVID_N;
                                                                                   V_VSLRPTETA_DT :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLRPTETA;
                                                                                   V_VSLRPTETD_DT :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLRPTETD_DT;
                                                                                   V_VSLRPTARR_DT :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLRPTARR_DT;
                                                                                   V_VSLRPTDEP_DT :=LV_REC_PAN_APP_TG(I).V_PTMS_VSLRPTDEP_DT;

                                                                                         IF V_VSLRECID_N IS NULL  THEN
                                                                                                V_VSL_CALL_ID := NULL;
                                                                                                V_VSLRECID_N :=NULL;
                                                                                            END IF; --IF V_VSLRECID_N IS NULL  THEN
                                                                            END IF; --	IF V_VSL_CALL_ID IS NULL  THEN

                                                                  ELSE --IF LV_REC_PAN_APP_TG(I).V_VSLMVID_N IS NOT NULL THEN
                                                                   V_VSL_CALL_ID := NULL;
                                                                   V_VSLRECID_N :=NULL;
                                                                 END IF;				--IF LV_REC_PAN_APP_TG(I).V_VSLMVID_N IS NOT NULL THEN	



                         IF 	V_VSL_CALL_ID IS NOT NULL OR V_VSLRECID_N IS NOT NULL  THEN
                       



                            IF 	V_VSL_CALL_ID IS NOT NULL   THEN --V_VSL_CALL_ID IS NOT NULL

	                              BEGIN  --APPLICATION_SUBMISSION

	                                      INSERT INTO APPLICATION_SUBMISSION (APPLN_SUBMISSN_ID_N,
														MSW_APPLN_REF_ID_X,
														VSL_CALL_ID_N,
														EXTL_APPLN_REF_ID_X,
														MSW_VSL_ID_N,
														ETA_DT,
														ETD_DT,
														APPLN_TY_C,
														APPLN_DATA_X,
														ST_C,
														PROCESSING_REM_X,
														PROCESSED_BY_X,
														PROCESSED_ON_DT,
														CUTOFF_DT,
														LOCK_VER_N,
														CRT_ON_DT,
														CRT_BY_X,
														UPT_ON_DT,
														UPT_BY_X,
														DELETED_I,
														ORG_C,
														VSL_REF_ID_N,
														REASON)


												VALUES(APP_SUB_SEQ.NEXTVAL,
													   V_MSW_APPLN_REF_ID_X,												   
													   V_VSL_CALL_ID,												   
													   lv_rec_pan_app_tg(i).v_pansid_n,												   
													   lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
													   nvl(lv_rec_pan_app_tg(i).v_eta_dt,sysdate),
													   lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
													   'PAN',
													   null ,  --NULL,
													   'PROCESSED',
													   NULL,
													   NULL,
													   NULL,
													   NULL,
													   0,
													   lv_rec_pan_app_tg(i).v_reportdate_dt,
													   lv_rec_pan_app_tg(i).v_userId_n,
													   lv_rec_pan_app_tg(i).v_reportdate_dt,
													   lv_rec_pan_app_tg(i).v_userId_n,
													   0,
													   'MSW',
													   V_VSL_REF_ID_N,
													   null);

                              

	                                             exception when others  then  null; --APPLICATION_SUBMISSION

	                                                 V_ERR_CODE := SQLCODE;
	                                                 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
                                                     V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


	                                                  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
                                                                    ('APPLICATION_SUBMISSION','PROC_2_PAN_APP_VCALL',

                                                                     'APPLN_SUBMISSN_ID_N:' || APP_SUB_SEQ.currval ||'<{||}>'||
                                                                     'MSW_APPLN_REF_ID_X:' || V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
                                                                     'VSL_CALL_ID_N:' || V_VSL_CALL_ID  ||'<{||}>'|| 
                                                                     'EXTL_APPLN_REF_ID_X:'|| lv_rec_pan_app_tg(i).v_pansid_n	  ||'<{||}>'||
                                                                     'MSW_VSL_ID_N:' || lv_rec_pan_app_tg(i).v_msw_vsl_id_n  ||'<{||}>'||
                                                                     'ETA_DT:' || nvl(lv_rec_pan_app_tg(i).v_eta_dt,sysdate) ||'<{||}>'||
                                                                     'ETD_DT:' || lv_rec_pan_app_tg(i).v_BWMC_ETA_DT  ||'<{||}>'||
                                                                     'APPLN_TY_C:' || 'PAN'  ||'<{||}>'||
                                                                     'ST_C:'  || 'PROCESSED'  ||'<{||}>'||
                                                                     'PROCESSING_REM_X:' || null  ||'<{||}>'||
                                                                     'PROCESSED_BY_X:' || null  ||'<{||}>'||
                                                                      'PROCESSED_ON_DT:' || null  ||'<{||}>'||
                                                                      'CUTOFF_DT:' || null  ||'<{||}>'||
                                                                     'LOCK_VER_N:' || 0  ||'<{||}>'||
                                                                     'CRT_ON_DT:' || lv_rec_pan_app_tg(i).v_reportdate_dt  ||'<{||}>'||
                                                                      'CRT_BY_X:' || lv_rec_pan_app_tg(i).v_userId_n  ||'<{||}>'||
                                                                      'UPT_ON_DT:' || lv_rec_pan_app_tg(i).v_reportdate_dt ||'<{||}>'||
                                                                        'UPT_BY_X:'  || lv_rec_pan_app_tg(i).v_userId_n  ||'<{||}>'||
                                                                        'DELETED_I:' || 0   ||'<{||}>'||
                                                                          'ORG_C:'  || 'MSW'   ||'<{||}>'||
                                                                           'VSL_REF_ID_N:' ||V_VSL_REF_ID_N   ||'<{||}>'||
                                                                          'REASON:' ||null
                                                                          ,'ERROR',
                                                                                PV_RUN_ID,
                                                                                V_SQLERRM,
                                                                                APP_SUB_SEQ.currval ||'<{||}>'||
                                                                                V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
                                                                                V_VSL_CALL_ID  ||'<{||}>'|| 
                                                                                lv_rec_pan_app_tg(i).v_pansid_n ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_msw_vsl_id_n  ||'<{||}>'||
                                                                                nvl(lv_rec_pan_app_tg(i).v_eta_dt,sysdate)  ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_BWMC_ETA_DT   ||'<{||}>'||
                                                                                 'PAN'  ||'<{||}>'||
                                                                                 'PROCESSED'  ||'<{||}>'||
                                                                                 null  ||'<{||}>'||
                                                                                 null  ||'<{||}>'||
                                                                                 null  ||'<{||}>'||
                                                                                 null  ||'<{||}>'||
                                                                                 0  ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_reportdate_dt  ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_userId_n  ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_reportdate_dt  ||'<{||}>'||
                                                                                lv_rec_pan_app_tg(i).v_userId_n  ||'<{||}>'||
                                                                                 0   ||'<{||}>'||
                                                                                 'MSW'   ||'<{||}>'||
                                                                                V_VSL_REF_ID_N  ||'<{||}>'||
                                                                                null
                                                                                ,
                                                                                'T');


	                                    CONTINUE;

	                    END;--APPLICATION_SUBMISSION


	              END IF; --V_VSL_CALL_ID IS NOT NULL   THEN




                                    IF V_VSLRECID_N IS NOT NULL THEN

                                                     PROC_1_VSL_REF(lv_rec_pan_app_tg(i).v_msw_vsl_id_n,--V_MSW_VSL_ID_N 
                                                                                V_VSLRECID_N,--V_VSL_REC_ID_N 
                                                                                null,--V_VSL_M  done 
                                                                                lv_rec_pan_app_tg(i).V_PORT_OF_REGY_C,--V_PORT_OF_REGY_C  done 
                                                                                null,--V_VSL_IMO_N
                                                                                null,--V_VSL_CALL_SIGN_N  done
                                                                                lv_rec_pan_app_tg(i).V_VSL_CRAFT_LIC_N,--V_VSL_CRAFT_LIC_N
                                                                                null,--V_VSL_GT_Q  done 
                                                                                lv_rec_pan_app_tg(i).V_VSL_NT_Q,--V_VSL_NT_Q
                                                                                null,--V_VSL_FLAG_C  done
                                                                                null,--VSLTY_C  done
                                                                                V_VSL_REF_ID_OUT,
                                                                                V_FLAG_OUT);


													IF V_FLAG_OUT IS NULL THEN                     

                                                                   proc_2_vc_as
                                                                  ( lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                  V_VSLRPTETA_DT, -- need to change in future after clarification
                                                                  V_VSLRPTETD_DT,
                                                                  V_VSLRPTARR_DT,
                                                                  V_VSLRPTDEP_DT,
                                                                  V_VSLMVID_N_PT,
                                                                  v_msw_appln_ref_id_x,
                                                                  lv_rec_pan_app_tg(i).v_pansid_n,
                                                                  'PAN',
                                                                  null,--json (need to change)
                                                                  PV_RUN_ID, 
                                                                  'PAN_APPLICATION',
                                                                  v_msw_vsl_call_id,
                                                                  V_FLAG,
                                                                  'MSW',
                                                                  V_VSL_REF_ID_OUT,
                                                                  'PROCESSED',
                                                                  lv_rec_pan_app_tg(i).v_reportdate_dt,
                                                                  lv_rec_pan_app_tg(i).v_userId_n,
                                                                  lv_rec_pan_app_tg(i).v_reportdate_dt,
                                                                  lv_rec_pan_app_tg(i).v_userId_n);

															IF V_FLAG IS NULL
															THEN
															V_VSL_CALL_ID :=v_msw_vsl_call_id;
															ELSE --IF V_FLAG IS NULL
															V_VSL_CALL_ID :=NULL;
															END IF; --IF V_FLAG IS NULL
													ELSE  --V_FLAG_OUT
													CONTINUE;																  
													END IF;	 --V_FLAG_OUT

							ELSE --V_VSLRECID_N IS NOT NULL
											V_VSL_CALL_ID :=V_VSL_CALL_ID;
							END IF; --V_VSLRECID_N



                                                      IF V_VSL_CALL_ID IS NOT NULL THEN


                                 /************************************************************************************************************************************

                                                                                               PAN_APPLICATION  

                                 ******************************************************************************************************************************************/


              Begin    -- inner begin to insert data into pan application

                                                                    INSERT INTO pan_application (

                                                                        APPLN_REF_N,
                                                                        VSL_CALL_ID_N,
                                                                        MSW_APPLN_REF_ID_X,
                                                                        EXTL_APPLN_REF_ID_X,
                                                                        MSW_VSL_ID_N,
                                                                        VOY_X,
                                                                        APPLCNT_ID_X,
                                                                        ARR_FWD_DFT_Q,
                                                                        ARR_MID_DFT_Q,
                                                                        ARR_AFT_DFT_Q,
                                                                        AIR_DFT_Q,
                                                                        VSL_IMS_CALL_NO_C,
                                                                        CSO_M,
                                                                        CSO_TEL_N,
                                                                        AGT_NM_M,
                                                                        LOCN_LAT_N,
                                                                        LOCN_LONG_N,
                                                                        AGT_TEL_N,
                                                                        AGT_FAX_N,
                                                                        AGT_EMAIL_X,
                                                                        SHP_EMAIL_X,
                                                                        ANCH_DURN_N,
                                                                        ANCH_ETA_DT,
                                                                        ANCH_ETD_DT,
                                                                        CGO_DESC_X,
                                                                        SHP_SECU_PLAN_I,
                                                                        SECU_LVL_SG_C,
                                                                        SECU_PERS_I,
                                                                        APPLN_ST_C,
                                                                        SLOP_SLUDGE_I,
                                                                        SLOP_QTY_Q,
                                                                        SLUDGE_QTY_Q,
                                                                        SS_CONTENT_X,
                                                                        SS_REP_FAC_X,
                                                                        HEIGHT_N,
                                                                        NAME_PER_REPORTING_X,
                                                                        SAFETY_SEC_AFFECT_I,
                                                                        VSL_MMSI_N,
                                                                        CO_NAME_X,
                                                                        MV_CON_REM_I,
                                                                        SAFETY_REM_I,
                                                                        FIRE_HZ_REM_I,
                                                                        ARMS_STRONG_RM_I,
                                                                        ARMS_STRONG_RM_LOCN_X,
                                                                        MV_REM_X,
                                                                        MV_HMS_I,
                                                                        MV_HMS_X,
                                                                        GPP_C_I,
                                                                        BURNING_LNG_I,
                                                                        BURNING_CLN_FUEL_I,
                                                                        BWMC_I,
                                                                        IBWMC_I,
                                                                        BWMC_EXEMPTED_I,
                                                                        BWMC_COM_C,
                                                                        BWMC_D1_I,
                                                                        BWMC_D1_REASON_X,
                                                                        BWMC_D1_DISCHARGE_I,
                                                                        BWMC_D1_DISCHARGE_Q,
                                                                        BWMC_D2_I,
                                                                        BWMC_D2_REASON_I,
                                                                        BWMC_D2_DISCHARGE_I,
                                                                        BWMC_D2_DISCHARGE_Q,
                                                                        BWMC_D4_I,
                                                                        USER_TITLE_X,
                                                                        LOCN_X,
                                                                        TIME_STAMP_DT,
                                                                        ARMS_AMMUNITION_I,
                                                                        ARMS_TYPE_X,
                                                                        ARMS_QTY_Q,
                                                                        HNS_I,
                                                                        DG_ON_BOARD_I,
                                                                        DG_CGO_MANF_I,
                                                                        CR_LIST_I,
                                                                        PASSN_LIST_ICA_I,
                                                                        PORT_FACILITY_ETA_DT,
                                                                        PORT_FACILITY_ETD_DT,
                                                                        GRS_TNG_N,
                                                                        IS_NOA_I,
                                                                        DRAFT_X,
                                                                        LAST_PORT_X,
                                                                        ETA_DT,
                                                                        VALID_BCC_I,
                                                                        MAN_REM_I,
                                                                        SAFETY_SECURITY_I,
                                                                        LOCATION_X,
                                                                        OTHER_LOCATION_X,
                                                                        MV_STM_DT,
                                                                        LOCN_TO_X,
                                                                        MARPOL_I,
                                                                        OTERM_FAC_C,
                                                                        OTERM_FAC_X,
                                                                        TRANS_ID_N,
                                                                        NEW_NOA_I,
                                                                        PAGER_X,
                                                                        SESS_X,
                                                                        OTH_REM_I,
                                                                        ARMS_SRC_I,
                                                                        SOURCE_I,
                                                                        USER_ID_X,
                                                                        LATD_DIRCN_C,
                                                                        LONGD_DIRCN_C,
                                                                        SHP_ARVL_DIRCN_C,
                                                                        SUBR_EMAIL_I,
                                                                        SUBR_SMS_I,
                                                                        PROCESSING_REM_X,
                                                                        PROCESSED_BY_X,
                                                                        PROCESSED_ON_DT,
                                                                        CRT_BY_N,
                                                                        CRT_ON_DT,
                                                                        UPT_BY_X,
                                                                        UPT_ON_DT,
                                                                        LOCK_VER_N,
                                                                        DELETED_I,
                                                                        SECRTY_REM_X,
                                                                        ETD_DT,
                                                                        SUBMISSION_MODE,
                                                                        SHP_ARR_DIRN_DESC_X,
                                                                        P_LOCN_DESC_X,
                                                                        SECU_LVL_SG_DESC_X,
                                                                        LATD_DIRN_DESC_X,
                                                                        LONGD_DIRN_DESC_X,
                                                                        BWMC_COM_DESC_X,
                                                                        BWMC_D1_RSN_DESC_X,
                                                                        INTENDED_LOCN_DESC_X,
                                                                        SEC_REF_I
                                                                    ) VALUES (
                                                                            seq_pan_app.nextval,
                                                                            V_VSL_CALL_ID ,    
                                                                            v_msw_appln_ref_id_x,         
                                                                            lv_rec_pan_app_tg(i).v_pansid_n,
                                                                            lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                            lv_rec_pan_app_tg(i).v_mvvoyageno_x,
                                                                            'D1',                                                  ---Pending on User Service Data Model
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10,     
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10,
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10  ,    
                                                                            lv_rec_pan_app_tg(i).v_mvHgt_q,
                                                                            lv_rec_pan_app_tg(i).v_vslimscallno_c,
                                                                            lv_rec_pan_app_tg(i).v_csoname_x,
                                                                            lv_rec_pan_app_tg(i).v_csotelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentname_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlatlong_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlong_x,
                                                                            lv_rec_pan_app_tg(i).v_agenttelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentfaxno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentEmail,
                                                                            lv_rec_pan_app_tg(i).v_shipEmail,
                                                                            lv_rec_pan_app_tg(i).v_anchdaysstay_n,
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            lv_rec_pan_app_tg(i).v_cargo_x,
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_shpsecplan_i), 'N', 0, 'Y',1),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securitylevel_c), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securityper_i), 'N', 0, 'Y', 1),
                                                                            'PROCESSED',                                            ---as per mapping sheet
                                                                            decode(TRIM(lv_rec_pan_app_tg(i).v_slopSludge_i), 'N',0,'Y',1),
                                                                            TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q),
                                                                            TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q),
                                                                            lv_rec_pan_app_tg(i).v_SSContent_x,
                                                                            lv_rec_pan_app_tg(i).v_SSRepFac_x,
                                                                            0,                                              --according to mapping sheet
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(trim(lv_rec_pan_app_tg(i).v_safetyRem_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_vsl_mmsi_n,
                                                                            lv_rec_pan_app_tg(i).v_coname_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvConRem_i),'N',0,'Y',1),
                                                                            0,                                          --according to mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_fireHzRem_i),'N',0,'Y',1),
                                                                            substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1, 1),
                                                                            lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x,
                                                                            lv_rec_pan_app_tg(i).v_mvRem_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvhms_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_mvhms_x,
                                                                            LV_GPP_c_i ,                            
                                                                            LV_BURNING_LNG_I,                                
                                                                            LV_BURNING_CLN_FUEL_I ,                                
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_ibwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcexempted_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmc_c,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1reason_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2_i,
                                                                            Decode(Trim(lv_rec_pan_app_tg(i).v_bwmcd2reason_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd2discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd4_i,
                                                                            lv_rec_pan_app_tg(i).v_usertitle,
                                                                            lv_rec_pan_app_tg(i).v_locn_x,
                                                                            lv_rec_pan_app_tg(i).v_timestamp_dt,
                                                                            decode(lv_rec_pan_app_tg(i).v_armsammunition_i,'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_armsType_x,         
                                                                            0,
                                                                            0,                                                --- accordingly to a mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_dgcargo_c),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_dgcargopc_i,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_crewlst_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_paxlst_i,
                                                                            lv_rec_pan_app_tg(i).v_eta_dt,
                                                                            lv_rec_pan_app_tg(i).v_etd_dt,
                                                                            lv_rec_pan_app_tg(i).v_vslgt_q,
                                                                            0,
                                                                            'DM',                                            ---pending
                                                                            'DM',
                                                                            lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_validbcc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_manRem_i),'N',0,'Y',1),
                                                                            0,
                                                                            'PAN',
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnlatlong_x),-1),'N','NORTH','S','SOUTH'),
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnLong_x),-1),'W', 'WEST', 'E', 'EAST'),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvDirnFr_c) , 'W', 'WEST', 'E', 'EAST','S', 'SOUTN', 'N', 'NORTH'),
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            'DATA MIGRATION',
                                                                            sysdate,
                                                                            'DATA MIGRATION',
                                                                            sysdate,
                                                                            0,
                                                                            0,
                                                                            lv_rec_pan_app_tg(i).V_SECRTY_REM_X,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).V_SUBMISSION_MODE,
                                                                            lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X,
                                                                            0

                                                                            
                                                                          );



                                                    ------------------------------



                                                    EXCEPTION --inner exception for PAN_APPLICATION
                                                                    WHEN OTHERS THEN
                                                                    ---deleting records from vessel_call and Application_submission  table when we get exception while inserting records in PAN_APPLICATION
                                                                  --    DELETE FROM vessel_call     
                                                                   --     WHERE   vsl_call_id_n = v_msw_vsl_call_id;

                                                                     --  DELETE FROM Application_submission     
                                                                --  WHERE   VSL_CALL_ID_N = v_msw_vsl_call_id;

                                                                        v_err_code := sqlcode;
                                                                        v_err_msg := substr(sqlerrm, 1, 200);
                                                                        v_sqlerrm := v_err_code
                                                                                     || v_err_msg
                                                                                     || dbms_utility.format_error_backtrace;




                                                                        v_exp_rows:=    'APPLN_REF_N :'	||seq_pan_app.currval||'<{||}>'||
                                                                                        'VSL_CALL_ID_N,:'|| V_VSL_CALL_ID||'<{||}>'||
                                                                                        'MSW_APPLN_REF_ID_X:'|| v_msw_appln_ref_id_x||'<{||}>'||
                                                                                        'EXTL_APPLN_REF_ID_X:'||lv_rec_pan_app_tg(i).v_pansid_n	||'<{||}>'||
                                                                                        'MSW_VSL_ID_N:' ||lv_rec_pan_app_tg(i).v_msw_vsl_id_n||'<{||}>'||
                                                                                        'VOY_X:'		||lv_rec_pan_app_tg(i).v_mvvoyageno_x||'<{||}>'||
                                                                                        'APPLCNT_ID_X:'	||'D1'||'<{||}>'  ||           
                                                                                        'ARR_FWD_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_MID_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_AFT_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10||'<{||}>'||
                                                                                        'AIR_DFT_Q:'	||lv_rec_pan_app_tg(i).v_mvHgt_q	||	'<{||}>'||
                                                                                        'VSL_IMS_CALL_NO_C:'||lv_rec_pan_app_tg(i).v_vslimscallno_c	||'<{||}>'||
                                                                                        'CSO_M:'		||lv_rec_pan_app_tg(i).v_csoname_x||'<{||}>'||
                                                                                        'CSO_TEL_N:'	||lv_rec_pan_app_tg(i).v_csotelno_c	||'<{||}>'||
                                                                                        'AGT_NM_M:'		||lv_rec_pan_app_tg(i).v_agentname_x||'<{||}>'||
                                                                                        'LOCN_LAT_N:'	||lv_rec_pan_app_tg(i).v_locnlatlong_x||'<{||}>'||
                                                                                        'LOCN_LONG_N:'	||lv_rec_pan_app_tg(i).v_locnlong_x	||'<{||}>'||
                                                                                        'AGT_TEL_N:'	||lv_rec_pan_app_tg(i).v_agenttelno_c||'<{||}>'||
                                                                                        'AGT_FAX_N:'	||lv_rec_pan_app_tg(i).v_agentfaxno_c||'<{||}>'||
                                                                                        'AGT_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_agentEmail	||'<{||}>'||
                                                                                        'SHP_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_shipEmail	||'<{||}>'||
                                                                                        'ANCH_DURN_N:'	||lv_rec_pan_app_tg(i).v_anchdaysstay_n	||	'<{||}>'||
                                                                                        'ANCH_ETA_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'ANCH_ETD_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'CGO_DESC_X:'	||lv_rec_pan_app_tg(i).v_cargo_x||'<{||}>'||									
                                                                                        'APPLN_ST_C:'	||'PROCESSED' ||	'<{||}>'||								
                                                                                        'SLOP_QTY_Q:'	||TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q)	||	'<{||}>'||
                                                                                        'SLUDGE_QTY_Q:'	||TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q)	||	'<{||}>'||
                                                                                        'SS_CONTENT_X:'	||lv_rec_pan_app_tg(i).v_SSContent_x||	'<{||}>'||
                                                                                        'SS_REP_FAC_X:'	||lv_rec_pan_app_tg(i).v_SSRepFac_x	||	'<{||}>'||									
                                                                                        'NAME_PER_REPORTING_X:'	||lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||									
                                                                                        'VSL_MMSI_N:'	||lv_rec_pan_app_tg(i).v_vsl_mmsi_n	||	'<{||}>'||
                                                                                        'CO_NAME_X:'	||lv_rec_pan_app_tg(i).v_coname_x	||	'<{||}>'||			
                                                                                        'ARMS_STRONG_RM_I:'	|| substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1 ,1)	||	'<{||}>'||
                                                                                        'ARMS_STRONG_RM_LOCN_X:'||	 lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x	||	'<{||}>'||
                                                                                        'MV_REM_X:'		||	 lv_rec_pan_app_tg(i).v_mvRem_x	||	'<{||}>'||									
                                                                                        'MV_HMS_X:'		||	 lv_rec_pan_app_tg(i).v_mvhms_x	||	'<{||}>'||
                                                                                        'GPP_C_I:'		||	 LV_GPP_c_i||'<{||}>'||
                                                                                        'BURNING_LNG_I:'||	 LV_BURNING_LNG_I ||	'<{||}>'||
                                                                                        'BURNING_CLN_FUEL_I:'	||	 LV_BURNING_CLN_FUEL_I||'<{||}>'||									
                                                                                        'BWMC_COM_C:'	||	 lv_rec_pan_app_tg(i).v_bwmc_c	||	'<{||}>'||									
                                                                                        'BWMC_D1_REASON_X:'	|| lv_rec_pan_app_tg(i).v_bwmcd1reason_x	||	'<{||}>'||								
                                                                                        'BWMC_D1_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd1discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D2_I:'	||lv_rec_pan_app_tg(i).v_bwmcd2_i	||	'<{||}>'||								
                                                                                        'BWMC_D2_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd2discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D4_I:'	||lv_rec_pan_app_tg(i).v_bwmcd4_i	||	'<{||}>'||
                                                                                        'USER_TITLE_X:'	||lv_rec_pan_app_tg(i).v_usertitle	||	'<{||}>'||
                                                                                        'LOCN_X:'		||lv_rec_pan_app_tg(i).v_locn_x	||	'<{||}>'||
                                                                                        'TIME_STAMP_DT:'|| lv_rec_pan_app_tg(i).v_timestamp_dt	||	'<{||}>'||
                                                                                        'ARMS_AMMUNITION_I:'||lv_rec_pan_app_tg(i).v_armsammunition_i	||	'<{||}>'||
                                                                                        'ARMS_TYPE_X:'	||lv_rec_pan_app_tg(i).v_armsType_x        	||	'<{||}>'||																		
                                                                                        'DG_CGO_MANF_I:'||lv_rec_pan_app_tg(i).v_dgcargopc_i	||	'<{||}>'||									
                                                                                        'PASSN_LIST_ICA_I:'	||	 lv_rec_pan_app_tg(i).v_paxlst_i	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETA_DT:'	||	 lv_rec_pan_app_tg(i).v_eta_dt	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETD_DT:'	||	 lv_rec_pan_app_tg(i).v_etd_dt	||	'<{||}>'||
                                                                                        'GRS_TNG_N:'	||	 lv_rec_pan_app_tg(i).v_vslgt_q	||	'<{||}>'||								
                                                                                        'ETA_DT:'		||	 lv_rec_pan_app_tg(i).v_BWMC_ETA_DT	||	'<{||}>'||
                                                                                        'VALID_BCC_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_validbcc_i)	||	'<{||}>'||
                                                                                        'MAN_REM_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_manRem_i)	||	'<{||}>'||									
                                                                                        'USER_ID_X:'	||	 lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||				
                                                                                        'CRT_BY_N:'	||	 'DATA MIGRATION'	||	'<{||}>'||
                                                                                        'CRT_ON_DT:'||	 SYSDATE ||	'<{||}>'||
                                                                                        'UPT_BY_X:'|| 'DATA MIGRATION' ||	'<{||}>'||
                                                                                        'UPT_ON_DT:'|| SYSDATE ||	'<{||}>'||
                                                                                        'LOCK_VER_N:'||0 ||	'<{||}>'||
                                                                                        'DELETED_I:'|| 0    ||	'<{||}>'||
                                                                                        'SEC_REF_I:'||0 ||	'<{||}>'||
                                                                                        'SECRTY_REM_X: '||lv_rec_pan_app_tg(i).V_SECRTY_REM_X|| '<{||}>'||
                                                                                        'SUBMISSION_MODE: '||lv_rec_pan_app_tg(i).V_SUBMISSION_MODE|| '<{||}>'||
                                                                                        'SHP_ARR_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X|| '<{||}>'||
                                                                                        'P_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SECU_LVL_SG_DESC_X: '||lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X|| '<{||}>'||
                                                                                        'LATD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'LONGD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'BWMC_COM_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X|| '<{||}>'||
                                                                                        'BWMC_D1_RSN_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X|| '<{||}>'||
                                                                                        'INTENDED_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SEC_REF_I: '||NVL(lv_rec_pan_app_tg(i).V_SEC_REF_I,0)
                                                                                        ;


i_excep_cnt := i_excep_cnt +1;

if i_excep_cnt < 50000  then 

pkg_datamigration_generic.proc_trace_exception('pan_APPLICATION', 'PROC_2_PAN_APP_VCALL', dbms_utility.format_error_backtrace,'ERROR',PV_RUN_ID,SQLERRM, v_exp_rows,'T');                                                                                       
end if;--i_excep_cnt < 50000  then 

continue;

END;     ---begin end for pan application


--end if;--if lv_rec_pan_app_tg(i).V_MSW_APPLN_REF_ID_X2 is  not null then


end if ; --V_VSL_CALL_ID IS NOT NULL THEN



















                         ELSE ---added by rohit  --V_VSL_CALL_ID IS NOT NULL OR V_VSLRECID_N IS NOT NULL  THEN

                                    BEGIN            --SI_PAN_UNTAGGED      

                                    INSERT INTO SI_PAN_UNTAGGED (
                                    VSL_REC_ID_N,
                                    PANSID_N	,
                                    MSW_VSL_ID_N	,
                                    MVVOYAGENO_X	,
                                    MVFWDDFT_Q	,
                                    MVMIDDFT_Q	,
                                    MVAFTDFT_Q	,
                                    MVHGT_Q	,
                                    VSLIMSCALLNO_C	,
                                    CSONAME_X	,
                                    CSOTELNO_C	,
                                    AGENTNAME_X	,
                                    LOCNLATLONG_X	,
                                    LOCNLONG_X	,
                                    AGENTTELNO_C	,
                                    AGENTFAXNO_C	,
                                    AGENTEMAIL	,
                                    SHIPEMAIL	,
                                    ANCHDAYSSTAY_N	,
                                    ANCHETA_DT	,
                                    ANCHETD_DT	,
                                    CARGO_X	,
                                    SHPSECPLAN_I	,
                                    SECURITYLEVEL_C	,
                                    SECURITYPER_I	,
                                    SLOPSLUDGE_I	,
                                    SLOPQTY_Q	,
                                    SLUDGEQTY_Q	,
                                    SSCONTENT_X	,
                                    SSREPFAC_X	,
                                    USERID_X	,
                                    SAFETYREM_I	,
                                    VSL_MMSI_N	,
                                    CONAME_X	,
                                    MVCONREM_I	,
                                    FIREHZREM_I	,
                                    ARMSSTRONGRM_I	,
                                    ARMSSTRONGRMLOCN_X	,
                                    MVREM_X	,
                                    MVHMS_I	,
                                    MVHMS_X	,
                                    GPP_C	,
                                    BWMC_I	,
                                    IBWMC_I	,
                                    BWMCEXEMPTED_I	,
                                    BWMC_C	,
                                    BWMCD1_I	,
                                    BWMCD1REASON_X	,
                                    BWMCD1DISCHARGE_I	,
                                    BWMCD1DISCHARGE_Q	,
                                    BWMCD2_I	,
                                    BWMCD2REASON_I	,
                                    BWMCD2DISCHARGE_I	,
                                    BWMCD2DISCHARGE_Q	,
                                    BWMCD4_I	,
                                    USERTITLE	,
                                    LOCN_X	,
                                    TIMESTAMP_DT	,
                                    ARMSAMMUNITION_I	,
                                    ARMSTYPE_X	,
                                    DGCARGO_C	,
                                    DGCARGOPC_I	,
                                    CREWLST_I	,
                                    PAXLST_I	,
                                    ETA_DT	,
                                    ETD_DT	,
                                    VSLGT_Q	,
                                    BWMC_ETA_DT	,
                                    VALIDBCC_I	,
                                    MANREM_I	,
                                    REPORTDATE_DT	,
                                    USERID_N	,
                                    MVDIRNFR_C	,
                                    PURPOSECALL_C	,
                                    OTHERSPURPOSE_X	,
                                    ANCHPURPOSE_C ,
                                    ANCHPURPOSE_X,
                                    VSLMVID_N,
                                    PORT_OF_REGY_C,
                                    VSL_CRAFT_LIC_N,
                                    VSL_NT_Q,
                                    SECRTY_REM_X,
                                    SUBMISSION_MODE,
                                    SHP_ARR_DIRN_DESC_X,
                                    P_LOCN_DESC_X,
                                    SECU_LVL_SG_DESC_X,
                                    LATD_DIRN_DESC_X,
                                    LONGD_DIRN_DESC_X,
                                    BWMC_COM_DESC_X,
                                    BWMC_D1_RSN_DESC_X,
                                    INTENDED_LOCN_DESC_X,
                                    SEC_REF_I
                                    ) 

                                    VALUES (
                                    lv_rec_pan_app_tg(i).v_VSL_REC_ID_N       	,
                                    lv_rec_pan_app_tg(i).v_pansid_n           	,
                                    lv_rec_pan_app_tg(i).v_msw_vsl_id_n       	,
                                    lv_rec_pan_app_tg(i).v_mvvoyageno_x       	,
                                    lv_rec_pan_app_tg(i).v_mvfwddft_q         	,
                                    lv_rec_pan_app_tg(i).v_mvmiddft_q         	,
                                    lv_rec_pan_app_tg(i).v_mvaftdft_q         	,
                                    lv_rec_pan_app_tg(i).v_mvhgt_q            	,
                                    lv_rec_pan_app_tg(i).v_vslimscallno_c     	,
                                    lv_rec_pan_app_tg(i).v_csoname_x          	,
                                    lv_rec_pan_app_tg(i).v_csotelno_c         	,
                                    lv_rec_pan_app_tg(i).v_agentname_x        	,
                                    lv_rec_pan_app_tg(i).v_locnlatlong_x      	,
                                    lv_rec_pan_app_tg(i).v_locnlong_x         	,
                                    lv_rec_pan_app_tg(i).v_agenttelno_c       	,
                                    lv_rec_pan_app_tg(i).v_agentfaxno_c       	,
                                    lv_rec_pan_app_tg(i).v_agentemail         	,
                                    lv_rec_pan_app_tg(i).v_shipemail          	,
                                    lv_rec_pan_app_tg(i).v_anchdaysstay_n     	,
                                    lv_rec_pan_app_tg(i).v_ancheta_dt         	,
                                    lv_rec_pan_app_tg(i).v_anchetd_dt         	,
                                    lv_rec_pan_app_tg(i).v_cargo_x            	,
                                    lv_rec_pan_app_tg(i).v_shpsecplan_i       	,
                                    lv_rec_pan_app_tg(i).v_securitylevel_c    	,
                                    lv_rec_pan_app_tg(i).v_securityper_i      	,
                                    lv_rec_pan_app_tg(i).v_slopsludge_i       	,
                                    lv_rec_pan_app_tg(i).v_slopqty_q          	,
                                    lv_rec_pan_app_tg(i).v_sludgeqty_q        	,
                                    lv_rec_pan_app_tg(i).v_sscontent_x        	,
                                    lv_rec_pan_app_tg(i).v_ssrepfac_x         	,
                                    lv_rec_pan_app_tg(i).v_userid_x           	,
                                    lv_rec_pan_app_tg(i).v_safetyrem_i        	,
                                    lv_rec_pan_app_tg(i).v_vsl_mmsi_n         	,
                                    lv_rec_pan_app_tg(i).v_coname_x           	,
                                    lv_rec_pan_app_tg(i).v_mvconrem_i         	,
                                    lv_rec_pan_app_tg(i).v_firehzrem_i        	,
                                    lv_rec_pan_app_tg(i).v_armsstrongrm_i     	,
                                    lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x 	,
                                    lv_rec_pan_app_tg(i).v_mvrem_x            	,
                                    lv_rec_pan_app_tg(i).v_mvhms_i            	,
                                    lv_rec_pan_app_tg(i).v_mvhms_x            	,
                                    lv_rec_pan_app_tg(i).v_gpp_c              	,
                                    lv_rec_pan_app_tg(i).v_bwmc_i             	,
                                    lv_rec_pan_app_tg(i).v_ibwmc_i            	,
                                    lv_rec_pan_app_tg(i).v_bwmcexempted_i     	,
                                    lv_rec_pan_app_tg(i).v_bwmc_c             	,
                                    lv_rec_pan_app_tg(i).v_bwmcd1_i           	,
                                    lv_rec_pan_app_tg(i).v_bwmcd1reason_x     	,
                                    lv_rec_pan_app_tg(i).v_bwmcd1discharge_i  	,
                                    lv_rec_pan_app_tg(i).v_bwmcd1discharge_q  	,
                                    lv_rec_pan_app_tg(i).v_bwmcd2_i           	,
                                    lv_rec_pan_app_tg(i).v_bwmcd2reason_i     	,
                                    lv_rec_pan_app_tg(i).v_bwmcd2discharge_i  	,
                                    lv_rec_pan_app_tg(i).v_bwmcd2discharge_q  	,
                                    lv_rec_pan_app_tg(i).v_bwmcd4_i           	,
                                    lv_rec_pan_app_tg(i).v_usertitle          	,
                                    lv_rec_pan_app_tg(i).v_locn_x             	,
                                    lv_rec_pan_app_tg(i).v_timestamp_dt       	,
                                    lv_rec_pan_app_tg(i).v_armsammunition_i   	,
                                    lv_rec_pan_app_tg(i).v_armstype_x         	,
                                    lv_rec_pan_app_tg(i).v_dgcargo_c          	,
                                    lv_rec_pan_app_tg(i).v_dgcargopc_i        	,
                                    lv_rec_pan_app_tg(i).v_crewlst_i          	,
                                    lv_rec_pan_app_tg(i).v_paxlst_i           	,
                                    lv_rec_pan_app_tg(i).v_eta_dt             	,
                                    lv_rec_pan_app_tg(i).v_etd_dt             	,
                                    lv_rec_pan_app_tg(i).v_vslgt_q            	,
                                    lv_rec_pan_app_tg(i).v_BWMC_ETA_DT        	,
                                    lv_rec_pan_app_tg(i).v_validbcc_i         	,
                                    lv_rec_pan_app_tg(i).v_MANREM_I           	,
                                    lv_rec_pan_app_tg(i).v_reportdate_dt      	,
                                    lv_rec_pan_app_tg(i).v_userid_n           	,
                                    lv_rec_pan_app_tg(i).v_MVDIRNFR_C         	,
                                    lv_rec_pan_app_tg(i).v_purposecall_c      	,
                                    lv_rec_pan_app_tg(i).v_otherspurpose_x    	,
                                    lv_rec_pan_app_tg(i).v_anchpurpose_c      	,
                                    lv_rec_pan_app_tg(i).v_anchpurpose_x      	,
                                    lv_rec_pan_app_tg(i).V_VSLMVID_N    ,
                                    lv_rec_pan_app_tg(i).V_PORT_OF_REGY_C,
                                    lv_rec_pan_app_tg(i).V_VSL_CRAFT_LIC_N,
                                    lv_rec_pan_app_tg(i).V_VSL_NT_Q,
                                      lv_rec_pan_app_tg(i).V_SECRTY_REM_X,
                                      lv_rec_pan_app_tg(i).V_SUBMISSION_MODE,
                                      lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X,
                                      lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X,
                                      lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X,
                                      lv_rec_pan_app_tg(i).V_SEC_REF_I
                                    );

                                    v_si_untagged := 1;

                            EXCEPTION           --       SI_PAN_UNTAGGED                          
                                WHEN OTHERS THEN
                                    V_ERR_CODE := SQLCODE;
                                    V_ERR_MSG := SQLERRM;
                                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| V_ERR_CODE || V_ERR_MSG||DBMS_UTILITY.FORMAT_CALL_STACK;
                                     V_EXP_ROWS_SI := 
                                                ' VSL_REC_ID_N: '||lv_rec_pan_app_tg(i).v_VSL_REC_ID_N       ||
                                                ' PANSID_N: '||lv_rec_pan_app_tg(i).v_pansid_n           ||
                                                ' MSW_VSL_ID_N: '||lv_rec_pan_app_tg(i).v_msw_vsl_id_n       ||
                                                ' MVVOYAGENO_X: '||lv_rec_pan_app_tg(i).v_mvvoyageno_x       ||
                                                ' MVFWDDFT_Q: '||lv_rec_pan_app_tg(i).v_mvfwddft_q         ||
                                                ' MVMIDDFT_Q: '||lv_rec_pan_app_tg(i).v_mvmiddft_q         ||
                                                ' MVAFTDFT_Q: '||lv_rec_pan_app_tg(i).v_mvaftdft_q         ||
                                                ' MVHGT_Q: '||lv_rec_pan_app_tg(i).v_mvhgt_q            ||
                                                ' VSLIMSCALLNO_C: '||lv_rec_pan_app_tg(i).v_vslimscallno_c     ||
                                                ' CSONAME_X: '||lv_rec_pan_app_tg(i).v_csoname_x          ||
                                                ' CSOTELNO_C: '||lv_rec_pan_app_tg(i).v_csotelno_c         ||
                                                ' AGENTNAME_X: '||lv_rec_pan_app_tg(i).v_agentname_x        ||
                                                ' LOCNLATLONG_X: '||lv_rec_pan_app_tg(i).v_locnlatlong_x      ||
                                                ' LOCNLONG_X: '||lv_rec_pan_app_tg(i).v_locnlong_x         ||
                                                ' AGENTTELNO_C: '||lv_rec_pan_app_tg(i).v_agenttelno_c       ||
                                                ' AGENTFAXNO_C: '||lv_rec_pan_app_tg(i).v_agentfaxno_c       ||
                                                ' AGENTEMAIL: '||lv_rec_pan_app_tg(i).v_agentemail         ||
                                                ' SHIPEMAIL: '||lv_rec_pan_app_tg(i).v_shipemail          ||
                                                ' ANCHDAYSSTAY_N: '||lv_rec_pan_app_tg(i).v_anchdaysstay_n     ||
                                                ' ANCHETA_DT: '||lv_rec_pan_app_tg(i).v_ancheta_dt         ||
                                                ' ANCHETD_DT: '||lv_rec_pan_app_tg(i).v_anchetd_dt         ||
                                                ' CARGO_X: '||lv_rec_pan_app_tg(i).v_cargo_x            ||
                                                ' SHPSECPLAN_I: '||lv_rec_pan_app_tg(i).v_shpsecplan_i       ||
                                                ' SECURITYLEVEL_C: '||lv_rec_pan_app_tg(i).v_securitylevel_c    ||
                                                ' SECURITYPER_I: '||lv_rec_pan_app_tg(i).v_securityper_i      ||
                                                ' SLOPSLUDGE_I: '||lv_rec_pan_app_tg(i).v_slopsludge_i       ||
                                                ' SLOPQTY_Q: '||lv_rec_pan_app_tg(i).v_slopqty_q          ||
                                                ' SLUDGEQTY_Q: '||lv_rec_pan_app_tg(i).v_sludgeqty_q        ||
                                                ' SSCONTENT_X: '||lv_rec_pan_app_tg(i).v_sscontent_x        ||
                                                ' SSREPFAC_X: '||lv_rec_pan_app_tg(i).v_ssrepfac_x         ||
                                                ' USERID_X: '||lv_rec_pan_app_tg(i).v_userid_x           ||
                                                ' SAFETYREM_I: '||lv_rec_pan_app_tg(i).v_safetyrem_i        ||
                                                ' VSL_MMSI_N: '||lv_rec_pan_app_tg(i).v_vsl_mmsi_n         ||
                                                ' CONAME_X: '||lv_rec_pan_app_tg(i).v_coname_x           ||
                                                ' MVCONREM_I: '||lv_rec_pan_app_tg(i).v_mvconrem_i         ||
                                                ' FIREHZREM_I: '||lv_rec_pan_app_tg(i).v_firehzrem_i        ||
                                                ' ARMSSTRONGRM_I: '||lv_rec_pan_app_tg(i).v_armsstrongrm_i     ||
                                                ' ARMSSTRONGRMLOCN_X: '||lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x ||
                                                ' MVREM_X: '||lv_rec_pan_app_tg(i).v_mvrem_x            ||
                                                ' MVHMS_I: '||lv_rec_pan_app_tg(i).v_mvhms_i            ||
                                                ' MVHMS_X: '||lv_rec_pan_app_tg(i).v_mvhms_x            ||
                                                ' GPP_C: '||lv_rec_pan_app_tg(i).v_gpp_c              ||
                                                ' BWMC_I: '||lv_rec_pan_app_tg(i).v_bwmc_i             ||
                                                ' IBWMC_I: '||lv_rec_pan_app_tg(i).v_ibwmc_i            ||
                                                ' BWMCEXEMPTED_I: '||lv_rec_pan_app_tg(i).v_bwmcexempted_i     ||
                                                ' BWMC_C: '||lv_rec_pan_app_tg(i).v_bwmc_c             ||
                                                ' BWMCD1_I: '||lv_rec_pan_app_tg(i).v_bwmcd1_i           ||
                                                ' BWMCD1REASON_X: '||lv_rec_pan_app_tg(i).v_bwmcd1reason_x     ||
                                                ' BWMCD1DISCHARGE_I: '||lv_rec_pan_app_tg(i).v_bwmcd1discharge_i  ||
                                                ' BWMCD1DISCHARGE_Q: '||lv_rec_pan_app_tg(i).v_bwmcd1discharge_q  ||
                                                ' BWMCD2_I: '||lv_rec_pan_app_tg(i).v_bwmcd2_i           ||
                                                ' BWMCD2REASON_I: '||lv_rec_pan_app_tg(i).v_bwmcd2reason_i     ||
                                                ' BWMCD2DISCHARGE_I: '||lv_rec_pan_app_tg(i).v_bwmcd2discharge_i  ||
                                                ' BWMCD2DISCHARGE_Q: '||lv_rec_pan_app_tg(i).v_bwmcd2discharge_q  ||
                                                ' BWMCD4_I: '||lv_rec_pan_app_tg(i).v_bwmcd4_i           ||
                                                ' USERTITLE: '||lv_rec_pan_app_tg(i).v_usertitle          ||
                                                ' LOCN_X: '||lv_rec_pan_app_tg(i).v_locn_x             ||
                                                ' TIMESTAMP_DT: '||lv_rec_pan_app_tg(i).v_timestamp_dt       ||
                                                ' ARMSAMMUNITION_I: '||lv_rec_pan_app_tg(i).v_armsammunition_i   ||
                                                ' ARMSTYPE_X: '||lv_rec_pan_app_tg(i).v_armstype_x         ||
                                                ' DGCARGO_C: '||lv_rec_pan_app_tg(i).v_dgcargo_c          ||
                                                ' DGCARGOPC_I: '||lv_rec_pan_app_tg(i).v_dgcargopc_i        ||
                                                ' CREWLST_I: '||lv_rec_pan_app_tg(i).v_crewlst_i          ||
                                                ' PAXLST_I: '||lv_rec_pan_app_tg(i).v_paxlst_i           ||
                                                ' ETA_DT: '||lv_rec_pan_app_tg(i).v_eta_dt             ||
                                                ' ETD_DT: '||lv_rec_pan_app_tg(i).v_etd_dt             ||
                                                ' VSLGT_Q: '||lv_rec_pan_app_tg(i).v_vslgt_q            ||
                                                ' BWMC_ETA_DT: '||lv_rec_pan_app_tg(i).v_BWMC_ETA_DT        ||
                                                ' VALIDBCC_I: '||lv_rec_pan_app_tg(i).v_validbcc_i         ||
                                                ' MANREM_I: '||lv_rec_pan_app_tg(i).v_MANREM_I           ||
                                                ' REPORTDATE_DT: '||lv_rec_pan_app_tg(i).v_reportdate_dt      ||
                                                ' USERID_N: '||lv_rec_pan_app_tg(i).v_userid_n           ||
                                                ' MVDIRNFR_C: '||lv_rec_pan_app_tg(i).v_MVDIRNFR_C         ||
                                                ' PURPOSECALL_C: '||lv_rec_pan_app_tg(i).v_purposecall_c      ||
                                                ' OTHERSPURPOSE_X: '||lv_rec_pan_app_tg(i).v_otherspurpose_x    ||
                                                ' ANCHPURPOSE_C : '||lv_rec_pan_app_tg(i).v_anchpurpose_c      ||
                                                ' ANCHPURPOSE_X: '||lv_rec_pan_app_tg(i).v_anchpurpose_x      ||
                                                ' VSLMVID_N: '||lv_rec_pan_app_tg(i).V_VSLMVID_N ||
                                                'PORT_OF_REGY_C: '||lv_rec_pan_app_tg(i).V_PORT_OF_REGY_C||
                                                'VSL_CRAFT_LIC_N: '||lv_rec_pan_app_tg(i).V_VSL_CRAFT_LIC_N||
                                                'VSL_NT_Q: '||lv_rec_pan_app_tg(i).V_VSL_NT_Q||
                                                'SECRTY_REM_X: '||lv_rec_pan_app_tg(i).V_SECRTY_REM_X||
                                                'SUBMISSION_MODE: '||lv_rec_pan_app_tg(i).V_SUBMISSION_MODE||
                                                'SHP_ARR_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X||
                                                'P_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X||
                                                'SECU_LVL_SG_DESC_X: '||lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X||
                                                'LATD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X||
                                                'LONGD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X||
                                                'BWMC_COM_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X||
                                                'BWMC_D1_RSN_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X||
                                                'INTENDED_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X||
                                                'SEC_REF_I: '||lv_rec_pan_app_tg(i).V_SEC_REF_I
                                                ;



                                  I_EXCEP_CNT_SI := I_EXCEP_CNT_SI +1;

                                IF I_EXCEP_CNT_SI < 50000  THEN 

                                 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_PAN_UNTAGGED', 
                                 'PROC_2_PAN_APP_VCALL',
                                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE , 
                                 'ERROR',
                                 PV_RUN_ID,
                                 DBMS_UTILITY.FORMAT_ERROR_STACK ||V_SQLERRM,
                                 V_EXP_ROWS_SI  ,
                                 'T');

                                END IF;--I_EXCEP_CNT_SI < 50000 

                        END; --SI_PAN_UNTAGGED

                        END IF;--V_VSL_CALL_ID IS NOT NULL OR V_VSLRECID_N IS NOT NULL  THEN











else  --lv_rec_pan_app_tg(i).V_MSW_APPLN_REF_ID_X2 is  null

                                    v_msw_appln_ref_id_x := lv_rec_pan_app_tg(i).V_MSW_APPLN_REF_ID_X2 ;

                                    V_VSL_CALL_ID := LV_REC_PAN_APP_TG(I).V_VSL_CALL_ID_N;

                                   SELECT  DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'N',0,'L',1,1) 
                                   INTO LV_GPP_c_i 
                                   FROM DUAL;

                                   if   TRIM(lv_rec_pan_app_tg(i).v_GPP_c) = 'N' then 
                                   LV_BURNING_LNG_I  := Null;
                                   LV_BURNING_CLN_FUEL_I := Null;
                                   end if;


                                   SELECT DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',1,'Y',0,NULL) INTO LV_BURNING_LNG_I FROM DUAL;
                                   SELECT DECODE(TRIM(lv_rec_pan_app_tg(i).v_GPP_c),'L',0,'Y',1,NULL)INTO LV_BURNING_CLN_FUEL_I FROM DUAL;

                                         Begin    -- inner begin to insert data into pan application

                                                                    INSERT INTO pan_application (

                                                                        APPLN_REF_N,
                                                                        VSL_CALL_ID_N,
                                                                        MSW_APPLN_REF_ID_X,
                                                                        EXTL_APPLN_REF_ID_X,
                                                                        MSW_VSL_ID_N,
                                                                        VOY_X,
                                                                        APPLCNT_ID_X,
                                                                        ARR_FWD_DFT_Q,
                                                                        ARR_MID_DFT_Q,
                                                                        ARR_AFT_DFT_Q,
                                                                        AIR_DFT_Q,
                                                                        VSL_IMS_CALL_NO_C,
                                                                        CSO_M,
                                                                        CSO_TEL_N,
                                                                        AGT_NM_M,
                                                                        LOCN_LAT_N,
                                                                        LOCN_LONG_N,
                                                                        AGT_TEL_N,
                                                                        AGT_FAX_N,
                                                                        AGT_EMAIL_X,
                                                                        SHP_EMAIL_X,
                                                                        ANCH_DURN_N,
                                                                        ANCH_ETA_DT,
                                                                        ANCH_ETD_DT,
                                                                        CGO_DESC_X,
                                                                        SHP_SECU_PLAN_I,
                                                                        SECU_LVL_SG_C,
                                                                        SECU_PERS_I,
                                                                        APPLN_ST_C,
                                                                        SLOP_SLUDGE_I,
                                                                        SLOP_QTY_Q,
                                                                        SLUDGE_QTY_Q,
                                                                        SS_CONTENT_X,
                                                                        SS_REP_FAC_X,
                                                                        HEIGHT_N,
                                                                        NAME_PER_REPORTING_X,
                                                                        SAFETY_SEC_AFFECT_I,
                                                                        VSL_MMSI_N,
                                                                        CO_NAME_X,
                                                                        MV_CON_REM_I,
                                                                        SAFETY_REM_I,
                                                                        FIRE_HZ_REM_I,
                                                                        ARMS_STRONG_RM_I,
                                                                        ARMS_STRONG_RM_LOCN_X,
                                                                        MV_REM_X,
                                                                        MV_HMS_I,
                                                                        MV_HMS_X,
                                                                        GPP_C_I,
                                                                        BURNING_LNG_I,
                                                                        BURNING_CLN_FUEL_I,
                                                                        BWMC_I,
                                                                        IBWMC_I,
                                                                        BWMC_EXEMPTED_I,
                                                                        BWMC_COM_C,
                                                                        BWMC_D1_I,
                                                                        BWMC_D1_REASON_X,
                                                                        BWMC_D1_DISCHARGE_I,
                                                                        BWMC_D1_DISCHARGE_Q,
                                                                        BWMC_D2_I,
                                                                        BWMC_D2_REASON_I,
                                                                        BWMC_D2_DISCHARGE_I,
                                                                        BWMC_D2_DISCHARGE_Q,
                                                                        BWMC_D4_I,
                                                                        USER_TITLE_X,
                                                                        LOCN_X,
                                                                        TIME_STAMP_DT,
                                                                        ARMS_AMMUNITION_I,
                                                                        ARMS_TYPE_X,
                                                                        ARMS_QTY_Q,
                                                                        HNS_I,
                                                                        DG_ON_BOARD_I,
                                                                        DG_CGO_MANF_I,
                                                                        CR_LIST_I,
                                                                        PASSN_LIST_ICA_I,
                                                                        PORT_FACILITY_ETA_DT,
                                                                        PORT_FACILITY_ETD_DT,
                                                                        GRS_TNG_N,
                                                                        IS_NOA_I,
                                                                        DRAFT_X,
                                                                        LAST_PORT_X,
                                                                        ETA_DT,
                                                                        VALID_BCC_I,
                                                                        MAN_REM_I,
                                                                        SAFETY_SECURITY_I,
                                                                        LOCATION_X,
                                                                        OTHER_LOCATION_X,
                                                                        MV_STM_DT,
                                                                        LOCN_TO_X,
                                                                        MARPOL_I,
                                                                        OTERM_FAC_C,
                                                                        OTERM_FAC_X,
                                                                        TRANS_ID_N,
                                                                        NEW_NOA_I,
                                                                        PAGER_X,
                                                                        SESS_X,
                                                                        OTH_REM_I,
                                                                        ARMS_SRC_I,
                                                                        SOURCE_I,
                                                                        USER_ID_X,
                                                                        LATD_DIRCN_C,
                                                                        LONGD_DIRCN_C,
                                                                        SHP_ARVL_DIRCN_C,
                                                                        SUBR_EMAIL_I,
                                                                        SUBR_SMS_I,
                                                                        PROCESSING_REM_X,
                                                                        PROCESSED_BY_X,
                                                                        PROCESSED_ON_DT,
                                                                        CRT_BY_N,
                                                                        CRT_ON_DT,
                                                                        UPT_BY_X,
                                                                        UPT_ON_DT,
                                                                        LOCK_VER_N,
                                                                        DELETED_I,
                                                                        SECRTY_REM_X,
                                                                        ETD_DT,
                                                                        SUBMISSION_MODE,
                                                                        SHP_ARR_DIRN_DESC_X,
                                                                        P_LOCN_DESC_X,
                                                                        SECU_LVL_SG_DESC_X,
                                                                        LATD_DIRN_DESC_X,
                                                                        LONGD_DIRN_DESC_X,
                                                                        BWMC_COM_DESC_X,
                                                                        BWMC_D1_RSN_DESC_X,
                                                                        INTENDED_LOCN_DESC_X,
                                                                        SEC_REF_I
                                                                    ) VALUES (
                                                                            seq_pan_app.nextval,
                                                                            V_VSL_CALL_ID ,    
                                                                            v_msw_appln_ref_id_x,         
                                                                            lv_rec_pan_app_tg(i).v_pansid_n,
                                                                            lv_rec_pan_app_tg(i).v_msw_vsl_id_n,
                                                                            lv_rec_pan_app_tg(i).v_mvvoyageno_x,
                                                                            'D1',                                                  ---Pending on User Service Data Model
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10,     
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10,
                                                                            LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10  ,    
                                                                            lv_rec_pan_app_tg(i).v_mvHgt_q,
                                                                            lv_rec_pan_app_tg(i).v_vslimscallno_c,
                                                                            lv_rec_pan_app_tg(i).v_csoname_x,
                                                                            lv_rec_pan_app_tg(i).v_csotelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentname_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlatlong_x,
                                                                            lv_rec_pan_app_tg(i).v_locnlong_x,
                                                                            lv_rec_pan_app_tg(i).v_agenttelno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentfaxno_c,
                                                                            lv_rec_pan_app_tg(i).v_agentEmail,
                                                                            lv_rec_pan_app_tg(i).v_shipEmail,
                                                                            lv_rec_pan_app_tg(i).v_anchdaysstay_n,
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt, 'yyyymmdd HH24:MI:SS'),                 
                                                                            lv_rec_pan_app_tg(i).v_cargo_x,
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_shpsecplan_i), 'N', 0, 'Y',1),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securitylevel_c), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'),
                                                                            DECODE(TRIM(lv_rec_pan_app_tg(i).v_securityper_i), 'N', 0, 'Y', 1),
                                                                            'PROCESSED',                                            ---as per mapping sheet
                                                                            decode(TRIM(lv_rec_pan_app_tg(i).v_slopSludge_i), 'N',0,'Y',1),
                                                                            TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q),
                                                                            TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q),
                                                                            lv_rec_pan_app_tg(i).v_SSContent_x,
                                                                            lv_rec_pan_app_tg(i).v_SSRepFac_x,
                                                                            0,                                              --according to mapping sheet
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(trim(lv_rec_pan_app_tg(i).v_safetyRem_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_vsl_mmsi_n,
                                                                            lv_rec_pan_app_tg(i).v_coname_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvConRem_i),'N',0,'Y',1),
                                                                            0,                                          --according to mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_fireHzRem_i),'N',0,'Y',1),
                                                                            substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1, 1),
                                                                            lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x,
                                                                            lv_rec_pan_app_tg(i).v_mvRem_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvhms_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_mvhms_x,
                                                                            LV_GPP_c_i ,                            
                                                                            LV_BURNING_LNG_I,                                
                                                                            LV_BURNING_CLN_FUEL_I ,                                
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_ibwmc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcexempted_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmc_c,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1reason_x,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd1discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd1discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2_i,
                                                                            Decode(Trim(lv_rec_pan_app_tg(i).v_bwmcd2reason_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_bwmcd2discharge_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_bwmcd2discharge_q,
                                                                            lv_rec_pan_app_tg(i).v_bwmcd4_i,
                                                                            lv_rec_pan_app_tg(i).v_usertitle,
                                                                            lv_rec_pan_app_tg(i).v_locn_x,
                                                                            lv_rec_pan_app_tg(i).v_timestamp_dt,
                                                                            decode(lv_rec_pan_app_tg(i).v_armsammunition_i,'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_armsType_x,         
                                                                            0,
                                                                            0,                                                --- accordingly to a mapping sheet
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_dgcargo_c),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_dgcargopc_i,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_crewlst_i),'N',0,'Y',1),
                                                                            lv_rec_pan_app_tg(i).v_paxlst_i,
                                                                            lv_rec_pan_app_tg(i).v_eta_dt,
                                                                            lv_rec_pan_app_tg(i).v_etd_dt,
                                                                            lv_rec_pan_app_tg(i).v_vslgt_q,
                                                                            0,
                                                                            'DM',                                            ---pending
                                                                            'DM',
                                                                            lv_rec_pan_app_tg(i).v_BWMC_ETA_DT,
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_validbcc_i),'N',0,'Y',1),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_manRem_i),'N',0,'Y',1),
                                                                            0,
                                                                            'PAN',
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).v_userid_x,
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnlatlong_x),-1),'N','NORTH','S','SOUTH'),
                                                                            DECODE(substr(trim(lv_rec_pan_app_tg(i).v_locnLong_x),-1),'W', 'WEST', 'E', 'EAST'),
                                                                            DECODE(Trim(lv_rec_pan_app_tg(i).v_mvDirnFr_c) , 'W', 'WEST', 'E', 'EAST','S', 'SOUTN', 'N', 'NORTH'),
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            NULL,
                                                                            'DATA MIGRATION',
                                                                            sysdate,
                                                                            'DATA MIGRATION',
                                                                            sysdate,
                                                                            0,
                                                                            0,
                                                                            lv_rec_pan_app_tg(i).V_SECRTY_REM_X,
                                                                            NULL,
                                                                            lv_rec_pan_app_tg(i).V_SUBMISSION_MODE,
                                                                            lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X,
                                                                            lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X,
                                                                            0
                                                                          );



                                                    ------------------------------



                                                    EXCEPTION --inner exception for PAN_APPLICATION
                                                                    WHEN OTHERS THEN
                                                                    ---deleting records from vessel_call and Application_submission  table when we get exception while inserting records in PAN_APPLICATION
                                                                  --    DELETE FROM vessel_call     
                                                                   --     WHERE   vsl_call_id_n = v_msw_vsl_call_id;

                                                                     --  DELETE FROM Application_submission     
                                                                --  WHERE   VSL_CALL_ID_N = v_msw_vsl_call_id;

                                                                        v_err_code := sqlcode;
                                                                        v_err_msg := substr(sqlerrm, 1, 200);
                                                                        v_sqlerrm := v_err_code
                                                                                     || v_err_msg
                                                                                     || dbms_utility.format_error_backtrace;




                                                                        v_exp_rows:=    'APPLN_REF_N :'	||seq_pan_app.currval||'<{||}>'||
                                                                                        'VSL_CALL_ID_N,:'|| V_VSL_CALL_ID||'<{||}>'||
                                                                                        'MSW_APPLN_REF_ID_X:'|| v_msw_appln_ref_id_x||'<{||}>'||
                                                                                        'EXTL_APPLN_REF_ID_X:'||lv_rec_pan_app_tg(i).v_pansid_n	||'<{||}>'||
                                                                                        'MSW_VSL_ID_N:' ||lv_rec_pan_app_tg(i).v_msw_vsl_id_n||'<{||}>'||
                                                                                        'VOY_X:'		||lv_rec_pan_app_tg(i).v_mvvoyageno_x||'<{||}>'||
                                                                                        'APPLCNT_ID_X:'	||'D1'||'<{||}>'  ||           
                                                                                        'ARR_FWD_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvfwddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_MID_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvmiddft_q,'0')/10||'<{||}>'||
                                                                                        'ARR_AFT_DFT_Q:'||LTRIM(lv_rec_pan_app_tg(i).v_mvaftdft_q,'0')/10||'<{||}>'||
                                                                                        'AIR_DFT_Q:'	||lv_rec_pan_app_tg(i).v_mvHgt_q	||	'<{||}>'||
                                                                                        'VSL_IMS_CALL_NO_C:'||lv_rec_pan_app_tg(i).v_vslimscallno_c	||'<{||}>'||
                                                                                        'CSO_M:'		||lv_rec_pan_app_tg(i).v_csoname_x||'<{||}>'||
                                                                                        'CSO_TEL_N:'	||lv_rec_pan_app_tg(i).v_csotelno_c	||'<{||}>'||
                                                                                        'AGT_NM_M:'		||lv_rec_pan_app_tg(i).v_agentname_x||'<{||}>'||
                                                                                        'LOCN_LAT_N:'	||lv_rec_pan_app_tg(i).v_locnlatlong_x||'<{||}>'||
                                                                                        'LOCN_LONG_N:'	||lv_rec_pan_app_tg(i).v_locnlong_x	||'<{||}>'||
                                                                                        'AGT_TEL_N:'	||lv_rec_pan_app_tg(i).v_agenttelno_c||'<{||}>'||
                                                                                        'AGT_FAX_N:'	||lv_rec_pan_app_tg(i).v_agentfaxno_c||'<{||}>'||
                                                                                        'AGT_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_agentEmail	||'<{||}>'||
                                                                                        'SHP_EMAIL_X:'	||lv_rec_pan_app_tg(i).v_shipEmail	||'<{||}>'||
                                                                                        'ANCH_DURN_N:'	||lv_rec_pan_app_tg(i).v_anchdaysstay_n	||	'<{||}>'||
                                                                                        'ANCH_ETA_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_ancheta_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'ANCH_ETD_DT:'	||to_timestamp(lv_rec_pan_app_tg(i).v_anchetd_dt ,'yyyymmdd HH24:MI:SS')||'<{||}>'||
                                                                                        'CGO_DESC_X:'	||lv_rec_pan_app_tg(i).v_cargo_x||'<{||}>'||									
                                                                                        'APPLN_ST_C:'	||'PROCESSED' ||	'<{||}>'||								
                                                                                        'SLOP_QTY_Q:'	||TO_NUMBER (lv_rec_pan_app_tg(i).v_slopQty_q)	||	'<{||}>'||
                                                                                        'SLUDGE_QTY_Q:'	||TO_NUMBER(lv_rec_pan_app_tg(i).v_sludgeQty_q)	||	'<{||}>'||
                                                                                        'SS_CONTENT_X:'	||lv_rec_pan_app_tg(i).v_SSContent_x||	'<{||}>'||
                                                                                        'SS_REP_FAC_X:'	||lv_rec_pan_app_tg(i).v_SSRepFac_x	||	'<{||}>'||									
                                                                                        'NAME_PER_REPORTING_X:'	||lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||									
                                                                                        'VSL_MMSI_N:'	||lv_rec_pan_app_tg(i).v_vsl_mmsi_n	||	'<{||}>'||
                                                                                        'CO_NAME_X:'	||lv_rec_pan_app_tg(i).v_coname_x	||	'<{||}>'||			
                                                                                        'ARMS_STRONG_RM_I:'	|| substr(lv_rec_pan_app_tg(i).v_armsstrongrm_i, 1 ,1)	||	'<{||}>'||
                                                                                        'ARMS_STRONG_RM_LOCN_X:'||	 lv_rec_pan_app_tg(i).v_armsstrongrmlocn_x	||	'<{||}>'||
                                                                                        'MV_REM_X:'		||	 lv_rec_pan_app_tg(i).v_mvRem_x	||	'<{||}>'||									
                                                                                        'MV_HMS_X:'		||	 lv_rec_pan_app_tg(i).v_mvhms_x	||	'<{||}>'||
                                                                                        'GPP_C_I:'		||	 LV_GPP_c_i||'<{||}>'||
                                                                                        'BURNING_LNG_I:'||	 LV_BURNING_LNG_I ||	'<{||}>'||
                                                                                        'BURNING_CLN_FUEL_I:'	||	 LV_BURNING_CLN_FUEL_I||'<{||}>'||									
                                                                                        'BWMC_COM_C:'	||	 lv_rec_pan_app_tg(i).v_bwmc_c	||	'<{||}>'||									
                                                                                        'BWMC_D1_REASON_X:'	|| lv_rec_pan_app_tg(i).v_bwmcd1reason_x	||	'<{||}>'||								
                                                                                        'BWMC_D1_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd1discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D2_I:'	||lv_rec_pan_app_tg(i).v_bwmcd2_i	||	'<{||}>'||								
                                                                                        'BWMC_D2_DISCHARGE_Q:'	||lv_rec_pan_app_tg(i).v_bwmcd2discharge_q	||	'<{||}>'||
                                                                                        'BWMC_D4_I:'	||lv_rec_pan_app_tg(i).v_bwmcd4_i	||	'<{||}>'||
                                                                                        'USER_TITLE_X:'	||lv_rec_pan_app_tg(i).v_usertitle	||	'<{||}>'||
                                                                                        'LOCN_X:'		||lv_rec_pan_app_tg(i).v_locn_x	||	'<{||}>'||
                                                                                        'TIME_STAMP_DT:'|| lv_rec_pan_app_tg(i).v_timestamp_dt	||	'<{||}>'||
                                                                                        'ARMS_AMMUNITION_I:'||lv_rec_pan_app_tg(i).v_armsammunition_i	||	'<{||}>'||
                                                                                        'ARMS_TYPE_X:'	||lv_rec_pan_app_tg(i).v_armsType_x        	||	'<{||}>'||																		
                                                                                        'DG_CGO_MANF_I:'||lv_rec_pan_app_tg(i).v_dgcargopc_i	||	'<{||}>'||									
                                                                                        'PASSN_LIST_ICA_I:'	||	 lv_rec_pan_app_tg(i).v_paxlst_i	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETA_DT:'	||	 lv_rec_pan_app_tg(i).v_eta_dt	||	'<{||}>'||
                                                                                        'PORT_FACILITY_ETD_DT:'	||	 lv_rec_pan_app_tg(i).v_etd_dt	||	'<{||}>'||
                                                                                        'GRS_TNG_N:'	||	 lv_rec_pan_app_tg(i).v_vslgt_q	||	'<{||}>'||								
                                                                                        'ETA_DT:'		||	 lv_rec_pan_app_tg(i).v_BWMC_ETA_DT	||	'<{||}>'||
                                                                                        'VALID_BCC_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_validbcc_i)	||	'<{||}>'||
                                                                                        'MAN_REM_I:'	||	 to_number(lv_rec_pan_app_tg(i).v_manRem_i)	||	'<{||}>'||									
                                                                                        'USER_ID_X:'	||	 lv_rec_pan_app_tg(i).v_userid_x	||	'<{||}>'||				
                                                                                        'CRT_BY_N:'	||	 'DATA MIGRATION'	||	'<{||}>'||
                                                                                        'CRT_ON_DT:'||	 SYSDATE ||	'<{||}>'||
                                                                                        'UPT_BY_X:'|| 'DATA MIGRATION' ||	'<{||}>'||
                                                                                        'UPT_ON_DT:'|| SYSDATE ||	'<{||}>'||
                                                                                        'LOCK_VER_N:'||0 ||	'<{||}>'||
                                                                                        'DELETED_I:'|| 0    ||	'<{||}>'||
                                                                                        'SEC_REF_I:'||0 ||	'<{||}>'||
                                                                                        'SECRTY_REM_X: '||lv_rec_pan_app_tg(i).V_SECRTY_REM_X|| '<{||}>'||
                                                                                        'SUBMISSION_MODE: '||lv_rec_pan_app_tg(i).V_SUBMISSION_MODE|| '<{||}>'||
                                                                                        'SHP_ARR_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_SHP_ARR_DIRN_DESC_X|| '<{||}>'||
                                                                                        'P_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_P_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SECU_LVL_SG_DESC_X: '||lv_rec_pan_app_tg(i).V_SECU_LVL_SG_DESC_X|| '<{||}>'||
                                                                                        'LATD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LATD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'LONGD_DIRN_DESC_X: '||lv_rec_pan_app_tg(i).V_LONGD_DIRN_DESC_X|| '<{||}>'||
                                                                                        'BWMC_COM_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_COM_DESC_X|| '<{||}>'||
                                                                                        'BWMC_D1_RSN_DESC_X: '||lv_rec_pan_app_tg(i).V_BWMC_D1_RSN_DESC_X|| '<{||}>'||
                                                                                        'INTENDED_LOCN_DESC_X: '||lv_rec_pan_app_tg(i).V_INTENDED_LOCN_DESC_X|| '<{||}>'||
                                                                                        'SEC_REF_I: '||NVL(lv_rec_pan_app_tg(i).V_SEC_REF_I,0)  ;


i_excep_cnt := i_excep_cnt +1;

if i_excep_cnt < 50000  then 

                                                                pkg_datamigration_generic.proc_trace_exception('pan_APPLICATION', 'PROC_2_PAN_APP_VCALL', dbms_utility.format_error_backtrace,'ERROR',
                                                                                                                                                            PV_RUN_ID,SQLERRM, v_exp_rows,'T');                                                                                       
end if; --if i_excep_cnt < 50000  then 

                                                                continue;

                                                              END;     ---begin end for pan application
end if ; --lv_rec_pan_app_tg(i).V_MSW_APPLN_REF_ID_X2 is  null


 /************************************************************************************************************************************

                                                                                               PURPOSE OF CALL  

                                 ******************************************************************************************************************************************/

if v_si_untagged <> 1 then 


             v_len:=   length(Trim(lv_rec_pan_app_tg(i).v_purposecall_c));

              WHILE v_len > 0
              LOOP    --start while loop

                   ---logic for purposeof call---

                   v_regex:=  nvl(substr(regexp_substr(trim(lv_rec_pan_app_tg(i).v_purposecall_c), '[0-9]+', 1, v_len), 1, 1), 0);

                    IF v_regex <> 0 THEN
                        v_cnt_poc := v_cnt_poc + 1;
                        IF v_regex = 1 THEN 

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Cargo Operation',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );
                           EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                            i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Cargo Operation' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Cargo Operation' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;

                        ELSIF v_regex = 2 THEN

                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Embarking/disembarking Passenger',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );

                                EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Embarking/disembarking Passenger' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Embarking/disembarking Passenger' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;


                        ELSIF v_regex = 3 THEN

                        begin 


                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Taking Bunkers',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                             EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Taking Bunkers' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Taking Bunkers' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;



                        ELSIF v_regex = 4 THEN

                        begin 
                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Taking Suppliers',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Taking Suppliers' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Taking Suppliers' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );


end if;
                            end;


                        ELSIF v_regex = 5 THEN

                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Changing Crew',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );

                           EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Changing Crew' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Changing Crew' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;


                        ELSIF v_regex = 6 THEN

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                               seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Repair/Docking/Outfitting',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                                0
                            );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Repair/Docking/Outfitting' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Repair/Docking/Outfitting' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;



                        ELSIF v_regex = 7 THEN

                        begin 

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'Offshore Vessel',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );


                              EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'Offshore Vessel' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'Offshore Vessel' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;



                        ELSIF v_regex = 9 THEN


                        begin

                            INSERT INTO pan_purpose_of_call (
                                pan_purp_of_call_id_n,
                                appln_ref_n,
                                purpcall_c,
                                others_purpose_x,
                                arrival_purpse_c,
                                lock_ver_n,
                                deleted_i
                            ) VALUES (
                                seq_pan_purp.nextval,
                                seq_pan_app.currval,
                                'others',
                                lv_rec_pan_app_tg(i).v_otherspurpose_x,
                                'PORT_FACILITY',
                                0,
                               0
                            );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                                i_excep_cnt_poc := i_excep_cnt_poc +1;

                           if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',
							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || 'others' ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'PORT_FACILITY' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0
						 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
						seq_pan_purp.CURRVAL ||'<{||}>'||
						seq_pan_app.CURRVAL ||'<{||}>'||
						'others' ||'<{||}>'||
							lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
						'PORT_FACILITY' ||'<{||}>'||
                         0 ||'<{||}>'||
                          0
							 ,
							 'T'
							 );

                             end if;

                            end;


                        END IF;

                    END IF;

                    v_len := v_len - 1;
               END LOOP;    
                                           ----end while loop for purpose of call c




----transformation logic for anchpurpose-----

           v_len2:=  length(trim(lv_rec_pan_app_tg(i).v_anchpurpose_c));                   

           WHILE v_len2 > 0 LOOP    
                  ---start while loop for anchorpurpose of call
                v_regexx:=   nvl(substr(trim(regexp_substr(lv_rec_pan_app_tg(i).v_anchpurpose_c, '[0-9]+', 1,v_len2)), 1, 1), 0);
                --- dbms_output.put_line(' v_regexx : ' || v_regexx);

                    IF v_regexx <> 0 THEN
                        v_cnt_poc := v_cnt_poc + 1;
                    begin 

                        INSERT INTO pan_purpose_of_call (
                            pan_purp_of_call_id_n,
                            appln_ref_n,
                            purpcall_c,
                            others_purpose_x,
                            arrival_purpse_c,
                            lock_ver_n,
                            deleted_i
                        ) VALUES (
                             seq_pan_purp.nextval,
                                seq_pan_app.currval,
                            v_regexx,
                            lv_rec_pan_app_tg(i).v_anchpurpose_x,
                            'ANCHORAGE',
                            0,
                            0
                        );


                            EXCEPTION

						WHEN OTHERS THEN 

							V_ERR_CODE := SQLCODE;
							V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
							V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

                             if i_excep_cnt_poc < 50000  then 

							PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
							  ( 'pan_purpose_of_call',
							  'PROC_2_PAN_APP_VCALL',

							'pan_purp_of_call_id_n:'||seq_pan_purp.CURRVAL ||'<{||}>'||
							'appln_ref_n:'||seq_pan_app.CURRVAL ||'<{||}>'||
							'purpcall_c:' || v_regexx ||'<{||}>'||
							'others_purpose_x:'||lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
							'arrival_purpse_c:'||'ANCHORAGE' ||'<{||}>'||
							'lock_ver_n:'||0 ||'<{||}>'||
							'deleted_i:'||0

							 ,
							'ERROR',
							PV_RUN_ID,
							V_SQLERRM,
					seq_pan_purp.CURRVAL ||'<{||}>'||
					seq_pan_app.CURRVAL ||'<{||}>'||
					 v_regexx ||'<{||}>'||
					lv_rec_pan_app_tg(i).v_otherspurpose_x ||'<{||}>'||
					'ANCHORAGE' ||'<{||}>'||
					0 ||'<{||}>'||
					0
							 ,
							 'T'
							 );

                             end if;

                            end;



                    END IF;

                 v_len2 := v_len2 - 1;

                END LOOP;                   --END WHILE LOOP


end if ; -- if v_si_untagged <> 1




exception              -- inner exception  when  any exception occurs in JSON or sequence reset

      WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := sqlerrm;
            v_sqlerrm := dbms_utility.format_error_backtrace|| v_err_code || v_err_msg||dbms_utility.format_call_stack;

            pkg_datamigration_generic.proc_trace_exception('JSON_EXCEPTION' , 'PROC_2_PAN_APP_VCALL', dbms_utility.format_error_backtrace , 'ERROR',PV_RUN_ID,dbms_utility.format_error_stack ||v_sqlerrm, v_exp_rows_si  ,'T');

 continue;

END;  -- inner end which covers only JSON

--Added by rohit for new vslcall logic
	V_VSL_CALL_ID := NULL;
	V_VSLRECID_N :=NULL;




      END LOOP;    ----end for loop
      COMMIT;

    END LOOP;     ---end cursor loop


CLOSE cur_tg_pan;  -- close cursor loop

 /****************************************************************************************/
---------------------------------------------------------------------------------------------------------------------------------------------


/********************************************************************************************************
Calling a proc to remove the uncommon records in vc, as , vr which are not present in pan application  starts
*******************************************************************************************************/

begin 

proc_pan_vc_vr_as_del;

end;

/********************************************************************************************************
Calling a proc to remove the uncommon records in vc, as , vr which are not present in pan application  ends
*******************************************************************************************************/


---RECON LOGIC FOR SI PAN APPLICATION------------





 SELECT
        COUNT(*)
    INTO v_m_src_count
    FROM
        st_pans_pansinfofrmrlog    a,
        st_pans_pansinfofrmrlog2   b,
        st_pans_pansinfofrmrlog3   c,
        ST_PTMS_BWMC e,
        ST_PTMS_NOAFREFORM f,
        VESSEL   d
      WHERE
        a.pansid_n = b.pansid_n       
        AND a.pansid_n = c.pansid_n   
        and a.pansID_n = e.transID_n(+)
        and a.vslRecID_n = e.vslRecID_n(+)
        and a.pansID_n = f.pansID_n(+)    
        AND a.vslrecid_n = d.vsl_rec_id_n;  --QUERY 




    SELECT
        COUNT(*)
    INTO v_si_count                     ----COUNT FOR SI PN SPPLICATION
    FROM
        si_pan_application;



   if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into si_pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into SI_PAN_APPLICATION table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into SI_PAN_APPLICATION table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('SI_QUERY', v_m_src_count, 'SI_PAN_APPLICATION', v_si_count, 'N');    





    ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    SELECT   COUNT(*)
    INTO v_m_src_count                     ----COUNT FOR SI PN SPPLICATION
    FROM   si_pan_application;




        select count(*)

        into v_si_count

        from pan_application;





   if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_application table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_application  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('SI_PAN_APPLICATION', v_m_src_count, 'PAN_APPLICATION', v_si_count, 'N');     



   --------------------------------------------------------------------------------------------------------------------------------------------------------------


   ----
 select  count(*)
   into v_m_src_count
    from  st_pans_pansinfofrmrlog ;    ----driving table count


     select count(*)
        into v_si_count
       from pan_application;



      if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_application table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_application table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_application  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('ST_PANS_PANSINFOFRMRLOG', v_m_src_count, 'PAN_APPLICATION', v_si_count, 'Y');     



 ----------------------------------------------------------------------------------------------------------------------------------------------------------  





  v_m_src_count :=  v_cnt_poc;



     select count(*)
        into v_si_count
       from pan_purpose_of_call;



      if (v_m_src_count =  v_si_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

         pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into pan_purpose_of_call table' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_src_count  <> v_si_count and v_m_src_count <> 0 then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
      v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into pan_purpose_of_call table' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_m_src_count  <> v_si_count or v_m_src_count  = v_si_count ) and (v_m_src_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL', 
    v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into pan_purpose_of_call  table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');



end if;



    pkg_datamigration_generic.proc_migration_recon('COUNT OF POC ', v_m_src_count, 'PAN_PURPOSE_OF_CALL', v_si_count, 'Y'); 

    select count(*) into v_m_src_count
    from SI_PAN_UNTAGGED;

    pkg_datamigration_generic.proc_migration_recon('SI_PAN_UNTAGGED ', v_m_src_count, NULL, NULL, 'Y');



/*
    pkg_datamigration_generic.proc_migration_recon('SI_pan_application', v_si_count, 'pan_application', v_m_tgt_count, 'N');

    pkg_datamigration_generic.proc_migration_recon('ST_PANS_pansInfoFrMRLog',v_dr_st_count, 'PAN_APPLICATION', v_m_tgt_count,'Y');

    pkg_datamigration_generic.proc_migration_recon('SI_pan_application',v_cnt_poc, 'PAN_PURPOSE_OF_CALL', v_m_tgt_count1, 'Y');   ---FOR PAN_PURPOSE_OF_CALLL
*/

--------outer exception-----


EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;
        pkg_datamigration_generic.proc_trace_exception('PAN_APPLICATION', 'PROC_2_PAN_APP_VCALL_END', v_sqlerrm, 'ERROR',PV_RUN_ID,NULL,NULL,'T');
END PROC_2_PAN_APP_VCALL;
/