create or replace procedure PROC_PAN_VC_VR_AS_DEL  is 

V_ERR_CODE  number;

V_SQLERRM  varchar2(2000);

V_ERR_MSG  varchar2(2000);

/*******************************************************************
cursor to delete  data from vessel call 
*****************************************************************/

cursor cur_pan_vsl_del is 

select vc.VSL_CALL_ID_N  
from vessel_call  vc,application_submission apsub
where  vc.VSL_CALL_ID_N  not in (select VSL_CALL_ID_N from pan_application )
and vc.VSL_CALL_ID_N = apsub.VSL_CALL_ID_N
and apsub.APPLN_TY_C= 'PAN';




TYPE REC_V_VSL_CALL_ID_N IS RECORD 
(
 V_VSL_CALL_ID_N    vessel_call.VSL_CALL_ID_N%type
);

 TYPE TYPE_V_VSL_CALL_ID_N  IS    TABLE OF REC_V_VSL_CALL_ID_N  INDEX BY PLS_INTEGER;

  lv_V_VSL_CALL_ID_N   TYPE_V_VSL_CALL_ID_N ;
  
  
/*******************************************************************
cursor to delete  data from vessel call   ends
*****************************************************************/



/*******************************************************************
cursor to delete  data from application submission starts
*****************************************************************/

cursor cur_pan_appsub_del is 

select VSL_CALL_ID_N from Application_submission 
WHERE   VSL_CALL_ID_N not in (select VSL_CALL_ID_N from pan_application)
and APPLN_TY_C = 'PAN' ;


TYPE REC_V_APP_SUB_ID_N IS RECORD 
(
 V_APP_SUB_VSLCALLIDN    Application_submission.VSL_CALL_ID_N%type
);

 TYPE TYPE_V_APP_SUB_ID_N  IS    TABLE OF REC_V_APP_SUB_ID_N  INDEX BY PLS_INTEGER;

  LV_V_APP_SUB_ID_N   TYPE_V_APP_SUB_ID_N ;
  

/*******************************************************************
cursor to delete  data from vessel call   ends
*****************************************************************/

/*******************************************************************
cursor to delete  data from vessel reference starts
*****************************************************************/
cursor  cur_pan_vsl_ref is 
SELECT VSL_REF_ID_N 
FROM APPLICATION_SUBMISSION
WHERE APPLN_TY_C ='PAN' AND VSL_CALL_ID_N NOT IN
(SELECT VSL_CALL_ID_N FROM pan_application);


TYPE rec_vslref IS RECORD 
(
 V_VSL_REF_ID_N    vessel_reference.VSL_REF_ID_N%type
);

 TYPE type_rec_vslref IS    TABLE OF rec_vslref  INDEX BY PLS_INTEGER;

 lv_rec_vslref  type_rec_vslref ;






begin 



/************************************
DELETE FROM Vessel Reference Starts
*******************************************/


open  cur_pan_vsl_ref;

loop



  FETCH cur_pan_vsl_ref BULK COLLECT INTO lv_rec_vslref limit 10000;


   EXIT WHEN lv_rec_vslref.count = 0;

FORALL i IN lv_rec_vslref.FIRST..lv_rec_vslref.LAST


DELETE FROM VESSEL_REFERENCE     
WHERE   VSL_REF_ID_N =  lv_rec_vslref(i).V_VSL_REF_ID_N;

commit;
end loop;
close cur_pan_vsl_ref;



/************************************
DELETE FROM Vessel Reference Ends
*******************************************/


/*************************************
DELETE FROM Vessel_Call  starts 
****************************************/
open  cur_pan_vsl_del;

loop

  FETCH cur_pan_vsl_del BULK COLLECT INTO lv_V_VSL_CALL_ID_N limit 10000;


   EXIT WHEN lv_V_VSL_CALL_ID_N.count = 0;

FORALL i IN lv_V_VSL_CALL_ID_N.FIRST..lv_V_VSL_CALL_ID_N.LAST


DELETE FROM vessel_call
WHERE vsl_call_id_n = lv_V_VSL_CALL_ID_N(i).V_VSL_CALL_ID_N;
commit;

end loop;
close cur_pan_vsl_del;


   
   
/*************************************
DELETE FROM Vessel_Call  Ends 
****************************************/  
   

/*************************************
DELETE FROM Application Submission
****************************************/

open  cur_pan_appsub_del;

loop

  FETCH cur_pan_appsub_del BULK COLLECT INTO LV_V_APP_SUB_ID_N limit 10000;


   EXIT WHEN LV_V_APP_SUB_ID_N.count = 0;

FORALL i IN LV_V_APP_SUB_ID_N.FIRST..LV_V_APP_SUB_ID_N.LAST


DELETE FROM Application_submission     
WHERE   VSL_CALL_ID_N =  LV_V_APP_SUB_ID_N(i).V_APP_SUB_VSLCALLIDN;
commit;
end loop;
close cur_pan_appsub_del;





/*************************************
DELETE FROM Application Submission Ends
****************************************/



exception 
when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('PAN_DELETE', 'proc_pan_vc_vr_as_del', V_SQLERRM, 'FAIL',null,null,null,'T');

end;
/