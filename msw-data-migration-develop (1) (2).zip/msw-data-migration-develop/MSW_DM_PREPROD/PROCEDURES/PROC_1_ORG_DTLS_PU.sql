CREATE OR REPLACE PROCEDURE PROC_1_ORG_DTLS_PU ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_SI_ORG_DTLS_PU         NUMBER;
    LV_CNT_TAR        NUMBER;
    lv_cnt_tar_prof     NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    LV_USR_LOGON_ID_N   VARCHAR2(255); 
    LV_USR_ID_TY_C      VARCHAR2(255); 
    LV_USR_ID_N         VARCHAR2(255);


   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_ORG_DTLS_PU
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-JUL-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_ORG_DTLS IS
 /*
     SELECT 
    UPPER(c.uen_n), c.org_m, c.org_c, e.addrpostalcode_n, e.addrblk_n, e.addrst_m, 
    e.addrflr_n, e.addrunit_n, e.addrbldg_m, e.addrcity_m,  e.addrctry_c, F.SUSPD_I,
    DECODE( F.SUSPD_I , 'Y' , 'SUSPENDED', 'DISABLED' ) ST_C
    FROM
    st_pu_profile a, 
    (select * from st_pu_usrorg where org_c is not null and UEN_N is not null and puid_n  IS NOT NULL) c,
    st_pu_usraddr e,
    ( SELECT puid_n, MAX(addrid_n) addrid_n
        FROM  st_pu_profileaddrmapper
        GROUP BY  puid_n ) d , ST_PU_portClrceSchmMstr F
    WHERE
        a.puid_n = c.puid_n (+)
    AND a.puid_n = d.puid_n (+)
    AND a.puid_n = F.puid_n (+)
    AND d.addrid_n = e.addrid_n (+)
    AND NOT EXISTS ( SELECT   org_c FROM  org_dtls n
                        WHERE  c.org_c = n.org_c )
    AND NOT EXISTS ( SELECT co_uen_n  FROM org_dtls n  
                        WHERE c.uen_n = n.co_uen_n );
                        */
    -- Stanley, too many reduntant blank records, rewrite the select logic
      SELECT UPPER(uo.UEN_N), uo.ORG_M, uo.ORG_C, sa.ADDRPOSTALCODE_N, sa.ADDRBLK_N, sa.ADDRST_M,
	  	sa.ADDRFLR_N, sa.ADDRUNIT_N, sa.ADDRBLDG_M, sa.ADDRCITY_M, sa.ADDRCTRY_C, m.SUSPD_I,
	  	DECODE( m.SUSPD_I , 'Y' , 'SUSPENDED', 'DISABLED' ) ST_C
	  FROM ST_PU_USRORG uo 
	  LEFT JOIN (SELECT PUID_N, MAX(ADDRID_N) AS MAX_ADDRID_N FROM ST_PU_PROFILEADDRMAPPER
	  	GROUP BY PUID_N) a ON uo.PUID_N = a.PUID_N
	  LEFT JOIN ST_PU_USRADDR sa ON a.MAX_ADDRID_N = sa.ADDRID_N
	  LEFT JOIN ST_PU_PORTCLRCESCHMMSTR m ON uo.PUID_N = m.PUID_N
	  WHERE uo.ORG_C IS NOT NULL
	  AND uo.UEN_N IS NOT NULL
	  AND NOT EXISTS(SELECT 1 FROM ORG_DTLS WHERE ORG_C = uo.ORG_C AND CO_UEN_N = uo.UEN_N);
    
---------------------***************** DECLARING TYPES ****************----------------------------
    TYPE REC_ORG_DTLS IS RECORD (
        UEN_n             ST_PU_USRORG.UEN_n%TYPE,
        org_m             ST_PU_USRORG.org_m%TYPE, 
        org_c             ST_PU_USRORG.org_c%TYPE, 
        addrPostalcode_n  ST_PU_USRADDR.addrPostalcode_n%TYPE, 
        addrBlk_n         ST_PU_USRADDR.addrBlk_n%TYPE, 
        addrSt_m          ST_PU_USRADDR.addrSt_m%TYPE,
        addrFlr_n         ST_PU_USRADDR.addrFlr_n%TYPE, 
        addrUnit_n        ST_PU_USRADDR.addrUnit_n%TYPE, 
        addrBldg_m        ST_PU_USRADDR.addrBldg_m%TYPE ,
        addrCity_m        ST_PU_USRADDR.addrCity_m%TYPE, 
        addrCtry_c        ST_PU_USRADDR.addrCtry_c%TYPE,
        SUSPD_I           ST_PU_portClrceSchmMstr.SUSPD_I%TYPE,
        ST_C              ORG_DTLS.ORG_ST_C%TYPE
    );
    TYPE TYP_ORG_DTLS IS
    TABLE OF REC_ORG_DTLS INDEX BY PLS_INTEGER;

    LV_ORG_DTLS       TYP_ORG_DTLS;

BEGIN

    execute immediate 'UPDATE st_pu_usraddr SET addrblk_n = NULL WHERE UPPER(TRIM(addrblk_n)) = ''NULL''';
    execute immediate 'UPDATE st_pu_usraddr SET addrbldg_m = NULL WHERE UPPER(TRIM(addrbldg_m)) = ''NULL''';
/*
    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
       st_pu_profile ;   ---- DRIVING TABLE COUNT 
      */ 
    select COUNT(*)
       INTO LV_CNT_ST 
    from st_pu_usrorg where org_c is not null and UEN_N is not null and puid_n  IS NOT NULL ;    ---- DRIVING TABLE COUNT 
    
    SELECT COUNT(*) INTO LV_SI_ORG_DTLS_PU
    FROM (
     SELECT UPPER(uo.UEN_N), uo.ORG_M, uo.ORG_C, sa.ADDRPOSTALCODE_N, sa.ADDRBLK_N, sa.ADDRST_M,
	  	sa.ADDRFLR_N, sa.ADDRUNIT_N, sa.ADDRBLDG_M, sa.ADDRCITY_M, sa.ADDRCTRY_C, m.SUSPD_I,
	  	DECODE( m.SUSPD_I , 'Y' , 'SUSPENDED', 'DISABLED' ) ST_C
	  FROM ST_PU_USRORG uo 
	  LEFT JOIN (SELECT PUID_N, MAX(ADDRID_N) AS MAX_ADDRID_N FROM ST_PU_PROFILEADDRMAPPER
	  	GROUP BY PUID_N) a ON uo.PUID_N = a.PUID_N
	  LEFT JOIN ST_PU_USRADDR sa ON a.MAX_ADDRID_N = sa.ADDRID_N
	  LEFT JOIN ST_PU_PORTCLRCESCHMMSTR m ON uo.PUID_N = m.PUID_N
	  WHERE uo.ORG_C IS NOT NULL
	  AND uo.UEN_N IS NOT NULL
	  AND NOT EXISTS(SELECT 1 FROM ORG_DTLS WHERE ORG_C = uo.ORG_C AND CO_UEN_N = uo.UEN_N) ) ; ------ SI Table count

    OPEN CR_ORG_DTLS;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', 'INSERTION INTO TABLE ORG_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_DTLS BULK COLLECT INTO LV_ORG_DTLS LIMIT 10000;
        EXIT WHEN LV_ORG_DTLS.COUNT = 0;

        FOR J IN LV_ORG_DTLS.FIRST..LV_ORG_DTLS.LAST LOOP
            BEGIN

                INSERT INTO ORG_DTLS (
										ID_N, 
                                        CO_UEN_N, 
                                        CO_M, 
                                        ORG_C, 
                                        ORG_POSTAL_C, 
                                        ORG_BLK_N, 
                                        ORG_ST_N, 
                                        ORG_LVL_X, 
                                        ORG_U_N, 
                                        ORG_BLDG_M, 
                                        ORG_CITY_M, 
                                        ORG_STATE_M, 
                                        ORG_CTRY_M,ORG_ST_C
										)
								VALUES (    
										SYN_SEQ_ORG_DTLS_ID_N.NEXTVAL,
                                        LV_ORG_DTLS(J).UEN_n,
										LV_ORG_DTLS(J).org_m,
                                        LV_ORG_DTLS(J).org_c,
                                        LV_ORG_DTLS(J).addrPostalcode_n,
                                        LV_ORG_DTLS(J).addrBlk_n,
                                        LV_ORG_DTLS(J).addrSt_m,
                                        LV_ORG_DTLS(J).addrFlr_n,
                                        LV_ORG_DTLS(J).addrUnit_n,
                                        LV_ORG_DTLS(J).addrBldg_m,
                                        LV_ORG_DTLS(J).addrCity_m,
                                        NULL,
                                        LV_ORG_DTLS(J).addrCtry_c,LV_ORG_DTLS(J).ST_C
                                );

                INSERT INTO AUTH_PROFILE (
                        ID_N,
                        REFR_ID,
                        PROFILE_TY,
                        LOCK_VER_N
                    ) VALUES (
                        SYN_SEQ_AUTH_PROFILE_ID_N.NEXTVAL,
                        SYN_SEQ_ORG_DTLS_ID_N.CURRVAL,
                        'ORGANIZATION',
                        0 
                    );

            EXCEPTION                   
                WHEN OTHERS THEN        
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;

                    V_EXP_ROWS_SI :=    LV_ORG_DTLS(J).UEN_n
                                        ||'<{||}>'||	
										LV_ORG_DTLS(J).org_m
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).org_c
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrPostalcode_n
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrBlk_n
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrSt_m
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrFlr_n
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrUnit_n
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrBldg_m
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrCity_m
                                         ||'<{||}>'||	
                                        LV_ORG_DTLS(J).addrCtry_c  ;

            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

            END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_ORG_DTLS;


    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM ORG_DTLS;  ---- TARGET TABLE COUNT 
    
     SELECT
        COUNT(*)
    INTO lv_cnt_tar_prof
    FROM
        auth_profile where PROFILE_TY = 'ORGANIZATION' ; 

    IF ( LV_CNT_TAR = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_ST AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_ST OR LV_CNT_TAR = LV_CNT_ST ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;
    
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_USRORG', LV_CNT_ST, 'SI_ORG_DTLS_PU_Q', LV_SI_ORG_DTLS_PU, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_USRORG', LV_CNT_ST, 'ORG_DTLS', LV_CNT_TAR, 'Y');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_USRORG', LV_CNT_ST, 'AUTH_PROFILE', LV_CNT_TAR_PROF, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS_PU', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ORG_DTLS_PU;
/