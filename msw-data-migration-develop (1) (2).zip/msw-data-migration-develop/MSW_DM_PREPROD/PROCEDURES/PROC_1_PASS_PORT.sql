create or replace PROCEDURE proc_1_pass_port (PV_RUN_ID IN NUMBER)IS 
    
     /************************************************************************************************************************************
                procedure name : PROC_proc_1_pass_port
                Created By     : V. R. Yembarwar
                Date           : 20-05-2019
                Purpose        : Inserting  the data from "ST_PANS_last10CallsFrMRFrlog",
                                 "ST_PANS_last10MeasuresFrLOG"  to "SI_PAST_PORT_CALL" to            
                                 Target table "PAST_PORT_CALL".
                Modified by    :
                Modified date  :
    *********************************************************************************************************************************************/


     ---**** cursor for fetching data from Source Staging Table ****

        CURSOR cur_si_port IS
        SELECT 
            a.APPLN_REF_N	,
            b.seq_n	,
            b.arr_dt	,
            b.dep_dt	,
            b.portFacility	,
            b.UNP_m	,
            b.securityLevel_c	,
            c.addMeasures	,
            b.userId_n	,
            b.timeStamp_dt,
            a.MSW_VSL_ID_N


        from
        PAN_APPLICATION a, 	
        ST_PANS_last10CallsFrMRLog b,       
        ST_PANS_last10MeasuresFrMRLog c      ---tested with dummy data
        where
        a.EXTL_APPLN_REF_ID_X = b.pansID_n
        and b.vslRecId_n = c.vslRecId_n 
       and b.pansId_n = c.pansId_n;



      ------Declaring the variables-----       

        v_dr_st_count           number;
        v_si_count              INTEGER;
        v_m_tgt_count1         INTEGER;
        v_m_src_count          INTEGER;
        v_m_tgt_count          INTEGER;
        v_m_err_code           NUMBER;
        v_m_err_msg            VARCHAR2(200);
        v_m_sqlerrm            VARCHAR2(2500);
        v_err_code             VARCHAR2(1000);
        v_err_msg              VARCHAR2(1000);
        v_sqlerrm              VARCHAR2(1000);
        v_blkexptn_count       VARCHAR2(1000);
        v_blkexptn_desc        VARCHAR2(4000);
        v_src_count            INTEGER;
        v_exp_rows             VARCHAR2(1000);
        v_exp_rows1            VARCHAR2(1000);
        v_exp_rows2            VARCHAR2(1000);
        v_exp_rows3            VARCHAR2(1000);
        v_exp_rows4            VARCHAR2(1000);
        v_exp_rows5            VARCHAR2(1000);
        v_exp_rows6            VARCHAR2(1000);
        v_exp_rows7            VARCHAR2(1000);
        v_exp_rows8            VARCHAR2(1000);
        v_exp_rows9            VARCHAR2(1000);


    CURSOR cur_tg_port IS
        SELECT         
            APPLNREF_N,
            seq_n	,
            arr_dt	,
            dep_dt	,
            portFacility	,
            UNP_m	,
            securityLevel_c	,
            addMeasures	,
            userId_n	,
            timeStamp_dt   ,
            MSW_VSL_ID_N
        from 
          SI_PAST_PORT_CALLS;

       TYPE rec_pass_port_tg IS RECORD (


        v_APPLNREF_N		    SI_PAST_PORT_CALLS.APPLNREF_N%type,
        v_SEQ_N				    SI_PAST_PORT_CALLS.SEQ_N%type	,
        v_arr_dt	        	SI_PAST_PORT_CALLS.arr_dt%type	,
        v_dep_dt                SI_PAST_PORT_CALLS.dep_dt%type	,
        v_portFacility		    SI_PAST_PORT_CALLS.portFacility%type	,
        v_UNP_m			        SI_PAST_PORT_CALLS.UNP_m%type	,
        v_securityLevel_c		SI_PAST_PORT_CALLS.securityLevel_c%type	,
        v_addMeasures		    SI_PAST_PORT_CALLS.addMeasures%type	,
        v_userId_n		        SI_PAST_PORT_CALLS.userId_n%type	,
        v_timeStamp_dt		    SI_PAST_PORT_CALLS.timeStamp_dt%type ,
        V_MSW_VSL_ID_N          SI_PAST_PORT_CALLS.MSW_VSL_ID_N%type 



      );


        TYPE type_rec_pass_port_tg IS
            TABLE OF rec_pass_port_tg INDEX BY PLS_INTEGER;

        lv_rec_pass_port_tg     type_rec_pass_port_tg;
        lv_seq_past_port        PAST_PORT_CALLS.PAST_PORT_CALLS_ID_N%TYPE;
        lv_data_dump            CLOB;    
        V_APPLN_REF_N           NUMBER;
        LV_SECU_LVL_C          VARCHAR2(10);   --Number;
      ---  V_POC                   PAST_PORT_CALLS%ROWTYPE;



     ---Inserting data into itermediate table--------


i_excep_cnt_tgt   number := 0;

i_excep_cnt_si  number := 0;

     BEGIN

        pkg_datamigration_generic.proc_trace_exception('PAST_PORT_CALLS', 'PROC_1_PAST_PORT', 'SI_PAST_PORT_CALLS', 'START',PV_RUN_ID,NULL,NULL,'T');

       FOR i IN cur_si_port 

       loop
          begin

           INSERT INTO SI_PAST_PORT_CALLS (

                    applnRef_n	,
                    seq_n	,
                    arr_dt	,
                    dep_dt	,
                    portFacility	,
                    UNP_m	,
                    securityLevel_c	,
                    addMeasures	,
                    userId_n	,
                    timeStamp_dt,
                    MSW_VSL_ID_N

                ) 
           values
             (
             i.APPLN_REF_N	,
             i.seq_n	,
             i.arr_dt	,
             i.dep_dt	,
             i.portfacility	,
             i.UNP_m	,
             i.securityLevel_c	,
             i.addMeasures	,
             i.userId_n	,
             i.timeStamp_dt,
             i.MSW_VSL_ID_N

             );

      EXCEPTION
            WHEN OTHERS THEN
               	V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
				V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
                
i_excep_cnt_si:= i_excep_cnt_si+1;

if i_excep_cnt_si < 50000  then 

             pkg_datamigration_generic.proc_trace_exception('SI_PAST_PORT_CALLS', 
                                                            'proc_1_pass_port', 


                                                            'applnRef_n:'||i.APPLN_REF_N||'<{||}>'||
							                                'seq_n:'||i.seq_n||'<{||}>'||
							                                'arr_dt:' ||  i.arr_dt ||'<{||}>'||
							                                'dep_dt:'||i.dep_dt ||'<{||}>'||
                                                            'portFacility:'||i.portfacility||'<{||}>'||
							                                'UNP_m:'||i.UNP_m	 ||'<{||}>'||
                                                            'securityLevel_c:'|| i.securityLevel_c ||'<{||}>'||
                                                            'addMeasures:' ||i.addMeasures||'<{||}>'||
                                                            'userId_n:' || i.userId_n||'<{||}>'||
                                                            'timeStamp_dt:' ||i.timeStamp_dt||'<{||}>'||
                                                            'MSW_VSL_ID_N: '||i.MSW_VSL_ID_N
                                                           ,



							                                'ERROR',

						                                  	PV_RUN_ID,

							                                V_SQLERRM,

                                                            i.APPLN_REF_N||'<{||}>'||
							                                i.seq_n||'<{||}>'||
							                                i.arr_dt ||'<{||}>'||
							                                i.dep_dt ||'<{||}>'||
                                                            i.portfacility||'<{||}>'||
							                                i.UNP_m	 ||'<{||}>'||
                                                             i.securityLevel_c ||'<{||}>'||
                                                           i.addMeasures||'<{||}>'||
                                                           i.userId_n||'<{||}>'||
                                                           i.timeStamp_dt ||'<{||}>'||
                                                           i.MSW_VSL_ID_N,

							                                'T'
                                                            );


end if ; 


        END; 


        END LOOP;
       Commit; 





    /***********************************************************************************************************
    INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
    *************************************************************************************************************/
    OPEN  cur_tg_port;

     pkg_datamigration_generic.proc_trace_exception('PAST_PORT_CALLS', 'proc_1_past_port', 'Insertion begins into PAST_PORT_CALLS', 'START' ,PV_RUN_ID,NULL,NULL,'T');                                                                                 

        LOOP    ----cursor loop
           FETCH cur_tg_port BULK COLLECT INTO  lv_rec_pass_port_tg LIMIT 3000;
            EXIT WHEN  lv_rec_pass_port_tg.count = 0;
            FOR i IN  lv_rec_pass_port_tg.first.. lv_rec_pass_port_tg.last 
        LOOP      ----for loop

         BEGIN    




    ----------logic for security level-----





    ---------------
     /*        
                v_poc.APPLN_REF_N:=lv_rec_pass_port_tg(i).v_APPLNREF_N;
                v_poc.SEQ_N:= lv_rec_pass_port_tg(i).v_seq_n;
                v_poc.LAST_PORT_FR_DT:=lv_rec_pass_port_tg(i).v_arr_dt;
                v_poc.LAST_PORT_TILL_DT:=lv_rec_pass_port_tg(i).v_dep_dt;
                v_poc.LAST_PORT_FAC_X:=lv_rec_pass_port_tg(i).v_dep_dt;
                v_poc.LAST_PORT_C:= lv_rec_pass_port_tg(i).v_UNP_m;
                v_poc.SECU_LVL_C:= v_secu_lvl_c;
                v_poc.SECU_MSR_X:= NULL;
                v_poc.CRT_BY_X:=lv_rec_pass_port_tg(i).v_userId_n;
                v_poc.CRT_ON_DT:=lv_rec_pass_port_tg(i).v_timeStamp_dt;



             lv_data_dump := FNC_JSON_VAL_PAN( V_APPLN_REF_N); 

     */    

          INSERT INTO  past_port_calls

                (
                        PAST_PORT_CALLS_ID_N,
                        APPLN_REF_N,
                        SEQ_N,
                        LAST_PORT_FR_DT,
                        LAST_PORT_TILL_DT,
                        LAST_PORT_FAC_X,
                        LAST_PORT_C,
                        SECU_LVL_C,
                        SECU_MSR_X,
                        CRT_BY_X,
                        CRT_ON_DT,
                        UPT_BY_X,
                        UPT_ON_DT,
                        DELETED_I,
                        LOCK_VER_N,
                        MSW_VSL_ID_N

                )
            values
            (

             seq_past_port.nextval,
             lv_rec_pass_port_tg(i).v_APPLNREF_N,
             lv_rec_pass_port_tg(i).v_seq_n,
             lv_rec_pass_port_tg(i).v_arr_dt,
             lv_rec_pass_port_tg(i).v_dep_dt,
             lv_rec_pass_port_tg(i).v_portfacility,
             lv_rec_pass_port_tg(i).v_UNP_m,        
             DECODE(Trim(lv_rec_pass_port_tg(i).v_securitylevel_c), '1', 'NORMAL', '2', 'MEDIUM', '3','HIGH'), 

             lv_rec_pass_port_tg(i).v_addMeasures,                      
             lv_rec_pass_port_tg(i).v_userId_n,
             lv_rec_pass_port_tg(i).v_timeStamp_dt	,
             NULL,
             NULL,
             0,
             0,
             lv_rec_pass_port_tg(i).v_MSW_VSL_ID_N
            );

         EXCEPTION
            WHEN OTHERS THEN
               	V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
				V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
                
                i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception('past_port_calls', 
                                                            'proc_1_pass_port', 


                                                            'PAST_PORT_CALLS_ID_N:'||seq_past_port.currval||'<{||}>'||
							                                'APPLN_REF_N:'||lv_rec_pass_port_tg(i).v_APPLNREF_N||'<{||}>'||
							                                'SEQ_N:' || lv_rec_pass_port_tg(i).v_seq_n||'<{||}>'||
							                                'LAST_PORT_FR_DT:'||lv_rec_pass_port_tg(i).v_arr_dt||'<{||}>'||
                                                            'LAST_PORT_TILL_DT:'||lv_rec_pass_port_tg(i).v_dep_dt||'<{||}>'||
							                                'LAST_PORT_FAC_X:'||lv_rec_pass_port_tg(i).v_portfacility ||'<{||}>'||
                                                            'LAST_PORT_C:'|| lv_rec_pass_port_tg(i).v_UNP_m||'<{||}>'||
                                                            'SECU_LVL_C:' ||lv_rec_pass_port_tg(i).v_securitylevel_c||'<{||}>'||
                                                            'SECU_MSR_X:' ||lv_rec_pass_port_tg(i).v_addMeasures||'<{||}>'||
                                                            'CRT_BY_X:' ||lv_rec_pass_port_tg(i).v_userId_n ||'<{||}>'||
                                                            'CRT_ON_DT:' ||  lv_rec_pass_port_tg(i).v_timeStamp_dt  ||'<{||}>'||               
                                                            'UPT_BY_X:'||  null  ||'<{||}>'||
                                                            'UPT_ON_DT:'|| null  ||'<{||}>'||
                                                            'DELETED_I:'|| 0  ||'<{||}>'||
                                                            'LOCK_VER_N:'|| 0 ||'<{||}>'||
                                                            'MSW_VSL_ID_N: '||lv_rec_pass_port_tg(i).v_MSW_VSL_ID_N

                                                           ,



							                                'ERROR',

						                                  	PV_RUN_ID,

							                                V_SQLERRM,

                                                             seq_past_port.currval||'<{||}>'||
							                                lv_rec_pass_port_tg(i).v_APPLNREF_N||'<{||}>'||
							                                lv_rec_pass_port_tg(i).v_seq_n||'<{||}>'||
							                                lv_rec_pass_port_tg(i).v_arr_dt||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_dep_dt||'<{||}>'||
							                                lv_rec_pass_port_tg(i).v_portfacility ||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_UNP_m||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_securitylevel_c||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_addMeasures||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_userId_n ||'<{||}>'||
                                                            lv_rec_pass_port_tg(i).v_timeStamp_dt  ||'<{||}>'||               
                                                            null  ||'<{||}>'||
                                                            null  ||'<{||}>'||
                                                             0  ||'<{||}>'||
                                                             0  ||'<{||}>'||
                                                             lv_rec_pass_port_tg(i).v_MSW_VSL_ID_N,


							                                'T'
                                                            );



end if;

        END; 

       END LOOP;
      Commit;
     END LOOP;

    CLOSE cur_tg_port;

    -----------count of driving  taging table--------  

    select count(*)
      into v_dr_st_count
       from ST_PANS_last10CallsFrMRLog;


    --------
      SELECT
         COUNT(*)
         INTO v_m_src_count
         from
            PAN_APPLICATION a, 
            ST_PANS_last10CallsFrMRLog b,
            ST_PANS_last10MeasuresFrMRLog c
         where
            a.EXTL_APPLN_REF_ID_X = b.pansID_n
            and b.vslRecId_n = c.vslRecId_n 
            and b.pansId_n = c.pansId_n;

    --count of intrmediate------ and recon

      SELECT
            COUNT(*)
        INTO v_si_count
        FROM
           SI_PAST_PORT_CALLS;


      pkg_datamigration_generic.proc_migration_recon('ST_PANS_last10CallsFrMRLog', v_m_src_count, 'SI_PAST_PORT_CALLS', v_si_count, 'N');



       if (v_si_count =  v_m_src_count ) and v_m_src_count <>  0  and v_si_count <> 0 then 

             pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
          v_si_count ||' out of ' ||v_m_src_count ||' rows  have been inserted into SI_PASS_PORT_CALLS table' ,
            'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_si_count  <> v_m_src_count and v_si_count <> 0 then 

            pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
          v_si_count ||' out of ' ||v_m_src_count ||' rows have been inserted into SI_PASS_PORT_CALLStable' ,
            'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


        elsif (v_si_count  <> v_m_src_count or v_si_count  = v_m_src_count ) and (v_si_count = 0) then 

            pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
        v_si_count ||' out of ' ||v_m_src_count || ' rows have been inserted into SI_PASS_PORT_CALLS table' ,
            'FAIL',PV_RUN_ID,NULL,NULL,'T');



    end if;

    ----count of target table and recon------

        SELECT
            COUNT(*)
        INTO v_m_tgt_count
        FROM
            PAST_PORT_CALLS;            

        if (v_m_tgt_count =  v_si_count) and v_si_count <>  0  and v_m_tgt_count <> 0 then 

             pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
             v_m_tgt_count ||' out of ' ||v_si_count ||' rows  have been inserted into PASS_PORT_CALLS table' ,
            'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif v_m_tgt_count <> v_si_count and v_m_tgt_count<> 0 then 

            pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
           v_m_tgt_count ||' out of ' ||v_si_count||' rows have been inserted into PASS_PORT_CALLStable' ,
            'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


        elsif (v_m_tgt_count <> v_si_count or v_m_tgt_count = v_si_count) and (v_m_tgt_count = 0) then 

            pkg_datamigration_generic.proc_trace_exception('PASS_PORT_CALLS', 'proc_1_PASS_PORT', 
            v_m_tgt_count||' out of ' ||v_si_count|| ' rows have been inserted into PASS_PORT_CALLS table' ,
           'FAIL',PV_RUN_ID,NULL,NULL,'T');      
       end if;




    ----Recon logic for PAST_PORT_CALLS-----



        pkg_datamigration_generic.proc_migration_recon('SI_PAST_PORT_CALLS', v_si_count, 'PAST_PORT_CALLS', v_m_tgt_count, 'N');

        pkg_datamigration_generic.proc_migration_recon('ST_PANS_last10CallsFrMRLog', v_dr_st_count, 'PAST_PORT_CALLS', v_m_tgt_count,'Y');




            ------------------uncommon records from joinn ST_PANS_last10CallsFrMRLog and pan aplicatio---------------

/*

     begin
     for i in
      (
      select * from ST_PANS_last10CallsFrMRLog  
      where pansid_n  not in 
     (select EXTL_APPLN_REF_ID_X  from  pan_application ))

     loop

     pkg_datamigration_generic.proc_trace_exception('SI_PASS_PORT_CALLS', 'proc_1_PASS_PORT','uncommon recordss FROM pan_application',
                                                                   null,PV_RUN_ID,null, 
                                                                    'VSLRECID_N:'||i.VSLRECID_N||'<{||}>'||
                                                                    'PANSID_N:'	||i.PANSID_N||'<{||}>'||
                                                                    'UNP_C:'	||i.UNP_C||'<{||}>'||
                                                                    'UNP_M:'	||i.UNP_M||'<{||}>'||
                                                                    'PORTFACILITY:'||i.PORTFACILITY	||'<{||}>'||
                                                                    'ARR_DT:'	||i.ARR_DT||'<{||}>'||
                                                                    'DEP_DT:'	||i.DEP_DT||'<{||}>'||
                                                                    'SECURITYLEVEL_C:'||i.SECURITYLEVEL_C||'<{||}>'||
                                                                    'SEQ_N:'	||i.SEQ_N||'<{||}>'||
                                                                    'USERID_N:'	||i.USERID_N||'<{||}>'||
                                                                    'TIMESTAMP_DT:'||i.TIMESTAMP_DT,                                                              
                                                                    'B');


    end loop;
    exception  when others then 


          v_err_code := sqlcode;
                v_err_msg := substr(sqlerrm, 1, 200);
                v_sqlerrm := v_err_code
                             || v_err_msg
                             ||dbms_utility.format_error_backtrace     ;

    end;
    -------------------------------------------------------- 
    Begin
     for j in
      (
      select * from ST_PANS_last10MeasuresFrMRLog
      where pansid_n  not in 
     (select pansid_n from ST_PANS_last10CallsFrMRLog ))

     loop

     pkg_datamigration_generic.proc_trace_exception('SI_PASS_PORT_CALLS', 'proc_1_PASS_PORT','uncommon recordss from ST_PANS_last10MeasuresFrMRLog ',
                                                                   null,PV_RUN_ID,null, 
                                                                    'VSLRECID_N:'	||	j.VSLRECID_N	||'<{||}>'||
                                                                    'PANSID_N:'	||	j.PANSID_N	||'<{||}>'||
                                                                    'UNP_C:'	||	j.UNP_C	||'<{||}>'||
                                                                    'UNP_M:'	||	j.UNP_M	||'<{||}>'||
                                                                    'PORTFACILITY:'	||	j.PORTFACILITY	||'<{||}>'||
                                                                    'ADDMEASURES:'	||	j.ADDMEASURES	||'<{||}>'||
                                                                    'ARR_DT:'	||	j.ARR_DT	||'<{||}>'||
                                                                    'DEP_DT:'	||	j.DEP_DT	||'<{||}>'||
                                                                    'SEQ_N:'	||	j.SEQ_N	||'<{||}>'||
                                                                    'USERID_N:'	||	j.USERID_N	||'<{||}>'||
                                                                    'TIMESTAMP_DT:'	||	j.TIMESTAMP_DT,                                                                                                                           
                                                                    'D');


    end loop;
    exception  when others then 


          v_err_code := sqlcode;
                v_err_msg := substr(sqlerrm, 1, 200);
                v_sqlerrm := v_err_code
                             || v_err_msg
                             ||dbms_utility.format_error_backtrace   ;


    end;


*/


    ----outer exception----  
     EXCEPTION
        WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         || dbms_utility.format_error_stack;
            pkg_datamigration_generic.proc_trace_exception('PAST_PORT_CALLS', 'proc_1_PAST_PORT', v_sqlerrm, 'ERROR',PV_RUN_ID,NULL,NULL,'T');
    END;
	/