create or replace PROCEDURE PROC_5_PUSH_ORG IS
    
/***********************************************************************************************************
PROCEDURE NAME : PROC_5_PUSH_ORG
CREATED BY     : ROHIT KHOOL
DATE           : 10-SEP-2019
PURPOSE        : TO PUSH USR_DTL TABLE RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO RESPECTIVE TARGET SCHEMAS AUTHENTICATION_SERVICE.USR_DTL
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****

    CURSOR cr_org_dtls IS
    SELECT
        id_n,
        co_uen_n,
        co_m,
        org_c,
        org_postal_c,
        org_blk_n,
        org_st_n,
        org_lvl_x,
        org_u_n,
        org_bldg_m,
        org_city_m,
        org_state_m,
        org_ctry_m,
        org_st_c
    FROM
        org_dtls;

    CURSOR cr_org_code IS
    SELECT
        id_n,
        code,
        crt_by_n,
        st_c,
        crt_on_dt,
        deleted_i
    FROM
        org_code;

    CURSOR cr_org_privledge IS
    SELECT
        org_dtls_id_n,
        codeorg_privileges_id_n
    FROM
        org_privileges;

    CURSOR cr_auth_profile IS
    SELECT
        id_n,
        refr_id,
        profile_ty,
        lock_ver_n
    FROM
        auth_profile;
        
        CURSOR CR_CREW_CO_REQ IS
	SELECT
		ID_N, CO_UEN_N, BOND_EXPY_D, ELG_VSL_TY, CR_REQ_ST, LOCK_VER_N
	FROM 
		CREW_CO_REQ ;
     

    TYPE rec_org_dtls IS RECORD (
        id_n                      org_dtls.id_n%TYPE,
        co_uen_n                  org_dtls.co_uen_n%TYPE,
        co_m                      org_dtls.co_m%TYPE,
        org_c                     org_dtls.org_c%TYPE,
        org_postal_c              org_dtls.org_postal_c%TYPE,
        org_blk_n                 org_dtls.org_blk_n%TYPE,
        org_st_n                  org_dtls.org_st_n%TYPE,
        org_lvl_x                 org_dtls.org_lvl_x%TYPE,
        org_u_n                   org_dtls.org_u_n%TYPE,
        org_bldg_m                org_dtls.org_bldg_m%TYPE,
        org_city_m                org_dtls.org_city_m%TYPE,
        org_state_m               org_dtls.org_state_m%TYPE,
        org_ctry_m                org_dtls.org_ctry_m%TYPE,
        org_st_c                  org_dtls.org_st_c%TYPE
    );
    TYPE rec_org_code IS RECORD (
        id_n                      org_code.id_n%TYPE,
        code                      org_code.code%TYPE,
        crt_by_n                  org_code.crt_by_n%TYPE,
        st_c                      org_code.st_c%TYPE,
        crt_on_dt                 org_code.crt_on_dt%TYPE,
        deleted_i                 org_code.deleted_i%TYPE
    );
    TYPE rec_org_priviledges IS RECORD (
        org_dtls_id_n             org_privileges.org_dtls_id_n%TYPE,
        codeorg_privileges_id_n   org_privileges.codeorg_privileges_id_n%TYPE
    );
    TYPE rec_auth_profile IS RECORD (
        id_n                      auth_profile.id_n%TYPE,
        refr_id                   auth_profile.refr_id%TYPE,
        profile_ty                auth_profile.profile_ty%TYPE,
        lock_ver_n                auth_profile.lock_ver_n%TYPE
    );
    
    TYPE REC_CREW_CO_REQ IS RECORD
	(
        ID_N                CREW_CO_REQ.ID_N%TYPE, 
        CO_UEN_N            CREW_CO_REQ.CO_UEN_N%TYPE,
        BOND_EXPY_D         CREW_CO_REQ.BOND_EXPY_D%TYPE, 
        ELG_VSL_TY          CREW_CO_REQ.ELG_VSL_TY%TYPE, 
        CR_REQ_ST           CREW_CO_REQ.CR_REQ_ST%TYPE, 
        LOCK_VER_N          CREW_CO_REQ.LOCK_VER_N%TYPE
    );
    
    TYPE type_org_dtls IS
        TABLE OF rec_org_dtls;
    lv_org_dtls               type_org_dtls;
    TYPE type_org_code IS
        TABLE OF rec_org_code;
    lv_org_code               type_org_code;
    TYPE type_org_privledge IS
        TABLE OF rec_org_priviledges;
    lv_org_privledge          type_org_privledge;
    TYPE type_auth_profile IS
        TABLE OF rec_auth_profile;
    lv_auth_profile           type_auth_profile;
    
     TYPE TYPE_CREW_CO_REQ  IS TABLE OF REC_CREW_CO_REQ;
	LV_CREW_CO_REQ				TYPE_CREW_CO_REQ;
    
    lv_cnt_dm_ud_dtls         NUMBER;
    lv_cnt_tt_ud_dtls         NUMBER;
    lv_cnt_dm_ud_code         NUMBER;
    lv_cnt_tt_ud_code         NUMBER;
    lv_cnt_dm_ud_priv         NUMBER;
    lv_cnt_tt_ud_priv         NUMBER;
    lv_cnt_dm_ud_prof         NUMBER;
    lv_cnt_tt_ud_prof         NUMBER;
    lv_cnt_dm_ud_crew         NUMBER;
    lv_cnt_tt_ud_crew         NUMBER;
    v_err_code                NUMBER;
    v_err_msg                 VARCHAR2(500);
    v_sqlerrm                 VARCHAR2(2500);
    v_exp_rows                VARCHAR2(1000);
BEGIN
    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_dtls
    FROM
        org_dtls;

    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_code
    FROM
        org_code;

    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_priv
    FROM
        org_privileges;

    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_prof
    FROM
        auth_profile;
    
    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_crew
    FROM
        crew_co_req;
    

    OPEN cr_org_code;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.ORG_CODE'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.ORG_CODE and inseting into target table AUTHENTICATION_SERVICE.ORG_CODE ************------------------        
        FETCH cr_org_code BULK COLLECT INTO lv_org_code LIMIT 10000;
        EXIT WHEN lv_org_code.count = 0;
        FOR j IN lv_org_code.first..lv_org_code.last LOOP			
-------------************ SYN_ORG_CODE is synonym of AUTHENTICATION_SERVICE.ORG_CODE  ************------------------  
            BEGIN
                INSERT INTO syn_org_code (
                    id_n,
                    code,
                    crt_by_n,
                    st_c,
                    crt_on_dt,
                    deleted_i
                ) VALUES (
                    lv_org_code(j).id_n,
                    lv_org_code(j).code,
                    lv_org_code(j).crt_by_n,
                    lv_org_code(j).st_c,
                    lv_org_code(j).crt_on_dt,
                    lv_org_code(j).deleted_i
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ID_N: '
                                  || lv_org_code(j).id_n
                                  || ' CO_UEN_N: '
                                  || lv_org_code(j).code
                                  || ' CO_M: '
                                  || lv_org_code(j).crt_by_n
                                  || ' ORG_C: '
                                  || lv_org_code(j).st_c
                                  || ' ORG_POSTAL_C: '
                                  || lv_org_code(j).crt_on_dt
                                  || ' ORG_BLK_N: '
                                  || lv_org_code(j).deleted_i;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', v_err_msg

                    , 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_org_code;
    OPEN cr_org_dtls;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.ORG_DTLS'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.ORG_DTLS and inseting into target table AUTHENTICATION_SERVICE.ORG_DTLS ************------------------        
        FETCH cr_org_dtls BULK COLLECT INTO lv_org_dtls LIMIT 10000;
        EXIT WHEN lv_org_dtls.count = 0;
        FOR i IN lv_org_dtls.first..lv_org_dtls.last LOOP			
-------------************ SYN_ORG_DTLS is synonym of AUTHENTICATION_SERVICE.ORG_DTLS  ************------------------  
            BEGIN
                INSERT INTO syn_org_dtls (
                    id_n,
                    co_uen_n,
                    co_m,
                    org_c,
                    org_postal_c,
                    org_blk_n,
                    org_st_n,
                    org_lvl_x,
                    org_bldg_m,
                    org_city_m,
                    org_state_m,
                    org_ctry_m,
                    org_u_n,
                    org_st_c
                ) VALUES (
                    lv_org_dtls(i).id_n,
                    lv_org_dtls(i).co_uen_n,
                    lv_org_dtls(i).co_m,
                    lv_org_dtls(i).org_c,
                    lv_org_dtls(i).org_postal_c,
                    lv_org_dtls(i).org_blk_n,
                    lv_org_dtls(i).org_st_n,
                    lv_org_dtls(i).org_lvl_x,
                    lv_org_dtls(i).org_bldg_m,
                    lv_org_dtls(i).org_city_m,
                    lv_org_dtls(i).org_state_m,
                    lv_org_dtls(i).org_ctry_m,
                    lv_org_dtls(i).org_u_n,
                    lv_org_dtls(i).org_st_c
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ID_N: '
                                  || lv_org_dtls(i).id_n
                                  || ' CO_UEN_N: '
                                  || lv_org_dtls(i).co_uen_n
                                  || ' CO_M: '
                                  || lv_org_dtls(i).co_m
                                  || ' ORG_C: '
                                  || lv_org_dtls(i).org_c
                                  || ' ORG_POSTAL_C: '
                                  || lv_org_dtls(i).org_postal_c
                                  || ' ORG_BLK_N: '
                                  || lv_org_dtls(i).org_blk_n
                                  || ' ORG_ST_N: '
                                  || lv_org_dtls(i).org_st_n
                                  || ' ORG_LVL_X: '
                                  || lv_org_dtls(i).org_lvl_x
                                  || ' ORG_BLDG_M: '
                                  || lv_org_dtls(i).org_bldg_m
                                  || ' ORG_CITY_M: '
                                  || lv_org_dtls(i).org_city_m
                                  || ' ORG_STATE_M: '
                                  || lv_org_dtls(i).org_state_m
                                  || ' ORG_CTRY_M: '
                                  || lv_org_dtls(i).org_ctry_m
                                  || ' ORG_U_N: '
                                  || lv_org_dtls(i).org_u_n;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', v_err_msg

                    , 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_org_dtls;
    OPEN cr_org_privledge;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
-------------************ Fetching records form MSW_DATA_MIGRATION.ORG_PRIVLEDGE and inseting into target table AUTHENTICATION_SERVICE.ORG_PRIVLEDGE ************------------------        
        FETCH cr_org_privledge BULK COLLECT INTO lv_org_privledge LIMIT 10000;
        EXIT WHEN lv_org_privledge.count = 0;
        FOR k IN lv_org_privledge.first..lv_org_privledge.last LOOP			
-------------************ SYN_ORG_PRIVLEDGE is synonym of AUTHENTICATION_SERVICE.ORG_PRIVLEDGE  ************------------------  
            BEGIN
                INSERT INTO syn_org_privileges (
                    org_dtls_id_n,
                    org_privilege_id_n
                ) VALUES (
                    lv_org_privledge(k).org_dtls_id_n,
                    lv_org_privledge(k).codeorg_privileges_id_n
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ORG_DTLS_ID_N: '
                                  || lv_org_privledge(k).org_dtls_id_n
                                  || ' ORG_PRIVILEGE_ID_N: '
                                  || lv_org_privledge(k).codeorg_privileges_id_n;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG'

                    , v_err_msg, 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_org_privledge;
    OPEN cr_auth_profile;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.AUTH_PROFILE'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.AUTH_PROFILE and inseting into target table AUTHENTICATION_SERVICE.AUTH_PROFILE ************------------------        
        FETCH cr_auth_profile BULK COLLECT INTO lv_auth_profile LIMIT 10000;
        EXIT WHEN lv_auth_profile.count = 0;
        FOR l IN lv_auth_profile.first..lv_auth_profile.last LOOP			
-------------************ SYN_AUTH_PROFILE is synonym of AUTHENTICATION_SERVICE.AUTH_PROFILE  ************------------------  
            BEGIN
                INSERT INTO syn_auth_profile (
                    id_n,
                    refr_id,
                    profile_ty,
                    lock_ver_n
                ) VALUES (
                    lv_auth_profile(l).id_n,
                    lv_auth_profile(l).refr_id,
                    lv_auth_profile(l).profile_ty,
                    lv_auth_profile(l).lock_ver_n
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ID_N: '
                                  || lv_auth_profile(l).id_n
                                  || ' REFR_ID: '
                                  || lv_auth_profile(l).refr_id
                                  || ' PROFILE_TY: '
                                  || lv_auth_profile(l).profile_ty
                                  || ' LOCK_VER_N: '
                                  || lv_auth_profile(l).lock_ver_n;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG'

                    , v_err_msg, 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_auth_profile;	
    
    OPEN CR_CREW_CO_REQ;
	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('MSW_DATA_MIGRATION.CREW_CO_REQ', 'PROC_5_PUSH_ORG', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.CREW_CO_REQ', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.CREW_CO_REQ and inseting into target table AUTHENTICATION_SERVICE.CREW_CO_REQ ************------------------        

			FETCH CR_CREW_CO_REQ BULK COLLECT INTO LV_CREW_CO_REQ LIMIT 10000;
            EXIT WHEN LV_CREW_CO_REQ.count = 0;
			FOR m IN LV_CREW_CO_REQ.first..LV_CREW_CO_REQ.last
			LOOP			
-------------************ SYN_CREW_CO_REQ is synonym of AUTHENTICATION_SERVICE.CREW_CO_REQ  ************------------------  
			BEGIN
			INSERT INTO SYN_CREW_CO_REQ (
							ID_N, CO_UEN_N, BOND_EXPY_D, ELG_VSL_TY, CR_REQ_ST, LOCK_VER_N
								)
						VALUES (
								LV_CREW_CO_REQ(m).ID_N,
								LV_CREW_CO_REQ(m).CO_UEN_N,
                                LV_CREW_CO_REQ(m).BOND_EXPY_D,
                                LV_CREW_CO_REQ(m).ELG_VSL_TY,
                                LV_CREW_CO_REQ(m).CR_REQ_ST,
                                LV_CREW_CO_REQ(m).LOCK_VER_N
								);
			        EXCEPTION
					WHEN OTHERS THEN
					V_ERR_CODE := SQLCODE;
					V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
					V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


					V_EXP_ROWS := 	' ID_N: '||LV_CREW_CO_REQ(m).ID_N||
									' CO_UEN_N: '||LV_CREW_CO_REQ(m).CO_UEN_N||
                                    ' BOND_EXPY_D: '||LV_CREW_CO_REQ(m).BOND_EXPY_D||
                                    ' ELG_VSL_TY: '||LV_CREW_CO_REQ(m).ELG_VSL_TY||
                                    ' CR_REQ_ST: '||LV_CREW_CO_REQ(m).CR_REQ_ST||
                                    ' LOCK_VER_N: '||LV_CREW_CO_REQ(m).LOCK_VER_N
									;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('MSW_DATA_MIGRATION.CREW_CO_REQ', 'PROC_5_PUSH_ORG',  V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,V_EXP_ROWS,'T');
		END;

		END LOOP;

        COMMIT;

    END LOOP;
	CLOSE CR_CREW_CO_REQ;	
    
    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_dtls
    FROM
        syn_org_dtls;

    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_code
    FROM
        syn_org_code;

    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_priv
    FROM
        syn_org_privileges;

    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_prof
    FROM
        syn_auth_profile;
        
    SELECT
    COUNT(*)
    INTO lv_cnt_tt_ud_crew
    FROM
    SYN_CREW_CO_REQ;

    IF ( lv_cnt_tt_ud_dtls = lv_cnt_dm_ud_dtls ) AND lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_dtls
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_dtls
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_DTLS'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF lv_cnt_dm_ud_dtls <> lv_cnt_tt_ud_dtls AND lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_dtls
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_dtls
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_DTLS'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_dtls
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_dtls
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_DTLS'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;

    IF ( lv_cnt_tt_ud_code = lv_cnt_dm_ud_code ) AND lv_cnt_dm_ud_code <> 0 AND lv_cnt_tt_ud_code <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_code
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_code
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_CODE'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF lv_cnt_dm_ud_code <> lv_cnt_tt_ud_code AND lv_cnt_dm_ud_code <> 0 AND lv_cnt_tt_ud_code <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_code
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_code
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_CODE'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF lv_cnt_dm_ud_code <> 0 AND lv_cnt_tt_ud_code = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_code
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_code
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_CODE'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;

    IF ( lv_cnt_tt_ud_priv = lv_cnt_dm_ud_priv ) AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_priv
                                                                                                                        || ' OUT OF '
                                                                                                                        || lv_cnt_tt_ud_priv
                                                                                                                        || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                                        , 'SUCCESS'
                                                                                                                        , NULL, NULL
                                                                                                                        , NULL, NULL
                                                                                                                        );
    ELSIF lv_cnt_dm_ud_priv <> lv_cnt_tt_ud_priv AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_priv
                                                                                                                        || ' OUT OF '
                                                                                                                        || lv_cnt_tt_ud_priv
                                                                                                                        || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                                        , 'PARTIALLY SUCCESSFULL'
                                                                                                                        , NULL, NULL
                                                                                                                        , NULL, NULL
                                                                                                                        );
    ELSIF lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_priv
                                                                                                                        || ' OUT OF '
                                                                                                                        || lv_cnt_tt_ud_priv
                                                                                                                        || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                                        , 'FAIL',
                                                                                                                        NULL, NULL
                                                                                                                        , NULL, NULL
                                                                                                                        );
    END IF;

    IF ( lv_cnt_tt_ud_prof = lv_cnt_dm_ud_prof ) AND lv_cnt_dm_ud_prof <> 0 AND lv_cnt_tt_ud_prof <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_prof
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_prof
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'SUCCESS'
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL, NULL
                                                                                                                      );
    ELSIF lv_cnt_dm_ud_prof <> lv_cnt_tt_ud_prof AND lv_cnt_dm_ud_prof <> 0 AND lv_cnt_tt_ud_prof <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_prof
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_prof
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'PARTIALLY SUCCESSFULL'
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL, NULL
                                                                                                                      );
    ELSIF lv_cnt_dm_ud_prof <> 0 AND lv_cnt_tt_ud_prof = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_prof
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_prof
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'FAIL', NULL
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL);
    END IF;   
    
    IF ( lv_cnt_tt_ud_crew = lv_cnt_dm_ud_crew ) AND lv_cnt_dm_ud_crew <> 0 AND lv_cnt_tt_ud_crew <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_crew
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_crew
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'SUCCESS'
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL, NULL
                                                                                                                      );
    ELSIF lv_cnt_dm_ud_crew <> lv_cnt_tt_ud_crew AND lv_cnt_dm_ud_crew <> 0 AND lv_cnt_tt_ud_crew <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_crew
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_crew
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'PARTIALLY SUCCESSFULL'
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL, NULL
                                                                                                                      );
    ELSIF lv_cnt_dm_ud_crew <> 0 AND lv_cnt_tt_ud_crew = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', lv_cnt_dm_ud_crew
                                                                                                                      || ' OUT OF '
                                                                                                                      || lv_cnt_tt_ud_crew
                                                                                                                      || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.AUTH_PROFILE'
                                                                                                                      , 'FAIL', NULL
                                                                                                                      , NULL, NULL
                                                                                                                      , NULL);
    END IF;   
   
    pkg_datamigration_generic.proc_migration_recon('DM_ORG_DTLS', lv_cnt_dm_ud_dtls, 'ORG_DTLS'

    , lv_cnt_tt_ud_dtls, 'Y');
    pkg_datamigration_generic.proc_migration_recon('DM_ORG_CODE', lv_cnt_dm_ud_code, 'ORG_CODE'
    , lv_cnt_tt_ud_code, 'Y');
    pkg_datamigration_generic.proc_migration_recon('DM_ORG_PRIVLEDGE', lv_cnt_dm_ud_priv, 'ORG_PRIVLEDGE'
    , lv_cnt_tt_ud_priv, 'Y');
    pkg_datamigration_generic.proc_migration_recon('DM_AUTH_PROFILE', lv_cnt_dm_ud_prof, 'AUTH_PROFILE'
    , lv_cnt_tt_ud_prof, 'Y');	
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DM_CREW_CO_REQ', LV_CNT_DM_UD_CREW, 'CREW_CO_REQ', LV_CNT_TT_UD_CREW,'Y');	
EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200)
                     || dbms_utility.format_error_backtrace;
        v_sqlerrm := v_err_code || v_err_msg;
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_DTLS', 'PROC_5_PUSH_ORG', v_sqlerrm, 'ERROR',
        NULL, NULL, NULL, 'T');

        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_CODE', 'PROC_5_PUSH_ORG', v_sqlerrm, 'ERROR'

        , NULL, NULL, NULL, 'T');

        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.ORG_PRIVLEDGE', 'PROC_5_PUSH_ORG', v_sqlerrm

        , 'ERROR', NULL, NULL, NULL, 'T');

        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.AUTH_PROFILE', 'PROC_5_PUSH_ORG', v_sqlerrm,

        'ERROR', NULL, NULL, NULL, 'T');
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('MSW_DATA_MIGRATION.CREW_CO_REQ', 'PROC_5_PUSH_ORG', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END proc_5_push_org;
/