create or replace procedure PROC_DEP_JSON
is 
CURSOR CR_DEP_JSON IS
SELECT
a.	APPLN_REF_N					,		
a.	MSW_APPLN_REF_ID_X			,		
a.	EXTL_APPLN_REF_ID_X			,		
a.	APPLCNT_ID_X				,		
a.	VSL_CALL_ID_N				,		
a.	MSW_VSL_ID_N				,		
a.	GD_TY_C						,		
a.	AGT_DECLR_AC_N				,		
a.	GDV_N						,		
a.	CONTACT_PERS_M				,		
a.	OFF_TEL_N					,		
a.	HOME_TEL_N					,		
a.	MOBILE_N					,		
a.	FAX_N						,		
a.	EMAIL_ADDR_X				,		
a.	VSL_GT_Q					,		
a.	NEW_VSL_GT_Q				,		
a.	ARR_DECLR_DT				,		
a.	ARR_CTRY_FR_C				,		
a.	ARR_LAST_PORT_C			,		
a.	ARR_PAX_Q					,		
a.	ARR_CREW_Q					,		
a.	ARR_CGO_Q					,		
a.	ARR_MSTR_ON_ARR_X			,		
a.	ARR_LOCN_ON_ARR_C			,		
a.	ARR_LOCN_ON_ARR_M			,		
a.	ARR_GRID_REF_N				,		
a.	ARR_MOTHER_GDV_N			,		
a.	ARR_BUNKR_Q					,		
a.	ARR_BUNKR_GR_C				,		
a.	ARR_CST_N					,		
a.	ARR_CHARTERER_NAT_C			,		
a.	ARR_SLN_C					,		
a.	CALL_REC_ST_C				,		
a.	RTA_DT						,		
a.	PCC_EXEMPN_RSN_X			,		
a.	OFFICIAL_GDV_N				,		
a.	APPLN_ST_C					,		
a.	PROCESSED_BY_X				,		
a.	PROCESSED_ON_DT				,		
a.	PROCESSING_REM_X			,		
a.	INTL_REM_X					,		
a.	UNIT_NO_FROM				,		
a.	UNIT_NO_TO					,		
a.	POSTAL_CODE					,		
a.	APPLICANT_NAME				,		
a.	BUILDING_NAME				,		
a.	FIN							,		
a.	NRIC						,		
a.	PASSPORT					,		
a.	STREET_NAME					,		
a.	DELETED_I					,		
a.	LOCK_VER_N					,		
a.	CRT_ON_DT					,		
a.	CRT_BY_N					,		
a.	UPT_ON_DT					,		
a.	UPT_BY_X					,		
d.	APPLN_REF_N					,		
d.	MSW_APPLN_REF_ID_X			,		
d.	EXTL_APPLN_REF_ID_X			,		
d.	GDV_N						,		
d.	DEP_DECLR_DT				,		
d.	VSL_GT_ON_DEP_Q				,		
d.	AGT_DECLR_AC_N				,		
d.	NX_PORT_CTRY_C				,		
d.	NX_PORT_C					,		
d.	NX_PORT_M					,		
d.	PERS_Q						,		
d.	PAX_Q						,		
d.	CREW_Q						,		
d.	CGO_Q						,		
d.	MSTR_ON_DEP_X				,		
d.	MOTHER_GDV_N				,		
d.	BUNKR_Q						,		
d.	BUNKR_GR_C					,		
d.	CST_N						,		
d.	CHARTERER_NAT_C				,		
d.	SLN_C						,		
d.	APPLN_ST_C					,		
d.	PROCESSED_BY_X				,		
d.	PROCESSED_ON_DT				,		
d.	PROCESSING_REM_X			,		
d.	COMPANY_NAME				,		
--d.	DEPARTURE_LOCATION			,		
--d.	MPA_ACCOUNT_NAMES			,		
d.	DELETED_I					,		
d.	LOCKVER_N					,		
d.	CRT_ON_DT					,		
d.	CRT_BY_N					,		
d.	UPT_ON_DT					,		
d.	UPT_BY_X					,		
d.	INTL_REM_X							

from arrival_gd_application a , 
DEPARTURE_GD_APPLICATION d 
where a.gdv_n = d.gdv_n;

TYPE REC_DEP_JSON IS RECORD
(
arr_APPLN_REF_N				ARRIVAL_GD_APPLICATION.APPLN_REF_N%TYPE	,
arr_MSW_APPLN_REF_ID_X		ARRIVAL_GD_APPLICATION.MSW_APPLN_REF_ID_X%TYPE	,
arr_EXTL_APPLN_REF_ID_X		ARRIVAL_GD_APPLICATION.EXTL_APPLN_REF_ID_X%TYPE	,
arr_APPLCNT_ID_X			ARRIVAL_GD_APPLICATION.APPLCNT_ID_X%TYPE	,
arr_VSL_CALL_ID_N			ARRIVAL_GD_APPLICATION.VSL_CALL_ID_N%TYPE	,
arr_MSW_VSL_ID_N			ARRIVAL_GD_APPLICATION.MSW_VSL_ID_N%TYPE	,
arr_GD_TY_C					ARRIVAL_GD_APPLICATION.GD_TY_C%TYPE	,
arr_AGT_DECLR_AC_N			ARRIVAL_GD_APPLICATION.AGT_DECLR_AC_N%TYPE	,
arr_GDV_N					ARRIVAL_GD_APPLICATION.GDV_N%TYPE	,
arr_CONTACT_PERS_M			ARRIVAL_GD_APPLICATION.CONTACT_PERS_M%TYPE	,
arr_OFF_TEL_N				ARRIVAL_GD_APPLICATION.OFF_TEL_N%TYPE	,
arr_HOME_TEL_N				ARRIVAL_GD_APPLICATION.HOME_TEL_N%TYPE	,
arr_MOBILE_N				ARRIVAL_GD_APPLICATION.MOBILE_N%TYPE	,
arr_FAX_N					ARRIVAL_GD_APPLICATION.FAX_N%TYPE	,
arr_EMAIL_ADDR_X			ARRIVAL_GD_APPLICATION.EMAIL_ADDR_X%TYPE	,
arr_VSL_GT_Q				ARRIVAL_GD_APPLICATION.VSL_GT_Q%TYPE	,
arr_NEW_VSL_GT_Q			ARRIVAL_GD_APPLICATION.NEW_VSL_GT_Q%TYPE	,
arr_ARR_DECLR_DT			ARRIVAL_GD_APPLICATION.ARR_DECLR_DT%TYPE	,
arr_ARR_CTRY_FR_C			ARRIVAL_GD_APPLICATION.ARR_CTRY_FR_C%TYPE	,
arr_ARR_LAST_PORT_C			ARRIVAL_GD_APPLICATION.ARR_LAST_PORT_C%TYPE	,
arr_ARR_PAX_Q				ARRIVAL_GD_APPLICATION.ARR_PAX_Q%TYPE	,
arr_ARR_CREW_Q				ARRIVAL_GD_APPLICATION.ARR_CREW_Q%TYPE	,
arr_ARR_CGO_Q				ARRIVAL_GD_APPLICATION.ARR_CGO_Q%TYPE	,
arr_ARR_MSTR_ON_ARR_X		ARRIVAL_GD_APPLICATION.ARR_MSTR_ON_ARR_X%TYPE	,
arr_ARR_LOCN_ON_ARR_C		ARRIVAL_GD_APPLICATION.ARR_LOCN_ON_ARR_C%TYPE	,
arr_ARR_LOCN_ON_ARR_M		ARRIVAL_GD_APPLICATION.ARR_LOCN_ON_ARR_M%TYPE	,
arr_ARR_GRID_REF_N			ARRIVAL_GD_APPLICATION.ARR_GRID_REF_N%TYPE	,
arr_ARR_MOTHER_GDV_N		ARRIVAL_GD_APPLICATION.ARR_MOTHER_GDV_N%TYPE	,
arr_ARR_BUNKR_Q				ARRIVAL_GD_APPLICATION.ARR_BUNKR_Q%TYPE	,
arr_ARR_BUNKR_GR_C			ARRIVAL_GD_APPLICATION.ARR_BUNKR_GR_C%TYPE	,
arr_ARR_CST_N				ARRIVAL_GD_APPLICATION.ARR_CST_N%TYPE	,
arr_ARR_CHARTERER_NAT_C		ARRIVAL_GD_APPLICATION.ARR_CHARTERER_NAT_C%TYPE	,
arr_ARR_SLN_C				ARRIVAL_GD_APPLICATION.ARR_SLN_C%TYPE	,
arr_CALL_REC_ST_C			ARRIVAL_GD_APPLICATION.CALL_REC_ST_C%TYPE	,
arr_RTA_DT					ARRIVAL_GD_APPLICATION.RTA_DT%TYPE	,
arr_PCC_EXEMPN_RSN_X		ARRIVAL_GD_APPLICATION.PCC_EXEMPN_RSN_X%TYPE	,
arr_OFFICIAL_GDV_N			ARRIVAL_GD_APPLICATION.OFFICIAL_GDV_N%TYPE	,
arr_APPLN_ST_C				ARRIVAL_GD_APPLICATION.APPLN_ST_C%TYPE	,
arr_PROCESSED_BY_X			ARRIVAL_GD_APPLICATION.PROCESSED_BY_X%TYPE	,
arr_PROCESSED_ON_DT			ARRIVAL_GD_APPLICATION.PROCESSED_ON_DT%TYPE	,
arr_PROCESSING_REM_X		ARRIVAL_GD_APPLICATION.PROCESSING_REM_X%TYPE	,
arr_INTL_REM_X				ARRIVAL_GD_APPLICATION.INTL_REM_X%TYPE	,
arr_UNIT_NO_FROM			ARRIVAL_GD_APPLICATION.UNIT_NO_FROM%TYPE	,
arr_UNIT_NO_TO				ARRIVAL_GD_APPLICATION.UNIT_NO_TO%TYPE	,
arr_POSTAL_CODE				ARRIVAL_GD_APPLICATION.POSTAL_CODE%TYPE	,
arr_APPLICANT_NAME			ARRIVAL_GD_APPLICATION.APPLICANT_NAME%TYPE	,
arr_BUILDING_NAME			ARRIVAL_GD_APPLICATION.BUILDING_NAME%TYPE	,
arr_FIN						ARRIVAL_GD_APPLICATION.FIN%TYPE	,
arr_NRIC					ARRIVAL_GD_APPLICATION.NRIC%TYPE	,
arr_PASSPORT				ARRIVAL_GD_APPLICATION.PASSPORT%TYPE	,
arr_STREET_NAME				ARRIVAL_GD_APPLICATION.STREET_NAME%TYPE	,
arr_DELETED_I				ARRIVAL_GD_APPLICATION.DELETED_I%TYPE	,
arr_LOCK_VER_N				ARRIVAL_GD_APPLICATION.LOCK_VER_N%TYPE	,
arr_CRT_ON_DT				ARRIVAL_GD_APPLICATION.CRT_ON_DT%TYPE	,
arr_CRT_BY_N				ARRIVAL_GD_APPLICATION.CRT_BY_N%TYPE	,
arr_UPT_ON_DT				ARRIVAL_GD_APPLICATION.UPT_ON_DT%TYPE	,
arr_UPT_BY_X				ARRIVAL_GD_APPLICATION.UPT_BY_X%TYPE	,
dep_APPLN_REF_N				DEPARTURE_GD_APPLICATION.APPLN_REF_N%TYPE	,
dep_MSW_APPLN_REF_ID_X		DEPARTURE_GD_APPLICATION.MSW_APPLN_REF_ID_X%TYPE,
dep_EXTL_APPLN_REF_ID_X		DEPARTURE_GD_APPLICATION.EXTL_APPLN_REF_ID_X%TYPE,
dep_GDV_N					DEPARTURE_GD_APPLICATION.GDV_N%TYPE,
dep_DEP_DECLR_DT			DEPARTURE_GD_APPLICATION.DEP_DECLR_DT%TYPE,
dep_VSL_GT_ON_DEP_Q			DEPARTURE_GD_APPLICATION.VSL_GT_ON_DEP_Q%TYPE,
dep_AGT_DECLR_AC_N			DEPARTURE_GD_APPLICATION.AGT_DECLR_AC_N%TYPE,
dep_NX_PORT_CTRY_C			DEPARTURE_GD_APPLICATION.NX_PORT_CTRY_C%TYPE,
dep_NX_PORT_C				DEPARTURE_GD_APPLICATION.NX_PORT_C%TYPE,
dep_NX_PORT_M				DEPARTURE_GD_APPLICATION.NX_PORT_M%TYPE,
dep_PERS_Q					DEPARTURE_GD_APPLICATION.PERS_Q%TYPE,
dep_PAX_Q					DEPARTURE_GD_APPLICATION.PAX_Q%TYPE,
dep_CREW_Q					DEPARTURE_GD_APPLICATION.CREW_Q%TYPE,
dep_CGO_Q					DEPARTURE_GD_APPLICATION.CGO_Q%TYPE,
dep_MSTR_ON_DEP_X			DEPARTURE_GD_APPLICATION.MSTR_ON_DEP_X%TYPE,
dep_MOTHER_GDV_N			DEPARTURE_GD_APPLICATION.MOTHER_GDV_N%TYPE,
dep_BUNKR_Q					DEPARTURE_GD_APPLICATION.BUNKR_Q%TYPE,
dep_BUNKR_GR_C				DEPARTURE_GD_APPLICATION.BUNKR_GR_C%TYPE,
dep_CST_N					DEPARTURE_GD_APPLICATION.CST_N%TYPE,
dep_CHARTERER_NAT_C			DEPARTURE_GD_APPLICATION.CHARTERER_NAT_C%TYPE,
dep_SLN_C					DEPARTURE_GD_APPLICATION.SLN_C%TYPE,
dep_APPLN_ST_C				DEPARTURE_GD_APPLICATION.APPLN_ST_C%TYPE,
dep_PROCESSED_BY_X			DEPARTURE_GD_APPLICATION.PROCESSED_BY_X%TYPE,
dep_PROCESSED_ON_DT			DEPARTURE_GD_APPLICATION.PROCESSED_ON_DT%TYPE,
dep_PROCESSING_REM_X		DEPARTURE_GD_APPLICATION.PROCESSING_REM_X%TYPE,
dep_COMPANY_NAME			DEPARTURE_GD_APPLICATION.COMPANY_NAME%TYPE,
--dep_DEPARTURE_LOCATION		DEPARTURE_GD_APPLICATION.DEPARTURE_LOCATION%TYPE,
--dep_MPA_ACCOUNT_NAMES		DEPARTURE_GD_APPLICATION.MPA_ACCOUNT_NAMES%TYPE,
dep_DELETED_I				DEPARTURE_GD_APPLICATION.DELETED_I%TYPE,
dep_LOCKVER_N				DEPARTURE_GD_APPLICATION.LOCKVER_N%TYPE,
dep_CRT_ON_DT				DEPARTURE_GD_APPLICATION.CRT_ON_DT%TYPE,
dep_CRT_BY_N				DEPARTURE_GD_APPLICATION.CRT_BY_N%TYPE,
dep_UPT_ON_DT				DEPARTURE_GD_APPLICATION.UPT_ON_DT%TYPE,
dep_UPT_BY_X				DEPARTURE_GD_APPLICATION.UPT_BY_X%TYPE,
dep_INTL_REM_X				DEPARTURE_GD_APPLICATION.INTL_REM_X%TYPE		
);
TYPE TBL_DEP_JSON  IS TABLE OF REC_DEP_JSON;
LV_TBDJ				TBL_DEP_JSON;
LVAL   clob;
v_err_code  number;
v_err_msg  varchar2(4000);
v_sqlerrm   varchar2(4000);
v_src number := 0 ; 
v_tgt  number;
V_PURP_CALL_ID VARCHAR2(10);

i_excep_cnt  number := 0;


begin 

OPEN  CR_DEP_JSON;

loop  --  loop of departute GD 
FETCH CR_DEP_JSON BULK COLLECT INTO LV_TBDJ LIMIT 10000;
EXIT WHEN LV_TBDJ.count = 0;
FOR i IN LV_TBDJ.first..LV_TBDJ.last
		LOOP
        IF LV_TBDJ(i).arr_GD_TY_C <> 'ARRIVAL_DEPARTURE'
        THEN
begin 



LVAL := '{';
LVAL := LVAL ||  '"agentDeclaredAccountNumber": "'||nvl(trim(LV_TBDJ(i).arr_AGT_DECLR_AC_N),'null')||'",';
  --LVAL := LVAL ||'"mpaAccountNames": "'||nvl(trim(LV_TBDJ(i).dep_MPA_ACCOUNT_NAMES),'null')  ||'",';
  LVAL := LVAL ||'"mobilePhoneNumber":'|| nvl(trim(LV_TBDJ(i).arr_MOBILE_N),'null') ||',';
  LVAL := LVAL ||'"emailAddress": "'||nvl(trim(LV_TBDJ(i).arr_EMAIL_ADDR_X),'null')||'",';
  LVAL := LVAL ||'"faxNumber":'|| nvl(trim(LV_TBDJ(i).arr_FAX_N),'null')||',';
  LVAL := LVAL ||'"applicantName": "'||nvl(trim(LV_TBDJ(i).arr_APPLICANT_NAME),'null')||'",';
  LVAL := LVAL ||'"contactPersonName": "'||nvl(trim(LV_TBDJ(i).arr_CONTACT_PERS_M),'null')||'",';
  LVAL := LVAL ||'"officePhoneNumber": "'|| nvl(trim(LV_TBDJ(i).arr_OFF_TEL_N),'null')||'",';
  LVAL := LVAL ||'"vesselName":"'||'null'||'",';
  LVAL := LVAL ||'"imoNo":"'||'null'||'",';
  LVAL := LVAL ||'"craftLicenceNo":'|| 'null'||',';
  LVAL := LVAL ||'"nameOfOwner": "'||'null'||'",';
  LVAL := LVAL ||'"grossTonnage":'|| 'null'||',';
  LVAL := LVAL ||'"callSign": "'||'null'||'",';
  LVAL := LVAL ||'"flag": "'||'null'||'",';
  LVAL := LVAL ||'"officalNo": "'||nvl(trim(LV_TBDJ(i).arr_OFF_TEL_N),'null')||'",';
  LVAL := LVAL ||'"characterNationalityCode": "'||'null'||'",';
  LVAL := LVAL ||'"shippingLineCode": "'||'null'||'",';
  LVAL := LVAL ||'"gdvNumber": "'||NVL(trim(LV_TBDJ(i).DEP_GDV_N),'NULL')||'",';
  LVAL := LVAL ||'"officialGDVNumber": "'||trim(LV_TBDJ(i).arr_OFFICIAL_GDV_N)||'",';
  LVAL := LVAL ||'"mdo": '||'null'||',';
  LVAL := LVAL ||'"mfo":'|| 'null'||',';
  LVAL := LVAL ||'"checkTerm": '||'null'||',';
  LVAL := LVAL ||'"mgo":'|| 'null'||',';
  LVAL := LVAL ||'"shipYardsLocation": [],';
  LVAL := LVAL ||'"nextPortCode": "'||nvl(trim(LV_TBDJ(i).dep_NX_PORT_C),'null')||'",';
  LVAL := LVAL ||'"nextPortCountry": "'||nvl(trim(LV_TBDJ(i).dep_NX_PORT_CTRY_C),'null')||'",';
  LVAL := LVAL ||'"departureDateTime": "'||'null'||'",';
  LVAL := LVAL ||'"nextPortName": "'||nvl(trim(LV_TBDJ(i).dep_NX_PORT_M),'null')||'",';
  LVAL := LVAL ||'"departureReasons": "'||'null' ||'",';
  LVAL := LVAL ||'"departureOtherReasons": "'||'null'  ||'",';
 -- LVAL := LVAL ||'"departureLocation": "'  ||nvl(trim(LV_TBDJ(i).dep_DEPARTURE_LOCATION),'null') ||'",';
  LVAL := LVAL ||'"masterOnDeparture": "'||nvl(trim(LV_TBDJ(i).dep_MSTR_ON_DEP_X),'null')||'",';
  LVAL := LVAL ||'"numberOfCrew":'|| nvl(trim(LV_TBDJ(i).dep_CREW_Q),'null')||',';
  LVAL := LVAL ||'"totalPassengersOnBoard":'|| nvl(trim(LV_TBDJ(i).dep_PAX_Q),'null')||',';
  LVAL := LVAL ||'"totalCargoOnBoard": '||nvl(trim(LV_TBDJ(i).dep_CGO_Q),'null')||',';
  LVAL := LVAL ||'"totalPersonsOnBoard": "'||nvl(trim(LV_TBDJ(i).dep_PERS_Q),'null') ||'",';
  LVAL := LVAL ||'"arrivalMotherVessel": "' ||'null' ||'",';
  LVAL := LVAL ||'"motherGDV": "'||nvl(trim(LV_TBDJ(i).dep_MOTHER_GDV_N),'null')||'",';
  LVAL := LVAL ||'"declaredArrivalDateTime":"'|| nvl(trim(LV_TBDJ(i).arr_arr_declr_dt),'null')||'",';
  LVAL := LVAL ||'"motherVesselArrivalDateTime":'|| 'null'||',';
  LVAL := LVAL ||'"confirm": "'||'null'  || '",';
  LVAL := LVAL ||'"vesselCallId":'||nvl(trim(LV_TBDJ(i).arr_VSL_CALL_ID_N),'null')||',';
  LVAL := LVAL ||'"vesselId":'|| nvl(trim(LV_TBDJ(i).arr_MSW_VSL_ID_N),'null')||',';
  LVAL := LVAL ||'"otherAfloatActivities": "'|| 'null' ||'",';
  LVAL := LVAL ||'"departureGDPurposeOfCallEvents": [';







 for j in (select  PURPCALL_C, OTHERS_PURPOSE_X ,PURP_CALL_OTHERS_TOW_X,PURPCALL_OTHERS_TOW_VSL_M,PURPCALL_OTHERS_UND_TOW_VSL_M
         from departure_gd_purpose_of_call
         where APPLN_REF_N =LV_TBDJ(i).dep_APPLN_REF_N )

 loop
 
	IF trim(J.PURPCALL_C) = 'Cargo Operation'
			THEN
			V_PURP_CALL_ID :=1;
			ELSIF trim(J.PURPCALL_C) = 'Embarking/disembarking Passenger'
			THEN
			V_PURP_CALL_ID :=2;
			ELSIF trim(J.PURPCALL_C)= 'Taking Bunkers'
			THEN
			V_PURP_CALL_ID :=3;
			ELSIF trim(J.PURPCALL_C) = 'Taking Suppliers'
			THEN
			V_PURP_CALL_ID :=4;
			ELSIF trim(J.PURPCALL_C) = 'Changing Crew'
			THEN
			V_PURP_CALL_ID :=5;
			ELSIF trim(J.PURPCALL_C) = 'Repair/Docking/Outfitting'
			THEN
			V_PURP_CALL_ID :=6;
			ELSIF trim(J.PURPCALL_C)= 'Offshore Vessel'
			THEN
			V_PURP_CALL_ID :=7;
            ELSIF( trim(J.PURPCALL_C)='Towing' or trim(J.PURPCALL_C)='Shipped in as Cargo' or trim(J.PURPCALL_C)='Shipped out as Cargo'
            or trim(J.PURPCALL_C)='Recreation/Pleasure' or trim(J.PURPCALL_C)='Other')
            THEN
			V_PURP_CALL_ID :=9;
   ELSE
	V_PURP_CALL_ID :=NULL;
	END IF;

		LVAL := LVAL ||    '{';
		LVAL := LVAL ||  '"purposeOfCall": "'|| V_PURP_CALL_ID||'",';
		LVAL := LVAL || '"othersPurpose": "'||NVL(trim(j.OTHERS_PURPOSE_X),'NULL')  ||'",';
	  
	  
		LVAL:=LVAL||'"purposeCallOthersTow":"'||J.PURP_CALL_OTHERS_TOW_X||'",';
		LVAL:=LVAL||'"purposeCallOthersTowVSL":"'||J.PURPCALL_OTHERS_TOW_VSL_M||'",';
		LVAL:=LVAL||'"purposeCallOthersUndTowVSL":"'||J.PURPCALL_OTHERS_UND_TOW_VSL_M||'",';
		LVAL:=LVAL||'"otherAfloatActivities":"'||'null'||'"';
			
			
			
    LVAL := LVAL || '},';

    end loop;

    -- LVAL :=  rtrim(LVAL,'},');
	-- LVAL :=  LVAL || ',"gdPurposeOfCallShipyardLocEvents": []}';
   --  LVAL := LVAL || '],';

     LVAL :=  rtrim(LVAL,',');
     LVAL := LVAL || '],';
     
 LVAL := LVAL || '"mswApplicationReferenceOfAGD": "'||NVL(trim(LV_TBDJ(i).arr_MSW_APPLN_REF_ID_X),'NULL')||'",';
LVAL := LVAL ||  '"createdOn": "'||NVL(trim(LV_TBDJ(i).arr_CRT_ON_DT),'NULL')||'",';
LVAL := LVAL ||  '"createdBy": "'||NVL(trim(LV_TBDJ(i).arr_CRT_BY_N),'NULL')||'",';
LVAL := LVAL ||  '"applicantId": "'||NVL(trim(LV_TBDJ(i).arr_APPLCNT_ID_X),'NULL')||'",';





LVAL := LVAL ||   '"departureGDShipCertificates": [';
--need to put  the loop ..

LVAL := LVAL ||      '{';
LVAL := LVAL ||       '"classReportOnShipCertificatesStatus":'|| 'null'||',';
LVAL := LVAL ||       '"issuingClass": "'||'null' ||'",';
LVAL := LVAL ||       '"issueDate": "'||'null'||'",';
LVAL := LVAL ||       '"documentId":'|| 'null'||',';
LVAL := LVAL ||       '"certificateType": "'||'null'||'",';
LVAL := LVAL ||       '"classReportDocuments": "'||'null' ||'",';
LVAL := LVAL ||       '"createdBy": "'||'null'||'",';
LVAL := LVAL ||      ' "createdOn": "'||'null'||'"';
LVAL := LVAL ||     '},';
LVAL := LVAL ||      '{';
LVAL := LVAL ||      '"registrationStatus": "'||'null'  ||'",';
LVAL := LVAL ||      '"officialNo": "'||'null' ||'",';
LVAL := LVAL ||      '"issuingAuthority": "'||'null'  ||'",';
LVAL := LVAL ||      '"issueDate": "' ||'null'  ||'",';
LVAL := LVAL ||      '"portOfRegistry": "'||'null'  ||'",';
LVAL := LVAL ||      '"expiryDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"nameOfOwner": "'  || 'null'    ||'",';
LVAL := LVAL ||      '"yearBuilt": "'||'null'  || '",';
LVAL := LVAL ||      '"countryOfOwner": "' ||'null'  ||'",';
LVAL := LVAL ||      '"length": "'||'null'  ||'",';
LVAL := LVAL ||      '"breadth": "'||'null'  ||'",';
LVAL := LVAL ||      '"depth": "'||'null'  ||'",';
LVAL := LVAL ||      '"certificateType": "'|| 'null'||'",';
LVAL := LVAL ||      '"createdBy": "'||'NCS'||'",';
LVAL := LVAL ||     ' "createdOn": "'||'null'||'"';
LVAL := LVAL ||    '},';
LVAL := LVAL ||    '{';
LVAL := LVAL ||      '"submitNewIntsOilPollutionPreventionCertificates":'|| 'null'||',';
LVAL := LVAL ||      '"issuingClass": "'||'null'  ||'",';
LVAL := LVAL ||      '"issueDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"dateOfDelivery": "'||'null'  ||'",';
LVAL := LVAL ||      '"dueDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"sopepSmpepIsOnBoard": "'|| 'null'  ||'",';
LVAL := LVAL ||      '"dwt": "'||'null'  ||'",';
LVAL := LVAL ||      '"certificateType": "'||'null'||'",';
LVAL := LVAL ||      '"createdBy": "'||'null'||'",';
LVAL := LVAL ||      '"createdOn": "'||'null'||'"';
LVAL := LVAL ||     '}';
LVAL := LVAL ||   ']';
LVAL := LVAL || '}';


insert into SI_JSON values (null,LVAL,sysdate,'GDD',trim(LV_TBDJ(i).dep_MSW_APPLN_REF_ID_X));


LVAL := null;


--commit;

exception when others then 

   v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 2000);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;

            i_excep_cnt:= i_excep_cnt+1;

if i_excep_cnt < 1000  then          

        pkg_datamigration_generic.proc_trace_exception('DEP_GD_JSON', 'proc_1_Dep_json', v_sqlerrm, 'ERROR',null,NULL,NULL,'T');


end if;


end;

v_src := v_src + 1;
END IF;
end loop;
commit;
end loop ;--of departure GD

CLOSE CR_DEP_JSON;	
select count(*) 
into v_tgt
from SI_JSON where appln_type = 'GDD';


 pkg_datamigration_generic.proc_migration_recon('SRC_CNT', v_src , 'SI_JSON', v_tgt,'Y'); 



exception  --- exception of   outer begin 


    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 2000);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;
        pkg_datamigration_generic.proc_trace_exception('DEP_GD_JSON', 'PROC_DEP_JSON', v_sqlerrm, 'ERROR',null,NULL,NULL,'T');


end ;
/