create or replace PROCEDURE PROC_PROCESS_DOC_DEP_GD (
   -- FILENAME VARCHAR2,
    PV_RUN_ID IN   NUMBER
) IS

    LV_CNT_ST              NUMBER;
    LV_CNT_SI              NUMBER;
    LV_CNT_TAR             NUMBER;
    LV_DIR                 VARCHAR2(500) ;

/***********************************************************************************************************
PROCEDURE NAME : PROC_PROCESS_DOC_DEP_GD
CREATED BY     : Rohit Khool
DATE           : 05-NOV-2019
PURPOSE        : PROCESS GD DOCUMENT
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/
    CURSOR CUR_DOC IS
    SELECT
		ID,
		DOC_TY_C,
		SFTP_PATH_X,
		FILE_M
    FROM
        GD_DOC;

    CURSOR CUR_DOC_TAR IS
    SELECT
        ID,
		DOC_TY_C,
		SFTP_PATH_X,
		FILE_M
    FROM
        SI_GD_DOC_MAPPING;

--***************** DECLARING TYPES ****************------

    TYPE REC_DOC IS RECORD
	(
        V_ID   			SI_GD_DOC_MAPPING.ID%TYPE,
		V_DOC_TY_C		SI_GD_DOC_MAPPING.DOC_TY_C%TYPE,
        V_SFTP_PATH_X   SI_GD_DOC_MAPPING.SFTP_PATH_X%TYPE,
        V_FILE_M        SI_GD_DOC_MAPPING.FILE_M%TYPE
	);

    TYPE TYPE_DOC_TBL IS        TABLE OF REC_DOC;
    LV_DOC_TBL             TYPE_DOC_TBL;

----------------------------
    TYPE REC_DOC_TAR IS RECORD
	(
        V_ID   			SI_GD_DOC_MAPPING.ID%TYPE,
		V_DOC_TY_C		SI_GD_DOC_MAPPING.DOC_TY_C%TYPE,
        V_SFTP_PATH_X   SI_GD_DOC_MAPPING.SFTP_PATH_X%TYPE,
        V_FILE_M        SI_GD_DOC_MAPPING.FILE_M%TYPE
    );

    TYPE TYPE_DOC_TBL_TAR IS     TABLE OF REC_DOC_TAR;
    LV_DOC_TBL_TAR         TYPE_DOC_TBL_TAR;

    F_LOB                  BFILE;
    B_LOB                  BLOB;
    IMAGE_NAME             VARCHAR2(100);
    MIME_TYPE              VARCHAR2(30);
    DOT_POS                NUMBER;
    V_SQ_DOC_ID_N           NUMBER;
   -- FILENAME VARCHAR2(500):= 'DOC_MANAGEMENT' ;
BEGIN
    SELECT
        COUNT(*)
    INTO LV_CNT_ST
    FROM      GD_DOC;

    OPEN CUR_DOC;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_PROCESS_DOC_DEP_GD', 'INSERTION INTO TABLE SI_GD_DOC_MAPPING', 'START'
    , PV_RUN_ID, NULL, NULL, 'T');

    LOOP
        FETCH CUR_DOC BULK COLLECT INTO LV_DOC_TBL LIMIT 10000;
        EXIT WHEN LV_DOC_TBL.COUNT = 0;
        FOR I IN LV_DOC_TBL.FIRST..LV_DOC_TBL.LAST LOOP

            BEGIN
                INSERT INTO SI_GD_DOC_MAPPING
											(
											ID,
											DOC_TY_C,
											SFTP_PATH_X,
											FILE_M
											)
									VALUES (
												LV_DOC_TBL(I).V_ID,
												LV_DOC_TBL(I).V_DOC_TY_C,
												LV_DOC_TBL(I).V_SFTP_PATH_X,
												LV_DOC_TBL(I).V_FILE_M
											);

            EXCEPTION
            WHEN OTHERS THEN
            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_PROCESS_DOC_DEP_GD', SQLERRM
                                                                                                   || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                                                                                   || DBMS_UTILITY.FORMAT_ERROR_STACK
                                                                                                   , 'ERROR', NULL, SQLERRM, NULL
                                                                                                   , 'T');
            END;

        END LOOP;

        COMMIT;
    END LOOP;
    CLOSE CUR_DOC;


    SELECT
    COUNT(*)
    INTO LV_CNT_SI
    FROM
    SI_GD_DOC_MAPPING;

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_SI
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_ST
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN SI TABLE', 'SUCCESS'
                                                                                       , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_SI
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_ST
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN SI TABLE', 'PARTIALLY SUCCESSFULL'
                                                                                       , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GD_DOC', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_SI
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_ST
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN SI TABLE', 'FAIL',
                                                                                       PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('GD_DOCUMENT', LV_CNT_ST, 'SI_GD_DOC_MAPPING', LV_CNT_SI, 'N');


------------------------------------ INSERTING DATA DOC TARGET TABLE ---------------------------------------
    OPEN CUR_DOC_TAR;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DOCUMENT', 'PROC_PROCESS_DOC_DEP_GD', 'INSERTION INTO TABLE DOC', 'START'
                                                    , PV_RUN_ID, NULL, NULL, 'T');

    SELECT DIRECTORY_PATH INTO LV_DIR
    FROM ALL_DIRECTORIES  WHERE DIRECTORY_NAME = 'DOC_MANAGEMENT';

    LOOP
        FETCH CUR_DOC_TAR BULK COLLECT INTO LV_DOC_TBL_TAR LIMIT 10000;
        EXIT WHEN LV_DOC_TBL_TAR.COUNT = 0;
        FOR J IN LV_DOC_TBL_TAR.FIRST..LV_DOC_TBL_TAR.LAST

        LOOP


        BEGIN

            V_SQ_DOC_ID_N := SYN_SEQ_DOC_ID_N.NEXTVAL ;

            DOT_POS := INSTR(LV_DOC_TBL_TAR(J).V_FILE_M,'.');
            IMAGE_NAME := LV_DOC_TBL_TAR(J).V_FILE_M;       --'FILENAME';
            MIME_TYPE := 'IMAGE/'||SUBSTR( LV_DOC_TBL_TAR(J).V_FILE_M,DOT_POS+1,LENGTH(LV_DOC_TBL_TAR(J).V_FILE_M) );

            INSERT INTO DOC (
                    DOC_ID_N,
                    LOCK_VER_N,
                    DOC_TITLE_M,
                    FILE_TY_C,
                    ACC_CNT_N,
                    STRG_LOC_X,
                    CRT_BY_N,
                    CRT_ON_DT,
                    DELETED_I,
                    USR_FILE_M,
                    FILE_DATA
                ) VALUES (
                    V_SQ_DOC_ID_N ,
                    0,
                    IMAGE_NAME,
                    LV_DOC_TBL_TAR(J).V_DOC_TY_C,
                    0,
                    LV_DIR,
                    'DATA MIGRATION',
                    SYSDATE,
                    0,
                    MIME_TYPE,
                    EMPTY_BLOB() )
                RETURN FILE_DATA INTO B_LOB;

            F_LOB := BFILENAME('DOC_MANAGEMENT',LV_DOC_TBL_TAR(J).V_FILE_M);
            DBMS_LOB.FILEOPEN(F_LOB,DBMS_LOB.FILE_READONLY);
            DBMS_LOB.LOADFROMFILE(B_LOB,F_LOB,DBMS_LOB.GETLENGTH(F_LOB) );
            DBMS_LOB.FILECLOSE(F_LOB);

            UPDATE GD_DOC A
            SET A.DOC_ID_N = V_SQ_DOC_ID_N
            WHERE A.ID = LV_DOC_TBL_TAR(J).V_ID ;

--DBMS_OUTPUT.PUT_LINE('LV_DG_APPLN_DOC_ID_N '||LV_DOC_TBL_TAR(J).LV_DG_APPLN_DOC_ID_N ) ;
--DBMS_OUTPUT.PUT_LINE('V_SQ_DOC_ID_N '||V_SQ_DOC_ID_N) ;

            EXCEPTION
                WHEN OTHERS THEN
                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DOCUMENT', 'PROC_PROCESS_DOC_DEP_GD', SQLERRM
                                                                                                   || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                                                                                   || DBMS_UTILITY.FORMAT_ERROR_STACK
                                                                                                   , 'ERROR', NULL, SQLERRM, NULL
                                                                                                   , 'T');
            END;

        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE CUR_DOC_TAR;
      /*
        UPDATE DANGEROUS_GOODS_APPLICATION_DOCUMENT A
            SET A.DOC_ID_N = (SELECT B.DOC_ID_N  FROM DOC B
                                WHERE A.DG_APPLN_DOC_ID_N = B.DOC_ID_N)  ;

        COMMIT ;
      */
    SELECT
        COUNT(*)
    INTO LV_CNT_TAR
    FROM
        DOC;

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DOCUMENT', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_TAR
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_SI
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN TARGET TABLE ', 'SUCCESS'
                                                                                       , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DOCUMENT', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_TAR
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_SI
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN TARGET TABLE ', 'PARTIALLY SUCCESSFULL'
                                                                                       , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DOCUMENT', 'PROC_PROCESS_DOC_DEP_GD', LV_CNT_TAR
                                                                                       || ' OUT OF '
                                                                                       || LV_CNT_SI
                                                                                       || ' RECORDS LOADED SUCCESSFULLY IN TARGET TABLE ', 'FAIL',
                                                                                       PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_GD_DOC_MAPPING', LV_CNT_SI, 'DOC', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('GD_DOC', LV_CNT_ST, 'DOC', LV_CNT_TAR, 'Y');
END PROC_PROCESS_DOC_DEP_GD;
/