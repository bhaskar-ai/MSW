create or replace PROCEDURE PROC_1_CREW_CO_REQ ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_TAR        NUMBER;
    LV_SI_CREW_CO_REQ    NUMBER; 
    LV_CNT_ORG_PRIV     NUMBER; 
    LV_CDORG_PRIV_ID_N  NUMBER; 
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_CREW_CO_REQ
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-NOV-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/

   CURSOR CR_CREW_CO_REQ IS
        SELECT
            A.COY_RCB, A.BOND_EXPIRY_DATE, SUBSTR(A.STATUS, 1, 1) AS STATUS
        FROM
            ST_BONDSTATUS A
            WHERE NOT EXISTS (SELECT  CO_UEN_N FROM ORG_DTLS_PROD_BKP n WHERE   A.COY_RCB = n.CO_UEN_N  ) ;--Table name changed by Tiyasha 28/11
                    
    CURSOR CR_ORG_PRIV IS              
        SELECT
            B.ID_N
        FROM
            ST_BONDSTATUS A , ORG_DTLS_PROD_BKP B
            WHERE A.COY_RCB = B.CO_UEN_N  ; --Table name changed by Tiyasha 28/11

---------------------***************** DECLARING TYPES ****************----------------------------
    TYPE REC_CREW_CO_REQ IS RECORD (
        COY_RCB_R             ST_BONDSTATUS.COY_RCB%TYPE ,
        BOND_EXPIRY_DATE_R    ST_BONDSTATUS.BOND_EXPIRY_DATE%TYPE,
        STATUS_R              ST_BONDSTATUS.STATUS%TYPE
      );

    TYPE TYP_CREW_CO_REQ IS
    TABLE OF REC_CREW_CO_REQ INDEX BY PLS_INTEGER;

    LV_CREW_CO_REQ       TYP_CREW_CO_REQ;
    
    
    TYPE REC_ORG_PRIV IS RECORD (
        ID_N_R             ORG_DTLS.ID_N%TYPE 
      );

    TYPE TYP_ORG_PRIV IS
    TABLE OF REC_ORG_PRIV INDEX BY PLS_INTEGER;

    LV_ORG_PRIV      TYP_ORG_PRIV ;

BEGIN

    SELECT COUNT(*)
        INTO LV_CNT_ST
    FROM ST_BONDSTATUS ;
    
    /****Added by Tiyasha 28-Nov****/
    
    EXECUTE IMMEDIATE 'TRUNCATE TABLE ORG_DTLS_PROD_BKP';
    
    EXECUTE IMMEDIATE 'INSERT INTO ORG_DTLS_PROD_BKP SELECT * FROM SYN_ORG_DTLS';
    
    /****Added by Tiyasha 28-Nov****/
    
    SELECT COUNT(*) INTO LV_SI_CREW_CO_REQ
    FROM (
    SELECT
            A.COY_RCB, A.BOND_EXPIRY_DATE, A.STATUS
        FROM
            ST_BONDSTATUS A
            WHERE --COY_RCB NOT IN (SELECT CO_UEN_N FROM ORG_DTLS) 
            NOT EXISTS (SELECT  CO_UEN_N 
                        FROM ORG_DTLS n WHERE   A.COY_RCB = n.CO_UEN_N  ) ) ;
    
    SELECT ID_N INTO LV_CDORG_PRIV_ID_N
    FROM SYS_PRIVILEGE_TY 
    WHERE   DESCR_X     = 'Crew Eligible' 
    AND     AGENCY_X    = 'ICA' ;

    OPEN CR_CREW_CO_REQ;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CREW_CO_REQ', 'PROC_1_CREW_CO_REQ', 'INSERTION INTO TABLE CREW_CO_REQ', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_CREW_CO_REQ BULK COLLECT INTO LV_CREW_CO_REQ LIMIT 10000;
        EXIT WHEN LV_CREW_CO_REQ.COUNT = 0;

        FOR J IN LV_CREW_CO_REQ.FIRST..LV_CREW_CO_REQ.LAST LOOP
            BEGIN   

                INSERT INTO CREW_CO_REQ (
                    ID_N ,
                    CO_UEN_N,
                    BOND_EXPY_D,
                    ELG_VSL_TY,
                    CR_REQ_ST,
                    LOCK_VER_N
                ) VALUES (
                    SYN_SEQ_CREW_CO_ID_N.NEXTVAL,
                    LV_CREW_CO_REQ(J).COY_RCB_R,
                    LV_CREW_CO_REQ(J).BOND_EXPIRY_DATE_R,
                    LV_CREW_CO_REQ(J).STATUS_R ,
                    'PENDING',
                    0                    
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                                 
                V_EXP_ROWS_SI :=        LV_CREW_CO_REQ(J).COY_RCB_R
                                     || '<{||}>'
                                     || LV_CREW_CO_REQ(J).BOND_EXPIRY_DATE_R
                                     || '<{||}>'
                                     || LV_CREW_CO_REQ(J).STATUS_R
                                     || '<{||}>'
                                     ||  NULL
                                     ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_ST_AUDIT', 'PROC_1_CREW_CO_REQ', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;
CLOSE CR_CREW_CO_REQ;
  --  COMMIT;
---------------------------------------------------
         OPEN CR_ORG_PRIV;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEDGES', 'PROC_1_CREW_CO_REQ', 'INSERTION INTO TABLE ORG_PRIVILEGES', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_PRIV BULK COLLECT INTO LV_ORG_PRIV LIMIT 10000;
        EXIT WHEN LV_ORG_PRIV.COUNT = 0;

        FOR K IN LV_ORG_PRIV.FIRST..LV_ORG_PRIV.LAST LOOP
            BEGIN   

                INSERT INTO ORG_PRIVILEGES (
                   ORG_DTLS_ID_N, 
                   CODEORG_PRIVILEGES_ID_N
                ) VALUES (
                    LV_ORG_PRIV(K).ID_N_R,
                    LV_CDORG_PRIV_ID_N               --'12'
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                /*                 
                V_EXP_ROWS_SI :=        LV_CREW_CO_REQ(J).COY_RCB_R
                                     || '<{||}>'
                                     || LV_CREW_CO_REQ(J).BOND_EXPIRY_DATE_R
                                     || '<{||}>'
                                     || LV_CREW_CO_REQ(J).STATUS_R
                                     || '<{||}>'
                                     ||  NULL
                                     ;
            */
                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_PRIVILEDGES', 'PROC_1_CREW_CO_REQ', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;
    CLOSE CR_ORG_PRIV;
--------------------------------------------------------
    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM CREW_CO_REQ;  ---- TARGET TABLE COUNT 
    
    SELECT
    COUNT(distinct ORG_DTLS_ID_N)
    INTO LV_CNT_ORG_PRIV
    FROM ORG_PRIVILEGES WHERE CODEORG_PRIVILEGES_ID_N = 12 ; 
    
    IF ( LV_CNT_TAR = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CREW_CO_REQ', 'PROC_1_CREW_CO_REQ', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_ST AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CREW_CO_REQ', 'PROC_1_CREW_CO_REQ', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_ST OR LV_CNT_TAR = LV_CNT_ST ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CREW_CO_REQ', 'PROC_1_CREW_CO_REQ', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;
    
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_BONDSTATUS', LV_CNT_ST, 'SI_CREW_CO_REQ_Q', LV_SI_CREW_CO_REQ, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_BONDSTATUS', LV_CNT_ST, 'CREW_CO_REQ', LV_CNT_TAR, 'Y');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_BONDSTATUS', LV_CNT_ST, 'ORG_PRIVILEGES', LV_CNT_ORG_PRIV, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CREW_CO_REQ', 'PROC_1_CREW_CO_REQ', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_CREW_CO_REQ ;
/