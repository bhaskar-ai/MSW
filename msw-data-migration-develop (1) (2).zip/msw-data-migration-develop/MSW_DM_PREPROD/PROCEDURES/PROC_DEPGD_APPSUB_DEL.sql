create or replace procedure PROC_DEPGD_APPSUB_DEL  is 

V_ERR_CODE  number;

V_SQLERRM  varchar2(2000);

V_ERR_MSG  varchar2(2000);





/*******************************************************************
cursor to delete  data from application submission starts
*****************************************************************/

cursor cur_depgd_appsub_del is 

select MSW_APPLN_REF_ID_X from Application_submission 
WHERE  APPLN_TY_C = 'GDD' and  MSW_APPLN_REF_ID_X not in (select MSW_APPLN_REF_ID_X from departure_gd_application);


TYPE rec_depgd_appsub_del IS RECORD 
(
 V_MSW_APPLN_REF_ID_X   Application_submission.MSW_APPLN_REF_ID_X%type
);

 TYPE TYPE_V_depgd_appsub_del  IS    TABLE OF rec_depgd_appsub_del  INDEX BY PLS_INTEGER;

  LV_V_APP_SUB_ID_N   TYPE_V_depgd_appsub_del ;


/*******************************************************************
cursor to delete  data from vessel call   ends
*****************************************************************/



begin 





/*************************************
DELETE FROM Application Submission
****************************************/

open  cur_depgd_appsub_del;

loop

  FETCH cur_depgd_appsub_del BULK COLLECT INTO LV_V_APP_SUB_ID_N limit 10000;


   EXIT WHEN LV_V_APP_SUB_ID_N.count = 0;

FORALL i IN LV_V_APP_SUB_ID_N.FIRST..LV_V_APP_SUB_ID_N.LAST


DELETE FROM Application_submission     
WHERE   MSW_APPLN_REF_ID_X =  LV_V_APP_SUB_ID_N(i).V_MSW_APPLN_REF_ID_X;
commit;
end loop;
close cur_depgd_appsub_del;





/*************************************
DELETE FROM Application Submission Ends
****************************************/


exception 
when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('GDD_DELETE', 'proc_depgd_appsub_del', V_SQLERRM, 'FAIL',null,null,null,'T');

end;
/