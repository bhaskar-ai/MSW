create or replace PROCEDURE PROC_2_DG_APPL (
    pv_run_id IN   NUMBER
) IS

    lv_cnt_st                  NUMBER;
    lv_cnt_si                  NUMBER;
  -- lv_cnt_src              NUMBER;
    lv_cnt_PSA_JPC              NUMBER;
    lv_cnt_tar_appl            NUMBER;
    lv_cnt_tar_doc             NUMBER;
    LV_pm4supportingdocindx_n   NUMBER; 
    LV_ty_x                     VARCHAR2(100);  
    LV_pm4id_n                  NUMBER;
    v_err_code                 VARCHAR2(1000);
    v_err_msg                  VARCHAR2(1000);
    v_sqlerrm                  VARCHAR2(1000);
  -- v_m_blkexptn_count      VARCHAR2 (100);
  -- v_m_blkexptn_desc       VARCHAR2 (1000);
    v_exp_rows_si              VARCHAR2(4000);
    v_exp_rows_appl            VARCHAR2(4000);
    v_exp_rows_doc             VARCHAR2(4000);
    v_exp_rows1                VARCHAR2(1000);
    v_exp_rows2                VARCHAR2(1000);
    v_exp_rows3                VARCHAR2(1000);
    v_exp_rows4                VARCHAR2(1000);
    v_exp_rows5                VARCHAR2(1000);
    v_exp_rows6                VARCHAR2(1000);
    v_exp_rows7                VARCHAR2(1000);
    v_exp_rows8                VARCHAR2(1000);
    v_exp_rows9                VARCHAR2(1000);
    v_exp_rows10               VARCHAR2(1000);
    v_exp_rows11               VARCHAR2(1000);
    v_exp_rows12               VARCHAR2(1000);
    v_exp_rows13               VARCHAR2(1000);
    v_exp_rows14               VARCHAR2(1000);
    v_exp_rows15               VARCHAR2(1000);
    v_exp_rows16               VARCHAR2(1000);
    v_exp_rows17               VARCHAR2(1000);
    v_exp_rows18               VARCHAR2(1000);
    v_exp_rows19               VARCHAR2(1000);
    v_exp_rows20               VARCHAR2(1000);
    v_exp_rows21               VARCHAR2(1000);
    v_exp_rows22               VARCHAR2(1000);
    v_exp_rows23               VARCHAR2(1000);
    v_exp_rows24               VARCHAR2(1000);
    v_exp_rows25               VARCHAR2(1000);
    v_exp_rows26               VARCHAR2(1000);
    v_exp_rows27               VARCHAR2(1000);
    v_exp_rows28               VARCHAR2(1000);
    v_exp_rows29               VARCHAR2(1000);
    v_exp_rows30               VARCHAR2(1000);
    v_exp_rows31               VARCHAR2(1000);
    v_exp_rows32               VARCHAR2(1000);
    v_exp_rows33               VARCHAR2(1000);
    v_exp_rows34               VARCHAR2(1000);
    v_exp_rows35               VARCHAR2(1000);
    v_exp_rows36               VARCHAR2(1000);
    v_exp_rows37               VARCHAR2(1000);
    v_exp_rows38               VARCHAR2(1000);
    v_exp_rows39               VARCHAR2(1000);
    v_exp_rows40               VARCHAR2(1000);
    v_exp_rows41               VARCHAR2(1000);
    v_exp_rows42               VARCHAR2(1000);
    v_exp_rows43               VARCHAR2(1000);
    v_exp_rows44               VARCHAR2(1000);
    v_exp_rows45               VARCHAR2(1000);
    v_exp_rows46               VARCHAR2(1000);
    v_exp_rows47               VARCHAR2(1000);
    v_exp_rows48               VARCHAR2(1000);
    v_exp_rows49               VARCHAR2(1000);
    v_exp_rows50               VARCHAR2(1000);
    LV_waste_i                 NUMBER(1) ;
    LV_residue_i               NUMBER(1) ;
    LV_tankcntr_i              NUMBER(1) ;
    lv_errcnt                  number(20) default 0;

   /***********************************************************************************************************
   procedure name : proc_2_dg_appl
   Created By     : Sourangshu Dhar
   Date           : 15-Apr-2019
   Purpose        : To insert data from Source Staging Table to Intermidiate Table
   Modified by    :
   Modified date  :

   *************************************************************************************************************/
    CURSOR cr_si_dg_application IS
   ------*************** Cursor for fetching data from the Source Staging Table *****----

    SELECT
                a.pm4id_n,
                a.loclcontact_m,
                a.notifnmtd_c,
                a.mobile_n,
                a.opern_c,
                a.locn_c,
                a.cntr_n,
                a.bl_n,
                a.imocl_c,
                a.un_n,
                a.psn_m,
                a.tn_m,
                a.pkgty_c,
                a.flashpt_n,
                a.compbgrp_c,
                a.wt_n,
                a.waste_i,
                a.residue_i,
                a.tankcntr_i,
                a.st_c,
                a.mparem_x,
                a.vettedon_dt,
                a.vettedby_m,
                a.crton_dt,
                a.crtby_m,
                a.updon_dt,
                a.updby_m,
                a.emailaddr_x,
                a.usrinputvsl_m,
                a.craftlic_n,
                b.eta_dt,
                b.rta_dt,
                b.rtd_dt,
                b.invoy_n,
                b.outvoy_n,
                b.vslid_n,
                vl.msw_vsl_id_n, a.NOOFPKG_N, a.SENDERORG_C,
				a.org_c,a.uen_n,a.org_m,a.usrid_c,a.usr_m,
				a.wc_c,a.autogenty_c,a.submissn_dt
            FROM
                st_dg_pm4 a,
                st_dg_vslcall b,
                vessel vl
            WHERE
                a.vslcallindx_n = b.vslcallindx_n
                AND b.vslid_n = vl.vsl_rec_id_n ;

   CURSOR cr_dg_appl IS
      --*************** Cursor for fetching data from the Intermidiate Table *****----
    SELECT
        pm4id_n,
        loclcontact_m,
        notifnmtd_c,
        mobile_n,
        DECODE(opern_c, 'D', 'DISCHARGE', 'L', 'LOADING', 'T', 'TRANSIT') opern_c,
        locn_c,
        cntr_n,
        bl_n,
        imocl_c,
        un_n,
        psn_m,
        tn_m,
        pkgty_c,
        flashpt_n,
        compbgrp_c,
        wt_n,
        waste_i,
        residue_i,
        tankcntr_i,
        DECODE(st_c, 'W', 'Withdrawn', 'A', 'Approved', 'P', 'Pending', 'N', 'Not Approved') st_c,
        crton_dt,
        crtby_m,
        updon_dt,
        updby_m,
        DECODE(nvl(emailaddr_x, '0'), '0', '0', '1') subr_email_i,
        emailaddr_x,
        DECODE(nvl(mobile_n, '0'), '0', '0', '1') subr_sms_i,
        usrinputvsl_m,
        craftlic_n,
        eta_dt,
        rta_dt,
        rtd_dt,
        invoy_n,
        outvoy_n,
      --  subrisk_c,
        mparem_x,
        vettedby_m,
        vettedon_dt,
        vslid_n,
        pm4supportingdocindx_n,
        ty_x,
        msw_vsl_id_n,NOOFPKG_N,SENDERORG_C,
		org_c,uen_n,org_m,usrid_c,usr_m,
		wc_c,autogenty_c,submissn_dt
    FROM
        si_dg_application
    ORDER BY
        crton_dt;

   --***************** Declaring Types ****************------

    TYPE rec_si_dg_application IS RECORD (
        pm4id_n_r                  st_dg_pm4.pm4id_n%TYPE,
        loclcontact_m_r            st_dg_pm4.loclcontact_m%TYPE,
        notifnmtd_c_r              st_dg_pm4.notifnmtd_c%TYPE,
        mobile_n_r                 st_dg_pm4.mobile_n%TYPE,
        opern_c_r                  st_dg_pm4.opern_c%TYPE,
        locn_c_r                   st_dg_pm4.locn_c%TYPE,
        cntr_n_r                   st_dg_pm4.cntr_n%TYPE,
        bl_n_r                     st_dg_pm4.bl_n%TYPE,
        imocl_c_r                  st_dg_pm4.imocl_c%TYPE,
        un_n_r                     st_dg_pm4.un_n%TYPE,
        psn_m_r                    st_dg_pm4.psn_m%TYPE,
        tn_m_r                     st_dg_pm4.tn_m%TYPE,
        pkgty_c_r                  st_dg_pm4.pkgty_c%TYPE,
        flashpt_n_r                st_dg_pm4.flashpt_n%TYPE,
        compbgrp_c_r               st_dg_pm4.compbgrp_c%TYPE,
        wt_n_r                     st_dg_pm4.wt_n%TYPE,
        waste_i_r                  st_dg_pm4.waste_i%TYPE,
        residue_i_r                st_dg_pm4.residue_i%TYPE,
        tankcntr_i_r               st_dg_pm4.tankcntr_i%TYPE,
        st_c_r                     st_dg_pm4.st_c%TYPE,
        mparem_x_r                 st_dg_pm4.mparem_x%TYPE,
        vettedon_dt_r              st_dg_pm4.vettedon_dt%TYPE,
        vettedby_m_r               st_dg_pm4.vettedby_m%TYPE,
        crton_dt_r                 st_dg_pm4.crton_dt%TYPE,
        crtby_m_r                  st_dg_pm4.crtby_m%TYPE,
        updon_dt_r                 st_dg_pm4.updon_dt%TYPE,
        updby_m_r                  st_dg_pm4.updby_m%TYPE,
        emailaddr_x_r              st_dg_pm4.emailaddr_x%TYPE,
        usrinputvsl_m_r            st_dg_pm4.usrinputvsl_m%TYPE,
        craftlic_n_r               st_dg_pm4.craftlic_n%TYPE,
        eta_dt_r                   st_dg_vslcall.eta_dt%TYPE,
        rta_dt_r                   st_dg_vslcall.rta_dt%TYPE,
        rtd_dt_r                   st_dg_vslcall.rtd_dt%TYPE,
        invoy_n_r                  st_dg_vslcall.invoy_n%TYPE,
        outvoy_n_r                 st_dg_vslcall.outvoy_n%TYPE,
        vslid_n_r                  st_dg_vslcall.vslid_n%TYPE,
       -- subrisk_c_r                st_dg_subrisk.subrisk_c%TYPE,
      --  pm4supportingdocindx_n_r   st_dg_pm4supportingdoc.pm4supportingdocindx_n%TYPE,
      --  ty_x_r                     st_pm4supportingdoc_mapping.ty_x%TYPE,
        msw_vsl_id_n_r             NUMBER,
        NOOFPKG_N_r                 st_dg_pm4.NOOFPKG_N%TYPE,
        SENDERORG_C_r               st_dg_pm4.SENDERORG_C%TYPE,
		org_c_r						st_dg_pm4.ORG_C%TYPE,
		uen_n_r						st_dg_pm4.UEN_N%TYPE,
		org_m_r						st_dg_pm4.ORG_M%TYPE,
		usrid_c_r					st_dg_pm4.USRID_C%TYPE,
		usr_m_r						st_dg_pm4.USR_M%TYPE,
		wc_c_r						st_dg_pm4.WC_C%TYPE,
		autogenty_c_r				st_dg_pm4.autogenty_c%TYPE,
		submissn_dt_r				st_dg_pm4.submissn_dt%TYPE
    );
    TYPE typ_si_dg_application IS
        TABLE OF rec_si_dg_application INDEX BY PLS_INTEGER;
    lv_si_dg_application       typ_si_dg_application;
    /*TYPE rec_dg_application IS RECORD (
        pm4id_n_r                  si_dg_application.pm4id_n%TYPE,
        loclcontact_m_r            si_dg_application.loclcontact_m%TYPE,
        notifnmtd_c_r              si_dg_application.notifnmtd_c%TYPE,
        mobile_n_r                 si_dg_application.mobile_n%TYPE,
        opern_c_r                  si_dg_application.opern_c%TYPE,
        locn_c_r                   si_dg_application.locn_c%TYPE,
        cntr_n_r                   si_dg_application.cntr_n%TYPE,
        bl_n_r                     si_dg_application.bl_n%TYPE,
        imocl_c_r                  si_dg_application.imocl_c%TYPE,
        un_n_r                     si_dg_application.un_n%TYPE,
        psn_m_r                    si_dg_application.psn_m%TYPE,
        tn_m_r                     si_dg_application.tn_m%TYPE,
        pkgty_c_r                  si_dg_application.pkgty_c%TYPE,
        flashpt_n_r                si_dg_application.flashpt_n%TYPE,
        compbgrp_c_r               si_dg_application.compbgrp_c%TYPE,
        wt_n_r                     si_dg_application.wt_n%TYPE,
        waste_i_r                  si_dg_application.waste_i%TYPE,
        residue_i_r                si_dg_application.residue_i%TYPE,
        tankcntr_i_r               si_dg_application.tankcntr_i%TYPE,
        st_c_r                     si_dg_application.st_c%TYPE,
        --mparem_x_r                 si_dg_application.mparem_x%TYPE,
       -- vettedon_dt_r              si_dg_application.vettedon_dt%TYPE,
       --vettedby_m_r               si_dg_application.vettedby_m%TYPE,
        crton_dt_r                 si_dg_application.crton_dt%TYPE,
        crtby_m_r                  si_dg_application.crtby_m%TYPE,
        updon_dt_r                 si_dg_application.updon_dt%TYPE,
        updby_m_r                  si_dg_application.updby_m%TYPE,
        emailaddr_x_r              si_dg_application.emailaddr_x%TYPE,
        usrinputvsl_m_r            si_dg_application.usrinputvsl_m%TYPE,
        craftlic_n_r               si_dg_application.craftlic_n%TYPE,
        eta_dt_r                   si_dg_application.eta_dt%TYPE,
        rta_dt_r                   si_dg_application.rta_dt%TYPE,
        invoy_n_r                  si_dg_application.invoy_n%TYPE,
        outvoy_n_r                 si_dg_application.outvoy_n%TYPE,
       -- subrisk_c_r                si_dg_application.subrisk_c%TYPE,
        pm4supportingdocindx_n_r   si_dg_application.pm4supportingdocindx_n%TYPE,
        ty_x_r                     si_dg_application.ty_x%TYPE,
        msw_vsl_id_n_r             NUMBER,
        NOOFPKG_N_r                 si_dg_application.NOOFPKG_N%TYPE,
		org_c_r						si_dg_application.ORG_C%TYPE,
		uen_n_r						si_dg_application.UEN_N%TYPE,
		org_m_r						si_dg_application.ORG_M%TYPE,
		usrid_c_r					si_dg_application.USRID_C%TYPE,
		usr_m_r						si_dg_application.USR_M%TYPE,
		wc_c_r						si_dg_application.WC_C%TYPE,
		autogenty_c_r				si_dg_application.autogenty_c%TYPE,
		submissn_dt_r				si_dg_application.submissn_dt%TYPE
    );
    TYPE typ_dg_application IS
        TABLE OF rec_dg_application INDEX BY PLS_INTEGER;
Commented by Maria*/
   --lv_dg_application       typ_dg_application;
    v_sq_appln_ref_n           NUMBER;
    v_msw_appln_ref_id_x       VARCHAR2(20);
    v_msw_vsl_call_id          NUMBER;
    v_flag                     VARCHAR2(1);
    pv_dg_application          dangerous_goods_application%rowtype;
    pv_dg_application_doc      dangerous_goods_application_document%rowtype;
    lval                       CLOB;
    lv_data_dump               CLOB;
    pv_data_dump               CLOB;
    l_val                      NUMBER(6);
    v_year_month               NUMBER(4);
    v_yr_mnth                  NUMBER(4);
    p_yymm                     VARCHAR2(5);
    v_blkexptn_count           NUMBER(20, 0);
    lv_max                     VARCHAR2(20);
    lv_yrmnth                  NUMBER(4);
    V_VSL_REF_ID_OUT       NUMBER;
    V_FLAG_VSL_REF         VARCHAR2(1);
BEGIN  -- OUTER BEGIN  


    SELECT
        COUNT(*)
    INTO lv_cnt_st
    FROM
        st_dg_pm4;    --driving table count 

    OPEN cr_si_dg_application;
    pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', 'Insertion into Table SI_DG_APPLICATION', 'START'
    , pv_run_id, NULL, NULL, 'T');

    LOOP   -- CURSOR LOOP STARTS 
         -------************ Bulk collect for inserting data into Intermidiate  Table ***********************---------------
            FETCH cr_si_dg_application BULK COLLECT INTO lv_si_dg_application LIMIT 1000;
            EXIT WHEN lv_si_dg_application.count = 0;
          --  FORALL i IN lv_si_dg_application.first..lv_si_dg_application.last SAVE EXCEPTIONS
            FOR i IN lv_si_dg_application.first..lv_si_dg_application.last

            LOOP  -- FOR LOOP   I 

            BEGIN   -- sI TALE BEGIN 
                INSERT INTO si_dg_application (
                    pm4id_n,
                    loclcontact_m,
                    notifnmtd_c,
                    mobile_n,
                    opern_c,
                    locn_c,
                    cntr_n,
                    bl_n,
                    imocl_c,
                    un_n,
                    psn_m,
                    tn_m,
                    pkgty_c,
                    flashpt_n,
                    compbgrp_c,
                    wt_n,
                    waste_i,
                    residue_i,
                    tankcntr_i,
                    st_c,
                    mparem_x,
                    vettedby_m,
                    vettedon_dt,
                    crton_dt,
                    crtby_m,
                    updon_dt,
                    updby_m,
                    emailaddr_x,
                    usrinputvsl_m,
                    craftlic_n,
                    eta_dt,
                    rta_dt,
                    rtd_dt,
                    invoy_n,
                    outvoy_n,
                    subrisk_c,
                  --  pm4supportingdocindx_n,
                 --   ty_x,
                    vslid_n,
                    msw_vsl_id_n,NOOFPKG_N,SENDERORG_C,
					org_c,uen_n,org_m,usrid_c,usr_m,
		wc_c,autogenty_c,submissn_dt
                ) VALUES (
                    lv_si_dg_application(i).pm4id_n_r,
                    lv_si_dg_application(i).loclcontact_m_r,
                    lv_si_dg_application(i).notifnmtd_c_r,
                    lv_si_dg_application(i).mobile_n_r,
                    lv_si_dg_application(i).opern_c_r,
                    lv_si_dg_application(i).locn_c_r,
                    lv_si_dg_application(i).cntr_n_r,
                    lv_si_dg_application(i).bl_n_r,
                    lv_si_dg_application(i).imocl_c_r,
                    lv_si_dg_application(i).un_n_r,
                    lv_si_dg_application(i).psn_m_r,
                    lv_si_dg_application(i).tn_m_r,
                    lv_si_dg_application(i).pkgty_c_r,
                    lv_si_dg_application(i).flashpt_n_r,
                    lv_si_dg_application(i).compbgrp_c_r,
                    lv_si_dg_application(i).wt_n_r,
                    lv_si_dg_application(i).waste_i_r,
                    lv_si_dg_application(i).residue_i_r,
                    lv_si_dg_application(i).tankcntr_i_r,
                    lv_si_dg_application(i).st_c_r,
                    lv_si_dg_application(i).mparem_x_r,
                    lv_si_dg_application(i).vettedby_m_r,
                    lv_si_dg_application(i).vettedon_dt_r,
                    lv_si_dg_application(i).crton_dt_r,
                    lv_si_dg_application(i).crtby_m_r,
                    lv_si_dg_application(i).updon_dt_r,
                    lv_si_dg_application(i).updby_m_r,
                    lv_si_dg_application(i).emailaddr_x_r,
                    lv_si_dg_application(i).usrinputvsl_m_r,
                    lv_si_dg_application(i).craftlic_n_r,
                    lv_si_dg_application(i).eta_dt_r,
                    lv_si_dg_application(i).rta_dt_r,
                    lv_si_dg_application(i).rtd_dt_r,
                    lv_si_dg_application(i).invoy_n_r,
                    lv_si_dg_application(i).outvoy_n_r,
                    null,                           --lv_si_dg_application(i).subrisk_c_r,
                 --   lv_si_dg_application(i).pm4supportingdocindx_n_r,
                 --   lv_si_dg_application(i).ty_x_r,
                    lv_si_dg_application(i).vslid_n_r,
                    lv_si_dg_application(i).msw_vsl_id_n_r, 
                    lv_si_dg_application(i).NOOFPKG_N_r,
                    lv_si_dg_application(i).SENDERORG_C_r,
					lv_si_dg_application(i).org_c_r,		
					lv_si_dg_application(i).uen_n_r	,	
					lv_si_dg_application(i).org_m_r	,	
					lv_si_dg_application(i).usrid_c_r,	
					lv_si_dg_application(i).usr_m_r		,
					lv_si_dg_application(i).wc_c_r		,
					lv_si_dg_application(i).autogenty_c_r,
					lv_si_dg_application(i).submissn_dt_r
                );

        EXCEPTION  -- SI EXCEPTION
            WHEN OTHERS THEN
                        v_err_code := sqlcode;
                        v_err_msg := substr(sqlerrm, 1, 200);
                        v_sqlerrm := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| v_err_code || v_err_msg;

        V_EXP_ROWS_SI:=            lv_si_dg_application(i).pm4id_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).loclcontact_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).notifnmtd_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).mobile_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).opern_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).locn_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).cntr_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).bl_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).imocl_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).un_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).psn_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).tn_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).pkgty_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).flashpt_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).compbgrp_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).wt_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).waste_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).residue_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).tankcntr_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).st_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).mparem_x_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vettedby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vettedon_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).crton_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).crtby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).updon_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).updby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).emailaddr_x_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).usrinputvsl_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).craftlic_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).eta_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).rta_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).invoy_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).outvoy_n_r
                                /*     || '<{||}>'
                                     || lv_si_dg_application(i).pm4supportingdocindx_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).ty_x_r  */
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vslid_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).msw_vsl_id_n_r;


    if lv_errcnt < 50 then 

        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', v_sqlerrm, 'ERROR', pv_run_id,
                                                        sqlerrm, v_exp_rows_si, 'T');
        lv_errcnt:=lv_errcnt+1;
    end if;

            END ;  -- SI END 
        END LOOP;   -- FOR LOOP I   ENDS
    END LOOP;   -- CURSOR LOOP  ENDS

    COMMIT;

    SELECT
        COUNT(*)
    INTO lv_cnt_si
    FROM
        si_dg_application;

    IF ( lv_cnt_si = lv_cnt_st ) AND lv_cnt_st <> 0 AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'SUCCESS'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_si <> lv_cnt_st AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'PARTIALLY SUCCESSFULL'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_si <> lv_cnt_st OR lv_cnt_si = lv_cnt_st ) AND ( lv_cnt_si = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'FAIL'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'SI_DG_APPLICATION', lv_cnt_si, 'N');

      ------------------------------------ Inserting data into DG_Appl. Staging Table ---------------------------------------

      --  OPEN cr_dg_appl;
        pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', 'Insertion into Table DG_Appl.and DG_Appl_Doc'
        , 'START', pv_run_id, NULL, NULL, 'T');





        FOR j IN cr_dg_appl 


        LOOP    -- FOR LOOP J  


        BEGIN   -- INNER BEGIN J 

                v_sq_appln_ref_n := seq_dg_appl.nextval;

                SELECT
                    TO_CHAR(j.crton_dt, 'YY')
                    || TO_CHAR(j.crton_dt, 'MM')
                INTO v_year_month
                FROM
                    dual;

                IF v_year_month != p_yymm AND p_yymm IS NOT NULL THEN
                    EXECUTE IMMEDIATE 'select APP_SUB_SEQ_DG.NEXTVAL from dual'
                    INTO l_val;
                    EXECUTE IMMEDIATE 'alter sequence APP_SUB_SEQ_DG increment by -'
                                      || l_val
                                      || ' minvalue 0';
                    EXECUTE IMMEDIATE 'select APP_SUB_SEQ_DG.NEXTVAL from dual'
                    INTO l_val;
                    EXECUTE IMMEDIATE 'alter sequence APP_SUB_SEQ_DG increment by 1 minvalue 0';
                END IF;

                p_yymm := v_year_month;

                v_msw_appln_ref_id_x := 'MSW'
                                        || 'DGD'
                                        || TO_CHAR(j.crton_dt, 'YY')
                                        || TO_CHAR(j.crton_dt, 'MM')
                                        || TO_CHAR(app_sub_seq_dg.nextval, 'FM00000');

----------**** Vessel Call and Appl.Submission Insertion *****----------------------

        SELECT          decode(j.waste_i,'Y',1,'N',0),decode(j.residue_i,'Y',1,'N',0),DECODE(j.tankcntr_i,'Y',1,'N',0)
            INTO        LV_waste_i,LV_residue_i,LV_tankcntr_i 
        FROM DUAL ;

             pv_dg_application.appln_ref_n := v_sq_appln_ref_n;
                pv_dg_application.vsl_call_id_n := v_msw_vsl_call_id;
                pv_dg_application.extl_appln_ref_x := j.pm4id_n;
                pv_dg_application.applcnt_id_x := '1';
                pv_dg_application.msw_appln_ref_id_x := v_msw_appln_ref_id_x;
                pv_dg_application.cont_pers_m := j.loclcontact_m;
                pv_dg_application.mobile_n := j.mobile_n;
                pv_dg_application.eta_dt := j.eta_dt;
                pv_dg_application.rta_dt := j.rta_dt;
                pv_dg_application.in_voy_x := j.invoy_n;
                pv_dg_application.out_voy_x := j.outvoy_n;
                pv_dg_application.opern_c := j.opern_c;
                pv_dg_application.locn_c := j.locn_c;
                pv_dg_application.cntr_x := j.cntr_n;
                pv_dg_application.ucr_x := j.bl_n;
                pv_dg_application.imo_cl_c := j.imocl_c;
                pv_dg_application.un_x := j.un_n;
                pv_dg_application.psn_n := j.psn_m;
                pv_dg_application.tn_n := j.tn_m;
                pv_dg_application.pkg_ty_c := j.pkgty_c;
                pv_dg_application.pkg_ty_others_x := NULL;
                pv_dg_application.flash_pt_n := j.flashpt_n;
                pv_dg_application.wt_n := j.wt_n;
                pv_dg_application.waste_i := LV_waste_i ;
                pv_dg_application.residue_i := LV_residue_i;
              --  pv_dg_application.sub_risk_c := j.subrisk_c;
                pv_dg_application.tank_cntr_i := LV_tankcntr_i;
                pv_dg_application.st_c := j.st_c;
                pv_dg_application.processing_rem_x := j.mparem_x;
                pv_dg_application.processed_by_x := j.vettedby_m;
                pv_dg_application.processed_on_dt := j.vettedon_dt;
                pv_dg_application.crt_by_x := j.crtby_m;
                pv_dg_application.crt_on_dt := j.crton_dt;
                pv_dg_application.upt_by_x := j.updby_m;
                pv_dg_application.upt_on_dt := j.updon_dt;
                pv_dg_application.subr_email_i := j.subr_email_i;
                pv_dg_application.email_x := j.emailaddr_x;
                pv_dg_application.subr_sms_i := j.subr_sms_i;
                pv_dg_application.usr_input_vsl_m := j.usrinputvsl_m;
                pv_dg_application.dgs_declrd_i := NULL;
                pv_dg_application.cft_lic_x := j.craftlic_n;
				/* Commented by Maria 
                pv_dg_application.org_c	 := j.org_c;
				pv_dg_application.uen_n	:= j.uen_n;	
				pv_dg_application.org_m	:= j.org_m;	
				pv_dg_application.usrid_c := j.usrid_c;
				pv_dg_application.usr_m	:= j.usr_m;
				pv_dg_application.wc_c	:= j.wc_c;
				pv_dg_application.submissn_dt := j.submissn_dt;*/

                pv_dg_application_doc.dg_appln_doc_id_n := seq_dg_appl_doc.nextval;
                pv_dg_application_doc.appln_ref_n := v_sq_appln_ref_n;
        --   pv_dg_application_doc.doc_id_n := s.pm4supportingdocindx_n;
        --   pv_dg_application_doc.ty_c :=   s.ty_x;
                pv_dg_application_doc.crt_by_x := j.crtby_m;
                pv_dg_application_doc.crt_on_dt := j.crton_dt;
                pv_dg_application_doc.LOCK_VER_N := 0;

                lv_data_dump := fnc_json_val_dgd(pv_dg_application, pv_dg_application_doc);  

----VESSEL_REFERENCE Insertion---
    	PROC_1_VSL_REF (j.msw_vsl_id_n,j.vslid_n,NULL,NULL,NULL,NULL,NULL,NULL,V_VSL_REF_ID_OUT,V_FLAG_VSL_REF);
---------- Vessel Call and Appl.Submission Insertion *****----------------------

		IF V_FLAG_VSL_REF IS NULL THEN
                proc_2_vc_as(j.msw_vsl_id_n, j.eta_dt, NULL, j.rta_dt, j.rtd_dt, NULL, v_msw_appln_ref_id_x, j.pm4id_n, 'DGD', NULL
                , pv_run_id, 'DANGEROUS_GOODS_APPLICATION', v_msw_vsl_call_id, v_flag,'MSW',V_VSL_REF_ID_OUT);

-------************ Inserting data into DG_Appl. Staging Table ***********************---------------

    IF v_flag IS NULL THEN
      IF j.SENDERORG_C in ('JPS','PSA') THEN 
       BEGIN 
                    INSERT INTO DG_PSA_JPC (
                    PSA_JPC_REF_N, 
                    PM4ID_X, 
                    CO_ORG_C, 
                    CO_UEN_X, 
                    CO_M, 
                    USR_ID_N, 
                    APPLCNT_M, 
                    CONT_PERS_M, 
                    EMAIL_ADDR_X, 
                    MOBILE_X, 
                    NOTIFN_MTD_C, 
                    VSL_ID_N, 
                    VSL_M, 
                    IN_VOY_N, 
                    OUT_VOY_N, 
                    ETA_DT, 
                    RTA_DT, 
                    MVMT_ID_N, 
                    LOCN_C, 
                    OPERN_TY_C, 
                    CFT_LIC_X, 
                    CNTR_N, 
                    BL_N, 
                    IMO_CL_C, 
                    UN_N, 
                    SHPG_M, 
                    TN_M, 
                    PKG_TY, 
                    NO_OF_PKG_N, 
                    RESIDUE_I, 
                    TANK_CNTR_I, 
                    WT_N, 
                    WASTE_I, 
                    FLASH_PT_N, 
                    ST_C, 
                    WT_C, 
                    MPA_REM_X, 
                    DG_VETTED_BY, 
                    DG_VETTED_DT, 
                    AUTO_GEN_TY_C, 
                    DG_SUBMISSN_DT, 
                    CRT_BY_N, 
                    CRT_ON_DT, 
                    LST_UPD_BY_N, 
                    LST_UPD_ON_DT, 
                    LOCK_VER_N, 
                    DELETED_I) 
                    VALUES(
                    SEQ_DG_PSA_JPC.nextval , 
                    j.pm4id_n, 
                    j.ORG_C ,
                    j.UEN_N,
                    j.ORG_M,
                    j.USRID_C,
                    j.USR_M, 
                    j.loclcontact_m,
                    j.emailaddr_x, 
                    j.mobile_n, 
                    j.NOTIFNMTD_C,
                    j.msw_vsl_id_n  , 
                    j.usrinputvsl_m , 
                    j.invoy_n,
                    j.outvoy_n, 
                    j.eta_dt,
                    j.rta_dt, 
                    11, 
                    j.locn_c, 
                    j.opern_c, 
                    j.craftlic_n, 
                    j.cntr_n, 
                    j.bl_n, 
                    j.imocl_c, 
                    j.un_n, 
                    'DM', 
                    j.tn_m, 
                    j.pkgty_c, 
                    j.NOOFPKG_N, 
                    decode(j.residue_i,'Y',1,'N',0),  
                    DECODE(j.tankcntr_i,'Y',1,'N',0), 
                    j.wt_n, 
                    decode(j.waste_i,'Y',1,'N',0),
                    j.flashpt_n, 
                    j.st_c, 
                    j.WC_C ,
                    j. MPAREM_X,
                    j.vettedby_m,
                    j.vettedon_dt ,
                    'DM',
                    j.SUBMISSN_DT, 
                    j.crtby_m,
                    j.crton_dt,
                    j.updby_m,
                    j.updon_dt, 
                    0, 
                    0
                    ) ;

        EXCEPTION   
        WHEN OTHERS THEN
           if lv_errcnt < 50 then 
              pkg_datamigration_generic.proc_trace_exception('DG_PSA_JPC', 'PROC_2_DG_APPL', dbms_utility.format_error_backtrace||dbms_utility.format_error_stack,
                                                                        'ERROR', pv_run_id, sqlerrm, null , 'T');
              lv_errcnt:=lv_errcnt+1;
           end if;

     CONTINUE;
     END;
     ELSE 
                BEGIN 
                    INSERT INTO dangerous_goods_application (
                        appln_ref_n,
                        vsl_call_id_n,
                        extl_appln_ref_x,
                        applcnt_id_x,
                        msw_appln_ref_id_x,
                        cont_pers_m,
                        mobile_n,
                        eta_dt,
                        rta_dt,
                        in_voy_x,
                        out_voy_x,
                                                     --etd_dt,
                        opern_c,
                        locn_c,
                        cntr_x,
                        ucr_x,
                        imo_cl_c,
                        un_x,
                        psn_n,
                        tn_n,
                        pkg_ty_c,
                        pkg_ty_others_x,
                        flash_pt_n,
                        wt_n,
                        waste_i,
                        residue_i,
                                                     --  bl_x,
                        sub_risk_c,
                        tank_cntr_i,
                        st_c,
                        processing_rem_x,
                        processed_by_x,
                        processed_on_dt,
                        crt_by_x,
                        crt_on_dt,
                        upt_by_x,
                        upt_on_dt,
                        subr_email_i,
                        email_x,
                        subr_sms_i,
                        usr_input_vsl_m,
                        dgs_declrd_i,
                        cft_lic_x,DELETED_I,LOCK_VER_N,MSW_VSL_ID_N,NOOFPKG_N,vsl_m
                    ) VALUES (
                        v_sq_appln_ref_n,
                        v_msw_vsl_call_id,                    --VSL_CALL_ID_N
                        j.pm4id_n,
                        '1',                                   --APPLCNT_ID_X
                        v_msw_appln_ref_id_x,            --MSW_APPLN_REF_ID_X
                        j.loclcontact_m,
                        j.mobile_n,
                        j.eta_dt,
                        j.rta_dt,
                        j.invoy_n,
                        j.outvoy_n,
                        j.opern_c,
                        j.locn_c,
                        j.cntr_n,
                        j.bl_n,
                        j.imocl_c,
                        j.un_n,
                        j.psn_m,
                        j.tn_m,
                        j.pkgty_c,
                        NULL,
                        j.flashpt_n,
                        j.wt_n,
                        decode(j.waste_i,'Y',1,'N',0),
                        decode(j.residue_i,'Y',1,'N',0),
                    -- NULL,
                        NULL,   --j.subrisk_c,
                        DECODE(j.tankcntr_i,'Y',1,'N',0),
                        j.st_c,
                        j.mparem_x,
                        j.vettedby_m,
                        j.vettedon_dt,
                        j.crtby_m,
                        j.crton_dt,
                        j.updby_m,
                        j.updon_dt,
                        j.subr_email_i,
                        j.emailaddr_x,
                        j.subr_sms_i,
                        j.usrinputvsl_m,
                        NULL,
                        j.craftlic_n,0,0,j.msw_vsl_id_n,j.NOOFPKG_N,j.usrinputvsl_m
                    );



				EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_exp_rows1 := v_sq_appln_ref_n;
                    v_exp_rows2 := v_msw_vsl_call_id;                    --VSL_CALL_ID_N
                    v_exp_rows3 := j.pm4id_n;
                    v_exp_rows4 := '1';                                   --APPLCNT_ID_X
                    v_exp_rows5 := v_msw_appln_ref_id_x;            --MSW_APPLN_REF_ID_X
                    v_exp_rows6 := j.loclcontact_m;
                    v_exp_rows7 := j.mobile_n;
                    v_exp_rows8 := j.eta_dt;
                    v_exp_rows9 := j.rta_dt;
                    v_exp_rows10 := j.invoy_n;
                    v_exp_rows11 := j.outvoy_n;
                    v_exp_rows12 := j.opern_c;
                    v_exp_rows13 := j.locn_c;
                    v_exp_rows14 := j.cntr_n;
                    v_exp_rows15 := j.bl_n;
                    v_exp_rows16 := j.imocl_c;
                    v_exp_rows17 := j.un_n;
                    v_exp_rows18 := j.psn_m;
                    v_exp_rows19 := j.tn_m;
                    v_exp_rows20 := j.pkgty_c;
                    v_exp_rows21 := NULL;
                    v_exp_rows22 := j.flashpt_n;
                    v_exp_rows23 := j.wt_n;
                    v_exp_rows24 := j.waste_i;
                    v_exp_rows25 := j.residue_i;
                  --  v_exp_rows26 := j.subrisk_c;
                    v_exp_rows27 := j.tankcntr_i;
                    v_exp_rows28 := j.st_c;
                    v_exp_rows29 := j.mparem_x;
                    v_exp_rows30 := j.vettedby_m;
                    v_exp_rows31 := j.vettedon_dt;
                    v_exp_rows32 := j.crtby_m;
                    v_exp_rows33 := j.crton_dt;
                    v_exp_rows34 := j.updon_dt;
                    v_exp_rows35 := j.updby_m;
                    v_exp_rows36 := j.subr_email_i;
                    v_exp_rows37 := j.emailaddr_x;
                    v_exp_rows38 := j.subr_sms_i;
                    v_exp_rows39 := j.usrinputvsl_m;
                    v_exp_rows40 := NULL;
                    v_exp_rows41 := j.craftlic_n;

                    v_exp_rows_appl :=    v_exp_rows1
                                       || '<{||}>'
                                       || v_exp_rows2
                                       || '<{||}>'
                                       || v_exp_rows3
                                       || '<{||}>'
                                       || v_exp_rows4
                                       || '<{||}>'
                                       || v_exp_rows5
                                       || '<{||}>'
                                       || v_exp_rows6
                                       || '<{||}>'
                                       || v_exp_rows7
                                       || '<{||}>'
                                       || v_exp_rows8
                                       || '<{||}>'
                                       || v_exp_rows9
                                       || '<{||}>'
                                       || v_exp_rows10
                                       || '<{||}>'
                                       || v_exp_rows11
                                       || '<{||}>'
                                       || v_exp_rows12
                                       || '<{||}>'
                                       || v_exp_rows13
                                       || '<{||}>'
                                       || v_exp_rows14
                                       || '<{||}>'
                                       || v_exp_rows15
                                       || '<{||}>'
                                       || v_exp_rows16
                                       || '<{||}>'
                                       || v_exp_rows17
                                       || '<{||}>'
                                       || v_exp_rows18
                                       || '<{||}>'
                                       || v_exp_rows19
                                       || '<{||}>'
                                       || v_exp_rows20
                                       || '<{||}>'
                                       || v_exp_rows21
                                       || '<{||}>'
                                       || v_exp_rows22
                                       || '<{||}>'
                                       || v_exp_rows23
                                       || '<{||}>'
                                       || v_exp_rows24
                                       || '<{||}>'
                                       || v_exp_rows25
                                       || '<{||}>'
                                       || v_exp_rows26
                                       || '<{||}>'
                                       || v_exp_rows27
                                       || '<{||}>'
                                       || v_exp_rows28
                                       || '<{||}>'
                                       || v_exp_rows29
                                       || '<{||}>'
                                       || v_exp_rows30
                                       || '<{||}>'
                                       || v_exp_rows31
                                       || '<{||}>'
                                       || v_exp_rows32
                                       || '<{||}>'
                                       || v_exp_rows33
                                       || '<{||}>'
                                       || v_exp_rows34
                                       || '<{||}>'
                                       || v_exp_rows35
                                       || '<{||}>'
                                       || v_exp_rows36
                                       || '<{||}>'
                                       || v_exp_rows37
                                       || '<{||}>'
                                       || v_exp_rows38
                                       || '<{||}>'
                                       || v_exp_rows39
                                       || '<{||}>'
                                       || v_exp_rows40
                                       || '<{||}>'
                                       || v_exp_rows41;


            if lv_errcnt < 50 then 
                    pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', dbms_utility.format_error_backtrace||dbms_utility.format_error_stack,
                                                                    'ERROR', pv_run_id, sqlerrm, v_exp_rows_appl, 'T');
                    lv_errcnt:=lv_errcnt+1;
            end if;

           CONTINUE;
        		END;
			END IF ;
				ELSE --else part on inner IF statement
				DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;
				CONTINUE;					
				END IF;
		ELSE
		CONTINUE;
		END IF;

------------ **************** Inserting into Dangerous Goods Appl. Document ********-------------------------
        FOR S IN ( 
            SELECT
                    doc1.pm4supportingdocindx_n,
                    doc2.ty_x ,
                    doc2.pm4id_n
                FROM
                    st_pm4supportingdoc_mapping doc2,
                    st_dg_pm4supportingdoc doc1,
                    ST_CM_DOCMETADATA y
                WHERE
                    doc2.pm4supportingdocindx_n = doc1.pm4supportingdocindx_n
                    and doc1.FILEPATH_X = y.DOCID_N(+)
                    and doc2.pm4id_n = j.pm4id_n )
        LOOP

        IF v_flag IS NULL AND s.pm4supportingdocindx_n IS NOT NULL  THEN

                BEGIN
                    INSERT INTO dangerous_goods_application_document (
                        dg_appln_doc_id_n,
                        appln_ref_n,
                        doc_id_n,
                        ty_c,
                        crt_by_x,
                        crt_on_dt,DELETED_I,LOCK_VER_N,DOC_OTHER_TY_C
                    ) VALUES (
                        seq_dg_appl_doc.nextval,
                        v_sq_appln_ref_n, --lv_dg_application_doc(j).appln_ref_n_r,
                        s.pm4supportingdocindx_n,
                        s.ty_x,
                        j.crtby_m,
                        j.crton_dt,0,0,NULL
                    );

                EXCEPTION
                    WHEN OTHERS THEN
                        v_err_code := sqlcode;
                        v_exp_rows1 := seq_dg_appl_doc.currval;
                        v_exp_rows2 := v_sq_appln_ref_n;
                        v_exp_rows3 := s.pm4supportingdocindx_n;
                        v_exp_rows4 := s.ty_x;
                        v_exp_rows5 := j.crtby_m;
                        v_exp_rows6 := j.crton_dt;
                        v_exp_rows_doc :=  
                                            v_exp_rows1
                                          || '<{||}>'
                                          || v_exp_rows2
                                          || '<{||}>'
                                          || v_exp_rows3
                                          || '<{||}>'
                                          || v_exp_rows4
                                          || '<{||}>'
                                          || v_exp_rows5
                                          || '<{||}>'
                                          || v_exp_rows6;    
        if lv_errcnt< 50 then
						pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL',dbms_utility.format_error_backtrace||dbms_utility.format_error_stack
                                                                        , 'ERROR', pv_run_id, sqlerrm, v_exp_rows_doc, 'T');
                        lv_errcnt:=lv_errcnt+1;
        end if;
                END;
        END IF;
		END LOOP; -- FOR LOOP S
		exception when others then

       if lv_errcnt<50 then
                 pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', v_sqlerrm,'ERROR', pv_run_id, 
                                                                sqlerrm||dbms_utility.format_error_backtrace, 'Error for j.pm4id_n'||j.pm4id_n, 'T');
                lv_errcnt:=lv_errcnt+1;
        end if;

        END;
        END LOOP;  -- J END LOOP 

       COMMIT;

       proc_dg_vr_vc_as_del    ;

       SELECT
            COUNT(*)
        INTO lv_cnt_PSA_JPC
        FROM
            DG_PSA_JPC ; 

        SELECT
            COUNT(*)
        INTO lv_cnt_tar_appl
        FROM
            dangerous_goods_application;

        SELECT
            COUNT(*)
        INTO lv_cnt_tar_doc
        FROM
            dangerous_goods_application_document; 

        pkg_datamigration_generic.proc_trace_exception('DG_PSA_JPC', 'PROC_2_DG_APPL', lv_cnt_PSA_JPC
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'SUCCESS', pv_run_id
                                                                                                            , NULL, NULL, 'T');

        IF ( lv_cnt_tar_appl = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar_appl <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'SUCCESS', pv_run_id
                                                                                                            , NULL, NULL, 'T');
        ELSIF lv_cnt_tar_appl <> lv_cnt_si AND lv_cnt_tar_appl <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'PARTIALLY SUCCESSFULL'
                                                                                                            , pv_run_id, NULL, NULL
                                                                                                            , 'T');
        ELSIF ( lv_cnt_tar_appl <> lv_cnt_si OR lv_cnt_tar_appl = lv_cnt_si ) AND ( lv_cnt_tar_appl = 0 ) THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'FAIL', pv_run_id, NULL
                                                                                                            , NULL, 'T');
        END IF;

        IF ( lv_cnt_tar_doc = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar_doc <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'SUCCESS',
                                                                                                                     pv_run_id, NULL
                                                                                                                     , NULL, 'T')
                                                                                                                     ;
        ELSIF lv_cnt_tar_doc <> lv_cnt_si AND lv_cnt_tar_doc <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'PARTIALLY SUCCESSFULL'
                                                                                                                     , pv_run_id,
                                                                                                                     NULL, NULL, 'T'
                                                                                                                     );
        ELSIF ( lv_cnt_tar_doc <> lv_cnt_si OR lv_cnt_tar_doc = lv_cnt_si ) AND ( lv_cnt_tar_doc = 0 ) THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'FAIL', pv_run_id
                                                                                                                     , NULL, NULL
                                                                                                                     , 'T');
        END IF;

        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'DG_PSA_JPC', lv_cnt_PSA_JPC, 'N');
        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'Dangerous_Goods_Application', lv_cnt_tar_appl

        , 'N');
        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'Dangerous_Goods_Application_Document', lv_cnt_tar_doc
        , 'N');
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'DG_PSA_JPC', lv_cnt_PSA_JPC, 'Y'
        );
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'Dangerous_Goods_Application', lv_cnt_tar_appl, 'Y'
        );
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'Dangerous_Goods_Application_Document', lv_cnt_tar_doc
        , 'Y');

END proc_2_dg_appl;
/