CREATE OR REPLACE PROCEDURE PROC_1_ORG_DTLS ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_SI         NUMBER;
    LV_CNT_TAR        NUMBER;
    lv_cnt_tar_prof     NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
    LV_ORG_LVL_X       VARCHAR2(5)  ;
    LV_ORG_U_N        VARCHAR2(10) ;
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_ORG_DTLS
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-NOV-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :
   MODIFIED DATE  :

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_SI_ORG_DTLS IS
	SELECT UPPER(A.UEN_N),A.CO_M,A.ORG_C,B.POSTAL_C,B.BLK_N,B.ROAD1_M,B.HOUSE_N,B.ROAD2_M
	FROM ST_XR_COREG A ,ST_XR_COADDR B
	WHERE A.ORG_C = B.ORG_C
	AND a.ORG_C IS NOT NULL 
	AND a.UEN_N IS NOT NULL;

------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
   CURSOR CR_ORG_DTLS IS
    SELECT
        *
    FROM
        SI_ORG_DTLS;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE REC_SI_ORG_DTLS IS RECORD (

        UEN_N_R                   ST_XR_COREG.UEN_N%TYPE,
        CO_M_R                    ST_XR_COREG.CO_M%TYPE,
        ORG_C_R                   ST_XR_COREG.ORG_C%TYPE,
        POSTAL_C_R                ST_XR_COADDR.POSTAL_C%TYPE,
        BLK_N_R                   ST_XR_COADDR.BLK_N%TYPE,
        ROAD1_M_R                 ST_XR_COADDR.ROAD1_M%TYPE,
        HOUSE_N_R                 ST_XR_COADDR.HOUSE_N%TYPE,
        ROAD2_M_R                 ST_XR_COADDR.ROAD2_M%TYPE
    );

    TYPE TYP_SI_ORG_DTLS IS
    TABLE OF REC_SI_ORG_DTLS INDEX BY PLS_INTEGER;

    LV_SI_ORG_DTLS    TYP_SI_ORG_DTLS;

    TYPE REC_ORG_DTLS IS RECORD (
        UEN_N_R                   ST_XR_COREG.UEN_N%TYPE,
        CO_M_R                    ST_XR_COREG.CO_M%TYPE,
        ORG_C_R                   ST_XR_COREG.ORG_C%TYPE,
        POSTAL_C_R                ST_XR_COADDR.POSTAL_C%TYPE,
        BLK_N_R                   ST_XR_COADDR.BLK_N%TYPE,
        ROAD1_M_R                 ST_XR_COADDR.ROAD1_M%TYPE,
        HOUSE_N_R                 ST_XR_COADDR.HOUSE_N%TYPE,
        ROAD2_M_R                 ST_XR_COADDR.ROAD2_M%TYPE
    );

    TYPE TYP_ORG_DTLS IS
    TABLE OF REC_ORG_DTLS INDEX BY PLS_INTEGER;

    LV_ORG_DTLS       TYP_ORG_DTLS;

BEGIN

execute immediate 'truncate table SI_ORG_DTLS';

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
        ST_XR_COREG ;    ---- DRIVING TABLE COUNT 

    OPEN CR_SI_ORG_DTLS;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', 'INSERTION INTO TABLE SI_ORG_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH CR_SI_ORG_DTLS BULK COLLECT INTO LV_SI_ORG_DTLS LIMIT 10000;
        EXIT WHEN LV_SI_ORG_DTLS.COUNT = 0;

        FOR I IN LV_SI_ORG_DTLS.FIRST..LV_SI_ORG_DTLS.LAST LOOP

        BEGIN
                INSERT INTO SI_ORG_DTLS (
                    UEN_N,
                    CO_M,
                    ORG_C,
                    POSTAL_C,
                    BLK_N,
                    ROAD1_M,
                    HOUSE_N,
                    ROAD2_M
                ) VALUES (
                    LV_SI_ORG_DTLS(I).UEN_N_R ,
                    LV_SI_ORG_DTLS(I).CO_M_R,
                    LV_SI_ORG_DTLS(I).ORG_C_R,
                    LV_SI_ORG_DTLS(I).POSTAL_C_R,
                    LV_SI_ORG_DTLS(I).BLK_N_R,
                    LV_SI_ORG_DTLS(I).ROAD1_M_R,
                    LV_SI_ORG_DTLS(I).HOUSE_N_R,
                    LV_SI_ORG_DTLS(I).ROAD2_M_R
                );

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_SI_ORG_DTLS(I).UEN_N_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).CO_M_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).ORG_C_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).POSTAL_C_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).BLK_N_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).ROAD1_M_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).HOUSE_N_R
                                     || '<{||}>'
                                     || LV_SI_ORG_DTLS(I).ROAD2_M_R
                                     ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;

    execute immediate 'UPDATE SI_ORG_DTLS SET BLK_N = NULL WHERE UPPER(TRIM(BLK_N)) = ''NULL''';
    execute immediate 'UPDATE SI_ORG_DTLS SET ROAD2_M = NULL WHERE UPPER(TRIM(ROAD2_M)) = ''NULL''';

    COMMIT;

    SELECT  COUNT(*)
    INTO LV_CNT_SI
    FROM SI_ORG_DTLS;   ---- INTERMIDATE TABLE COUNT 

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_XR_COREG', LV_CNT_ST, 'SI_ORG_DTLS', LV_CNT_SI, 'N');

    OPEN CR_ORG_DTLS;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', 'INSERTION INTO TABLE ORG_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_ORG_DTLS BULK COLLECT INTO LV_ORG_DTLS LIMIT 10000;
        EXIT WHEN LV_ORG_DTLS.COUNT = 0;

        FOR J IN LV_ORG_DTLS.FIRST..LV_ORG_DTLS.LAST LOOP
            BEGIN   

                SELECT  SUBSTR(LV_ORG_DTLS(J).HOUSE_N_R,INSTR(LV_ORG_DTLS(J).HOUSE_N_R,'#')+1,INSTR(LV_ORG_DTLS(J).HOUSE_N_R,'-')-2) LV_ORG_LVL_X,
                        SUBSTR(LV_ORG_DTLS(J).HOUSE_N_R,INSTR(LV_ORG_DTLS(J).HOUSE_N_R,'-')+1) LV_ORG_U_N
                        INTO LV_ORG_LVL_X,LV_ORG_U_N
                FROM DUAL ;

                INSERT INTO ORG_DTLS (
                    ID_N,
                    CO_UEN_N,
                    CO_M,
                    ORG_C,
                    ORG_POSTAL_C,
                    ORG_BLK_N,
                    ORG_ST_N,
                    ORG_LVL_X,
                    ORG_U_N,
                    ORG_BLDG_M,
                    ORG_CITY_M,
                    ORG_STATE_M,
                    ORG_CTRY_M,
                    ORG_ST_C
                ) VALUES (
                    SYN_SEQ_ORG_DTLS_ID_N.NEXTVAL ,
                    LV_ORG_DTLS(J).UEN_N_R ,
                    LV_ORG_DTLS(J).CO_M_R,
                    LV_ORG_DTLS(J).ORG_C_R,
                    LV_ORG_DTLS(J).POSTAL_C_R,
                    LV_ORG_DTLS(J).BLK_N_R,
                    LV_ORG_DTLS(J).ROAD1_M_R,
                    LV_ORG_LVL_X,
                    LV_ORG_U_N,
                    LV_ORG_DTLS(J).ROAD2_M_R,
                    'SINGAPORE',
                    'SINGAPORE',
                    'SG',
                    'DISABLED'
                );

                INSERT INTO AUTH_PROFILE (
                    ID_N,
                    REFR_ID,
                    PROFILE_TY,
                    LOCK_VER_N
                ) VALUES (
                    SYN_SEQ_AUTH_PROFILE_ID_N.NEXTVAL,
                    SYN_SEQ_ORG_DTLS_ID_N.CURRVAL,
                    'ORGANIZATION',
                    0 
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI :=    LV_ORG_DTLS(J).UEN_N_R 
                                     || '<{||}>'
                                     || LV_ORG_DTLS(J).CO_M_R
                                     || '<{||}>'
                                     ||  LV_ORG_DTLS(J).ORG_C_R
                                     || '<{||}>'
                                     || LV_ORG_DTLS(J).POSTAL_C_R
                                     || '<{||}>'
                                     || LV_ORG_DTLS(J).BLK_N_R
                                     || '<{||}>'
                                     || LV_ORG_DTLS(J).ROAD1_M_R
                                     || '<{||}>'
                                     || LV_ORG_LVL_X
                                     || '<{||}>'
                                     || LV_ORG_U_N
                                     || '<{||}>' 
                                     || LV_ORG_DTLS(J).ROAD2_M_R ;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T'); 

            END;
        END LOOP;
        COMMIT;
    END LOOP;

    COMMIT;

    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM ORG_DTLS;  ---- TARGET TABLE COUNT 
    
    SELECT
        COUNT(*)
    INTO lv_cnt_tar_prof
    FROM
        auth_profile where PROFILE_TY = 'ORGANIZATION' ; 

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_ORG_DTLS', LV_CNT_SI, 'ORG_DTLS', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_XR_COREG', LV_CNT_ST, 'ORG_DTLS', LV_CNT_TAR, 'Y');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_XR_COREG', LV_CNT_ST, 'AUTH_PROFILE', LV_CNT_TAR_PROF, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ORG_DTLS', 'PROC_1_ORG_DTLS', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_ORG_DTLS ;

/
