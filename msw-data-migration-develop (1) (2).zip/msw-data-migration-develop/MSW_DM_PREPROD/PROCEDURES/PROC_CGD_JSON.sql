create or replace PROCEDURE PROC_CGD_JSON
is 

CURSOR CR_CGD_JSON IS
SELECT
AGD.APPLN_REF_N,
AGD.VSL_CALL_ID_N,
AGD.MSW_APPLN_REF_ID_X,
AGD.EXTL_APPLN_REF_ID_X,
AGD.MSW_VSL_ID_N,
AGD.APPLCNT_ID_X,
AGD.GD_TY_C,
AGD.AGT_DECLR_AC_N,
AGD.GDV_N,
AGD.OFFICIAL_GDV_N,
AGD.CONTACT_PERS_M,
AGD.OFF_TEL_N,
AGD.HOME_TEL_N,
AGD.MOBILE_N,
AGD.FAX_N,
AGD.EMAIL_ADDR_X,
AGD.VSL_GT_Q,
AGD.NEW_VSL_GT_Q,
TO_CHAR(AGD.ARR_DECLR_DT,'YYYY-MM-DD HH24:MI:SS'),
AGD.ARR_CTRY_FR_C,
AGD.ARR_LAST_PORT_C,
AGD.ARR_PAX_Q,
AGD.ARR_CREW_Q,
AGD.ARR_CGO_Q,
AGD.ARR_MSTR_ON_ARR_X,
AGD.ARR_LOCN_ON_ARR_C,
AGD.ARR_LOCN_ON_ARR_M,
AGD.ARR_GRID_REF_N,
AGD.ARR_MOTHER_GDV_N,
AGD.ARR_BUNKR_Q,
AGD.ARR_BUNKR_GR_C,
AGD.ARR_CST_N,
AGD.ARR_CHARTERER_NAT_C,
AGD.ARR_SLN_C,
AGD.CALL_REC_ST_C,
TO_CHAR(AGD.RTA_DT,'YYYY-MM-DD HH24:MI:SS'),
TO_CHAR(AGD.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS'),
AGD.CRT_BY_N,
AGD.PCC_EXEMPN_RSN_X,
AGD.UNIT_NO_FROM,
AGD.UNIT_NO_TO,
AGD.POSTAL_CODE,
DECODE(AGD.MDO_I,0,'false',1,'true','false') MDO_I,
DECODE(AGD.MFO_I,0,'false',1,'true','false') MFO_I,
DECODE(AGD.MGO_I,0,'false',1,'true','false') MGO_I,
AGD.OTHERS_X,
AGD.CO_M,
AGD.APPLN_ST_C,
AGD.AGT_DECLR_AC_DESC_X,
AGD.ARR_CHARTERER_NAT_DESC_X,
AGD.ARR_SLN_DESC_X,
AGD.ARR_LOCN_ON_ARR_DESC_X,
AGD.ARR_CTRY_FR_DESC_X,
AGD.ARR_LST_P_DESC_X,
AGD.APPLICANT_NAME,
AGD.BUILDING_NAME,
AGD.FIN,
AGD.NRIC,
AGD.PASSPORT,
AGD.STREET_NAME,
AGD.INTL_REM_X,	
--DGD.APPLN_REF_N,
--DGD.MSW_APPLN_REF_ID_X,
--DGD.EXTL_APPLN_REF_ID_X,
--DGD.GDV_N,
--DGD.DEP_DECLR_DT,
--DGD.VSL_GT_ON_DEP_Q,
--DGD.AGT_DECLR_AC_N,
--DGD.NX_PORT_CTRY_C,
--DGD.NX_PORT_C,
--DGD.NX_PORT_M,
--DGD.PERS_Q,
--DGD.PAX_Q,
--DGD.CREW_Q,
--DGD.CGO_Q,
--DGD.MSTR_ON_DEP_X,
--DGD.MOTHER_GDV_N,
--DGD.BUNKR_Q,
--DGD.BUNKR_GR_C,
--DGD.CST_N,
--DGD.CHARTERER_NAT_C,
--DGD.SLN_C,
--DGD.APPLN_ST_C,
--DGD.PROCESSED_BY_X,
--DGD.PROCESSED_ON_DT,
--DGD.PROCESSING_REM_X,
--DGD.COMPANY_NAME,
--DGD.DEPARTURE_LOCATION,
--DGD.MPA_ACCOUNT_NAMES,
--DGD.DELETED_I,
--DGD.LOCKVER_N,
--DGD.CRT_ON_DT,
--DGD.CRT_BY_N,
--DGD.UPT_ON_DT,
--DGD.UPT_BY_X,
--DGD.INTL_REM_X,
--DECODE(DGD.MDO_I,0,'false',1,'true','false') D_MDO_I,
--DECODE(DGD.MFO_I,0,'false',1,'true','false') D_MFO_I,
--DECODE(DGD.MGO_I,0,'false',1,'true','false') D_MGO_I

DGD.AGT_DECLR_AC_DESC_X,
DGD.AGT_DECLR_AC_N,
DGD.APPLCNT_ID_N,
DGD.APPLCNT_M,
DGD.APPLN_REF_N,
DGD.APPLN_ST_C,
DGD.ARRIVAL_APPLN_REF_N,
DGD.BUNKR_GR_C,
DGD.BUNKR_Q,
DGD.CGO_Q,
DGD.CHARTERER_NAT_C,
DGD.CHARTERER_NAT_DESC_X,
DGD.COMPANY_NAME,
DGD.CO_M,
DGD.CREW_Q,
DGD.CRT_BY_N,
DGD.CRT_ON_DT,
DGD.CST_N,
DGD.DELETED_I,
DGD.DEP_CRUISE_OPERATOR_ID,
DGD.DEP_CRUISE_OPERATOR_NAME,
DGD.DEP_DECLR_DT,
DGD.DEP_LOCN,
DGD.DEP_LOCN_DESC_X,
DGD.DEP_RSN_OTHERS,
DGD.DEP_RSN_TO_HIGH_SEA_C,
DGD.EMAIL_ADDR_X,
DGD.EXTL_APPLN_REF_ID_X,
DGD.GDV_N  as D_GDV_N,
DGD.INTL_REM_X,
DGD.LOCKVER_N,
DECODE(DGD.MDO_I,0,'false',1,'true','false') D_MDO_I,
DECODE(DGD.MFO_I,0,'false',1,'true','false') D_MFO_I,
DECODE(DGD.MGO_I,0,'false',1,'true','false') D_MGO_I,
DGD.MOBILE_N,
DGD.MOTHER_GDV_N,
DGD.MPA_AC_M,
DGD.MSTR_ON_DEP_X,
DGD.MSW_APPLN_REF_ID_X,
DGD.NX_PORT_C,
DGD.NX_PORT_CTRY_C,
DGD.NX_PORT_M,
DGD.NX_P_CTRY_DESC_X,
DGD.NX_P_DESC_X,
DGD.OFFICIAL_GDV_N,
DGD.PAX_Q,
DGD.PERS_Q,
DGD.PROCESSED_BY_X,
DGD.PROCESSED_ON_DT,
DGD.PROCESSING_REM_X,
DGD.SLN_C,
DGD.SLN_DESC_X,
DGD.UPT_BY_X,
DGD.UPT_ON_DT,
DGD.VSL_GT_ON_DEP_Q

FROM ARRIVAL_GD_APPLICATION AGD , 
DEPARTURE_GD_APPLICATION DGD
WHERE AGD.GDV_N = DGD.GDV_N;



TYPE REC_CGD_JSON IS RECORD
(
AGD_APPLN_REF_N						ARRIVAL_GD_APPLICATION.APPLN_REF_N%TYPE	,
AGD_VSL_CALL_ID_N						ARRIVAL_GD_APPLICATION.VSL_CALL_ID_N%TYPE	,
AGD_MSW_APPLN_REF_ID_X				ARRIVAL_GD_APPLICATION.MSW_APPLN_REF_ID_X%TYPE	,
AGD_EXTL_APPLN_REF_ID_X				ARRIVAL_GD_APPLICATION.EXTL_APPLN_REF_ID_X%TYPE	,
AGD_MSW_VSL_ID_N						ARRIVAL_GD_APPLICATION.MSW_VSL_ID_N%TYPE	,
AGD_APPLCNT_ID_X						ARRIVAL_GD_APPLICATION.APPLCNT_ID_X%TYPE	,
AGD_GD_TY_C							ARRIVAL_GD_APPLICATION.GD_TY_C%TYPE	,
AGD_AGT_DECLR_AC_N					ARRIVAL_GD_APPLICATION.AGT_DECLR_AC_N%TYPE	,
AGD_GDV_N								ARRIVAL_GD_APPLICATION.GDV_N%TYPE	,
AGD_OFFICIAL_GDV_N					ARRIVAL_GD_APPLICATION.OFFICIAL_GDV_N%TYPE	,
AGD_CONTACT_PERS_M					ARRIVAL_GD_APPLICATION.CONTACT_PERS_M%TYPE	,
AGD_OFF_TEL_N							ARRIVAL_GD_APPLICATION.OFF_TEL_N%TYPE	,
AGD_HOME_TEL_N						ARRIVAL_GD_APPLICATION.HOME_TEL_N%TYPE	,
AGD_MOBILE_N							ARRIVAL_GD_APPLICATION.MOBILE_N%TYPE	,
AGD_FAX_N								ARRIVAL_GD_APPLICATION.FAX_N%TYPE	,
AGD_EMAIL_ADDR_X						ARRIVAL_GD_APPLICATION.EMAIL_ADDR_X%TYPE	,
AGD_VSL_GT_Q							ARRIVAL_GD_APPLICATION.VSL_GT_Q%TYPE	,
AGD_NEW_VSL_GT_Q						ARRIVAL_GD_APPLICATION.NEW_VSL_GT_Q%TYPE	,
AGD_ARR_DECLR_DT						VARCHAR2(30)	,
AGD_ARR_CTRY_FR_C						ARRIVAL_GD_APPLICATION.ARR_CTRY_FR_C%TYPE	,
AGD_ARR_LAST_PORT_C					ARRIVAL_GD_APPLICATION.ARR_LAST_PORT_C%TYPE	,
AGD_ARR_PAX_Q							ARRIVAL_GD_APPLICATION.ARR_PAX_Q%TYPE	,
AGD_ARR_CREW_Q						ARRIVAL_GD_APPLICATION.ARR_CREW_Q%TYPE	,
AGD_ARR_CGO_Q							ARRIVAL_GD_APPLICATION.ARR_CGO_Q%TYPE	,
AGD_ARR_MSTR_ON_ARR_X					ARRIVAL_GD_APPLICATION.ARR_MSTR_ON_ARR_X%TYPE	,
AGD_ARR_LOCN_ON_ARR_C					ARRIVAL_GD_APPLICATION.ARR_LOCN_ON_ARR_C%TYPE	,
AGD_ARR_LOCN_ON_ARR_M					ARRIVAL_GD_APPLICATION.ARR_LOCN_ON_ARR_M%TYPE	,
AGD_ARR_GRID_REF_N					ARRIVAL_GD_APPLICATION.ARR_GRID_REF_N%TYPE	,
AGD_ARR_MOTHER_GDV_N					ARRIVAL_GD_APPLICATION.ARR_MOTHER_GDV_N%TYPE	,
AGD_ARR_BUNKR_Q						ARRIVAL_GD_APPLICATION.ARR_BUNKR_Q%TYPE	,
AGD_ARR_BUNKR_GR_C					ARRIVAL_GD_APPLICATION.ARR_BUNKR_GR_C%TYPE	,
AGD_ARR_CST_N							ARRIVAL_GD_APPLICATION.ARR_CST_N%TYPE	,
AGD_ARR_CHARTERER_NAT_C				ARRIVAL_GD_APPLICATION.ARR_CHARTERER_NAT_C%TYPE	,
AGD_ARR_SLN_C							ARRIVAL_GD_APPLICATION.ARR_SLN_C%TYPE	,
AGD_CALL_REC_ST_C						ARRIVAL_GD_APPLICATION.CALL_REC_ST_C%TYPE	,
AGD_RTA_DT							    VARCHAR2(30)	,
AGD_CRT_ON_DT							VARCHAR2(30)	,
AGD_CRT_BY_N							ARRIVAL_GD_APPLICATION.CRT_BY_N%TYPE	,
AGD_PCC_EXEMPN_RSN_X					ARRIVAL_GD_APPLICATION.PCC_EXEMPN_RSN_X%TYPE	,
AGD_UNIT_NO_FROM						ARRIVAL_GD_APPLICATION.UNIT_NO_FROM%TYPE	,
AGD_UNIT_NO_TO						ARRIVAL_GD_APPLICATION.UNIT_NO_TO%TYPE	,
AGD_POSTAL_CODE						ARRIVAL_GD_APPLICATION.POSTAL_CODE%TYPE	,
AGD_MDO_I								VARCHAR2(10),
AGD_MFO_I								VARCHAR2(10),
AGD_MGO_I								VARCHAR2(10),
AGD_OTHERS_X							ARRIVAL_GD_APPLICATION.OTHERS_X%TYPE	,
AGD_CO_M								ARRIVAL_GD_APPLICATION.CO_M%TYPE	,
AGD_APPLN_ST_C   						ARRIVAL_GD_APPLICATION.APPLN_ST_C%TYPE		,
AGD_AGT_DECLR_AC_DESC_X				ARRIVAL_GD_APPLICATION.AGT_DECLR_AC_DESC_X%TYPE		,
AGD_ARR_CHARTERER_NAT_DESC_X			ARRIVAL_GD_APPLICATION.ARR_CHARTERER_NAT_DESC_X%TYPE		,
AGD_ARR_SLN_DESC_X					ARRIVAL_GD_APPLICATION.ARR_SLN_DESC_X%TYPE		,
AGD_ARR_LOCN_ON_ARR_DESC_X			ARRIVAL_GD_APPLICATION.ARR_LOCN_ON_ARR_DESC_X%TYPE		,
AGD_ARR_CTRY_FR_DESC_X				ARRIVAL_GD_APPLICATION.ARR_CTRY_FR_DESC_X%TYPE		,
AGD_ARR_LST_P_DESC_X					ARRIVAL_GD_APPLICATION.ARR_LST_P_DESC_X%TYPE		,
AGD_APPLICANT_NAME					ARRIVAL_GD_APPLICATION.APPLICANT_NAME%TYPE	,
AGD_BUILDING_NAME						ARRIVAL_GD_APPLICATION.BUILDING_NAME%TYPE	,
AGD_FIN								ARRIVAL_GD_APPLICATION.FIN%TYPE	,
AGD_NRIC								ARRIVAL_GD_APPLICATION.NRIC%TYPE	,
AGD_PASSPORT							ARRIVAL_GD_APPLICATION.PASSPORT%TYPE	,
AGD_STREET_NAME						ARRIVAL_GD_APPLICATION.STREET_NAME%TYPE	,
AGD_INTL_REM_X						ARRIVAL_GD_APPLICATION.INTL_REM_X%TYPE	,
DEP_AGT_DECLR_AC_DESC_X					DEPARTURE_GD_APPLICATION.AGT_DECLR_AC_DESC_X%type,
DEP_AGT_DECLR_AC_N					DEPARTURE_GD_APPLICATION.AGT_DECLR_AC_N%type,
DEP_APPLCNT_ID_N					DEPARTURE_GD_APPLICATION.APPLCNT_ID_N%type,
DEP_APPLCNT_M					DEPARTURE_GD_APPLICATION.APPLCNT_M%type,
DEP_APPLN_REF_N					DEPARTURE_GD_APPLICATION.APPLN_REF_N%type,
DEP_APPLN_ST_C					DEPARTURE_GD_APPLICATION.APPLN_ST_C%type,
DEP_ARRIVAL_APPLN_REF_N					DEPARTURE_GD_APPLICATION.ARRIVAL_APPLN_REF_N%type,
DEP_BUNKR_GR_C					DEPARTURE_GD_APPLICATION.BUNKR_GR_C%type,
DEP_BUNKR_Q					DEPARTURE_GD_APPLICATION.BUNKR_Q%type,
DEP_CGO_Q					DEPARTURE_GD_APPLICATION.CGO_Q%type,
DEP_CHARTERER_NAT_C					DEPARTURE_GD_APPLICATION.CHARTERER_NAT_C%type,
DEP_CHARTERER_NAT_DESC_X					DEPARTURE_GD_APPLICATION.CHARTERER_NAT_DESC_X%type,
DEP_COMPANY_NAME					DEPARTURE_GD_APPLICATION.COMPANY_NAME%type,
DEP_CO_M					DEPARTURE_GD_APPLICATION.CO_M%type,
DEP_CREW_Q					DEPARTURE_GD_APPLICATION.CREW_Q%type,
DEP_CRT_BY_N					DEPARTURE_GD_APPLICATION.CRT_BY_N%type,
DEP_CRT_ON_DT					DEPARTURE_GD_APPLICATION.CRT_ON_DT%type,
DEP_CST_N					DEPARTURE_GD_APPLICATION.CST_N%type,
DEP_DELETED_I					DEPARTURE_GD_APPLICATION.DELETED_I%type,
DEP_DEP_CRUISE_OPERATOR_ID					DEPARTURE_GD_APPLICATION.DEP_CRUISE_OPERATOR_ID%type,
DEP_DEP_CRUISE_OPERATOR_NAME					DEPARTURE_GD_APPLICATION.DEP_CRUISE_OPERATOR_NAME%type,
DEP_DEP_DECLR_DT					DEPARTURE_GD_APPLICATION.DEP_DECLR_DT%type,
DEP_DEP_LOCN					DEPARTURE_GD_APPLICATION.DEP_LOCN%type,
DEP_DEP_LOCN_DESC_X					DEPARTURE_GD_APPLICATION.DEP_LOCN_DESC_X%type,
DEP_DEP_RSN_OTHERS					DEPARTURE_GD_APPLICATION.DEP_RSN_OTHERS%type,
DEP_DEP_RSN_TO_HIGH_SEA_C					DEPARTURE_GD_APPLICATION.DEP_RSN_TO_HIGH_SEA_C%type,
DEP_EMAIL_ADDR_X					DEPARTURE_GD_APPLICATION.EMAIL_ADDR_X%type,
DEP_EXTL_APPLN_REF_ID_X					DEPARTURE_GD_APPLICATION.EXTL_APPLN_REF_ID_X%type,
DEP_GDV_N					DEPARTURE_GD_APPLICATION.GDV_N%type,
DEP_INTL_REM_X					DEPARTURE_GD_APPLICATION.INTL_REM_X%type,
DEP_LOCKVER_N					DEPARTURE_GD_APPLICATION.LOCKVER_N%type,
DEP_MDO_I					varchar2(10),--DEPARTURE_GD_APPLICATION.MDO_I%type,
DEP_MFO_I					varchar2(10),--DEPARTURE_GD_APPLICATION.MFO_I%type,
DEP_MGO_I					varchar2(10),--DEPARTURE_GD_APPLICATION.MGO_I%type,
DEP_MOBILE_N					DEPARTURE_GD_APPLICATION.MOBILE_N%type,
DEP_MOTHER_GDV_N					DEPARTURE_GD_APPLICATION.MOTHER_GDV_N%type,
DEP_MPA_AC_M					DEPARTURE_GD_APPLICATION.MPA_AC_M%type,
DEP_MSTR_ON_DEP_X					DEPARTURE_GD_APPLICATION.MSTR_ON_DEP_X%type,
DEP_MSW_APPLN_REF_ID_X					DEPARTURE_GD_APPLICATION.MSW_APPLN_REF_ID_X%type,
DEP_NX_PORT_C					DEPARTURE_GD_APPLICATION.NX_PORT_C%type,
DEP_NX_PORT_CTRY_C					DEPARTURE_GD_APPLICATION.NX_PORT_CTRY_C%type,
DEP_NX_PORT_M					DEPARTURE_GD_APPLICATION.NX_PORT_M%type,
DEP_NX_P_CTRY_DESC_X					DEPARTURE_GD_APPLICATION.NX_P_CTRY_DESC_X%type,
DEP_NX_P_DESC_X					DEPARTURE_GD_APPLICATION.NX_P_DESC_X%type,
DEP_OFFICIAL_GDV_N					DEPARTURE_GD_APPLICATION.OFFICIAL_GDV_N%type,
DEP_PAX_Q					DEPARTURE_GD_APPLICATION.PAX_Q%type,
DEP_PERS_Q					DEPARTURE_GD_APPLICATION.PERS_Q%type,
DEP_PROCESSED_BY_X					DEPARTURE_GD_APPLICATION.PROCESSED_BY_X%type,
DEP_PROCESSED_ON_DT					DEPARTURE_GD_APPLICATION.PROCESSED_ON_DT%type,
DEP_PROCESSING_REM_X					DEPARTURE_GD_APPLICATION.PROCESSING_REM_X%type,
DEP_SLN_C					DEPARTURE_GD_APPLICATION.SLN_C%type,
DEP_SLN_DESC_X					DEPARTURE_GD_APPLICATION.SLN_DESC_X%type,
DEP_UPT_BY_X					DEPARTURE_GD_APPLICATION.UPT_BY_X%type,
DEP_UPT_ON_DT					DEPARTURE_GD_APPLICATION.UPT_ON_DT%type,
DEP_VSL_GT_ON_DEP_Q					DEPARTURE_GD_APPLICATION.VSL_GT_ON_DEP_Q%type

);

TYPE TYPE_CGD_JSON  IS TABLE OF REC_CGD_JSON;
LV_CGD_JSON				TYPE_CGD_JSON;


V_ERR_CODE          NUMBER;
V_ERR_MSG           VARCHAR2(500);
V_SQLERRM           VARCHAR2(2500);
V_EXP_ROWS          VARCHAR2(1000);
V_APPLN_REF			NUMBER;
V_APPLN_REF_O		NUMBER;
V_APPLN_SUBMISSN_ID	NUMBER;
L_CR_CNT            NUMBER;
L_LP_CNT            NUMBER;
LV_CNT_TT_JSON      NUMBER;
LV_CNT_ST_JSON      NUMBER;
V_PURP_CALL_ID      VARCHAR2(10):=NULL;
LVAL    CLOB:=NULL;

V_EXCP_CNT          NUMBER:=0;
V_EXCP_CNT_JSON     NUMBER:=0;

BEGIN
LV_CNT_ST_JSON :=0;
OPEN  CR_CGD_JSON;
pkg_datamigration_generic.proc_trace_exception('CGD_JSON', 'PROC_CGD_JSON', 'Insertion records into Table SI_JSON', 'START',NULL,NULL,NULL,NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.ARRIVAL_GD_APPLICATION and MSW_DATA_MIGRATION.ARRIVAL_GD_PURPOSE_OF_CALL ************------------------  


	FETCH CR_CGD_JSON BULK COLLECT INTO LV_CGD_JSON LIMIT 10000;
    EXIT WHEN LV_CGD_JSON.count = 0;
	FOR i IN LV_CGD_JSON.first..LV_CGD_JSON.last

	LOOP


dbms_output.put_line(LV_CGD_JSON(i).AGD_GD_TY_C);
	IF LV_CGD_JSON(i).AGD_GD_TY_C ='ARRIVAL_DEPARTURE'
    
    THEN
	BEGIN

	LVAL:='{';
	LVAL:=LVAL||'"arrivalGDApplicationSubmittedEvent": {';
	LVAL:=LVAL||'"vesselCallId":'||LV_CGD_JSON(i).AGD_VSL_CALL_ID_N||',';
	LVAL:=LVAL||'"mswApplicationReference":"'||LV_CGD_JSON(i).AGD_MSW_APPLN_REF_ID_X||'",';
	LVAL:=LVAL||'"externalApplicationReference":"'||LV_CGD_JSON(i).AGD_EXTL_APPLN_REF_ID_X||'",';
	LVAL:=LVAL||'"vesselId":'|| LV_CGD_JSON(i).AGD_MSW_VSL_ID_N||',';
	LVAL:=LVAL||'"autoArrivalInd":'||'null'||',';
	LVAL:=LVAL||'"applicantId":"'||LV_CGD_JSON(i).AGD_APPLCNT_ID_X||'",';
	LVAL:=LVAL||'"gdTypeCode":"'||LV_CGD_JSON(i).AGD_GD_Ty_C||'",';
	LVAL:=LVAL||'"agentDeclaredAccountNumber":"'||LV_CGD_JSON(i).AGD_AGT_DECLR_AC_N||'",';
	LVAL:=LVAL||'"arrivalDraftsAfter":'||'null'||',';
	LVAL:=LVAL||'"gdvNumber":"'||LV_CGD_JSON(i).AGD_GDV_N||'",';
	LVAL:=LVAL||'"officialGDVNumber": "'||LV_CGD_JSON(i).AGD_official_GDV_n||'",';
	LVAL:=LVAL||'"contactPersonName": "'||LV_CGD_JSON(i).AGD_CONTACT_PERS_M||'",';

	LVAL:=LVAL||'"officePhoneNumber": '||NVL(TRIM(LV_CGD_JSON(i).AGD_off_Tel_n),'null')||',';
	LVAL:=LVAL||'"homePhoneNumber":'|| NVL(TRIM(LV_CGD_JSON(i).AGD_home_Tel_n),'null')||',';
	LVAL:=LVAL||'"mobilePhoneNumber": '||NVL(TRIM(LV_CGD_JSON(i).AGD_mobile_n),'null')||',';
	LVAL:=LVAL||'"faxNumber": "'||LV_CGD_JSON(i).AGD_fax_n||'",';
	LVAL:=LVAL||'"emailAddress": "'||LV_CGD_JSON(i).AGD_email_Addr_x||'",';
	LVAL:=LVAL||'"grossTonnage": '||NVL(trim(LV_CGD_JSON(i).AGD_VSL_GT_Q),'null')||',';
	LVAL:=LVAL||'"newGrossTonnage":'|| NVL(TRIM(LV_CGD_JSON(i).AGD_NEW_VSL_GT_Q),'null')||',';
	LVAL:=LVAL||'"arrivalDateTime": "'||LV_CGD_JSON(i).AGD_ARR_DECLR_DT||'",';
	LVAL:=LVAL||'"arrivedFromCountry": "'||LV_CGD_JSON(i).AGD_ARR_CTRY_FR_C||'",';
	LVAL:=LVAL||'"lastPortOfArrival": "'||LV_CGD_JSON(i).AGD_ARR_LAST_PORT_C||'",';
	LVAL:=LVAL||'"totalPassengersOnBoard":'||NVL(TRIM(LV_CGD_JSON(i).AGD_ARR_PAX_Q),'null')||',';
	LVAL:=LVAL||'"totalCrewOnBoard": '||NVL(trim(LV_CGD_JSON(i).AGD_ARR_CREW_Q),'null')||',';
	LVAL:=LVAL||'"totalCargoOnBoard":'||NVL(trim(LV_CGD_JSON(i).AGD_ARR_CGO_Q),'null')||',';
	LVAL:=LVAL||'"masterOnArrival": "'||LV_CGD_JSON(i).AGD_ARR_MSTR_ON_ARR_X||'",';
	LVAL:=LVAL||'"locationOnArrivalCode": "'||LV_CGD_JSON(i).AGD_ARR_LOCN_ON_ARR_C||'",';
	LVAL:=LVAL||'"locationOnArrivalName": "'||LV_CGD_JSON(i).AGD_ARR_LOCN_ON_ARR_M||'",';
	LVAL:=LVAL||'"arrivalGridReference": "'||LV_CGD_JSON(i).AGD_ARR_GRID_REF_N||'",';
	LVAL:=LVAL||'"arrivalMotherVessel":  "'||LV_CGD_JSON(i).AGD_ARR_MOTHER_GDV_N||'",';
	LVAL:=LVAL||'"arrivalBunkerQuantity": '||NVL(TRIM(LV_CGD_JSON(i).AGD_ARR_BUNKR_Q),'null')||',';
	LVAL:=LVAL||'"arrivalBunkerGrade": "'||LV_CGD_JSON(i).AGD_ARR_BUNKR_GR_C||'",';
	LVAL:=LVAL||'"arrivalCST": '||NVL(TRIM(LV_CGD_JSON(i).AGD_ARR_CST_N),'null')||',';
	LVAL:=LVAL||'"arrivalCharacterNationalityCode": "'||LV_CGD_JSON(i).AGD_ARR_CHARTERER_NAT_C||'",'; 
	LVAL:=LVAL||'"arrivalShippingLineCode": "'||LV_CGD_JSON(i).AGD_ARR_SLN_C||'",';
	LVAL:=LVAL||'"callRecordStatus":"'||LV_CGD_JSON(i).AGD_CALL_REC_ST_C||'",';
	LVAL:=LVAL||'"reportedArrivalOnDateTime": "'||LV_CGD_JSON(i).AGD_RTA_DT||'",';
	LVAL:=LVAL||'"reportedDepartureOnDateTime": '||'null'||','; --have to get the RTD here
	LVAL:=LVAL||'"createdOn":"'||LV_CGD_JSON(i).AGD_CRT_ON_DT||'",';
	LVAL:=LVAL||'"createdBy":"'||LV_CGD_JSON(i).AGD_CRT_BY_N||'",';
	LVAL:=LVAL||'"pccExceptionReason": "'||LV_CGD_JSON(i).AGD_PCC_EXEMPN_RSN_X||'",';
	LVAL:=LVAL||'"unitNoFrom": "'||LV_CGD_JSON(i).AGD_UNIT_NO_FROM||'",';
	LVAL:=LVAL||'"unitNoTo": "'||LV_CGD_JSON(i).AGD_UNIT_NO_TO||'",';
	LVAL:=LVAL||'"postalCode": '||NVL(TRIM(LV_CGD_JSON(i).AGD_POSTAL_CODE),'null')||',';	
	LVAL:=LVAL||'"mdo":'||LV_CGD_JSON(i).AGD_MDO_I||',';
	LVAL:=LVAL||'"mfo":'||LV_CGD_JSON(i).AGD_MFO_I||',';
	LVAL:=LVAL||'"mgo":'||LV_CGD_JSON(i).AGD_MGO_I||',';
	LVAL:=LVAL||'"othersText":"'||LV_CGD_JSON(i).AGD_OTHERS_X||'",';	
	LVAL:=LVAL||'"applicantName": "'||LV_CGD_JSON(i).AGD_APPLICANT_NAME||'",';
	LVAL:=LVAL||'"buildingName": "'||LV_CGD_JSON(i).AGD_BUILDING_NAME||'",';
	LVAL:=LVAL||'"fin": "'||LV_CGD_JSON(i).AGD_FIN||'",';
	LVAL:=LVAL||'"nric": "'||LV_CGD_JSON(i).AGD_NRIC||'",';
	LVAL:=LVAL||'"passport": "'||LV_CGD_JSON(i).AGD_PASSPORT||'",';
	LVAL:=LVAL||'"streetName": "'||LV_CGD_JSON(i).AGD_STREET_NAME||'",';
	LVAL:=LVAL||'"intlRem": "'||LV_CGD_JSON(i).AGD_INTL_REM_X||'",';	
	LVAL:=LVAL||'"companyName":"'||LV_CGD_JSON(i).AGD_CO_M||'",';
	LVAL:=LVAL||'"applicationStatus":"'||LV_CGD_JSON(i).AGD_APPLN_ST_C||'",';			

	LVAL:=LVAL||'"isAuthority": '||'false'||',';
	LVAL:=LVAL||'"isCancel": '||'false'||',';
	LVAL:=LVAL||'"rejectionReason": '||'null'||',';
	LVAL:=LVAL||'"approvalDate": '||'null'||',';
	LVAL:=LVAL||'"agentId": '||'null'||',';
	LVAL:=LVAL||'"approverID": '||'null'||',';
	LVAL:=LVAL||'"approverUser": '||'null'||',';
	LVAL:=LVAL||'"source": "'||'MSW'||'",';

	LVAL:=LVAL||'	"purposeOfCalls": [';

		 for j in (select  ARR_GD_PURP_OF_CALL_ID_N,PURPCALL_C, OTHERS_PURPOSE_X ,PURP_CALL_OTHERS_TOW_X,PURPCALL_OTHERS_TOW_VSL_M,PURPCALL_OTHERS_UND_TOW_VSL_M
				 from ARRIVAL_GD_PURPOSE_OF_CALL
				 where APPLN_REF_N =LV_CGD_JSON(i).AGD_APPLN_REF_N )

		 LOOP

			IF j.ARR_GD_PURP_OF_CALL_ID_N IS NOT NULL
			THEN
					LVAL:=LVAL||'{"gdId":'||'null'||',';
					V_PURP_CALL_ID:=NULL;

					IF trim(J.PURPCALL_C) = 'Cargo Operation'
							THEN
							V_PURP_CALL_ID :=1;
							ELSIF trim(J.PURPCALL_C) = 'Embarking/disembarking Passenger'
							THEN
							V_PURP_CALL_ID :=2;
							ELSIF trim(J.PURPCALL_C)= 'Taking Bunkers'
							THEN
							V_PURP_CALL_ID :=3;
							ELSIF trim(J.PURPCALL_C) = 'Taking Suppliers'
							THEN
							V_PURP_CALL_ID :=4;
							ELSIF trim(J.PURPCALL_C) = 'Changing Crew'
							THEN
							V_PURP_CALL_ID :=5;
							ELSIF trim(J.PURPCALL_C) = 'Repair/Docking/Outfitting'
							THEN
							V_PURP_CALL_ID :=6;
							ELSIF trim(J.PURPCALL_C)= 'Offshore Vessel'
							THEN
							V_PURP_CALL_ID :=7;
							ELSIF( trim(J.PURPCALL_C)='Towing' or trim(J.PURPCALL_C)='Shipped in as Cargo' or trim(J.PURPCALL_C)='Shipped out as Cargo'
							or trim(J.PURPCALL_C)='Recreation/Pleasure' or trim(J.PURPCALL_C)='Other')
							THEN
							V_PURP_CALL_ID :=9;
					ELSE
					V_PURP_CALL_ID :=NULL;
					END IF;

				LVAL := LVAL ||'"purposeOfCall": "'|| V_PURP_CALL_ID||'",';
				LVAL:=LVAL||'"arrivalOrDeparture": "ARRIVAL_DEPARTURE",';
				LVAL := LVAL ||'"othersPurpose": "'||NVL(trim(j.OTHERS_PURPOSE_X),'NULL')  ||'",'; 

				LVAL:=LVAL||'"purposeCallOthersTow":"'||J.PURP_CALL_OTHERS_TOW_X||'",';
				LVAL:=LVAL||'"purposeCallOthersTowVSL":"'||J.PURPCALL_OTHERS_TOW_VSL_M||'",';
				LVAL:=LVAL||'"purposeCallOthersUndTowVSL":"'||J.PURPCALL_OTHERS_UND_TOW_VSL_M||'",';
				LVAL:=LVAL||'"otherAfloatActivities":'||'null'||',';

				LVAL:=LVAL||'"gdPurposeOfCallShipyardLocEvents":[';

						for i in (select  SHIPYARD_LOC_C,SHIPYARD_LOC_DESC_X
						from ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC
						where ARR_GD_PURP_OF_CALL_ID_N = j.ARR_GD_PURP_OF_CALL_ID_N)

						loop 

						LVAL := LVAL || '{';
						LVAL := LVAL ||  '"shipyardLocC": "'|| i.SHIPYARD_LOC_C||'",';
						LVAL := LVAL || '"shipyardLocDescX": "'||NVL(trim(i.SHIPYARD_LOC_DESC_X),'NULL')  ||'"';				
						LVAL := LVAL || '},';

						end loop;

						LVAL :=  rtrim(LVAL,',');
						LVAL := LVAL || ']},';

			END IF;		

		END LOOP;

			LVAL :=  rtrim(LVAL,',');
			LVAL:=LVAL||'],';
			LVAL:=LVAL||'"agdShipCertificates":'||'[]},';
            
     --departure GD   JSON starts----       
            
            
    LVAL:=LVAL||'"departureGDApplicationSubmittedEvent": {';
	LVAL:=LVAL||'"vesselCallId":'||trim(LV_CGD_JSON(i).AGD_VSL_CALL_ID_N)||',';
	LVAL:=LVAL||'"mswApplicationReference":"'|| nvl(trim(LV_CGD_JSON(i).DEP_MSW_APPLN_REF_ID_X),'null')||'",';
	LVAL:=LVAL||'"vesselId":'|| LV_CGD_JSON(i).AGD_MSW_VSL_ID_N ||',';
	LVAL:=LVAL||'"mswApplicationReferenceOfAGD":"'|| nvl(trim(LV_CGD_JSON(i).AGD_MSW_APPLN_REF_ID_X),'null')||'",';
	LVAL:=LVAL||'"gdvNumber":"'||nvl(trim(LV_CGD_JSON(i).DEP_GDV_N),'null')||'",'; --GDV_N
	LVAL:=LVAL||'"applicantId":'||nvl(trim(LV_CGD_JSON(i).DEP_APPLCNT_ID_N),'null')||',';--APPLCNT_ID_N
	LVAL:=LVAL||'"officialGDVNumber":"'||nvl(trim(LV_CGD_JSON(i).DEP_OFFICIAL_GDV_N),'null')||'",';--OFFICIAL_GDV_N
	LVAL:=LVAL||'"departureDateTime": "'||'null'||'",';
	LVAL:=LVAL||'"vesselGTOnDeparture":'|| nvl(trim(LV_CGD_JSON(i).DEP_VSL_GT_ON_DEP_Q),'null')||',';--VSL_GT_ON_DEP_Q
	LVAL:=LVAL||'"nextPortCountry": "'||nvl(trim(LV_CGD_JSON(i).DEP_NX_PORT_CTRY_C),'null')||'",';--NX_PORT_CTRY_C
	LVAL:=LVAL||'"nextPortCode": "'||nvl(trim(LV_CGD_JSON(i).DEP_NX_PORT_C),'null')||'",';--NX_PORT_C
	LVAL:=LVAL||'"agentDeclaredAccountNumber": "'||nvl(trim(LV_CGD_JSON(i).DEP_AGT_DECLR_AC_N),'null')||'",';--AGT_DECLR_AC_N
	LVAL:=LVAL||'"nextPortName": "'||nvl(trim(LV_CGD_JSON(i).DEP_NX_P_DESC_X),'null')||'",';--NX_P_DESC_X
	LVAL:=LVAL||'"totalPersonsOnBoard":'|| nvl(trim(LV_CGD_JSON(i).DEP_PERS_Q),'null')||',';--PERS_Q  
	LVAL:=LVAL||'"totalPassengersOnBoard":'|| nvl(trim(LV_CGD_JSON(i).DEP_PAX_Q),'null')||',';--DEP_PAX_Q
	LVAL:=LVAL||'"numberOfCrew":'||nvl(trim(LV_CGD_JSON(i).DEP_CREW_Q),'null')||',';--CREW_Q
	LVAL:=LVAL||'"totalCargoOnBoard":'|| nvl(trim(LV_CGD_JSON(i).DEP_CGO_Q),'null')||',';--CGO_Q
	LVAL:=LVAL||'"masterOnDeparture":"'||nvl(trim(LV_CGD_JSON(i).DEP_MSTR_ON_DEP_X),'null')||'",';--MSTR_ON_DEP_X
	LVAL:=LVAL||'"motherGDV": "'||nvl(trim(LV_CGD_JSON(i).DEP_MOTHER_GDV_N),'null')||'",'; --MOTHER_GDV_N
	LVAL:=LVAL||'"bunkerQuantity":'|| nvl(trim(LV_CGD_JSON(i).DEP_BUNKR_Q),'null')||',';--BUNKR_Q
	LVAL:=LVAL||'"bunkerGrade":'|| nvl(trim(LV_CGD_JSON(i).DEP_BUNKR_GR_C),'null')||',';--BUNKR_GR_C
	LVAL:=LVAL||'"mdo":'||nvl(trim(LV_CGD_JSON(i).DEP_MDO_I),'null')||',';--MDO_I
	LVAL:=LVAL||'"mfo":'||nvl(trim(LV_CGD_JSON(i).DEP_MFO_I),'null')||',';--MFO_I
	LVAL:=LVAL||'"mgo":'||nvl(trim(LV_CGD_JSON(i).DEP_MGO_I),'null')||',';--MGO_I
	LVAL:=LVAL||'"cstNumber":'||nvl(trim(LV_CGD_JSON(i).DEP_CST_N),'null')||',';--CST_N
	LVAL:=LVAL||'"characterNationalityCode":"'||nvl(trim(LV_CGD_JSON(i).DEP_CHARTERER_NAT_C),'null')||'",';--CHARTERER_NAT_C
	LVAL:=LVAL||'"shippingLineCode":'|| nvl(trim(LV_CGD_JSON(i).DEP_SLN_C),'null')||',';--SLN_C
	LVAL:=LVAL||'"createdOn": "'||nvl(trim(LV_CGD_JSON(i).DEP_CRT_ON_DT),'null')||'",';--CRT_ON_DT
	LVAL:=LVAL||'"createdBy": "'||nvl(trim(LV_CGD_JSON(i).DEP_CST_N),'null')||'",';--CST_N
	LVAL:=LVAL||'"companyName":"'||nvl(trim(LV_CGD_JSON(i).DEP_COMPANY_NAME),'null')||'",';--COMPANY_NAME
	LVAL:=LVAL||'"departureLocation": "'||nvl(trim(LV_CGD_JSON(i).DEP_DEP_LOCN),'null')||'",';--DEP_LOCN
	LVAL:=LVAL||'"mpaAccountNames":'|| nvl(trim(LV_CGD_JSON(i).DEP_MPA_AC_M),'null')||',';--MPA_AC_M
	LVAL:=LVAL||'"intlRem":"'|| nvl(trim(LV_CGD_JSON(i).DEP_INTL_REM_X),'null')||'",';--INTL_REM_X
	LVAL:=LVAL||'"isAuthority":'|| 'false'||',';
	LVAL:=LVAL||'"cvGDApplicationStatus": "'||'SUBMITTED'||'",';
	LVAL:=LVAL||'"departureGDPurposeOfCallEvents": [],';
	LVAL:=LVAL||'"departureGDShipCertificates": [],';
	LVAL:=LVAL||'"departureGDPortClearanceCertificates": [],';
	LVAL:=LVAL||'"agentDeclaredAccountNumberDesc":'|| 'null'||',';
	LVAL:=LVAL||'"characterNationalityCodeDesc": "'||nvl(trim(LV_CGD_JSON(i).DEP_CHARTERER_NAT_DESC_X),'null')||'",';--CHARTERER_NAT_DESC_X
	LVAL:=LVAL||'"shippingLineCodeDesc": "'||nvl(trim(LV_CGD_JSON(i).DEP_SLN_DESC_X),'null') ||'",';--SLN_DESC_X
	LVAL:=LVAL||'"nextPortCountryDesc": "'||nvl(trim(LV_CGD_JSON(i).DEP_NX_P_CTRY_DESC_X),'null') ||'",';--NX_P_CTRY_DESC_X
	LVAL:=LVAL||'"nextPortCodeDesc":"'|| nvl(trim(LV_CGD_JSON(i).DEP_NX_P_DESC_X),'null')||'",';--NX_P_DESC_X
	LVAL:=LVAL||'"departureLocationDesc":'|| nvl(trim(LV_CGD_JSON(i).DEP_DEP_LOCN_DESC_X),'null')||',';--DEP_LOCN_DESC_X
	LVAL:=LVAL||'"depCruiseOperatorID": "'||nvl(trim(LV_CGD_JSON(i).DEP_DEP_CRUISE_OPERATOR_ID),'null') ||'",';--DEP_CRUISE_OPERATOR_ID
	LVAL:=LVAL||'"depCruiseOperatorName": "'||nvl(trim(LV_CGD_JSON(i).DEP_DEP_CRUISE_OPERATOR_NAME),'null') ||'",';--DEP_CRUISE_OPERATOR_NAME
	LVAL:=LVAL||'"source": "'||'MSW'||'",';
	LVAL:=LVAL||'"departureGDApplicationCancelledEvent": '||'null'||',';
	LVAL:=LVAL||'"emailAddress":"'||nvl(trim(LV_CGD_JSON(i).DEP_EMAIL_ADDR_X),'null')||'",';--EMAIL_ADDR_X
	LVAL:=LVAL||'"mobilePhoneNumber":'|| nvl(trim(LV_CGD_JSON(i).DEP_MOBILE_N),'null')||',';--MOBILE_N
	LVAL:=LVAL||'"applicantName":'|| 'null'||',';
	LVAL:=LVAL||'"motherVesselOfficialGDVNumber": "'||'null' ||'",';
	LVAL:=LVAL||'"departureOtherReasons": "'|| 'null' ||'",';
	LVAL:=LVAL||'"departureReasons": "'|| 'null'||'",';
	LVAL:=LVAL||'"externalApplicationReference":'|| 'null'||',';
	LVAL:=LVAL||'"agentOrgCode":'|| 'null'||',';
	LVAL:=LVAL||'"agentUEN":'|| 'null' ||',';
	LVAL:=LVAL||'"blkOrHouseNo":'|| 'null'||',';
	LVAL:=LVAL||'"declaredArrivalDateTime":'|| 'null'||',';
	LVAL:=LVAL||'"vesselNameMother":'|| 'null'||',';
	LVAL:=LVAL||'"motherVesselArrivalDateTime":'|| 'null'||',';
	LVAL:=LVAL||'"faxNumber":'|| 'null'||',';
	LVAL:=LVAL||'"fin":'|| 'null' ||',';
	LVAL:=LVAL||'"nric":'|| 'null'||',';
	LVAL:=LVAL||'"passport":'|| 'null'||',';
	LVAL:=LVAL||'"uneNo":'|| 'null'||',';
	LVAL:=LVAL||'"unitNoFrom":'|| 'null'||',';
	LVAL:=LVAL||'"unitNoTo":'|| 'null'||',';
	LVAL:=LVAL||'"postalCode":'|| 'null'||',';
	LVAL:=LVAL||'"buildingName":'|| 'null'||',';
	LVAL:=LVAL||'"streetName":'|| 'null'||',';
	LVAL:=LVAL||'"contactPersonName":'|| 'null'||',';
	LVAL:=LVAL||'"isCitizenOrResident":'|| 'false'||',';
	LVAL:=LVAL||'"homePhoneNumber":'|| 'null'||',';
	LVAL:=LVAL||'"routingKey":"'||'null' ||'"';
     
    LVAL:=LVAL||'},';
	LVAL:=LVAL||'"routingKey": ""';
    LVAL:=LVAL||'}';
            
            
            
            
      dbms_output.put_line(1);
            
            
            

	                BEGIN
					INSERT INTO SI_JSON(APPLN_SUBMISSN_ID_N,APPLN_DATA_X,DATE_TIME,APPLN_TYPE,MSW_VSL_REF_ID)
					VALUES (NULL,LVAL,SYSDATE,'CGD',TRIM(LV_CGD_JSON(I).AGD_MSW_APPLN_REF_ID_X));


					EXCEPTION         
					WHEN OTHERS THEN 

					V_ERR_CODE := SQLCODE;
					V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
					V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

                    V_EXCP_CNT :=V_EXCP_CNT+1;                    
                    IF V_EXCP_CNT <50000 THEN

					pkg_datamigration_generic.proc_trace_exception('JSON_AGD', 'PROC_AGD_JSON',dbms_utility.format_error_backtrace||dbms_utility.format_error_stack
											, 'ERROR', null, V_SQLERRM, NULL, 'T');
                    END IF;

					END;

	LVAL := null;

        LV_CNT_ST_JSON:=LV_CNT_ST_JSON+1;
--commit;

	EXCEPTION WHEN OTHERS THEN 

	V_ERR_CODE := SQLCODE;
	V_ERR_MSG := SUBSTR(SQLERRM, 1, 2000);
	V_SQLERRM := V_ERR_CODE || V_ERR_MSG|| DBMS_UTILITY.FORMAT_ERROR_STACK;

	V_EXCP_CNT_JSON:= V_EXCP_CNT_JSON+1;

	IF V_EXCP_CNT_JSON < 1000  
	THEN        
	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_JSON', 'PROC_1_DEP_JSON', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');
	END IF;


END; 
END IF; -- LV_CGD_JSON(i).AGD_GD_TY_C ='ARRIVAL_DEPARTURE'
END LOOP; --CURSOR LOOP

COMMIT;
END LOOP;
CLOSE CR_CGD_JSON;	

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_JSON
     FROM
     SI_JSON
	 WHERE APPLN_TYPE = 'CGD';
     
     pkg_datamigration_generic.proc_trace_exception('CGD_JSON', 'PROC_CGD_JSON', 'Insertion records into Table SI_JSON', 'END',NULL,NULL,NULL,NULL);

	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('JSON_CGD', LV_CNT_ST_JSON, 'SI_JSON', LV_CNT_TT_JSON,'Y');
 

EXCEPTION  --- EXCEPTION OF   OUTER BEGIN 


    WHEN OTHERS THEN
    V_ERR_CODE := SQLCODE;
    V_ERR_MSG := SUBSTR(SQLERRM, 1, 2000);
    V_SQLERRM := V_ERR_CODE|| V_ERR_MSG|| DBMS_UTILITY.FORMAT_ERROR_STACK;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_CGD_JSON', 'PROC_DEP_JSON', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');


END;
/