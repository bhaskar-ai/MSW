create or replace PROCEDURE PROC_1_DEP_GD_P_CLRCE_CERT (PV_RUN_ID  in number)IS

/***********************************************************************************************************
procedure name : PROC_1_DEP_GD_P_CLRCE_CERT
Created By     : C.N.BHASKAR
Date           : 17-july-2019
Purpose        : Inserting  the data from ST_CV_GDAppln,ST_CV_pendingAppln,ST_CV_vslCall (main table) to 
                 SI_DEP_GD_P_CLRCE_CERT   and  DEP_GD_P_CLRCE_CERT
Modified by    :
Modified date  :

*************************************************************************************************************/

	/***********************************************************************************************************
	Defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table
	*************************************************************************************************************/

    TYPE rec_gd_application IS RECORD (
        v_applnref_n       si_dep_gd_p_clrce_cert.applnref_n%TYPE,
        v_gdv_n            si_dep_gd_p_clrce_cert.gdv_n%TYPE,
        v_pcc_n            si_dep_gd_p_clrce_cert.pcc_n%TYPE,
        v_pccissd_dt       si_dep_gd_p_clrce_cert.pccissd_dt%TYPE,
        v_pccexpy_dt       si_dep_gd_p_clrce_cert.pccexpy_dt%TYPE,
        v_pccissdby_m      si_dep_gd_p_clrce_cert.pccissdby_m%TYPE,
        v_pccprnt_i        si_dep_gd_p_clrce_cert.pccprnt_i%TYPE,
        v_pccst_c          si_dep_gd_p_clrce_cert.pccst_c%TYPE,
        v_pcclatecancl_i   si_dep_gd_p_clrce_cert.pcclatecancl_i%TYPE,
        v_pcccancl_dt      si_dep_gd_p_clrce_cert.pcccancl_dt%TYPE,
        v_docidatth_n      si_dep_gd_p_clrce_cert.docidatth_n%TYPE,
        v_officialgdv_n    SI_DEP_GD_P_CLRCE_CERT.officialgdv_n%TYPE,
        v_crton_dt         si_dep_gd_p_clrce_cert.crton_dt%type,
        v_crtby_n          si_dep_gd_p_clrce_cert.crtby_n%TYPE,
        v_updon_dt         si_dep_gd_p_clrce_cert.updon_dt%TYPE,
        v_updby_n          si_dep_gd_p_clrce_cert.updby_n%TYPE,
        v_cgo_q            si_dep_gd_p_clrce_cert.cgo_q%TYPE,
        v_depdeclr_dt      si_dep_gd_p_clrce_cert.depdeclr_dt%TYPE,
        v_mstrondep_x      si_dep_gd_p_clrce_cert.mstrondep_x%TYPE,
        v_nxctry_m         si_dep_gd_p_clrce_cert.nxctry_m%TYPE,
        v_nxport_m         si_dep_gd_p_clrce_cert.nxport_m%TYPE,
        v_org_c            si_dep_gd_p_clrce_cert.org_c%TYPE,
        v_pcc_i            si_dep_gd_p_clrce_cert.pcc_i%TYPE,
        v_pccseq_n         si_dep_gd_p_clrce_cert.pccseq_n%TYPE,
        v_vsl_m            si_dep_gd_p_clrce_cert.vsl_m%TYPE,
        v_vslcallsign_n    si_dep_gd_p_clrce_cert.vslcallsign_n%TYPE,
        v_vslflag_m        si_dep_gd_p_clrce_cert.vslflag_m%TYPE,
        v_vslgt_q          si_dep_gd_p_clrce_cert.vslgt_q%TYPE,
        v_vslimo_n         si_dep_gd_p_clrce_cert.vslimo_n%TYPE,
        v_vslmmsi_n        si_dep_gd_p_clrce_cert.vslmmsi_n%TYPE
    );

    TYPE type_gd_application IS TABLE OF rec_gd_application;

    lv_gd_appllication type_gd_application;
    v_err_code NUMBER;
    v_err_msg VARCHAR2(500);
    v_sqlerrm VARCHAR2(2500);
    v_year_month VARCHAR2(40);
    arr_p_yymm VARCHAR2(100);
    dep_p_yymm VARCHAR2(100);
    l_val NUMBER;
    lval CLOB;
    v_syl CLOB;
    v_poc CLOB;
    depsylogs CLOB;
    v_msw_vsl_call_id_out NUMBER;
    v_flag_out VARCHAR2(100);
    v_msw_appln_ref_id_x VARCHAR2(20);
    v_del_arrgd NUMBER;
    v_del_depgd NUMBER;
    v_src_count NUMBER;
    v_tgt_count  number;

    i_excep_cnt   number := 0;
cursor CUR_GD_APPLN is   

select *
from 
SI_DEP_GD_P_CLRCE_CERT;



begin  --outer begin

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_GD_P_CLRCE_CERT ', 'PROC_1_DEP_GD_P_CLRCE_CERT','INSERTION INTO SI_DEP_GD_P_CLRCE_CERT  STARTS' , 'START',null,null,null,'T');



FOR i IN

(
 select 
dga.APPLN_REF_N,
pcc.GDV_n,
pcc.pcc_n,
pcc.pccIssd_dt,
pcc.pccExpy_dt,
pcc.pccIssdBy_m,
pcc.pccPrnt_i,
pcc.pccSt_c,
pcc.pccLateCancl_i,
pcc.pccCancl_dt,
pcc.docIdAtth_n,
pccHist.officialGDV_n,
pcc.crtOn_dt,
pcc.crtBy_n,
pcc.updOn_dt,
pcc.updBy_n,
pccHist.cgo_q,
pccHist.depDeclr_dt,
pccHist.mstrOnDep_x,
pccHist.nxCtry_m,
pccHist.nxPort_m,
pccHist.org_c,
pccHist.pcc_i,
pccHist.pccSeq_n,
pccHist.vsl_m,
pccHist.vslCallSign_n,
pccHist.vslFlag_m,
pccHist.vslGT_q,
pccHist.vslIMO_n,
pccHist.vslMMSI_n

 from st_CV_depGD dep,
 st_CV_GDAppln app, 
st_CV_vslCall call ,
st_CV_pendingAppln pend,
st_CV_portClrceCertIssd pcc ,
ST_CV_portClrceCertIssdHist pccHist ,
departure_gd_application  dga
where 
 app.applnRef_n = dep.ref_n 
 and call.GDV_n = dep.GDV_n 
 and pend.applnRef_n = app.applnRef_n
and pcc.ref_n = dep.ref_n
and pcc.ref_n =pccHist.ref_n(+)
and  depGDSt_c in ('1','5')
and dga.gdv_n = dep.GDV_N


    )

LOOP               

BEGIN                                            -- inner begin  of SI  tablee 

 INSERT INTO SI_DEP_GD_P_CLRCE_CERT (
APPLNREF_N,
GDV_N,
PCC_N,
PCCISSD_DT,
PCCEXPY_DT,
PCCISSDBY_M,
PCCPRNT_I,
PCCST_C,
PCCLATECANCL_I,
PCCCANCL_DT,
DOCIDATTH_N,
OFFICIALGDV_N,
CRTON_DT,
CRTBY_N,
UPDON_DT,
UPDBY_N,
CGO_Q,
DEPDECLR_DT,
MSTRONDEP_X,
NXCTRY_M,
NXPORT_M,
ORG_C,
PCC_I,
PCCSEQ_N,
VSL_M,
VSLCALLSIGN_N,
VSLFLAG_M,
VSLGT_Q,
VSLIMO_N,
VSLMMSI_N

)

VALUES ( 
i.APPLN_REF_N,
i.GDV_n,
i.pcc_n,
i.pccIssd_dt,
i.pccExpy_dt,
i.pccIssdBy_m,
decode (i.pccPrnt_i,'Y',1,'N',0),
i.pccSt_c,
i.pccLateCancl_i,
i.pccCancl_dt,
i.docIdAtth_n,
i.officialGDV_n,
i.crtOn_dt,
i.crtBy_n,
i.updOn_dt,
i.updBy_n,
i.cgo_q,
i.depDeclr_dt,
i.mstrOnDep_x,
i.nxCtry_m,
i.nxPort_m,
i.org_c,
i.pcc_i,
i.pccSeq_n,
i.vsl_m,
i.vslCallSign_n,
i.vslFlag_m,
i.vslGT_q,
i.vslIMO_n,
i.vslMMSI_n
);

exception  --inner exception of SI table 

 WHEN OTHERS THEN                                                     -- inner exception for handling any errors in the SI table 
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_DEP_GD_P_CLRCE_CERT',
  'PROC_1_DEP_GD_P_CLRCE_CERT',
'APPLNREF_N	:'||i.APPLN_REF_N||'<{||}>'||
'GDV_N	:'||i.GDV_n||'<{||}>'||
'PCC_N	:'||i.pcc_n||'<{||}>'||
'PCCISSD_DT	:'||i.pccIssd_dt||'<{||}>'||
'PCCEXPY_DT	:'||i.pccExpy_dt||'<{||}>'||
'PCCISSDBY_M:'||i.pccIssdBy_m||'<{||}>'||
'PCCPRNT_I:'||i.pccPrnt_i||'<{||}>'||
'PCCST_C:'||i.pccSt_c||'<{||}>'||
'PCCLATECANCL_I	:'||i.pccLateCancl_i||'<{||}>'||
'PCCCANCL_DT:'||i.pccCancl_dt||'<{||}>'||
'DOCIDATTH_N:'||i.docIdAtth_n||'<{||}>'||
'OFFICIALGDV_N:'||i.officialGDV_n||'<{||}>'||
'CRTON_DT:'||i.crtOn_dt||'<{||}>'||
'CRTBY_N:'||i.crtBy_n||'<{||}>'||
'UPDON_DT:'||i.updOn_dt||'<{||}>'||
'UPDBY_N:'||i.updBy_n||'<{||}>'||
'CGO_Q:'||i.cgo_q||'<{||}>'||
'DEPDECLR_DT:'||i.depDeclr_dt||'<{||}>'||
'MSTRONDEP_X:'||i.mstrOnDep_x||'<{||}>'||
'NXCTRY_M:'||i.nxCtry_m||'<{||}>'||
'NXPORT_M:'||i.nxPort_m||'<{||}>'||
'ORG_C:'||i.org_c||'<{||}>'||
'PCC_I:'||i.pcc_i||'<{||}>'||
'PCCSEQ_N:'||i.pccSeq_n||'<{||}>'||
'VSL_M:'||i.vsl_m||'<{||}>'||
'VSLCALLSIGN_N:'||i.vslCallSign_n||'<{||}>'||
'VSLFLAG_M:'||i.vslFlag_m||'<{||}>'||
'VSLGT_Q:'||i.vslGT_q||'<{||}>'||
'VSLIMO_N:'||i.vslIMO_n||'<{||}>'||
'VSLMMSI_N:'||i.vslMMSI_n


  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

i.APPLN_REF_N||'<{||}>'||
i.GDV_n||'<{||}>'||
i.pcc_n||'<{||}>'||
i.pccIssd_dt||'<{||}>'||
i.pccExpy_dt||'<{||}>'||
i.pccIssdBy_m||'<{||}>'||
i.pccPrnt_i||'<{||}>'||
i.pccSt_c||'<{||}>'||
i.pccLateCancl_i||'<{||}>'||
i.pccCancl_dt||'<{||}>'||
i.docIdAtth_n||'<{||}>'||
i.officialGDV_n||'<{||}>'||
i.crtOn_dt||'<{||}>'||
i.crtBy_n||'<{||}>'||
i.updOn_dt||'<{||}>'||
i.updBy_n||'<{||}>'||
i.cgo_q||'<{||}>'||
i.depDeclr_dt||'<{||}>'||
i.mstrOnDep_x||'<{||}>'||
i.nxCtry_m||'<{||}>'||
i.nxPort_m||'<{||}>'||
i.org_c||'<{||}>'||
i.pcc_i||'<{||}>'||
i.pccSeq_n||'<{||}>'||
i.vsl_m||'<{||}>'||
i.vslCallSign_n||'<{||}>'||
i.vslFlag_m||'<{||}>'||
i.vslGT_q||'<{||}>'||
i.vslIMO_n||'<{||}>'||
i.vslMMSI_n


,
 'T'
 );

end ;   -- inner end of SI table 

end loop; -- end loop of for which inserts the data into the SI table 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT','INSERTION INTO SI_DEP_GD_P_CLRCE_CERT  ENDS' , 'ENDS',null,null,null,'T');



---------------------------------------------------------------------------------------------------------------------------------


OPEN CUR_GD_APPLN;

loop     -- loop of the cursor  CUR_GD_APPLN

  FETCH CUR_GD_APPLN BULK COLLECT INTO LV_GD_APPLLICATION LIMIT 1000;

               EXIT WHEN LV_GD_APPLLICATION.count = 0;


                  FOR i IN LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 


                  loop       --loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 



begin   -- inner begin to insert the values into the DEP_GD_P_CLRCE_CERT  table

insert into DEP_GD_P_CLRCE_CERT(
DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
APPLN_REF_N	,
GDV_N	,
PCC_N	,
PCC_ISSD_DT	,
PCC_EXPY_DT	,
PCC_ISSD_BY_M	,
PCC_PRNT_I	,
PCC_ST_C	,
PCC_LATE_CANCL_I	,
PCC_CANCEL_DT	,
DOC_ID_ATTH_N	,
OFFICIAL_GDV_N	,
MSW_DOC_ID_N	,
CRT_ON_DT	,
CRT_BY_N	,
LAST_UPDATED_ON_DT	,
LAST_UPDATED_BY_N	,
DELETED_I	,
LOCK_VER_N	,
CGO_Q	,
DEPDECLR_DT	,
MSTRONDEP_X	,
NXCTRY_M	,
NXPORT_M	,
ORG_C	,
PCC_I	,
PCCSEQ_N	,
VSL_M	,
VSLCALLSIGN_N	,
VSLFLAG_M	,
VSLGT_Q	,
VSLIMO_N	,
VSLMMSI_N	)
values(SEQ_DEPGD_PORTTLID_N.nextval,
LV_GD_APPLLICATION(i).v_applnref_n,
LV_GD_APPLLICATION(i).v_gdv_n 	,
LV_GD_APPLLICATION(i).v_pcc_n        	,
LV_GD_APPLLICATION(i). v_pccissd_dt       	,
LV_GD_APPLLICATION(i). v_pccexpy_dt      	,
LV_GD_APPLLICATION(i).v_pccissdby_m     	,
LV_GD_APPLLICATION(i).v_pccprnt_i   	,
LV_GD_APPLLICATION(i).v_pccst_c          	,
LV_GD_APPLLICATION(i).v_pcclatecancl_i   	,
LV_GD_APPLLICATION(i).v_pcccancl_dt    	,
LV_GD_APPLLICATION(i).v_docidatth_n    	,
LV_GD_APPLLICATION(i).v_officialgdv_n    	,
100		,
SYSDATE,--LV_GD_APPLLICATION(i).v_crton_dt      	,
'DATA MIGRATION',--LV_GD_APPLLICATION(i).v_crtby_n  	,
SYSDATE,--LV_GD_APPLLICATION(i).v_updon_dt   	,
'DATA MIGRATION',--LV_GD_APPLLICATION(i).v_updby_n          	,
0		,
0		,
LV_GD_APPLLICATION(i).v_cgo_q      	,
LV_GD_APPLLICATION(i).v_depdeclr_dt    	,
LV_GD_APPLLICATION(i).v_mstrondep_x      	,
LV_GD_APPLLICATION(i).v_nxctry_m        	,
LV_GD_APPLLICATION(i).v_nxport_m        	,
LV_GD_APPLLICATION(i).v_org_c            	,
LV_GD_APPLLICATION(i).v_pcc_i          	,
LV_GD_APPLLICATION(i).v_pccseq_n       	,
LV_GD_APPLLICATION(i).v_vsl_m            	,
LV_GD_APPLLICATION(i).v_vslcallsign_n  	,
LV_GD_APPLLICATION(i).v_vslflag_m     	,
LV_GD_APPLLICATION(i).v_vslgt_q        	,
LV_GD_APPLLICATION(i).v_vslimo_n       	,
LV_GD_APPLLICATION(i). v_vslmmsi_n        	
);







exception   -- inner exception to insert the values into the DEP_GD_P_CLRCE_CERT  table

when others then null;
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

i_excep_cnt := i_excep_cnt +1;

if i_excep_cnt < 50000  then 

 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_DEP_GD_P_CLRCE_CERT',
  'PROC_1_DEP_GD_P_CLRCE_CERT',

  'DEP_GD_PORT_CLEARENCE_CERT_ID_N:'||	SEQ_DEPGD_PORTTLID_N.currval	||'<{||}>'||
'APPLN_REF_N:'||	LV_GD_APPLLICATION(i).v_applnref_n	||'<{||}>'||
'GDV_N:'||	LV_GD_APPLLICATION(i).v_gdv_n 	||'<{||}>'||
'PCC_N:'||	LV_GD_APPLLICATION(i).v_pcc_n        	||'<{||}>'||
'PCC_ISSD_DT:'||	LV_GD_APPLLICATION(i). v_pccissd_dt       	||'<{||}>'||
'PCC_EXPY_DT:'||	LV_GD_APPLLICATION(i). v_pccexpy_dt      	||'<{||}>'||
'PCC_ISSD_BY_M:'||	LV_GD_APPLLICATION(i).v_pccissdby_m     	||'<{||}>'||
'PCC_PRNT_I:'||	LV_GD_APPLLICATION(i).v_pccprnt_i   	||'<{||}>'||
'PCC_ST_C:'||	LV_GD_APPLLICATION(i).v_pccst_c          	||'<{||}>'||
'PCC_LATE_CANCL_I:'||	LV_GD_APPLLICATION(i).v_pcclatecancl_i   	||'<{||}>'||
'PCC_CANCEL_DT:'||	LV_GD_APPLLICATION(i).v_pcccancl_dt    	||'<{||}>'||
'DOC_ID_ATTH_N:'||	LV_GD_APPLLICATION(i).v_docidatth_n    	||'<{||}>'||
'OFFICIAL_GDV_N:'||	LV_GD_APPLLICATION(i).v_officialgdv_n    	||'<{||}>'||
'MSW_DOC_ID_N:'||	100	||'<{||}>'||
'CRT_ON_DT:'||	SYSDATE    	||'<{||}>'||
'CRT_BY_N:'||	'DATA MIGRATION'	||'<{||}>'||
'LAST_UPDATED_ON_DT:'||	SYSDATE  	||'<{||}>'||
'LAST_UPDATED_BY_N:'||	'DATA MIGRATION'      	||'<{||}>'||
'DELETED_I:'||	0	||'<{||}>'||
'LOCK_VER_N:'||	0	||'<{||}>'||
'CGO_Q:'||	LV_GD_APPLLICATION(i).v_cgo_q      	||'<{||}>'||
'DEPDECLR_DT:'||	LV_GD_APPLLICATION(i).v_depdeclr_dt    	||'<{||}>'||
'MSTRONDEP_X:'||	LV_GD_APPLLICATION(i).v_mstrondep_x      	||'<{||}>'||
'NXCTRY_M:'||	LV_GD_APPLLICATION(i).v_nxctry_m        	||'<{||}>'||
'NXPORT_M:'||	LV_GD_APPLLICATION(i).v_nxport_m        	||'<{||}>'||
'ORG_C:'||	LV_GD_APPLLICATION(i).v_org_c            	||'<{||}>'||
'PCC_I:'||	LV_GD_APPLLICATION(i).v_pcc_i          	||'<{||}>'||
'PCCSEQ_N:'||	LV_GD_APPLLICATION(i).v_pccseq_n       	||'<{||}>'||
'VSL_M:'||	LV_GD_APPLLICATION(i).v_vsl_m            	||'<{||}>'||
'VSLCALLSIGN_N:'||	LV_GD_APPLLICATION(i).v_vslcallsign_n  	||'<{||}>'||
'VSLFLAG_M:'||	LV_GD_APPLLICATION(i).v_vslflag_m     	||'<{||}>'||
'VSLGT_Q:'||	LV_GD_APPLLICATION(i).v_vslgt_q        	||'<{||}>'||
'VSLIMO_N:'||	LV_GD_APPLLICATION(i).v_vslimo_n       	||'<{||}>'||
'VSLMMSI_N:'||	LV_GD_APPLLICATION(i). v_vslmmsi_n   

  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

SEQ_DEPGD_PORTTLID_N.currval	||'<{||}>'||
LV_GD_APPLLICATION(i).v_applnref_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_gdv_n 	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pcc_n        	||'<{||}>'||
LV_GD_APPLLICATION(i). v_pccissd_dt       	||'<{||}>'||
LV_GD_APPLLICATION(i). v_pccexpy_dt      	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pccissdby_m     	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pccprnt_i   	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pccst_c          	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pcclatecancl_i   	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pcccancl_dt    	||'<{||}>'||
LV_GD_APPLLICATION(i).v_docidatth_n    	||'<{||}>'||
LV_GD_APPLLICATION(i).v_officialgdv_n    	||'<{||}>'||
100	||'<{||}>'||
SYSDATE   	||'<{||}>'||
'DATA MIGRATION'  	||'<{||}>'||
SYSDATE 	||'<{||}>'||
'DATA MIGRATION'         	||'<{||}>'||
0	||'<{||}>'||
0	||'<{||}>'||
LV_GD_APPLLICATION(i).v_cgo_q      	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depdeclr_dt    	||'<{||}>'||
LV_GD_APPLLICATION(i).v_mstrondep_x      	||'<{||}>'||
LV_GD_APPLLICATION(i).v_nxctry_m        	||'<{||}>'||
LV_GD_APPLLICATION(i).v_nxport_m        	||'<{||}>'||
LV_GD_APPLLICATION(i).v_org_c            	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pcc_i          	||'<{||}>'||
LV_GD_APPLLICATION(i).v_pccseq_n       	||'<{||}>'||
LV_GD_APPLLICATION(i).v_vsl_m            	||'<{||}>'||
LV_GD_APPLLICATION(i).v_vslcallsign_n  	||'<{||}>'||
LV_GD_APPLLICATION(i).v_vslflag_m     	||'<{||}>'||
LV_GD_APPLLICATION(i).v_vslgt_q        	||'<{||}>'||
LV_GD_APPLLICATION(i).v_vslimo_n       	||'<{||}>'||
LV_GD_APPLLICATION(i). v_vslmmsi_n    	


,
 'T'
 );

 end if;


end;  -- inner end  to insert the values into the DEP_GD_P_CLRCE_CERT  table




                  end loop;    -- end loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST   


end loop; -- end of CUR_GD_APPLN


close CUR_GD_APPLN;





/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO    v_src_count
FROM    st_cv_gdappln appln
where   appln.GDTY_C in('D','C') ;



SELECT COUNT(*)
INTO V_TGT_COUNT
FROM
SI_DEP_GD_P_CLRCE_CERT ;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_gdappln', V_SRC_COUNT, 'SI_DEP_GD_P_CLRCE_CERT', V_TGT_COUNT,'N');	




        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into SI_DEP_GD_P_CLRCE_CERT table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_GD_P_CLRCE_CERT table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_GD_P_CLRCE_CERT table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_GD_P_CLRCE_CERT table' ,
        'AMBIGIOUS',null,null,null,null);

end if;




/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure ends 
*************************************************************************************************************/






/***********************************************************************************************************
Reconciling the count of source intermediate GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO v_src_count
FROM
SI_DEP_GD_P_CLRCE_CERT;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM DEP_GD_P_CLRCE_CERT;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_DEP_GD_P_CLRCE_CERT', V_SRC_COUNT, 'DEP_GD_P_CLRCE_CERT', V_TGT_COUNT,'N');	  



        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into DEP_GD_P_CLRCE_CERT table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEP_GD_P_CLRCE_CERT table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEP_GD_P_CLRCE_CERT table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEP_GD_P_CLRCE_CERT table' ,
        'AMBIGIOUS',null,null,null,null);

end if;

/***********************************************************************************************************
Reconcilation of source intermediate GD Arrival  and target table of GD Departure  ends
*************************************************************************************************************/








/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO    v_src_count
FROM    st_cv_gdappln appln
where   appln.GDTY_C in('D','C') ;


     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM DEP_GD_P_CLRCE_CERT;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_gdappln', V_SRC_COUNT, 'DEP_GD_P_CLRCE_CERT', V_TGT_COUNT,'Y');	  

/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure ends 
*************************************************************************************************************/


exception  --outer exception 

when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

              PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_1_DEP_GD_P_CLRCE_CERT', V_SQLERRM, 'FAIL',null,null,null,'T');

end ;  -- outer end
/