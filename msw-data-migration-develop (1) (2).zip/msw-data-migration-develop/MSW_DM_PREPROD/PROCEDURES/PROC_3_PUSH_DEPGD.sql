create or replace PROCEDURE PROC_3_PUSH_DEPGD IS

    
    
/***********************************************************************************************************
PROCEDURE NAME : PROC_3_PUSH_DEPGD
CREATED BY     : C.N.BHASKAR
DATE           : 17-AUG-2019
PURPOSE        : PUSH ARRIVAL_GD RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO TARGET SCHEMA CVS_INTEGRATION
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/

---**** cursor for fetching data from target  Table ****

	CURSOR CUR_DEPGD IS
	SELECT
        APPLN_REF_N	,
		MSW_APPLN_REF_ID_X	,
		EXTL_APPLN_REF_ID_X	,
		ARRIVAL_APPLN_REF_N	,
		GDV_N	,
		DEP_DECLR_DT	,
		VSL_GT_ON_DEP_Q	,
		AGT_DECLR_AC_N	,
		NX_PORT_CTRY_C	,
		NX_PORT_C	,
		NX_PORT_M	,
		PERS_Q	,
		PAX_Q	,
		CREW_Q	,
		CGO_Q	,
		MSTR_ON_DEP_X	,
		MOTHER_GDV_N	,
		BUNKR_Q	,
		BUNKR_GR_C	,
		CST_N	,
		CHARTERER_NAT_C	,
		SLN_C	,
		APPLN_ST_C	,
		PROCESSED_BY_X	,
		PROCESSED_ON_DT	,
		PROCESSING_REM_X	,
		DELETED_I	,
		LOCKVER_N	,
		CRT_ON_DT	,
		CRT_BY_N	,
		UPT_ON_DT	,
		UPT_BY_X	,
		OFFICIAL_GDV_N	,
		CO_M	,
		DEP_LOCN	,
		MPA_AC_M	,
		INTL_REM_X	,
		MDO_I	,
		MFO_I	,
		MGO_I	,
		APPLCNT_ID_N	,
		AGT_DECLR_AC_DESC_X	,
		CHARTERER_NAT_DESC_X	,
		SLN_DESC_X	,
		DEP_LOCN_DESC_X	,
		NX_P_CTRY_DESC_X	,
		NX_P_DESC_X	,
		DEP_CRUISE_OPERATOR_NAME	,
		DEP_CRUISE_OPERATOR_ID	,
		EMAIL_ADDR_X	,
		MOBILE_N	,
		APPLCNT_M	,
		DEP_RSN_OTHERS	,
		DEP_RSN_TO_HIGH_SEA_C	
		
	FROM DEPARTURE_GD_APPLICATION;

	TYPE REC_DEPGD IS RECORD
	(	V_APPLN_REF_N				DEPARTURE_GD_APPLICATION.APPLN_REF_N%TYPE	,
		V_MSW_APPLN_REF_ID_X		DEPARTURE_GD_APPLICATION.MSW_APPLN_REF_ID_X%TYPE	,
		V_EXTL_APPLN_REF_ID_X		DEPARTURE_GD_APPLICATION.EXTL_APPLN_REF_ID_X%TYPE	,
		V_ARRIVAL_APPLN_REF_N		DEPARTURE_GD_APPLICATION.ARRIVAL_APPLN_REF_N%TYPE	,
		V_GDV_N						DEPARTURE_GD_APPLICATION.GDV_N%TYPE	,
		V_DEP_DECLR_DT				DEPARTURE_GD_APPLICATION.DEP_DECLR_DT%TYPE	,
		V_VSL_GT_ON_DEP_Q		DEPARTURE_GD_APPLICATION.VSL_GT_ON_DEP_Q%TYPE	,
		V_AGT_DECLR_AC_N		DEPARTURE_GD_APPLICATION.AGT_DECLR_AC_N%TYPE	,
		V_NX_PORT_CTRY_C		DEPARTURE_GD_APPLICATION.NX_PORT_CTRY_C%TYPE	,
		V_NX_PORT_C				DEPARTURE_GD_APPLICATION.NX_PORT_C%TYPE	,
		V_NX_PORT_M				DEPARTURE_GD_APPLICATION.NX_PORT_M%TYPE	,
		V_PERS_Q				DEPARTURE_GD_APPLICATION.PERS_Q%TYPE	,
		V_PAX_Q					DEPARTURE_GD_APPLICATION.PAX_Q%TYPE	,
		V_CREW_Q				DEPARTURE_GD_APPLICATION.CREW_Q%TYPE	,
		V_CGO_Q					DEPARTURE_GD_APPLICATION.CGO_Q%TYPE	,
		V_MSTR_ON_DEP_X			DEPARTURE_GD_APPLICATION.MSTR_ON_DEP_X%TYPE	,
		V_MOTHER_GDV_N			DEPARTURE_GD_APPLICATION.MOTHER_GDV_N%TYPE	,
		V_BUNKR_Q				DEPARTURE_GD_APPLICATION.BUNKR_Q%TYPE	,
		V_BUNKR_GR_C			DEPARTURE_GD_APPLICATION.BUNKR_GR_C%TYPE	,
		V_CST_N					DEPARTURE_GD_APPLICATION.CST_N%TYPE	,
		V_CHARTERER_NAT_C		DEPARTURE_GD_APPLICATION.CHARTERER_NAT_C%TYPE	,
		V_SLN_C					DEPARTURE_GD_APPLICATION.SLN_C%TYPE	,
		V_APPLN_ST_C			DEPARTURE_GD_APPLICATION.APPLN_ST_C%TYPE	,
		V_PROCESSED_BY_X		DEPARTURE_GD_APPLICATION.PROCESSED_BY_X%TYPE	,
		V_PROCESSED_ON_DT		DEPARTURE_GD_APPLICATION.PROCESSED_ON_DT%TYPE	,
		V_PROCESSING_REM_X		DEPARTURE_GD_APPLICATION.PROCESSING_REM_X%TYPE	,
		V_DELETED_I				DEPARTURE_GD_APPLICATION.DELETED_I%TYPE	,
		V_LOCKVER_N				DEPARTURE_GD_APPLICATION.LOCKVER_N%TYPE	,
		V_CRT_ON_DT				DEPARTURE_GD_APPLICATION.CRT_ON_DT%TYPE	,
		V_CRT_BY_N				DEPARTURE_GD_APPLICATION.CRT_BY_N%TYPE	,
		V_UPT_ON_DT				DEPARTURE_GD_APPLICATION.UPT_ON_DT%TYPE	,
		V_UPT_BY_X				DEPARTURE_GD_APPLICATION.UPT_BY_X%TYPE	,
		V_OFFICIAL_GDV_N		DEPARTURE_GD_APPLICATION.OFFICIAL_GDV_N%TYPE	,
		V_CO_M					DEPARTURE_GD_APPLICATION.CO_M%TYPE	,
		V_DEP_LOCN				DEPARTURE_GD_APPLICATION.DEP_LOCN%TYPE	,
		V_MPA_AC_M				DEPARTURE_GD_APPLICATION.MPA_AC_M%TYPE	,
		V_INTL_REM_X			DEPARTURE_GD_APPLICATION.INTL_REM_X%TYPE	,
		V_MDO_I					DEPARTURE_GD_APPLICATION.MDO_I%TYPE	,
		V_MFO_I					DEPARTURE_GD_APPLICATION.MFO_I%TYPE	,
		V_MGO_I					DEPARTURE_GD_APPLICATION.MGO_I%TYPE	,
		V_APPLCNT_ID_N			DEPARTURE_GD_APPLICATION.APPLCNT_ID_N%TYPE	,
		V_AGT_DECLR_AC_DESC_X	DEPARTURE_GD_APPLICATION.AGT_DECLR_AC_DESC_X%TYPE	,
		V_CHARTERER_NAT_DESC_X	DEPARTURE_GD_APPLICATION.CHARTERER_NAT_DESC_X%TYPE	,
		V_SLN_DESC_X			DEPARTURE_GD_APPLICATION.SLN_DESC_X%TYPE	,
		V_DEP_LOCN_DESC_X		DEPARTURE_GD_APPLICATION.DEP_LOCN_DESC_X%TYPE	,
		V_NX_P_CTRY_DESC_X		DEPARTURE_GD_APPLICATION.NX_P_CTRY_DESC_X%TYPE	,
		V_NX_P_DESC_X			DEPARTURE_GD_APPLICATION.NX_P_DESC_X%TYPE	,
		V_DEP_CRUISE_OPERATOR_NAME	DEPARTURE_GD_APPLICATION.DEP_CRUISE_OPERATOR_NAME%TYPE	,
		V_DEP_CRUISE_OPERATOR_ID	DEPARTURE_GD_APPLICATION.DEP_CRUISE_OPERATOR_ID%TYPE	,
		V_EMAIL_ADDR_X				DEPARTURE_GD_APPLICATION.EMAIL_ADDR_X%TYPE	,
		V_MOBILE_N					DEPARTURE_GD_APPLICATION.MOBILE_N%TYPE	,
		V_APPLCNT_M					DEPARTURE_GD_APPLICATION.APPLCNT_M%TYPE	,
		V_DEP_RSN_OTHERS			DEPARTURE_GD_APPLICATION.DEP_RSN_OTHERS%TYPE	,
		V_DEP_RSN_TO_HIGH_SEA_C		DEPARTURE_GD_APPLICATION.DEP_RSN_TO_HIGH_SEA_C%TYPE		

	);


	CURSOR CUR_DEP_POC IS
	SELECT
            DEP_GD_PURP_OF_CALL_ID_N,
			APPLN_REF_N,
			PURPCALL_C,
			DELETED_I,
			OTHERS_PURPOSE_X,
			PURP_CALL_OTHERS_TOW_X,
			PURPCALL_OTHERS_TOW_VSL_M,
			LOCK_VER_N,
			PURPCALL_OTHERS_UND_TOW_VSL_M,
			OTHER_AFLOAT_ACT

     FROM DEPARTURE_GD_PURPOSE_OF_CALL;

	TYPE REC_DEPGD_POC IS RECORD
	(	
	V_DEP_GD_PURP_OF_CALL_ID_N			DEPARTURE_GD_PURPOSE_OF_CALL.DEP_GD_PURP_OF_CALL_ID_N%TYPE,
	V_APPLN_REF_N						DEPARTURE_GD_PURPOSE_OF_CALL.APPLN_REF_N%TYPE,
	V_PURPCALL_C						DEPARTURE_GD_PURPOSE_OF_CALL.PURPCALL_C%TYPE,
	V_DELETED_I							DEPARTURE_GD_PURPOSE_OF_CALL.DELETED_I%TYPE,
	V_OTHERS_PURPOSE_X					DEPARTURE_GD_PURPOSE_OF_CALL.OTHERS_PURPOSE_X%TYPE,
	V_PURP_CALL_OTHERS_TOW_X			DEPARTURE_GD_PURPOSE_OF_CALL.PURP_CALL_OTHERS_TOW_X%TYPE,
	V_PURPCALL_OTHERS_TOW_VSL_M			DEPARTURE_GD_PURPOSE_OF_CALL.PURPCALL_OTHERS_TOW_VSL_M%TYPE,
	V_LOCK_VER_N						DEPARTURE_GD_PURPOSE_OF_CALL.LOCK_VER_N%TYPE,
	V_PURPCALL_OTHERS_UND_TOW_VSL_M		DEPARTURE_GD_PURPOSE_OF_CALL.PURPCALL_OTHERS_UND_TOW_VSL_M%TYPE,
	V_OTHER_AFLOAT_ACT					DEPARTURE_GD_PURPOSE_OF_CALL.OTHER_AFLOAT_ACT%TYPE
	);

	CURSOR CUR_DEP_GD_PORT IS
	SELECT
        APPLN_REF_N	,
        CGO_Q	,
        CRT_BY_N	,
        CRT_ON_DT	,
        DELETED_I	,
        DEPDECLR_DT	,
        DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
        DOC_ID_ATTH_N	,
        GDV_N	,
        LAST_UPDATED_BY_N	,
        LAST_UPDATED_ON_DT	,
        LOCK_VER_N	,
        MSTRONDEP_X	,
        MSW_DOC_ID_N	,
        NXCTRY_M	,
        NXPORT_M	,
        OFFICIAL_GDV_N	,
        ORG_C	,
        PCCSEQ_N	,
        PCC_CANCEL_DT	,
        PCC_EXPY_DT	,
        PCC_I	,
        PCC_ISSD_BY_M	,
        PCC_ISSD_DT	,
        PCC_LATE_CANCL_I	,
        PCC_N	,
        PCC_PRNT_I	,
        PCC_ST_C	,
        VSLCALLSIGN_N	,
        VSLFLAG_M	,
        VSLGT_Q	,
        VSLIMO_N	,
        VSLMMSI_N	,
        VSL_M	


	FROM DEP_GD_P_CLRCE_CERT;


	TYPE REC_DEPGD_PORT IS RECORD

(V_APPLN_REF_N		DEP_GD_P_CLRCE_CERT.APPLN_REF_N	%type	,
V_CGO_Q		       DEP_GD_P_CLRCE_CERT.CGO_Q%type	,
V_CRT_BY_N		    DEP_GD_P_CLRCE_CERT.CRT_BY_N%type	,
V_CRT_ON_DT		DEP_GD_P_CLRCE_CERT.CRT_ON_DT%type	,
V_DELETED_I		DEP_GD_P_CLRCE_CERT.DELETED_I%type	,
V_DEPDECLR_DT		DEP_GD_P_CLRCE_CERT.DEPDECLR_DT%type	,
V_DEP_GD_PORT_CLEARENCE_CERT_ID_N		DEP_GD_P_CLRCE_CERT.DEP_GD_PORT_CLEARENCE_CERT_ID_N%type	,
V_DOC_ID_ATTH_N		DEP_GD_P_CLRCE_CERT.DOC_ID_ATTH_N%type	,
V_GDV_N		DEP_GD_P_CLRCE_CERT.GDV_N%type	,
V_LAST_UPDATED_BY_N		DEP_GD_P_CLRCE_CERT.LAST_UPDATED_BY_N%type	,
V_LAST_UPDATED_ON_DT		DEP_GD_P_CLRCE_CERT.LAST_UPDATED_ON_DT%type	,
V_LOCK_VER_N		DEP_GD_P_CLRCE_CERT.LOCK_VER_N%type	,
V_MSTRONDEP_X		DEP_GD_P_CLRCE_CERT.MSTRONDEP_X%type	,
V_MSW_DOC_ID_N		DEP_GD_P_CLRCE_CERT. MSW_DOC_ID_N%type	,
V_NXCTRY_M		DEP_GD_P_CLRCE_CERT.NXCTRY_M%type	,
V_NXPORT_M		DEP_GD_P_CLRCE_CERT.NXPORT_M%type	,
V_OFFICIAL_GDV_N		DEP_GD_P_CLRCE_CERT.OFFICIAL_GDV_N%type	,
V_ORG_C		DEP_GD_P_CLRCE_CERT.ORG_C%type	,
V_PCCSEQ_N		DEP_GD_P_CLRCE_CERT.PCCSEQ_N%type	,
V_PCC_CANCEL_DT		DEP_GD_P_CLRCE_CERT.PCC_CANCEL_DT%type	,
V_PCC_EXPY_DT		DEP_GD_P_CLRCE_CERT.PCC_EXPY_DT%type	,
V_PCC_I		DEP_GD_P_CLRCE_CERT.PCC_I%type	,
V_PCC_ISSD_BY_M		DEP_GD_P_CLRCE_CERT. PCC_ISSD_BY_M%type	,
V_PCC_ISSD_DT		DEP_GD_P_CLRCE_CERT.PCC_ISSD_DT%type	,
V_PCC_LATE_CANCL_I		DEP_GD_P_CLRCE_CERT.PCC_LATE_CANCL_I%type	,
V_PCC_N		DEP_GD_P_CLRCE_CERT.PCC_N%type	,
V_PCC_PRNT_I		DEP_GD_P_CLRCE_CERT.PCC_PRNT_I%type	,
V_PCC_ST_C		DEP_GD_P_CLRCE_CERT.PCC_ST_C%type	,
V_VSLCALLSIGN_N		DEP_GD_P_CLRCE_CERT.VSLCALLSIGN_N%type	,
V_VSLFLAG_M		DEP_GD_P_CLRCE_CERT.VSLFLAG_M%type	,
V_VSLGT_Q		DEP_GD_P_CLRCE_CERT.VSLGT_Q%type	,
V_VSLIMO_N		DEP_GD_P_CLRCE_CERT.VSLIMO_N%type	,
V_VSLMMSI_N		DEP_GD_P_CLRCE_CERT.VSLMMSI_N%type	,
V_VSL_M		DEP_GD_P_CLRCE_CERT.VSL_M%type	


	);
    
    
    
    
    
    
    cursor  cur_dep_syard_loc is select * from DEP_GD_PURP_OF_CALL_SYARD_LOC;
    
    type REC_DEP_SHYARD is record
(
 v_depgdshyrd                               DEP_GD_PURP_OF_CALL_SYARD_LOC.DEP_GD_PURP_OF_CALL_SHIPYARD_LOC_ID_N%TYPE,
 v_depgdpoc                                 DEP_GD_PURP_OF_CALL_SYARD_LOC.DEP_GD_PURP_OF_CALL_ID_N%TYPE,
 v_depshyloc                                DEP_GD_PURP_OF_CALL_SYARD_LOC.SHIPYARD_LOC_C%TYPE,
 v_depshydescx                              DEP_GD_PURP_OF_CALL_SYARD_LOC.SHIPYARD_LOC_DESC_X%TYPE,
v_deplockver                                DEP_GD_PURP_OF_CALL_SYARD_LOC.LOCK_VER_N%TYPE,
v_depdeleted                                DEP_GD_PURP_OF_CALL_SYARD_LOC.DELETED_I%TYPE

);
    
    
    
    
    

    

	TYPE TYPE_DEPGD IS TABLE OF REC_DEPGD;
	LV_DEPGD		TYPE_DEPGD;

	TYPE TYPE_DEPGD_POC  IS TABLE OF REC_DEPGD_POC;
	LV_DEPGD_POC		TYPE_DEPGD_POC;

	TYPE TYPE_DEPGD_PORT  IS TABLE OF REC_DEPGD_PORT;
	LV_DEPGD_PORT		TYPE_DEPGD_PORT;
    
    type  TYPE_DEP_SHYARD is table of REC_DEP_SHYARD;
    LV_DEP_SHYARD       TYPE_DEP_SHYARD;
    

	LV_CNT_DEPGD       NUMBER;
	LV_CNT_DEPGD_TGT		NUMBER;
	LV_CNT_DEPGD_POC   NUMBER;
	LV_CNT_DEPGD_POC_TGT	NUMBER;
	LV_CNT_DEPGD_PORT  NUMBER;
	LV_CNT_DEPGD_PORT_TGT	NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);
	V_BLKEXPTN_COUNT    NUMBER(20, 0);
	V_BLKEXPTN_DESC     VARCHAR2(3000);
    V_EXP_ROWS          VARCHAR2(4000);
    LV_CNT_DEPGD_SHYRD_TGT   number;
LV_CNT_DEP_SHYRD  number;

BEGIN
    LV_CNT_DEPGD_TGT:=0;
    LV_CNT_DEPGD_POC_TGT:=0;
    LV_CNT_DEPGD_PORT_TGT:=0;
    LV_CNT_DEPGD_SHYRD_TGT := 0;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD
    FROM 
    DEPARTURE_GD_APPLICATION;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD_POC
    FROM 
    DEPARTURE_GD_PURPOSE_OF_CALL;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD_PORT
    FROM 
    DEP_GD_P_CLRCE_CERT;
    
    
    select  count(*) into LV_CNT_DEP_SHYRD
    
    from DEP_GD_PURP_OF_CALL_SYARD_LOC;



	OPEN CUR_DEPGD;
	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DDEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD', 'Insertion into target Table DEP_GD_APPLN', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form DEPARTURE_GD_APPLICATION and inseting into target table CVS_INTEGRATION.DEP_GD_APPLN ************------------------        

			FETCH CUR_DEPGD BULK COLLECT INTO LV_DEPGD LIMIT 10000;
            EXIT WHEN LV_DEPGD.count = 0;
			--FORALL i IN LV_ARRGD.first..LV_ARRGD.last SAVE EXCEPTIONS       
			FOR i IN LV_DEPGD.first..LV_DEPGD.last
			LOOP
-------------************ SYN_DEPGD is synonym of CVS_INTEGRATION.DEP_GD_APPLN  ************------------------  
			BEGIN
			INSERT INTO SYN_DEPGD(
									APPLN_REF_N	,
									MSW_APPLN_REF_X	,
									EXTL_APPLN_REF_X	,
									ARRIVAL_APPLN_REF_N	,
									GDV_N	,
									DEP_DECLR_DT	,
									VSL_GT_ON_DEP_Q	,
									AGT_DECLR_AC_N	,
									NX_P_CTRY_C	,
									NX_P_C	,
									NX_P_M	,
									PERS_Q	,
									PAX_Q	,
									CR_Q	,
									CGO_Q	,
									MSTR_ON_DEP_X	,
									MOTHER_GDV_N	,
									BUNKR_Q	,
									BUNKR_GR_C	,
									CST_N	,
									CHARTERER_NAT_C	,
									SLN_C	,
									APPLN_ST_C	,
									PROCESSED_BY_N	,
									PROCESSED_ON_DT	,
									PROCESSING_REM_X	,
									DELETED_I	,
									LOCK_VER_N	,
									CRT_ON_DT	,
									CRT_BY_N	,
									LST_UPD_ON_DT	,
									LST_UPD_BY_N	,
									OFFICIAL_GDV_N	,
									CO_M	,
									DEP_LOCN	,
									MPA_AC_M	,
									INTL_REM_X	,
									MDO_I	,
									MFO_I	,
									MGO_I	,
									APPLCNT_ID_N	,
									AGT_DECLR_AC_DESC_X	,
									CHARTERER_NAT_DESC_X	,
									SLN_DESC_X	,
									DEP_LOCN_DESC_X	,
									NX_P_CTRY_DESC_X	,
									NX_P_DESC_X	,
									DEP_CRUISE_OPERATOR_NAME	,
									DEP_CRUISE_OPERATOR_ID	,
									EMAIL_ADDR_X	,
									MOBILE_N	,
									APPLCNT_M	,
									DEP_RSN_OTHERS	,
									DEP_RSN_TO_HIGH_SEA_C	


									)
							VALUES (
									LV_DEPGD(i).V_APPLN_REF_N,
									LV_DEPGD(i).V_MSW_APPLN_REF_ID_X,
									LV_DEPGD(i).V_EXTL_APPLN_REF_ID_X,
									LV_DEPGD(i).V_ARRIVAL_APPLN_REF_N,
									LV_DEPGD(i).V_GDV_N,
									LV_DEPGD(i).V_DEP_DECLR_DT,
									LV_DEPGD(i).V_VSL_GT_ON_DEP_Q,
									LV_DEPGD(i).V_AGT_DECLR_AC_N,
									LV_DEPGD(i).V_NX_PORT_CTRY_C,
									LV_DEPGD(i).V_NX_PORT_C,
									LV_DEPGD(i).V_NX_PORT_M,
									LV_DEPGD(i).V_PERS_Q,
									LV_DEPGD(i).V_PAX_Q,
									LV_DEPGD(i).V_CREW_Q,
									LV_DEPGD(i).V_CGO_Q,
									LV_DEPGD(i).V_MSTR_ON_DEP_X,
									LV_DEPGD(i).V_MOTHER_GDV_N,
									LV_DEPGD(i).V_BUNKR_Q,
									LV_DEPGD(i).V_BUNKR_GR_C,
									LV_DEPGD(i).V_CST_N,
									LV_DEPGD(i).V_CHARTERER_NAT_C,
									LV_DEPGD(i).V_SLN_C,
									LV_DEPGD(i).V_APPLN_ST_C,
									LV_DEPGD(i).V_PROCESSED_BY_X,
									LV_DEPGD(i).V_PROCESSED_ON_DT,
									LV_DEPGD(i).V_PROCESSING_REM_X,
									LV_DEPGD(i).V_DELETED_I,
									LV_DEPGD(i).V_LOCKVER_N,
									LV_DEPGD(i).V_CRT_ON_DT,
									LV_DEPGD(i).V_CRT_BY_N,
									LV_DEPGD(i).V_UPT_ON_DT,
									LV_DEPGD(i).V_UPT_BY_X,
									LV_DEPGD(i).V_OFFICIAL_GDV_N,
									LV_DEPGD(i).V_CO_M,
									LV_DEPGD(i).V_DEP_LOCN,
									LV_DEPGD(i).V_MPA_AC_M,
									LV_DEPGD(i).V_INTL_REM_X,
									LV_DEPGD(i).V_MDO_I,
									LV_DEPGD(i).V_MFO_I,
									LV_DEPGD(i).V_MGO_I,
									LV_DEPGD(i).V_APPLCNT_ID_N,
									LV_DEPGD(i).V_AGT_DECLR_AC_DESC_X,
									LV_DEPGD(i).V_CHARTERER_NAT_DESC_X,
									LV_DEPGD(i).V_SLN_DESC_X,
									LV_DEPGD(i).V_DEP_LOCN_DESC_X,
									LV_DEPGD(i).V_NX_P_CTRY_DESC_X,
									LV_DEPGD(i).V_NX_P_DESC_X,
									LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_NAME,
									LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_ID,
									LV_DEPGD(i).V_EMAIL_ADDR_X,
									LV_DEPGD(i).V_MOBILE_N,
									LV_DEPGD(i).V_APPLCNT_M,
									LV_DEPGD(i).V_DEP_RSN_OTHERS,
									LV_DEPGD(i).V_DEP_RSN_TO_HIGH_SEA_C
									);
            LV_CNT_DEPGD_TGT :=LV_CNT_DEPGD_TGT+1;

			EXCEPTION
				WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;
			
			

  pkg_datamigration_generic.proc_trace_exception('SYN_DEPGD', 'PROC_3_PUSH_DEPGD', 
                                                   
                                                ' APPLN_REF_N: '||LV_DEPGD(i).V_APPLN_REF_N||'<{||}>'||
												' MSW_APPLN_REF_ID_X: '||LV_DEPGD(i).V_MSW_APPLN_REF_ID_X||'<{||}>'||
												' EXTL_APPLN_REF_ID_X: '||LV_DEPGD(i).V_EXTL_APPLN_REF_ID_X||'<{||}>'||
												' ARRIVAL_APPLN_REF_N: '||LV_DEPGD(i).V_ARRIVAL_APPLN_REF_N||'<{||}>'||
												' GDV_N: '||LV_DEPGD(i).V_GDV_N||'<{||}>'||
												' DEP_DECLR_DT: '||LV_DEPGD(i).V_DEP_DECLR_DT||'<{||}>'||
												' VSL_GT_ON_DEP_Q: '||LV_DEPGD(i).V_VSL_GT_ON_DEP_Q||'<{||}>'||
												' AGT_DECLR_AC_N: '||LV_DEPGD(i).V_AGT_DECLR_AC_N||'<{||}>'||
												' NX_PORT_CTRY_C: '||LV_DEPGD(i).V_NX_PORT_CTRY_C||'<{||}>'||
												' NX_PORT_C: '||LV_DEPGD(i).V_NX_PORT_C||'<{||}>'||
												' NX_PORT_M: '||LV_DEPGD(i).V_NX_PORT_M||'<{||}>'||
												' PERS_Q: '||LV_DEPGD(i).V_PERS_Q||'<{||}>'||
												' PAX_Q: '||LV_DEPGD(i).V_PAX_Q||'<{||}>'||
												' CREW_Q: '||LV_DEPGD(i).V_CREW_Q||'<{||}>'||
												' CGO_Q: '||LV_DEPGD(i).V_CGO_Q||'<{||}>'||
												' MSTR_ON_DEP_X: '||LV_DEPGD(i).V_MSTR_ON_DEP_X||'<{||}>'||
												' MOTHER_GDV_N: '||LV_DEPGD(i).V_MOTHER_GDV_N||'<{||}>'||
												' BUNKR_Q: '||LV_DEPGD(i).V_BUNKR_Q||'<{||}>'||
												' BUNKR_GR_C: '||LV_DEPGD(i).V_BUNKR_GR_C||'<{||}>'||
												' CST_N: '||LV_DEPGD(i).V_CST_N||'<{||}>'||
												' CHARTERER_NAT_C: '||LV_DEPGD(i).V_CHARTERER_NAT_C||'<{||}>'||
												' SLN_C: '||LV_DEPGD(i).V_SLN_C||'<{||}>'||
												' APPLN_ST_C: '||LV_DEPGD(i).V_APPLN_ST_C||'<{||}>'||
												' PROCESSED_BY_X: '||LV_DEPGD(i).V_PROCESSED_BY_X||'<{||}>'||
												' PROCESSED_ON_DT: '||LV_DEPGD(i).V_PROCESSED_ON_DT||'<{||}>'||
												' PROCESSING_REM_X: '||LV_DEPGD(i).V_PROCESSING_REM_X||'<{||}>'||
												' DELETED_I: '||LV_DEPGD(i).V_DELETED_I||'<{||}>'||
												' LOCKVER_N: '||LV_DEPGD(i).V_LOCKVER_N||'<{||}>'||
												' CRT_ON_DT: '||LV_DEPGD(i).V_CRT_ON_DT||'<{||}>'||
												' CRT_BY_N: '||LV_DEPGD(i).V_CRT_BY_N||'<{||}>'||
												' UPT_ON_DT: '||LV_DEPGD(i).V_UPT_ON_DT||'<{||}>'||
												' UPT_BY_X: '||LV_DEPGD(i).V_UPT_BY_X||'<{||}>'||
												' OFFICIAL_GDV_N: '||LV_DEPGD(i).V_OFFICIAL_GDV_N||'<{||}>'||
												' CO_M: '||LV_DEPGD(i).V_CO_M||'<{||}>'||
												' DEP_LOCN: '||LV_DEPGD(i).V_DEP_LOCN||'<{||}>'||
												' MPA_AC_M: '||LV_DEPGD(i).V_MPA_AC_M||'<{||}>'||
												' INTL_REM_X: '||LV_DEPGD(i).V_INTL_REM_X||'<{||}>'||
												' MDO_I: '||LV_DEPGD(i).V_MDO_I||'<{||}>'||
												' MFO_I: '||LV_DEPGD(i).V_MFO_I||'<{||}>'||
												' MGO_I: '||LV_DEPGD(i).V_MGO_I||'<{||}>'||
												' APPLCNT_ID_N: '||LV_DEPGD(i).V_APPLCNT_ID_N||'<{||}>'||
												' AGT_DECLR_AC_DESC_X: '||LV_DEPGD(i).V_AGT_DECLR_AC_DESC_X||'<{||}>'||
												' CHARTERER_NAT_DESC_X: '||LV_DEPGD(i).V_CHARTERER_NAT_DESC_X||'<{||}>'||
												' SLN_DESC_X: '||LV_DEPGD(i).V_SLN_DESC_X||'<{||}>'||
												' DEP_LOCN_DESC_X: '||LV_DEPGD(i).V_DEP_LOCN_DESC_X||'<{||}>'||
												' NX_P_CTRY_DESC_X: '||LV_DEPGD(i).V_NX_P_CTRY_DESC_X||'<{||}>'||
												' NX_P_DESC_X: '||LV_DEPGD(i).V_NX_P_DESC_X||'<{||}>'||
												' DEP_CRUISE_OPERATOR_NAME: '||LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_NAME||'<{||}>'||
												' DEP_CRUISE_OPERATOR_ID: '||LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_ID||'<{||}>'||
												' EMAIL_ADDR_X: '||LV_DEPGD(i).V_EMAIL_ADDR_X||'<{||}>'||
												' MOBILE_N: '||LV_DEPGD(i).V_MOBILE_N||'<{||}>'||
												' APPLCNT_M: '||LV_DEPGD(i).V_APPLCNT_M||'<{||}>'||
												' DEP_RSN_OTHERS: '||LV_DEPGD(i).V_DEP_RSN_OTHERS||'<{||}>'||
												' DEP_RSN_TO_HIGH_SEA_C: '||LV_DEPGD(i).V_DEP_RSN_TO_HIGH_SEA_C||'<{||}>'
												,
												'ERROR',

						                                  	null,

							                                V_SQLERRM,
                
												LV_DEPGD(i).V_APPLN_REF_N||'<{||}>'||
												LV_DEPGD(i).V_MSW_APPLN_REF_ID_X||'<{||}>'||
												LV_DEPGD(i).V_EXTL_APPLN_REF_ID_X||'<{||}>'||
												LV_DEPGD(i).V_ARRIVAL_APPLN_REF_N||'<{||}>'||
												LV_DEPGD(i).V_GDV_N||'<{||}>'||
												LV_DEPGD(i).V_DEP_DECLR_DT||'<{||}>'||
												LV_DEPGD(i).V_VSL_GT_ON_DEP_Q||'<{||}>'||
												LV_DEPGD(i).V_AGT_DECLR_AC_N||'<{||}>'||
												LV_DEPGD(i).V_NX_PORT_CTRY_C||'<{||}>'||
												LV_DEPGD(i).V_NX_PORT_C||'<{||}>'||
												LV_DEPGD(i).V_NX_PORT_M||'<{||}>'||
												LV_DEPGD(i).V_PERS_Q||'<{||}>'||
												LV_DEPGD(i).V_PAX_Q||'<{||}>'||
												LV_DEPGD(i).V_CREW_Q||'<{||}>'||
												LV_DEPGD(i).V_CGO_Q||'<{||}>'||
												LV_DEPGD(i).V_MSTR_ON_DEP_X||'<{||}>'||
												LV_DEPGD(i).V_MOTHER_GDV_N||'<{||}>'||
												LV_DEPGD(i).V_BUNKR_Q||'<{||}>'||
												LV_DEPGD(i).V_BUNKR_GR_C||'<{||}>'||
												LV_DEPGD(i).V_CST_N||'<{||}>'||
												LV_DEPGD(i).V_CHARTERER_NAT_C||'<{||}>'||
												LV_DEPGD(i).V_SLN_C||'<{||}>'||
												LV_DEPGD(i).V_APPLN_ST_C||'<{||}>'||
												LV_DEPGD(i).V_PROCESSED_BY_X||'<{||}>'||
												LV_DEPGD(i).V_PROCESSED_ON_DT||'<{||}>'||
												LV_DEPGD(i).V_PROCESSING_REM_X||'<{||}>'||
												LV_DEPGD(i).V_DELETED_I||'<{||}>'||
												LV_DEPGD(i).V_LOCKVER_N||'<{||}>'||
												LV_DEPGD(i).V_CRT_ON_DT||'<{||}>'||
												LV_DEPGD(i).V_CRT_BY_N||'<{||}>'||
												LV_DEPGD(i).V_UPT_ON_DT||'<{||}>'||
												LV_DEPGD(i).V_UPT_BY_X||'<{||}>'||
												LV_DEPGD(i).V_OFFICIAL_GDV_N||'<{||}>'||
												LV_DEPGD(i).V_CO_M||'<{||}>'||
												LV_DEPGD(i).V_DEP_LOCN||'<{||}>'||
												LV_DEPGD(i).V_MPA_AC_M||'<{||}>'||
												LV_DEPGD(i).V_INTL_REM_X||'<{||}>'||
												LV_DEPGD(i).V_MDO_I||'<{||}>'||
												LV_DEPGD(i).V_MFO_I||'<{||}>'||
												LV_DEPGD(i).V_MGO_I||'<{||}>'||
												LV_DEPGD(i).V_APPLCNT_ID_N||'<{||}>'||
												LV_DEPGD(i).V_AGT_DECLR_AC_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_CHARTERER_NAT_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_SLN_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_DEP_LOCN_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_NX_P_CTRY_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_NX_P_DESC_X||'<{||}>'||
												LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_NAME||'<{||}>'||
												LV_DEPGD(i).V_DEP_CRUISE_OPERATOR_ID||'<{||}>'||
												LV_DEPGD(i).V_EMAIL_ADDR_X||'<{||}>'||
												LV_DEPGD(i).V_MOBILE_N||'<{||}>'||
												LV_DEPGD(i).V_APPLCNT_M||'<{||}>'||
												LV_DEPGD(i).V_DEP_RSN_OTHERS||'<{||}>'||
												LV_DEPGD(i).V_DEP_RSN_TO_HIGH_SEA_C
												,
												'T'
                                                );

			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEPGD;	

    /*
	 SELECT     COUNT(*)
     INTO LV_CNT_TT_AGD
     FROM
     SYN_ARRGD;
    */

	IF( LV_CNT_DEPGD =  LV_CNT_DEPGD_TGT ) AND LV_CNT_DEPGD <>  0  AND  LV_CNT_DEPGD_TGT <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD  <> LV_CNT_DEPGD_TGT AND  LV_CNT_DEPGD <> 0 AND  LV_CNT_DEPGD_TGT <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD  <> 0 AND  LV_CNT_DEPGD_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   



    pkg_datamigration_generic.proc_migration_recon('DEPARTURE_GD_APPLICATION', LV_CNT_DEPGD, 'DEP_GD_APPLN', LV_CNT_DEPGD_TGT,'Y');




	/***********************************************************************************************************
	Pushing records into CVS_INTEGRATION.DEP_GD_PURP_OF_CALL
    ***********************************************************************************************************/


	OPEN CUR_DEP_POC;

	pkg_datamigration_generic.proc_trace_exception('DEPGD_POC', 'PROC_3_PUSH_DEPGD', 'Insertion into SYN_DEPGD_POC', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form ARR_GD_PURP_OF_CALL and inseting into target table CVS_INTEGRATION.DEP_GD_PURP_OF_CALL ************------------------        

			FETCH CUR_DEP_POC BULK COLLECT INTO LV_DEPGD_POC LIMIT 10000;
       
            EXIT WHEN LV_DEPGD_POC.count = 0;
              

			--FORALL i IN LV_ARRGD_POC.first..LV_ARRGD_POC.last SAVE EXCEPTIONS  
			FOR i IN LV_DEPGD_POC.first..LV_DEPGD_POC.last
			LOOP
-------------************ SYN_ARRGD_POC is synonym of CVS_INTEGRATION.DEP_GD_PURP_OF_CALL  ************------------------  
			BEGIN
                   

            
      
			INSERT INTO SYN_DEPGD_POC
									(
									ID,
									APPLN_REF_N,
									PURPCALL_C,
									DELETED_I,
									OTHERS_PURP_X,
									PURP_CALL_OTHERS_TOW_X,
									PURPCALL_OTHERS_TOW_VSL_M,
									LOCK_VER_N,
									PURPCALL_OTHERS_UND_TOW_VSL_M,
									OTHER_AFLOAT_ACT
									)
							VALUES (
									LV_DEPGD_POC(i).V_DEP_GD_PURP_OF_CALL_ID_N,
									LV_DEPGD_POC(i).V_APPLN_REF_N,
									LV_DEPGD_POC(i).V_PURPCALL_C,
									LV_DEPGD_POC(i).V_DELETED_I,
									LV_DEPGD_POC(i).V_OTHERS_PURPOSE_X,
									LV_DEPGD_POC(i).V_PURP_CALL_OTHERS_TOW_X,
									LV_DEPGD_POC(i).V_PURPCALL_OTHERS_TOW_VSL_M,
									LV_DEPGD_POC(i).V_LOCK_VER_N,
									LV_DEPGD_POC(i).V_PURPCALL_OTHERS_UND_TOW_VSL_M,
									LV_DEPGD_POC(i).V_OTHER_AFLOAT_ACT
                                                                            
									);
                    LV_CNT_DEPGD_POC_TGT := LV_CNT_DEPGD_POC_TGT+1;
                    

			EXCEPTION
			WHEN OTHERS THEN
         
            V_ERR_CODE := SQLCODE;
            
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

  pkg_datamigration_generic.proc_trace_exception('SYN_DEPGD_POC', 
  
                                                   'PROC_3_PUSH_DEPGD', 
                                                   
													'DEP_GD_PURP_OF_CALL_ID_N: '||LV_DEPGD_POC(i).V_DEP_GD_PURP_OF_CALL_ID_N||'<{||}>'||
													'APPLN_REF_N: '||LV_DEPGD_POC(i).V_APPLN_REF_N||'<{||}>'||
													'PURPCALL_C: '||LV_DEPGD_POC(i).V_PURPCALL_C||'<{||}>'||
													'DELETED_I: '||LV_DEPGD_POC(i).V_DELETED_I||'<{||}>'||
													'OTHERS_PURPOSE_X: '||LV_DEPGD_POC(i).V_OTHERS_PURPOSE_X||'<{||}>'||
													'PURP_CALL_OTHERS_TOW_X: '||LV_DEPGD_POC(i).V_PURP_CALL_OTHERS_TOW_X||'<{||}>'||
													'PURPCALL_OTHERS_TOW_VSL_M: '||LV_DEPGD_POC(i).V_PURPCALL_OTHERS_TOW_VSL_M||'<{||}>'||
													'LOCK_VER_N: '||LV_DEPGD_POC(i).V_LOCK_VER_N||'<{||}>'||
													'PURPCALL_OTHERS_UND_TOW_VSL_M: '||LV_DEPGD_POC(i).V_PURPCALL_OTHERS_UND_TOW_VSL_M||'<{||}>'||
													'OTHER_AFLOAT_ACT: '||LV_DEPGD_POC(i).V_OTHER_AFLOAT_ACT,
							                        
													'ERROR',
													NULL,
													V_SQLERRM,
													LV_DEPGD_POC(i).V_DEP_GD_PURP_OF_CALL_ID_N||'<{||}>'||
													LV_DEPGD_POC(i).V_APPLN_REF_N||'<{||}>'||
													LV_DEPGD_POC(i).V_PURPCALL_C||'<{||}>'||
													LV_DEPGD_POC(i).V_DELETED_I||'<{||}>'||
													LV_DEPGD_POC(i).V_OTHERS_PURPOSE_X||'<{||}>'||
													LV_DEPGD_POC(i).V_PURP_CALL_OTHERS_TOW_X||'<{||}>'||
													LV_DEPGD_POC(i).V_PURPCALL_OTHERS_TOW_VSL_M||'<{||}>'||
													LV_DEPGD_POC(i).V_LOCK_VER_N||'<{||}>'||
													LV_DEPGD_POC(i).V_PURPCALL_OTHERS_UND_TOW_VSL_M
													,
													'T'
                                                );


			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEP_POC;

	IF( LV_CNT_DEPGD_POC =  LV_CNT_DEPGD_POC_TGT ) AND LV_CNT_DEPGD_POC_TGT <>  0  AND  LV_CNT_DEPGD_POC <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD_POC  <> LV_CNT_DEPGD_POC_TGT AND  LV_CNT_DEPGD_POC_TGT <> 0 AND  LV_CNT_DEPGD_POC <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD_POC  <> 0 AND  LV_CNT_DEPGD_POC_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEPARTURE_GD_PURPOSE_OF_CALL', LV_CNT_DEPGD_POC, 'DEP_GD_PURP_OF_CALL', LV_CNT_DEPGD_POC_TGT,'Y');


	/***********************************************************************************************************
	Pushing records into CVS_INTEGRATION.DEP_GD_PURP_OF_CALL
    ***********************************************************************************************************/


	OPEN CUR_DEP_GD_PORT;


	pkg_datamigration_generic.proc_trace_exception('DEP_GD_PORT', 'PROC_3_PUSH_DEPGD', 'Insertion into target Table DEP_GD_P_CLRCE_CERT', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form ARR_GD_PURP_OF_CALL_SYARD_LOC and inserting into target table CVS_INTEGRATION.DEP_GD_PURP_OF_CALL_SYARD_LOC ************------------------        

			FETCH CUR_DEP_GD_PORT BULK COLLECT INTO LV_DEPGD_PORT LIMIT 10000;
     
            EXIT WHEN LV_DEPGD_PORT.count = 0;
			--FORALL i IN LV_ARRGD_POC_SYL.first..LV_ARRGD_POC_SYL.last SAVE EXCEPTIONS
			FOR i IN LV_DEPGD_PORT.first..LV_DEPGD_PORT.last
			LOOP
-------------************ SYN_ARRGD_POC_SYL is synonym of CVS_INTEGRATION.DEP_GD_P_CLRCE_CERT  ************------------------  
			BEGIN

    dbms_output.put_line(600);
			INSERT INTO SYN_DEP_GD_P_CRT
									(															
									APPLN_REF_N	,
                                    CGO_Q	,
                                    CRT_BY_N	,
                                    CRT_ON_DT	,
                                    DELETED_I	,
                                    DEPDECLR_DT	,
                                    DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
                                    DOC_ID_ATTH_N	,
                                    GDV_N	,
                                    LOCK_VER_N	,
                                    LST_UPD_BY_N	,
                                    LST_UPD_ON_DT	,
                                    MSTRONDEP_X	,
                                    MSW_DOC_ID_N	,
                                    NX_CTRY_M	,
                                    NX_P_M	,
                                    OFFICIAL_GDV_N	,
                                    ORG_C	,
                                    PCCSEQ_N	,
                                    PCC_CANCL_DT	,
                                    PCC_DOC_M	,
                                    PCC_DOC_PATH_X	,
                                    PCC_EXPY_DT	,
                                    PCC_I	,
                                    PCC_ISSD_BY_M	,
                                    PCC_ISS_DT	,
                                    PCC_LATE_CANCL_I	,
                                    PCC_N	,
                                    PCC_PRNT_I	,
                                    PCC_ST_C	,
                                    VSLCALLSIGN_N	,
                                    VSLFLAG_M	,
                                    VSLGT_Q	,
                                    VSLIMO_N	,
                                    VSLMMSI_N	,
                                    VSL_M	
                                    
									)
							VALUES (									
									LV_DEPGD_PORT(I).v_APPLN_REF_N	,
                                    LV_DEPGD_PORT(I).v_CGO_Q	,
                                    LV_DEPGD_PORT(I).v_CRT_BY_N	,
                                    LV_DEPGD_PORT(I).v_CRT_ON_DT	,
                                    LV_DEPGD_PORT(I).v_DELETED_I	,
                                    LV_DEPGD_PORT(I).v_DEPDECLR_DT	,
                                    LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
                                    LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	,
                                    LV_DEPGD_PORT(I).v_GDV_N	,
                                    LV_DEPGD_PORT(I).v_LOCK_VER_N	,
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	,
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	,
                                    LV_DEPGD_PORT(I).v_MSTRONDEP_X	,
                                    LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	,
                                    LV_DEPGD_PORT(I).v_NXCTRY_M	,
                                    LV_DEPGD_PORT(I).v_NXPORT_M	,
                                    LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	,
                                    LV_DEPGD_PORT(I).v_ORG_C	,
                                    LV_DEPGD_PORT(I).v_PCCSEQ_N	,
                                    LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	,
                                                    '9'	,
                                                    '9'	,
                                    LV_DEPGD_PORT(I).v_PCC_EXPY_DT	,
                                    LV_DEPGD_PORT(I).v_PCC_I	,
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	,
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_DT	,
                                    LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	,
                                    LV_DEPGD_PORT(I).v_PCC_N	,
                                   LV_DEPGD_PORT(I).v_PCC_PRNT_I,	
                                    LV_DEPGD_PORT(I).v_PCC_ST_C	,
                                    LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	,
                                    LV_DEPGD_PORT(I).v_VSLFLAG_M	,
                                    LV_DEPGD_PORT(I).v_VSLGT_Q	,
                                    LV_DEPGD_PORT(I).v_VSLIMO_N	,
                                    LV_DEPGD_PORT(I).v_VSLMMSI_N	,
                                    LV_DEPGD_PORT(I).v_VSL_M	
                                    );
                                    
            LV_CNT_DEPGD_PORT_TGT :=LV_CNT_DEPGD_PORT_TGT+1;

			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

           pkg_datamigration_generic.proc_trace_exception('SYN_DEP_GD_P_CRT', 
                                                            'PROC_3_PUSH_DEPGD', 

                                    'APPLN_REF_N:'||LV_DEPGD_PORT(I).v_APPLN_REF_N	||'<{||}>'||
                                    'CGO_Q:'||LV_DEPGD_PORT(I).v_CGO_Q	||'<{||}>'||
                                    'CRT_BY_N:'|| LV_DEPGD_PORT(I).v_CRT_BY_N	||'<{||}>'||
                                    'CRT_ON_DT:'|| LV_DEPGD_PORT(I).v_CRT_ON_DT	||'<{||}>'||
                                    'DELETED_I:'||LV_DEPGD_PORT(I).v_DELETED_I	||'<{||}>'||
                                    'DEPDECLR_DT:'||LV_DEPGD_PORT(I).v_DEPDECLR_DT	||'<{||}>'||
                                    'DEP_GD_PORT_CLEARENCE_CERT_ID_N:'|| LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	||'<{||}>'||
                                    'DOC_ID_ATTH_N:'|| LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	||'<{||}>'||
                                    'GDV_N:'||LV_DEPGD_PORT(I).v_GDV_N	||'<{||}>'||
                                    'LOCK_VER_N:'|| LV_DEPGD_PORT(I).v_LOCK_VER_N	||'<{||}>'||
                                    'LST_UPD_BY_N:'||LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	||'<{||}>'||
                                    'LST_UPD_ON_DT:'||LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	||'<{||}>'||
                                    'MSTRONDEP_X:'||LV_DEPGD_PORT(I).v_MSTRONDEP_X	||'<{||}>'||
                                    'MSW_DOC_ID_N:'||LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	||'<{||}>'||
                                    'NX_CTRY_M:'|| LV_DEPGD_PORT(I).v_NXCTRY_M	||'<{||}>'||
                                    'NX_P_M:'||LV_DEPGD_PORT(I).v_NXPORT_M	||'<{||}>'||
                                    'OFFICIAL_GDV_N:'||LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	||'<{||}>'||
                                    'ORG_C:'||LV_DEPGD_PORT(I).v_ORG_C	||'<{||}>'||
                                    'PCCSEQ_N:'|| LV_DEPGD_PORT(I).v_PCCSEQ_N	||'<{||}>'||
                                    'PCC_CANCL_DT:'||LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	||'<{||}>'||
                                    'PCC_DOC_M:'||  'not null'	||'<{||}>'||
                                    'PCC_DOC_PATH_X:'||  null	||'<{||}>'||
                                    'PCC_EXPY_DT:'|| LV_DEPGD_PORT(I).v_PCC_EXPY_DT	||'<{||}>'||
                                    'PCC_I:'|| LV_DEPGD_PORT(I).v_PCC_I	||'<{||}>'||
                                    'PCC_ISSD_BY_M:'|| LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	||'<{||}>'||
                                    'PCC_ISS_DT:'|| LV_DEPGD_PORT(I).v_PCC_ISSD_DT	||'<{||}>'||
                                    'PCC_LATE_CANCL_I:'|| LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	||'<{||}>'||
                                    'PCC_N:'|| LV_DEPGD_PORT(I).v_PCC_N	||'<{||}>'||
                                    'PCC_PRNT_I:'||LV_DEPGD_PORT(I).v_PCC_PRNT_I	||'<{||}>'||
                                    'PCC_ST_C:'|| LV_DEPGD_PORT(I).v_PCC_ST_C	||'<{||}>'||
                                    'VSLCALLSIGN_N:'||LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	||'<{||}>'||
                                    'VSLFLAG_M:'|| LV_DEPGD_PORT(I).v_VSLFLAG_M	||'<{||}>'||
                                    'VSLGT_Q:'|| LV_DEPGD_PORT(I).v_VSLGT_Q	||'<{||}>'||
                                    'VSLIMO_N:'|| LV_DEPGD_PORT(I).v_VSLIMO_N	||'<{||}>'||
                                    'VSLMMSI_N:'||LV_DEPGD_PORT(I).v_VSLMMSI_N	||'<{||}>'||
                                    'VSL_M:'||LV_DEPGD_PORT(I).v_VSL_M	 ,

							                                'ERROR',

						                                  	null,

							                                V_SQLERRM,

                                                     LV_DEPGD_PORT(I).v_APPLN_REF_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CGO_Q	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CRT_BY_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CRT_ON_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DELETED_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DEPDECLR_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_GDV_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LOCK_VER_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_MSTRONDEP_X	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_NXCTRY_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_NXPORT_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_ORG_C	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCCSEQ_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	||'<{||}>'||
                                                    'not null'	||'<{||}>'||
                                                    null	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_EXPY_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_PRNT_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ST_C	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLFLAG_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLGT_Q	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLIMO_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLMMSI_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSL_M	
,


							                                'T'
                                                            );

			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEP_GD_PORT;
    
    
  
    
    
 
    

	IF( LV_CNT_DEPGD_PORT_TGT =  LV_CNT_DEPGD_PORT) AND LV_CNT_DEPGD_PORT<>  0  AND  LV_CNT_DEPGD_PORT_TGT <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD_PORT <> LV_CNT_DEPGD_PORT_TGT AND  LV_CNT_DEPGD_PORT<> 0 AND  LV_CNT_DEPGD_PORT_TGT <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD_PORT <> 0 AND  LV_CNT_DEPGD_PORT_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

    COMMIT;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEP_GD_P_CLRCE_CERT', LV_CNT_DEPGD_PORT, 'DEP_GD_P_CLRCE_CERT', LV_CNT_DEPGD_PORT_TGT,'Y');
    
    
    
    
    
    
     ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   --DEPSHYARDLOC
   
   OPEN cur_dep_syard_loc;


	pkg_datamigration_generic.proc_trace_exception('DEP_GD_SHYARD_LOC', 'PROC_3_PUSH_DEPGD', 'Insertion into target Table DEP_GD_PURP_OF_CALL_SYARD_LOC', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form ARR_GD_PURP_OF_CALL_SYARD_LOC and inserting into target table CVS_INTEGRATION.DEP_GD_PURP_OF_CALL_SYARD_LOC ************------------------        

			FETCH cur_dep_syard_loc BULK COLLECT INTO LV_DEP_SHYARD LIMIT 10000;
     
            EXIT WHEN LV_DEP_SHYARD.count = 0;
			--FORALL i IN LV_ARRGD_POC_SYL.first..LV_ARRGD_POC_SYL.last SAVE EXCEPTIONS
			FOR I IN LV_DEP_SHYARD.first..LV_DEP_SHYARD.last
			LOOP
-------------************ SYN_ARRGD_POC_SYL is synonym of CVS_INTEGRATION.DEP_GD_PURP_OF_CALL_SYARD_LOC  ************------------------  
			BEGIN


			INSERT INTO SYN_DEPGD_SYARD_LOC
									(															
									DEP_GD_PURP_OF_CALL_SHIPYARD_LOC_ID_N,
                                                DEP_GD_PURP_OF_CALL_ID_N,
                                                SYARD_LOC_C,
                                                SYARD_LOC_DESC_X,
                                                LOCK_VER_N,
                                                DELETED_I
                                                                                    
									)
							VALUES (									
									LV_DEP_SHYARD(I).v_depgdshyrd	,
                                    LV_DEP_SHYARD(I).v_depgdpoc	,
                                    LV_DEP_SHYARD(I).v_depshyloc	,
                                    LV_DEP_SHYARD(I).v_depshydescx ,
                                    LV_DEP_SHYARD(I).v_deplockver 	,
                                    LV_DEP_SHYARD(I).v_depdeleted 
                      
                                    );
                                    
            LV_CNT_DEPGD_SHYRD_TGT :=LV_CNT_DEPGD_SHYRD_TGT+1;

			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

           pkg_datamigration_generic.proc_trace_exception('SYN_DEPGD_SYARD_LOC', 
                                                            'PROC_3_PUSH_DEPGD', 

                                    'DEP_GD_PURP_OF_CALL_SHIPYARD_LOC_ID_N:'||LV_DEP_SHYARD(I).v_depgdshyrd	||'<{||}>'||
                                    'DEP_GD_PURP_OF_CALL_ID_N:'||LV_DEP_SHYARD(I).v_depgdpoc	||'<{||}>'||
                                    'SYARD_LOC_C:'|| LV_DEP_SHYARD(I).v_depshyloc	||'<{||}>'||
                                    'SYARD_LOC_DESC_X:'|| LV_DEP_SHYARD(I).v_depshydescx	||'<{||}>'||
                                    'LOCK_VER_N:'||LV_DEP_SHYARD(I).v_deplockver	||'<{||}>'||
                                    'DELETED_I:'||LV_DEP_SHYARD(I).v_depdeleted	
                                    ,

							                                'ERROR',

						                                  	null,

							                                V_SQLERRM,
                                     LV_DEP_SHYARD(I).v_depgdshyrd	||'<{||}>'||
                                    LV_DEP_SHYARD(I).v_depgdpoc	||'<{||}>'||
                                   LV_DEP_SHYARD(I).v_depshyloc	||'<{||}>'||
                                    LV_DEP_SHYARD(I).v_depshydescx	||'<{||}>'||
                                    LV_DEP_SHYARD(I).v_deplockver	||'<{||}>'||
                                    LV_DEP_SHYARD(I).v_depdeleted	
,


							                                'T'
                                                            );

			END;

			END LOOP;


    END LOOP;
	CLOSE cur_dep_syard_loc;

    
    
    
	IF( LV_CNT_DEPGD_SHYRD_TGT =  LV_CNT_DEP_SHYRD) AND LV_CNT_DEP_SHYRD<>  0  AND  LV_CNT_DEPGD_SHYRD_TGT <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_PURP_OF_CALL_SYARD_LOC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_SHYRD_TGT||' OUT OF ' || LV_CNT_DEP_SHYRD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_PURP_OF_CALL_SYARD_LOC' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEP_SHYRD <> LV_CNT_DEPGD_SHYRD_TGT AND  LV_CNT_DEP_SHYRD<> 0 AND  LV_CNT_DEPGD_SHYRD_TGT <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_PURP_OF_CALL_SYARD_LOC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_SHYRD_TGT||' OUT OF ' || LV_CNT_DEP_SHYRD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_PURP_OF_CALL_SYARD_LOC' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEP_SHYRD <> 0 AND  LV_CNT_DEPGD_SHYRD_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_PURP_OF_CALL_SYARD_LOC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_SHYRD_TGT||' OUT OF ' || LV_CNT_DEP_SHYRD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_PURP_OF_CALL_SYARD_LOC' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

    COMMIT;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEP_GD_PURP_OF_CALL_SYARD_LOC', LV_CNT_DEP_SHYRD, 'DEP_GD_PURP_OF_CALL_SYARD_LOC', LV_CNT_DEPGD_SHYRD_TGT,'Y');

    


	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_DEPARTURE_GD', 'PROC_3_PUSH_DEPGD', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_3_PUSH_DEPGD;
/