create or replace PROCEDURE PROC_2_DEPGD_SHP_CERT(PV_RUN_ID IN NUMBER)  IS


/***********************************************************************************************************
procedure name : PROC_2_DEPGD_SHP_CERT
Created By     : R.M.KHOOL
Date           : 24-OCT-2019
Purpose        : Inserting  the data from ST_CV_VSLCERTSUBMISSN,ST_CV_VSLCERTSUBMISSNAPPLN
                 SI_DEP_GD_SHP_CERT(Intermediate table) to DEP_GD_SHP_CERT(Target Table)
Modified by    :04-NOV-2019
Modified date  :

*************************************************************************************************************/
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARING VARIABLES FOR MAIN TABLE 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

 CURSOR CUR_SI IS
    SELECT 
	DEP.APPLN_REF_N,
	CERT.CERTTY_C  ,
	CERT.ISSD_DT ,  
	CERT.DUE_DT,
	CERT.ISSAUTHYCTRY_C ,
	CERT.ISSGCL_C,
	CERT.CERTST_C,
	CERT.DEL_I  ,
	CERT.CRTON_DT,
	CERT.CRTBY_N,
	CERT.UPDON_DT,
	CERT.UPDBY_M,
	CERT.ISSGCL_M,
	CERT.PERSALLW_Q,
    DM.DOCTY_C, 
    DM.docPath_m,
    DM.doc_m

	FROM 
	ST_CV_VSLCERTSUBMISSN CERT,
	ST_CV_VSLCERTSUBMISSNAPPLN STAPPLN,
	DEPARTURE_GD_APPLICATION DEP,
	ARRIVAL_GD_APPLICATION AGD ,
	VESSEL VL,
    ST_CM_DOCMETADATA DM
    
	WHERE 
	STAPPLN.APPLNREF_N=CERT.APPLNREF_N
	AND STAPPLN.VSLRECID_N=CERT.VSLRECID_N
	AND STAPPLN.VSLRECID_N=VL.VSL_REC_ID_N
	AND STAPPLN.APPLNREF_N=DEP.EXTL_APPLN_REF_ID_X
	AND DEP.EXTL_APPLN_REF_ID_X=AGD.EXTL_APPLN_REF_ID_X
	AND AGD.MSW_VSL_ID_N=VL.MSW_VSL_ID_N
    AND  CERT.docIdAtth_n = DM.docId_n;


  CURSOR CUR_DEPGD_SHP IS

    SELECT
	APPLNREF_N	,
	CERTTY_C  	,
	ISSD_DT   	,
	DUE_DT	,
	ISSAUTHYCTRY_C ,
	ISSGCL_C	,
	CERTST_C	,
	DEL_I  ,
	CRTON_DT	,
	CRTBY_N	,
	UPDON_DT	,
	UPDBY_M	,
	ISSGCL_M	,
	PERSALLW_Q	,
    DOCTY_C,
    DOCPATH_M,
    DOC_M


    FROM
        SI_DEP_GD_SHP_CERT;         

 TYPE REC_DEPGD_SHP IS RECORD 
	(

		V_APPLNREF_N		SI_DEP_GD_SHP_CERT.APPLNREF_N%TYPE,
		V_CERTTY_C  		SI_DEP_GD_SHP_CERT.CERTTY_C%TYPE,
		V_ISSD_DT   		SI_DEP_GD_SHP_CERT.ISSD_DT%TYPE,
		V_DUE_DT			SI_DEP_GD_SHP_CERT.DUE_DT%TYPE,
		V_ISSAUTHYCTRY_C 	SI_DEP_GD_SHP_CERT.ISSAUTHYCTRY_C %TYPE,
		V_ISSGCL_C			SI_DEP_GD_SHP_CERT.ISSGCL_C%TYPE,
		V_CERTST_C			SI_DEP_GD_SHP_CERT.CERTST_C%TYPE,
		V_DEL_I  			SI_DEP_GD_SHP_CERT.DEL_I%TYPE,
		V_CRTON_DT			SI_DEP_GD_SHP_CERT.CRTON_DT%TYPE,
		V_CRTBY_N			SI_DEP_GD_SHP_CERT.CRTBY_N%TYPE,
		V_UPDON_DT			SI_DEP_GD_SHP_CERT.UPDON_DT%TYPE,
		V_UPDBY_M			SI_DEP_GD_SHP_CERT.UPDBY_M%TYPE,
		V_ISSGCL_M			SI_DEP_GD_SHP_CERT.ISSGCL_M%TYPE,
		V_PERSALLW_Q		SI_DEP_GD_SHP_CERT.PERSALLW_Q%TYPE,
        V_DOCTY_C           SI_DEP_GD_SHP_CERT.DOCTY_C%TYPE,
        V_DOCPATH_M         SI_DEP_GD_SHP_CERT.DOCPATH_M%TYPE,
        V_DOC_M             SI_DEP_GD_SHP_CERT.DOC_M%TYPE
    );

    TYPE TYPE_DEPGD_SHP IS
        TABLE OF REC_DEPGD_SHP;

    LV_DEPGD_SHP              TYPE_DEPGD_SHP;

	V_ST_COUNT             INTEGER; 
    V_SRC_COUNT            NUMBER;
    V_TGT_COUNT            NUMBER;
    V_TGT_COUNT1           NUMBER;
    V_ERR_CODE             NUMBER;
    V_ERR_MSG              VARCHAR2(2000);
    V_SQLERRM              VARCHAR2(2500);
    V_EXP_ROWS_SI          VARCHAR2(3000);
	V_EXP_ROWS         		VARCHAR2(3000);







/********OPENING THE CURSOR FOR INTERMEDIATE TABLE*******/

BEGIN         



   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 'INSERTION INTO SI_DEP_GD_SHP_CERT STARTS', 'START',
   PV_RUN_ID, NULL, NULL,'T' );



    FOR I IN CUR_SI LOOP

		BEGIN

			INSERT INTO SI_DEP_GD_SHP_CERT
                (
				APPLNREF_N,
				CERTTY_C  ,
				ISSD_DT ,  
				DUE_DT,
				ISSAUTHYCTRY_C ,
				ISSGCL_C,
				CERTST_C,
				DEL_I  ,
				CRTON_DT,
				CRTBY_N,
				UPDON_DT,
				UPDBY_M,
				ISSGCL_M,
				PERSALLW_Q,
               DOCTY_C,
               DOCPATH_M,
               DOC_M
				)
			VALUES
				(
				I.APPLN_REF_N,
				I.CERTTY_C  ,
				I.ISSD_DT ,  
				I.DUE_DT,
				I.ISSAUTHYCTRY_C ,
				I.ISSGCL_C,
				I.CERTST_C,
				I.DEL_I  ,
				I.CRTON_DT,
				I.CRTBY_N,
				I.UPDON_DT,
				I.UPDBY_M,
				I.ISSGCL_M,
				I.PERSALLW_Q,
                I.DOCTY_C,
                I.DOCPATH_M,
                I.DOC_M
				); 

			EXCEPTION
				WHEN OTHERS THEN            
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE||SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;

				V_EXP_ROWS_SI:= I.APPLN_REF_N||'<{||}>'||
								I.CERTTY_C  ||'<{||}>'||
								I.ISSD_DT   ||'<{||}>'||
								I.DUE_DT||'<{||}>'||
								I.ISSAUTHYCTRY_C ||'<{||}>'||
								I.ISSGCL_C||'<{||}>'||
								I.CERTST_C||'<{||}>'||
								I.DEL_I  ||'<{||}>'||
								I.CRTON_DT||'<{||}>'||
								I.CRTBY_N||'<{||}>'||
								I.UPDON_DT||'<{||}>'||
								I.UPDBY_M||'<{||}>'||
								I.ISSGCL_M||'<{||}>'||
								I.PERSALLW_Q||'<{||}>'||
                                I.DOCTY_C||'<{||}>'||
                                I.DOCPATH_M||'<{||}>'||
                                I.DOC_M||'<{||}>';




                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', V_ERR_MSG,
                                                                'ERROR', PV_RUN_ID, V_SQLERRM , V_EXP_ROWS_SI ,'T');


		END;                                                                                                

    END LOOP;  

  COMMIT;    






/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 

OPEN CUR_DEPGD_SHP; 

   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION ( 'DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 'DEP_GD_SHP_CERT', 'START',PV_RUN_ID,NULL,NULL,'T' );


    LOOP

            FETCH CUR_DEPGD_SHP BULK COLLECT INTO LV_DEPGD_SHP LIMIT 10000 ;
            EXIT WHEN LV_DEPGD_SHP.COUNT = 0;
            
             FOR I IN LV_DEPGD_SHP.first..LV_DEPGD_SHP.last
			LOOP

            BEGIN

            BEGIN
			INSERT INTO DEP_GD_SHP_CERT
								(   ID,
									APPLN_REF_N,
									CERT_TY_C,
									ISS_DT,
									DUE_DT,
									ISS_AUTHY_CTRY_C,
									ISSG_CL_C,
									ST_C,
									DELETED_I,
									LOCK_VER_N,
									CRT_ON_DT,
									CRT_BY_N,
									LST_UPD_ON_DT,
									LST_UPD_BY_N,
									ISSG_CL_DESC_X,
									NO_PERS_ALLW_Q
								) 
						VALUES (	SEQ_DEPGD_SHPCERT.NEXTVAL,						
									LV_DEPGD_SHP(I).V_APPLNREF_N, 
									DECODE (LV_DEPGD_SHP(I).V_CERTTY_C ,'BLD','Builder''s Certificate','COR','Certificate of Registry','ITC','ITC69','LLC','LOADLINE/FREEBOARD','PSC','PASSENGER SAFETY',
									'SEC','SAFETY EQUIPMENT','SRC','SAFETY RADIO','SCC','SAFETY CONSTRUCTION','COF','CERT OF FITNESS','IOP','IOPP','ISP','INTERNATIONAL SEWAGE (ISPP)',
									'ORD','ORDER ON A DRUGGIST','COI','CERT OF INSURANCE','DOC','DOCUMENT OF COMPLIANCE','SMC','SAFETY MANAGEMENT','CLC','CLC92','ISS','INTERNATIONAL SHIP SECURITY',
									'IAP','INTL AIR POLLUTION PREVENTION','BCC','BUNKER CONVENTION CERT','3RD','CERT OF INSURANCE 3RD PARTY','COD','CERT OF CONDITION','COL','LIFTING APPLIANCES TEST',
									'BLDL','Builder Supporting Document') ,
									LV_DEPGD_SHP(I).V_ISSD_DT   ,     
									LV_DEPGD_SHP(I).V_DUE_DT   , 
									LV_DEPGD_SHP(I).V_ISSAUTHYCTRY_C   , 
									LV_DEPGD_SHP(I).V_ISSGCL_C   , 
									DECODE(LV_DEPGD_SHP(I).V_CERTST_C ,'1','Active','2','Inactive','3','Suspended','Active')  , --if null then set value to 1
									DECODE(LV_DEPGD_SHP(I).V_DEL_I,'Y',1,0)     ,
									0,
									SYSDATE,--NVL(LV_DEPGD_SHP(I).V_CRTON_DT ,SYSDATE),
									'DATA MIGRATION',--NVL(LV_DEPGD_SHP(I).V_CRTBY_N ,'Data Migration'),
									SYSDATE,--LV_DEPGD_SHP(I).V_UPDON_DT   , 
									'DATA MIGRATION',--LV_DEPGD_SHP(I).V_UPDBY_M   , 
									LV_DEPGD_SHP(I).V_ISSGCL_M   , 
									LV_DEPGD_SHP(I).V_PERSALLW_Q   
								);  

			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
			V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
			V_SQLERRM := V_ERR_CODE	 || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

			V_EXP_ROWS :=	' ID: '||SEQ_DEPGD_SHPCERT.CURRVAL||
							' APPLN_REF_N: '||LV_DEPGD_SHP(I).V_APPLNREF_N||
							' CERT_TY_C: '||LV_DEPGD_SHP(I).V_CERTTY_C||
							' ISS_DT: '||LV_DEPGD_SHP(I).V_ISSD_DT ||
							' DUE_DT: '||LV_DEPGD_SHP(I).V_DUE_DT ||
							' ISS_AUTHY_CTRY_C: '||LV_DEPGD_SHP(I).V_ISSAUTHYCTRY_C ||
							' ISSG_CL_C: '||LV_DEPGD_SHP(I).V_ISSGCL_C ||
							' ST_C: '||NVL(LV_DEPGD_SHP(I).V_CERTST_C ,'1')||
							' DELETED_I: '||NVL(LV_DEPGD_SHP(I).V_DEL_I,0) ||
							' LOCK_VER_N: '||0||
							' CRT_ON_DT: '||SYSDATE||
							' CRT_BY_N: '||'DATA MIGRATION'||
							' LST_UPD_ON_DT: '||SYSDATE||
							' LST_UPD_BY_N: '||'DATA MIGRATION'||
							' ISSG_CL_DESC_X: '||LV_DEPGD_SHP(I).V_ISSGCL_M ||
							' NO_PERS_ALLW_Q: '||LV_DEPGD_SHP(I).V_PERSALLW_Q ;


                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 
				   DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR', PV_RUN_ID, V_SQLERRM,V_EXP_ROWS, 'T'                                                                                                                    
                         );
                CONTINUE;   
            END;   
            
            /* INSERT INTO GD_DOC*/
            
                    BEGIN
                    insert into GD_DOC( ID,
                                        GD_SHIP_CERTIFICATE_ID,
                                        DOC_TY_C,
                                        DOC_ID_N,
                                        SFTP_PATH_X,
                                        FILE_M,
                                        MIMI_TY_C,
                                        DELETED_I
                                        )
                                VALUES(
                                        SEQ_GD_DOC.NEXTVAL,
                                        SEQ_DEPGD_SHPCERT.CURRVAL,
                                        'DEP_SHIP_CERT',
                                        NULL,
                                        LV_DEPGD_SHP(I).V_DOCPATH_M,
                                        LV_DEPGD_SHP(I).V_DOC_M,
                                        LV_DEPGD_SHP(I).V_DOCTY_C,
                                        0
                                        );
                    EXCEPTION
                    WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := V_ERR_CODE	 || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;
        
                    V_EXP_ROWS :=	' ID: '||SEQ_GD_DOC.CURRVAL||
                                    ' GD_SHIP_CERTIFICATE_ID: '||SEQ_DEPGD_SHPCERT.CURRVAL||
                                    ' DOC_TY_C: '||'DEP_SHIP_CERT'||
                                    ' SFTP_PATH_X: '||LV_DEPGD_SHP(I).V_DOCPATH_M ||
                                    ' FILE_M: '||LV_DEPGD_SHP(I).V_DOC_M ||
                                    ' MIMI_TY_C: '||LV_DEPGD_SHP(I).V_DOCTY_C||
                                    ' DELETED_I: '|| '0' ;
        
        
                           PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_DOC', 'PROC_2_DEPGD_SHP_CERT', 
                           DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR', PV_RUN_ID, V_SQLERRM,V_EXP_ROWS, 'T');
                    
                    END;


			END;	

			END LOOP;

		COMMIT;

	END LOOP;

  CLOSE CUR_DEPGD_SHP;





--------COUNT OF STAGING TABLE

    SELECT COUNT(*)
    INTO V_ST_COUNT
    FROM 	
	ST_CV_VSLCERTSUBMISSN CERT,
	ST_CV_VSLCERTSUBMISSNAPPLN STAPPLN,
	DEPARTURE_GD_APPLICATION DEP,
	ARRIVAL_GD_APPLICATION AGD ,
	VESSEL VL
	WHERE 
	STAPPLN.APPLNREF_N=CERT.APPLNREF_N
	AND STAPPLN.VSLRECID_N=CERT.VSLRECID_N
	AND STAPPLN.VSLRECID_N=VL.VSL_REC_ID_N
	AND STAPPLN.APPLNREF_N=DEP.EXTL_APPLN_REF_ID_X
	AND DEP.EXTL_APPLN_REF_ID_X=AGD.EXTL_APPLN_REF_ID_X
	AND AGD.MSW_VSL_ID_N=VL.MSW_VSL_ID_N;



---COUNT OF INTERMEDIATE TABLE   

    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM SI_DEP_GD_SHP_CERT;

----COUNT OF TARGRT TABLE           

    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM DEP_GD_SHP_CERT; 
    
    SELECT COUNT(*)
    INTO V_TGT_COUNT1
    FROM GD_DOC;




----DEP_GD_SHP_CERT


	IF (V_TGT_COUNT =  V_SRC_COUNT) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 
        V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO DEP_GD_SHP_CERT TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

	ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 
        V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||'ROWS  HAVE BEEN INSERTED INTO DEP_GD_SHP_CERT TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


	ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', 
       V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO DEP_GD_SHP_CERT TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');
    END IF;


	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_VSLCERTSUBMISSN', V_ST_COUNT, 'SI_DEP_GD_SHP_CERT', V_SRC_COUNT,'Y');	

	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_DEP_GD_SHP_CERT', V_SRC_COUNT, 'DEP_GD_SHP_CERT', V_TGT_COUNT,'Y');
    
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_DEP_GD_SHP_CERT', V_SRC_COUNT, 'GD_DOC', V_TGT_COUNT1,'Y');

EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)
                     || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_SHP_CERT', 'PROC_2_DEPGD_SHP_CERT', V_SQLERRM, 'ERROR',PV_RUN_ID,NULL,NULL,'T');
END;
/