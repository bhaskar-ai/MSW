create or replace PROCEDURE PROC_1_VSL_CERT_FOR(P_count  out number,
                                                PV_RUN_ID IN NUMBER) IS

  
/***********************************************************************************************************
Declaring variables for Main table 
*************************************************************************************************************/
CURSOR CUR_ST_CV_VSLCERT IS
	SELECT
        V.MSW_VSL_ID_N,
        VC.CERTTY_C,
        VC.ISSAUTHYCTRY_C,
        VC.ISSGCL_C,
        VC.ISSD_DT,
        VC.DUE_DT,
        VC.DOCIDATTH_N,
        VC.CERTST_C,
        VC.ISSGCL_M,
        VC.CRTON_DT,
        VC.CRTBY_N,
        VC.UPDON_DT,
        VC.UPDBY_N,
	    VC.LASTAPPRBY_M,
        VC.INTLREM_X,
        VC.ISSDBY_C,
        VC.LASTAPPRBY_N,
        VC.CRTBY_M,
        VC.CRTBYDEPT_M,
        VC.UPDBY_M,
        VC.UPDBYDEPT_M,
        VC.INSURTY_C,
        VC.INSURVALTILL_DT,
        CMO.DOC_M,
        CMO.DOCTY_C,
        CMO.DOCPATH_M

    FROM
        ST_CV_VSLCERT VC , VESSEL V , ST_CM_DOCMETADATA CMO
    WHERE
         VC.VSLRECID_N=V.VSL_REC_ID_N 
         AND VC.DOCIDATTH_N = CMO.DOCID_N(+);




-- defining the 'record type'  type to serve as the datatype of collection variable  of main table 

    TYPE REC_VSLCRT_M IS RECORD 
	(
		V_M_VSLRECID_N          VESSEL.MSW_VSL_ID_N%TYPE ,
        V_M_CERTTY_C          ST_CV_VSLCERT.CERTTY_C%TYPE ,
        V_M_ISSAUTHYCTRY       ST_CV_VSLCERT.ISSAUTHYCTRY_C%TYPE ,
        V_M_ISSGCL_C           ST_CV_VSLCERT.ISSGCL_C%TYPE ,
        V_M_ISSD_DT            ST_CV_VSLCERT.ISSD_DT%TYPE ,
        V_M_DUE_DT             ST_CV_VSLCERT.DUE_DT%TYPE ,
        V_M_DOCIDATTH_N        ST_CV_VSLCERT.DOCIDATTH_N%TYPE ,
        V_M_CERTST_C           ST_CV_VSLCERT.CERTST_C%TYPE ,
        V_M_ISSGCL_M           ST_CV_VSLCERT.ISSGCL_M%TYPE, 
        V_M_CRTON_DT           ST_CV_VSLCERT.CRTON_DT%TYPE,
        V_M_CRTBY_N            ST_CV_VSLCERT.CRTBY_N%TYPE,
        V_M_UPDON_DT           ST_CV_VSLCERT.UPDON_DT%TYPE,
        V_M_UPDBY_N            ST_CV_VSLCERT.UPDBY_N%TYPE,
	    V_M_LASTAPPRBY_M       ST_CV_VSLCERT.LASTAPPRBY_M%TYPE,
        V_M_INTLREM_X          ST_CV_VSLCERT.INTLREM_X%TYPE,
		V_M_ISSDBY_C			ST_CV_VSLCERT.ISSDBY_C%TYPE,
		V_M_LASTAPPRBY_N		ST_CV_VSLCERT.LASTAPPRBY_N%TYPE,
		V_M_CRTBY_M				ST_CV_VSLCERT.CRTBY_M%TYPE,
		V_M_CRTBYDEPT_M			ST_CV_VSLCERT.CRTBYDEPT_M%TYPE,
		V_M_UPDBY_M				ST_CV_VSLCERT.UPDBY_M%TYPE,
		V_M_UPDBYDEPT_M			ST_CV_VSLCERT.UPDBYDEPT_M%TYPE,
		V_M_INSURTY_C			ST_CV_VSLCERT.INSURTY_C%TYPE,
		V_M_INSURVALTILL_DT		ST_CV_VSLCERT.INSURVALTILL_DT%TYPE,
		V_M_DOC_M				ST_CM_DOCMETADATA.DOC_M%TYPE,
		V_M_DOCTY_C				ST_CM_DOCMETADATA.DOCTY_C%TYPE,
		V_M_DOCPATH_M			ST_CM_DOCMETADATA.DOCPATH_M%TYPE

    );




    TYPE TYPE_VSLCRT_M IS TABLE OF REC_VSLCRT_M;
    LV_M_VSL_CERT        TYPE_VSLCRT_M;




/***********************************************************************************************************
Declaring variables for intermeduiate table 
*************************************************************************************************************/

    CURSOR CUR_VESSEL_CERTIFICATE IS
    SELECT
        MSW_VSL_ID_N,
        CERTTY_C,
        ISSAUTHYCTRY_C,
        ISSGCL_C,
        ISSD_DT,
        DUE_DT,
        DOCIDATTH_N,
        CERTST_C,
        ISSGCL_M,
        CRTON_DT,
        CRTBY_N,
        UPDON_DT,
        UPDBY_N,
        LASTAPPRBY_M,
        INTLREM_X,
		ISSDBY_C,
		LST_APPR_BY_N,
		CRTBY_M,
		CRTBYDEPT_M,
		UPDBY_M,
		UPDBYDEPT_M,
		INSURTY_C,
		INSURVALTILL_DT,
		FILE_M,
		MIME_TY_C,
		SFTP_PATH_X
    FROM
        SI_CV_VSLCERT;

  -- defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table 

    TYPE REC_VSLCRT IS RECORD (
        V_VSLRECID_N       SI_CV_VSLCERT.MSW_VSL_ID_N%TYPE,   
        V_CERTTY_C         SI_CV_VSLCERT.CERTTY_C%TYPE,   
        V_ISSAUTHYCTRY_C   SI_CV_VSLCERT.ISSAUTHYCTRY_C%TYPE,   
        V_ISSGCL_C         SI_CV_VSLCERT.ISSGCL_C%TYPE,   
        V_ISSD_DT          SI_CV_VSLCERT.ISSD_DT%TYPE,   
        V_DUE_DT           SI_CV_VSLCERT.DUE_DT%TYPE,   
        V_DOCIDATTH_N      SI_CV_VSLCERT.DOCIDATTH_N%TYPE,   
        V_CERTST_C         SI_CV_VSLCERT.CERTST_C%TYPE,   
        V_ISSGCL_M         SI_CV_VSLCERT.ISSGCL_M%TYPE,
        V_CRTON_DT         SI_CV_VSLCERT.CRTON_DT%TYPE,
        V_CRTBY_N          SI_CV_VSLCERT.CRTBY_N%TYPE,
        V_UPDON_DT         SI_CV_VSLCERT.UPDON_DT%TYPE,
        V_UPDBY_N          SI_CV_VSLCERT.UPDBY_N%TYPE,
        V_LASTAPPRBY_M     SI_CV_VSLCERT.LASTAPPRBY_M%TYPE,
        V_INTLREM_X        SI_CV_VSLCERT.INTLREM_X%TYPE,
		V_ISSDBY_C			SI_CV_VSLCERT.ISSDBY_C%TYPE,
		V_LST_APPR_BY_N		SI_CV_VSLCERT.LST_APPR_BY_N%TYPE,
		V_CRTBY_M			SI_CV_VSLCERT.CRTBY_M%TYPE,
		V_CRTBYDEPT_M		SI_CV_VSLCERT.CRTBYDEPT_M%TYPE,
		V_UPDBY_M			SI_CV_VSLCERT.UPDBY_M%TYPE,
		V_UPDBYDEPT_M		SI_CV_VSLCERT.UPDBYDEPT_M%TYPE,
		V_INSURTY_C			SI_CV_VSLCERT.INSURTY_C%TYPE,
		V_INSURVALTILL_DT	SI_CV_VSLCERT.INSURVALTILL_DT%TYPE,
		V_FILE_M			SI_CV_VSLCERT.FILE_M%TYPE,
		V_MIME_TY_C			SI_CV_VSLCERT.MIME_TY_C%TYPE,
		V_SFTP_PATH_X		SI_CV_VSLCERT.SFTP_PATH_X%TYPE
    );

    --assigning the record type data to colelction variable for intermeditae table 
    TYPE TYPE_VSLCRT IS
	TABLE OF REC_VSLCRT;

    LV_VSL_CERT        TYPE_VSLCRT;


	V_M_SRC_COUNT        NUMBER;
    V_M_TGT_COUNT        NUMBER;
    V_M_ERR_CODE         NUMBER;
    V_M_ERR_MSG          VARCHAR2(200);
    V_M_SQLERRM          VARCHAR2(2500);


    V_SRC_COUNT       INTEGER;
    V_TGT_COUNT       INTEGER;
    V_ERR_CODE        NUMBER;
    V_ERR_MSG         VARCHAR2(2000);
    V_SQLERRM         VARCHAR2(2500);
    V_EXP_ROW     	  VARCHAR2(2000);

BEGIN 

/***********************************************************************************************************
procedure name : proc_1_vsl_cert
Created By     : C.N.Bhaskar
Date           : 26-mar-2019
Purpose        : Inserting  the data from ST_CV_vslCert (main table) to SI_CV_vslCert(Intermediate table) to VESSEL_CERTIFICATE(Target Table)
Modified by    :Bhaskar, Rohit
Modified date  :19-APR-19 (Mapping sheet change), 04-SEP-2019, 10-OCT-2019.

*************************************************************************************************************/


/***********************************************************************************************************
INSERTING DATA FROM MAIN TABLE INTO INTERMEDIATE TABLE
*************************************************************************************************************/


   --opening the cursor cur_ST_CV_vslCert to initiate the process of migrating the data from main table into intermediate table 

    OPEN cur_ST_CV_vslCert;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 'PROC_1_VSL_CERT_FOR','INSERTION INTO SI_VSL_CERT STARTS' ,'START',
                                                      PV_RUN_ID,
                                                      NULL,
                                                      NULL,
                                                      'T');

		LOOP


   --loading the data of cursor into the collection variable in the batches of the value specified in limit
            FETCH CUR_ST_CV_VSLCERT BULK COLLECT INTO LV_M_VSL_CERT LIMIT 5000;
			EXIT WHEN LV_M_VSL_CERT.COUNT = 0;

   -- inserting the data from the collection variable into the intermediate table in the batche value specified in limit     
                FOR I IN LV_M_VSL_CERT.FIRST..LV_M_VSL_CERT.LAST 
                LOOP

                    BEGIN

                        INSERT INTO SI_CV_VSLCERT  (MSW_VSL_ID_N,
                                                    CERTTY_C,
                                                    ISSAUTHYCTRY_C,
                                                    ISSGCL_C,
                                                    ISSD_DT,
                                                    DUE_DT,
                                                    DOCIDATTH_N,
                                                    CERTST_C,
                                                    ISSGCL_M,
                                                    CRTON_DT,
                                                    CRTBY_N,
                                                    UPDON_DT,
                                                    UPDBY_N,
                                                    LASTAPPRBY_M,
                                                    INTLREM_X,
													ISSDBY_C,
													LST_APPR_BY_N,
													CRTBY_M,
													CRTBYDEPT_M,
													UPDBY_M,
													UPDBYDEPT_M,
													INSURTY_C,
													INSURVALTILL_DT,
													FILE_M,
													MIME_TY_C,
													SFTP_PATH_X
                                                    ) 
										   VALUES 	(LV_M_VSL_CERT(I).V_M_VSLRECID_N,
													LV_M_VSL_CERT(I).V_M_CERTTY_C,
													LV_M_VSL_CERT(I).V_M_ISSAUTHYCTRY,
													LV_M_VSL_CERT(I).V_M_ISSGCL_C,
													LV_M_VSL_CERT(I).V_M_ISSD_DT,
													LV_M_VSL_CERT(I).V_M_DUE_DT,
													LV_M_VSL_CERT(I).V_M_DOCIDATTH_N,
													LV_M_VSL_CERT(I).V_M_CERTST_C,
													LV_M_VSL_CERT(I).V_M_ISSGCL_M,
													LV_M_VSL_CERT(I).V_M_CRTON_DT,
													LV_M_VSL_CERT(I).V_M_CRTBY_N,
													LV_M_VSL_CERT(I).V_M_UPDON_DT,
													LV_M_VSL_CERT(I).V_M_UPDBY_N,
													LV_M_VSL_CERT(I).V_M_LASTAPPRBY_M,
													LV_M_VSL_CERT(I).V_M_INTLREM_X,
													LV_M_VSL_CERT(I).v_m_issdBy_c,	
													LV_M_VSL_CERT(I).V_M_LASTAPPRBY_N,	
													LV_M_VSL_CERT(I).V_M_CRTBY_M,			
													LV_M_VSL_CERT(I).V_M_CRTBYDEPT_M,	
													LV_M_VSL_CERT(I).V_M_UPDBY_M,			
													LV_M_VSL_CERT(I).V_M_UPDBYDEPT_M,		
													LV_M_VSL_CERT(I).V_M_INSURTY_C,		
													LV_M_VSL_CERT(I).V_M_INSURVALTILL_DT,
													LV_M_VSL_CERT(I).V_M_DOC_M,		
													LV_M_VSL_CERT(I).V_M_DOCTY_C,			
													LV_M_VSL_CERT(I).V_M_DOCPATH_M
												   );


    -- defining the inner exception to prevent the control breaking out of loop abruptly in case of failure 
					  EXCEPTION

						 WHEN OTHERS THEN


							V_M_ERR_CODE := SQLCODE;

							V_M_ERR_MSG := SUBSTR(SQLERRM, 1, 200);

							V_M_SQLERRM := V_M_ERR_CODE || V_M_ERR_MSG;





		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                    'PROC_1_VSL_CERT_FOR',
													' MSW_VSL_ID_N: '||LV_M_VSL_CERT(I).V_M_VSLRECID_N||
													' CERTTY_C: '||LV_M_VSL_CERT(I).V_M_CERTTY_C||
													' ISSAUTHYCTRY_C: '||LV_M_VSL_CERT(I).V_M_ISSAUTHYCTRY||
													' ISSGCL_C: '||LV_M_VSL_CERT(I).V_M_ISSGCL_C||
                                                    ' ISSD_DT: '||LV_M_VSL_CERT(I).V_M_ISSD_DT||
													' DUE_DT: '||LV_M_VSL_CERT(I).V_M_DUE_DT||
													' DOCIDATTH_N: '||LV_M_VSL_CERT(I).V_M_DOCIDATTH_N||
													' CERTST_C: '||LV_M_VSL_CERT(I).V_M_CERTST_C||
													' ISSGCL_M: '||LV_M_VSL_CERT(I).V_M_ISSGCL_M||
													' CRTON_DT: '||LV_M_VSL_CERT(I).V_M_CRTON_DT||
													' CRTBY_M: '||LV_M_VSL_CERT(I).V_M_CRTBY_N||
													' UPDON_DT: '||LV_M_VSL_CERT(I).V_M_UPDON_DT||
													' UPDBY_M: '||LV_M_VSL_CERT(I).V_M_UPDBY_N||
													' LASTAPPRBY_M: '||LV_M_VSL_CERT(I).V_M_LASTAPPRBY_M||
													' INTLREM_X: '||LV_M_VSL_CERT(I).V_M_INTLREM_X||
													' ISSDBY_C: '||LV_M_VSL_CERT(I).v_m_issdBy_c||
													' LST_APPR_BY_N: '||LV_M_VSL_CERT(I).V_M_LASTAPPRBY_N||
													' CRTBY_M: '||LV_M_VSL_CERT(I).V_M_CRTBY_M||
													' CRTBYDEPT_M: '||LV_M_VSL_CERT(I).V_M_CRTBYDEPT_M||
													' UPDBY_M: '||LV_M_VSL_CERT(I).V_M_UPDBY_M||
													' UPDBYDEPT_M: '||LV_M_VSL_CERT(I).V_M_UPDBYDEPT_M||
													' INSURTY_C: '||LV_M_VSL_CERT(I).V_M_INSURTY_C||
													' INSURVALTILL_DT: '||LV_M_VSL_CERT(I).V_M_INSURVALTILL_DT||
													' FILE_M: '||LV_M_VSL_CERT(I).V_M_DOC_M||
													' MIME_TY_C: '||LV_M_VSL_CERT(I).V_M_DOCTY_C||
													' SFTP_PATH_X: '||LV_M_VSL_CERT(I).V_M_DOCPATH_M,
                                                    ' ERROR',
                                                    PV_RUN_ID,
                                                    V_M_SQLERRM, 
                                                    LV_M_VSL_CERT(I).V_M_VSLRECID_N||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CERTTY_C||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_ISSAUTHYCTRY||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_ISSGCL_C||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_ISSD_DT||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_DUE_DT||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_DOCIDATTH_N||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CERTST_C||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_ISSGCL_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CRTON_DT||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CRTBY_N||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_UPDON_DT||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_UPDBY_N||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_LASTAPPRBY_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_INTLREM_X||'<{||}>'||
													LV_M_VSL_CERT(I).v_m_issdBy_c||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_LASTAPPRBY_N||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CRTBY_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_CRTBYDEPT_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_UPDBY_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_UPDBYDEPT_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_INSURTY_C||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_INSURVALTILL_DT||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_DOC_M||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_DOCTY_C||'<{||}>'||
													LV_M_VSL_CERT(I).V_M_DOCPATH_M||'<{||}>'
													,
                                                    'B');



					END; -- INNER BEGIN
 --FIND THE COUNT OF MAIN TABLE(SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF INTERMEDIATE TABLE FOR RECONCIALATION PURPOSE
				END LOOP;  -- FOR LOOP


        END LOOP;-- CURSOR

        COMMIT;

    CLOSE CUR_ST_CV_VSLCERT;



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel starts 
*************************************************************************************************************/

/* --Commented by Rohit Khool

begin 

for i in (
select 
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT		       
from ST_CV_vslCert 
where vslRecID_n not in (  select VSL_REC_ID_N from vessel)

)  
loop


 pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE', 
                                                'PROC_1_VSL_CERT_FOR',
                                                'UNCOMMON RECORDS  of ST_CV_vslCert because of JOIN CONDITION FAILURE between ST_CV_vslCert AND VESSEL ',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                   i.CERTTY_C	||'*|'|| i.VSLRECID_N	||'*|'|| i.ISSD_DT	||'*|'||  i.DUE_DT	||'*|'||   i.REGST_C	||'*|'|| i.ISSDBY_C	||'*|'|| 
                                                   i.ISSAUTHYCTRY_C	||'*|'|| i.ISSGCL_C	||'*|'|| i.PERSALLW_Q	||'*|'|| i.SOPEPSMPEPONBD_I	||'*|'|| i.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   i.INCOMPLYMARPOLREGU21_I	||'*|'|| i.BCCAPPLN_N	||'*|'|| 
                                                   i.BCCAPPLNST_C	||'*|'|| i.BCCISSD_DT	||'*|'|| i.INSURTY_C	||'*|'|| i.INSURVALTILL_DT	||'*|'|| i.DOCIDATTH_N	||'*|'|| 
                                                   i.CERTST_C	||'*|'||i.LASTAPPRBY_N	||'*|'|| i.LASTAPPRBY_M	||'*|'|| i.CRTBY_N	||'*|'|| i.CRTBY_M	||'*|'|| i.CRTBYDEPT_M	||'*|'||
                                                   i.CRTON_DT	||'*|'|| i.UPDBY_N	||'*|'|| i.UPDBY_M	||'*|'|| i.UPDBYDEPT_M	||'*|'|| i.UPDON_DT	||'*|'|| i.INTLREM_X	||'*|'|| 
                                                   i.ISSGCL_M	||'*|'|| i.INCOMPLYMARPOLREGU20_DT	||'*|'|| i.INCOMPLYMARPOLREGU21_DT    ,
                                               'D');



end loop;


exception  when others then null;
end;




/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel ends 
*************************************************************************************************************/



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN vessel  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel starts 
*************************************************************************************************************/



/*





begin
for i  in (
select 
MSW_VSL_ID_N	,
VSL_REC_ID_N	,
VSL_M	,
OFFICIAL_N	,
VSL_FLAG_C	,
VSL_TYPE_ID_N	,
CRAFT_TYPE_ID_N	,
VSL_DWT_N	,
ST_C	,
VSL_CRAFT_LIC_N	,
VSL_ATTAINABLE_HGT_Q	,
VSL_YR_BLT_N	,
PORT_OF_REGY_C	,
PORT_N	,
VSL_LEN_Q	,
LOA_Q	,
VSL_DEPTH_Q	,
VSL_BRE_Q	,
MECHANIC_PROPEL_I	,
VSL_MMSI_N	,
LOCK_VER_N	,
CRT_ON_DT	,
CRT_BY_X	,
UPT_ON_DT	,
UPT_BY_X	,
VSL_GT_Q	,
VSL_NT_Q	,
VSL_CALL_SIGN_N	,
VSL_IMO_N	,
VSL_OWNR	,
DELETED_I	,
DELIVERY_DT	,
BOW_BRIDGE	,
BOW_THRUSTER	,
STERN_THRUSTER	,
DBL_HULL_CONSTRUCT_I	,
APPR_FOR_SEA_TRIAL_I	,
LAUNCH_ON_DT	,
MERGE_FR_TO_VSL_REC_ID	,
BARTER_TRADE_I	,
BARE_BOAT_CHARTER_OUT_I	,
TRANSIT_I	,
UNOFFICIAL_VSL_M	,
UNOFFCIAL_VSL_CALL_SIGN	,
UNOFFICIAL_VSL_TY_C	,
UNOFFICIAL_VSL_FLAG_C	,
UNOFFICIAL_VSL_GT	,
GT_FROM_E_PAN_Q	,
GT_FROM_E_PAN_DT	,
BUILDER_M	,
OWNER_CTRY_C	,
VSL_BUILT_PLACE_C	

FROM VESSEL   WHERE VSL_REC_ID_N NOT IN  (SELECT  VSLRECID_N  FROM  ST_CV_VSLCERT))


LOOP

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                'PROC_1_VSL_CERT_FOR',
                                                'UNCOMMON RECORDS  of VESSEL because of JOIN CONDITION FAILURE between ST_CV_vslCert AND VESSEL ',
                                                null,
                                                PV_RUN_ID,
                                                null,
                                                i.MSW_VSL_ID_N	||'*|'||
												i.VSL_REC_ID_N	||'*|'||
												i.VSL_M	||'*|'||
												i.OFFICIAL_N	||'*|'||
												i.VSL_FLAG_C	||'*|'||
												i.VSL_TYPE_ID_N	||'*|'||
												i.CRAFT_TYPE_ID_N	||'*|'||
												i.VSL_DWT_N	||'*|'||
												i.ST_C	||'*|'||
												i.VSL_CRAFT_LIC_N	||'*|'||
												i.VSL_ATTAINABLE_HGT_Q	||'*|'||
												i.VSL_YR_BLT_N	||'*|'||
												i.PORT_OF_REGY_C	||'*|'||
												i.PORT_N	||'*|'||
												i.VSL_LEN_Q	||'*|'||
												i.LOA_Q	||'*|'||
												i.VSL_DEPTH_Q	||'*|'||
												i.VSL_BRE_Q	||'*|'||
												i.MECHANIC_PROPEL_I	||'*|'||
												i.VSL_MMSI_N	||'*|'||
												i.LOCK_VER_N	||'*|'||
												i.CRT_ON_DT	||'*|'||
												i.CRT_BY_X	||'*|'||
												i.UPT_ON_DT	||'*|'||
												i.UPT_BY_X	||'*|'||
												i.VSL_GT_Q	||'*|'||
												i.VSL_NT_Q	||'*|'||
												i.VSL_CALL_SIGN_N	||'*|'||
												i.VSL_IMO_N	||'*|'||
												i.VSL_OWNR	||'*|'||
												i.DELETED_I	||'*|'||
												i.DELIVERY_DT	||'*|'||
												i.BOW_BRIDGE	||'*|'||
												i.BOW_THRUSTER	||'*|'||
												i.STERN_THRUSTER	||'*|'||
												i.DBL_HULL_CONSTRUCT_I	||'*|'||
												i.APPR_FOR_SEA_TRIAL_I	||'*|'||
												i.LAUNCH_ON_DT	||'*|'||
												i.MERGE_FR_TO_VSL_REC_ID	||'*|'||
												i.BARTER_TRADE_I	||'*|'||
												i.BARE_BOAT_CHARTER_OUT_I	||'*|'||
												i.TRANSIT_I	||'*|'||
												i.UNOFFICIAL_VSL_M	||'*|'||
												i.UNOFFCIAL_VSL_CALL_SIGN	||'*|'||
												i.UNOFFICIAL_VSL_TY_C	||'*|'||
												i.UNOFFICIAL_VSL_FLAG_C	||'*|'||
												i.UNOFFICIAL_VSL_GT	||'*|'||
												i.GT_FROM_E_PAN_Q	||'*|'||
												i.GT_FROM_E_PAN_DT	||'*|'||
												i.BUILDER_M	||'*|'||
												i.OWNER_CTRY_C	||'*|'||
												i.VSL_BUILT_PLACE_C	   ,
												'D');



END LOOP;




EXCEPTION

 WHEN OTHERS  THEN NULL;

END;



/***********************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN vessel  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel ends 
*************************************************************************************************************/








 /*********************************************************************************************************************
RECORDING THE UNCOMMON  RECORS IN ST_CV_vslCert  table due to JOIN FAILURE BETWEEN ST_CV_vslCert and vessel   ENDS
***********************************************************************************************************************/

      --Reconcialation  
        SELECT COUNT(*)
        INTO V_M_SRC_COUNT
        FROM ST_CV_VSLCERT;


        SELECT COUNT(*)
        INTO V_M_TGT_COUNT
        FROM SI_CV_VSLCERT;



        PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_VSLCERT', V_M_SRC_COUNT, 'SI_CV_VSLCERT', V_M_TGT_COUNT,'N');



        IF (V_M_TGT_COUNT =  V_M_SRC_COUNT ) AND V_M_SRC_COUNT <>  0  AND V_M_TGT_COUNT <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                        'PROC_1_VSL_CERT_FOR', 
                                                        V_M_TGT_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_CV_VSLCERT TABLE' ,
                                                        'SUCCESS',
                                                        NULL,
                                                        NULL,
                                                        NULL,
                                                        NULL);

        ELSIF V_M_TGT_COUNT  <> V_M_SRC_COUNT AND V_M_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                      'PROC_1_VSL_CERT_FOR', 
                                                      V_M_TGT_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_CV_VSLCERT TABLE' ,
                                                           'PARTIALLY SUCCESSFULL',
                                                           NULL,
                                                              NULL,
                                                                NULL,
                                                                NULL);


		ELSIF (V_M_TGT_COUNT  <> V_M_SRC_COUNT OR V_M_TGT_COUNT  = V_M_SRC_COUNT ) AND (V_M_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
        'PROC_1_VSL_CERT_FOR', 
		V_M_TGT_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_CV_VSLCERT TABLE' ,
        'FAIL',
        NULL,
        NULL,
        NULL,
        NULL);

        ELSE 

     PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                    'PROC_1_VSL_CERT_FOR', 
                                                     V_M_TGT_COUNT ||' OUT OF ' ||V_M_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE TABLE' ,
                                                     'AMBIGIOUS',
                                                         NULL,
                                                           NULL,
                                                              NULL,
                                                                 NULL);

		END IF;



   --opening the cursor cur_vessel_certificate to initiate the process of migrating the data from intermediate table into target table 

/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/

    OPEN CUR_VESSEL_CERTIFICATE;

           PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                          'PROC_1_VSL_CERT_FOR',
                                                          ' INSERTION INTO VESSEL_CERTIFICATE STARTS ' ,
                                                          'START',   
                                                          PV_RUN_ID,
                                                          NULL,
                                                          NULL,
                                                          'T');

       loop


   --loading the data of cursor into the collection variable in the batches of the value specified in limit
         --  v_sq_vslCrtId := seq_vsl_cert.nextval;

            FETCH CUR_VESSEL_CERTIFICATE BULK COLLECT INTO LV_VSL_CERT LIMIT 5000;
			EXIT WHEN LV_VSL_CERT.COUNT = 0;

   -- inserting the data from the collection variable into the target table in the batches of the value specified in limit     
                 FOR I IN LV_VSL_CERT.FIRST..LV_VSL_CERT.LAST 
                  LOOP

                    BEGIN


                       INSERT INTO VESSEL_CERTIFICATE ( VSL_CERT_ID_N,
                                                        MSW_VSL_ID_N,
                                                        MSW_DOC_ID,
                                                        CERT_TY_C,
                                                        ISS_AUTHY_CTRY_C,
                                                        ISSG_CL_C,
                                                        ISSD_DT,
                                                        DUE_DT,
                                                      --  DOC_ID_ATTH_N,
                                                        ST_C ,
                                                        ISSG_CL_M   ,
                                                        LOCK_VER_N  ,
                                                        CRT_ON_DT   ,
                                                        CRT_BY_X    ,
                                                        UPT_ON_DT,
                                                        UPT_BY_X,
                                                        DELETED_I,
                                                        LAST_APPROVED_BY_M,
                                                        INTL_REM_X,
														ISSDBY_C,
														LST_APPR_BY_N,
														CRTBY_M,
														CRTBYDEPT_M,
														UPDBY_M,
														UPDBYDEPT_M,
														INSURTY_C,
														INSURVALTILL_DT,
														CV_ATTH_ID_N,
														FILE_M,
														MIME_TY_C,
														SFTP_PATH_X) 
                    VALUES (SEQ_VSL_CERT.NEXTVAL,
                            LV_VSL_CERT(I).V_VSLRECID_N,
                            NULL,
                            LV_VSL_CERT(I).V_CERTTY_C,                  
                            LV_VSL_CERT(I).V_ISSAUTHYCTRY_C,
                            LV_VSL_CERT(I).V_ISSGCL_C,
                            LV_VSL_CERT(I).V_ISSD_DT,
                            LV_VSL_CERT(I).V_DUE_DT,
                            --LV_VSL_CERT(I).V_DOCIDATTH_N,
                            DECODE(LV_VSL_CERT(I).V_CERTST_C,1,'ACTIVE',2,'INACTIVE',3,'SUSPENDED'),
                            LV_VSL_CERT(I).V_ISSGCL_M,
                            0,
                            SYSDATE,
                            'DATA MIGRATION',
                            SYSDATE,
                            'DATA MIGRATION',
                            0,
                            LV_VSL_CERT(I).V_LASTAPPRBY_M,
                            LV_VSL_CERT(I).V_INTLREM_X,
							LV_VSL_CERT(I).V_ISSDBY_C,
							LV_VSL_CERT(I).V_LST_APPR_BY_N,
							LV_VSL_CERT(I).V_CRTBY_M,
							LV_VSL_CERT(I).V_CRTBYDEPT_M,
							LV_VSL_CERT(I).V_UPDBY_M,
							LV_VSL_CERT(I).V_UPDBYDEPT_M,
							LV_VSL_CERT(I).V_INSURTY_C,
							LV_VSL_CERT(I).V_INSURVALTILL_DT,
							LV_VSL_CERT(I).V_DOCIDATTH_N,
							LV_VSL_CERT(I).V_FILE_M,
							LV_VSL_CERT(I).V_MIME_TY_C,
							LV_VSL_CERT(I).V_SFTP_PATH_X
							);




    -- defining the inner exception to prevent the control breaking out of loop abruptly in case of failure 
          EXCEPTION

            WHEN OTHERS THEN

                V_M_ERR_CODE := SQLCODE;

                V_M_ERR_MSG := SUBSTR(SQLERRM, 1, 200);

                V_M_SQLERRM := V_M_ERR_CODE || V_M_ERR_MSG;


				V_EXP_ROW 	:=	' VSL_CERT_ID_N: '||SEQ_VSL_CERT.CURRVAL||
									' MSW_VSL_ID_N: '||LV_VSL_CERT(I).V_VSLRECID_N||
                                    ' MSW_DOC_ID: '||NULL||
									' CERT_TY_C: '||LV_VSL_CERT(I).V_CERTTY_C       ||
									' ISS_AUTHY_CTRY_C: '||LV_VSL_CERT(I).V_ISSAUTHYCTRY_C||
									' ISSG_CL_C: '||LV_VSL_CERT(I).V_ISSGCL_C||
									' ISSD_DT: '||LV_VSL_CERT(I).V_ISSD_DT||
									' DUE_DT: '||LV_VSL_CERT(I).V_DUE_DT||
									--' DOC_ID_ATTH_N: '||LV_VSL_CERT(I).V_DOCIDATTH_N||
									' ST_C : '||LV_VSL_CERT(I).V_CERTST_C||
									' ISSG_CL_M   : '||LV_VSL_CERT(I).V_ISSGCL_M||
									' LOCK_VER_N  : '||0||
									' CRT_ON_DT   : '||SYSDATE||
									' CRT_BY_X    : '||'DATA MIGRATION'||
									' UPT_ON_DT: '||SYSDATE||
									' UPT_BY_X: '||'DATA MIGRATION'||
									' DELETED_I: '||0||
									' LAST_APPROVED_BY_M: '||LV_VSL_CERT(I).V_LASTAPPRBY_M||
									' INTL_REM_X: '||LV_VSL_CERT(I).V_INTLREM_X||
									' ISSDBY_C: '||LV_VSL_CERT(I).V_ISSDBY_C||
									' LST_APPR_BY_N: '||LV_VSL_CERT(I).V_LST_APPR_BY_N||
									' CRTBY_M: '||LV_VSL_CERT(I).V_CRTBY_M||
									' CRTBYDEPT_M: '||LV_VSL_CERT(I).V_CRTBYDEPT_M||
									' UPDBY_M: '||LV_VSL_CERT(I).V_UPDBY_M||
									' UPDBYDEPT_M: '||LV_VSL_CERT(I).V_UPDBYDEPT_M||
									' INSURTY_C: '||LV_VSL_CERT(I).V_INSURTY_C||
									' INSURVALTILL_DT: '||LV_VSL_CERT(I).V_INSURVALTILL_DT||
									' CV_ATTH_ID_N: '||LV_VSL_CERT(I).V_DOCIDATTH_N||
									' FILE_M: '||LV_VSL_CERT(I).V_FILE_M||
									' MIME_TY_C: '||LV_VSL_CERT(I).V_MIME_TY_C||
									' SFTP_PATH_X: '||LV_VSL_CERT(I).V_SFTP_PATH_X ;




            PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                            'PROC_1_VSL_CERT_FOR', 
                                                            V_EXP_ROW||v_m_sqlerrm, 
                                                            'ERROR',
                                                            PV_RUN_ID,
                                                            V_M_SQLERRM,
															SEQ_VSL_CERT.CURRVAL||'<{||}>'||
															LV_VSL_CERT(I).V_VSLRECID_N||'<{||}>'||
															LV_VSL_CERT(I).V_CERTTY_C       ||'<{||}>'||
															LV_VSL_CERT(I).V_ISSAUTHYCTRY_C||'<{||}>'||
															LV_VSL_CERT(I).V_ISSGCL_C||'<{||}>'||
															LV_VSL_CERT(I).V_ISSD_DT||'<{||}>'||
															LV_VSL_CERT(I).V_DUE_DT||'<{||}>'||
															--LV_VSL_CERT(I).V_DOCIDATTH_N||'<{||}>'||
															LV_VSL_CERT(I).V_CERTST_C||'<{||}>'||
															LV_VSL_CERT(I).V_ISSGCL_M||'<{||}>'||
															0||'<{||}>'||
															SYSDATE||'<{||}>'||
															'DATA MIGRATION'||'<{||}>'||
															SYSDATE||'<{||}>'||
															'DATA MIGRATION'||'<{||}>'||
															0||'<{||}>'||
															LV_VSL_CERT(I).V_LASTAPPRBY_M||'<{||}>'||
															LV_VSL_CERT(I).V_INTLREM_X||'<{||}>'||
															LV_VSL_CERT(I).V_ISSDBY_C||'<{||}>'||
															LV_VSL_CERT(I).V_LST_APPR_BY_N||'<{||}>'||
															LV_VSL_CERT(I).V_CRTBY_M||'<{||}>'||
															LV_VSL_CERT(I).V_CRTBYDEPT_M||'<{||}>'||
															LV_VSL_CERT(I).V_UPDBY_M||'<{||}>'||
															LV_VSL_CERT(I).V_UPDBYDEPT_M||'<{||}>'||
															LV_VSL_CERT(I).V_INSURTY_C||'<{||}>'||
															LV_VSL_CERT(I).V_INSURVALTILL_DT||'<{||}>'||
															LV_VSL_CERT(I).V_DOCIDATTH_N||'<{||}>'||
															LV_VSL_CERT(I).V_FILE_M||'<{||}>'||
															LV_VSL_CERT(I).V_MIME_TY_C||'<{||}>'||
															LV_VSL_CERT(I).V_SFTP_PATH_X||'<{||}>'
															,
															'T' );

               END;
               END LOOP;
               COMMIT;





        END LOOP;
        close cur_vessel_certificate;


        --find the count of intermediate table(source table) to compare the count with the that of target table

		SELECT COUNT(*)
		INTO V_SRC_COUNT
		FROM SI_CV_VSLCERT;



        SELECT COUNT(*)
        INTO V_TGT_COUNT
        FROM VESSEL_CERTIFICATE;

        PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_CV_VSLCERT', V_SRC_COUNT, 'VESSEL_CERTIFICATE', V_TGT_COUNT,'N');

        IF (V_TGT_COUNT =  V_SRC_COUNT ) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
         'PROC_1_VSL_CERT_FOR', 
 V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE TABLE' ,
        'SUCCESS',
        NULL,
        NULL,
        NULL,
        NULL);

        ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
        'PROC_1_VSL_CERT_FOR', 
 V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||'ROWS  HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE TABLE' ,
        'PARTIALLY SUCCESSFULL',
        NULL,
        NULL,
        NULL,
        NULL);


    ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
        'PROC_1_VSL_CERT_FOR', 
 V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE TABLE' ,
        'FAIL',
        NULL,
        NULL,
        NULL,
        NULL);

        ELSE 

     PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
     'PROC_1_VSL_CERT_FOR', 
 V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO VESSEL_CERTIFICATE TABLE' ,
        'AMBIGIOUS',
        NULL,
        NULL,
        NULL,
        NULL);


        END IF;


        --RECONCILING THE STAGING TABLE CNT AND TARGET TABLE CNT

        SELECT COUNT(*)
		INTO V_SRC_COUNT
		FROM ST_CV_VSLCERT;



        SELECT COUNT(*)
        INTO V_TGT_COUNT
        FROM VESSEL_CERTIFICATE;

        PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_VSLCERT', V_SRC_COUNT, 'VESSEL_CERTIFICATE', V_TGT_COUNT,'Y');



        IF V_M_TGT_COUNT > 0 AND (V_M_TGT_COUNT - V_TGT_COUNT) = 0 THEN  
          P_COUNT := 0;
          ELSE 
        P_COUNT :=  -1;

        END IF ;

/* commented by Rohit Khool

BEGIN 

		FOR I IN
		(
		SELECT 
		CERTTY_C	,
		VSLRECID_N	,
		ISSD_DT	,
		DUE_DT	,
		REGST_C	,
		ISSDBY_C	,
		ISSAUTHYCTRY_C	,
		ISSGCL_C	,
		PERSALLW_Q	,
		SOPEPSMPEPONBD_I	,
		INCOMPLYMARPOLREGU20_I	,
		INCOMPLYMARPOLREGU21_I	,
		BCCAPPLN_N	,
		BCCAPPLNST_C	,
		BCCISSD_DT	,
		INSURTY_C	,
		INSURVALTILL_DT	,
		DOCIDATTH_N	,
		CERTST_C	,
		LASTAPPRBY_N	,
		LASTAPPRBY_M	,
		CRTBY_N	,
		CRTBY_M	,
		CRTBYDEPT_M	,
		CRTON_DT	,
		UPDBY_N	,
		UPDBY_M	,
		UPDBYDEPT_M	,
		UPDON_DT	,
		INTLREM_X	,
		ISSGCL_M	,
		INCOMPLYMARPOLREGU20_DT	,
		INCOMPLYMARPOLREGU21_DT	

		FROM ST_CV_VSLCERT 
		WHERE   VSLRECID_N    NOT IN 

		(  	SELECT VC.VSLRECID_N
			FROM
			ST_CV_VSLCERT VC , 
			VESSEL V ,
			ST_CM_docMetadata cmo
			WHERE
			VC.VSLRECID_N=V.VSL_REC_ID_N
			AND VC.DOCIDATTH_N = CMO.DOCID_N(+)))




LOOP

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 
                                                'PROC_1_VSL_CERT_FOR',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_VSLCERT AND WHOLE QUERY DUE TO JOIN CONDITION FAILURE',
                                                NULL,
                                                PV_RUN_ID,
                                                NULL,
                                                I.CERTTY_C	||'<{||}>'||
												I.VSLRECID_N||'<{||}>'||
												I.ISSD_DT	||'<{||}>'||
												I.DUE_DT	||'<{||}>'||
												I.REGST_C	||'<{||}>'||
												I.ISSDBY_C	||'<{||}>'||
												I.ISSAUTHYCTRY_C	||'<{||}>'||
												I.ISSGCL_C	||'<{||}>'||
												I.PERSALLW_Q	||'<{||}>'||
												I.SOPEPSMPEPONBD_I	||'<{||}>'||
												I.INCOMPLYMARPOLREGU20_I	||'<{||}>'||
												I.INCOMPLYMARPOLREGU21_I	||'<{||}>'||
												I.BCCAPPLN_N	||'<{||}>'||
												I.BCCAPPLNST_C	||'<{||}>'||
												I.BCCISSD_DT	||'<{||}>'||
												I.INSURTY_C	||'<{||}>'||
												I.INSURVALTILL_DT	||'<{||}>'||
												I.DOCIDATTH_N	||'<{||}>'||
												I.CERTST_C	||'<{||}>'||
												I.LASTAPPRBY_N	||'<{||}>'||
												I.LASTAPPRBY_M	||'<{||}>'||
												I.CRTBY_N	||'<{||}>'||
												I.CRTBY_M	||'<{||}>'||
												I.CRTBYDEPT_M	||'<{||}>'||
												I.CRTON_DT	||'<{||}>'||
												I.UPDBY_N	||'<{||}>'||
												I.UPDBY_M	||'<{||}>'||
												I.UPDBYDEPT_M	||'<{||}>'||
												I.UPDON_DT	||'<{||}>'||
												I.INTLREM_X	||'<{||}>'||
												I.ISSGCL_M	||'<{||}>'||
												I.INCOMPLYMARPOLREGU20_DT	||'<{||}>'||
												I.INCOMPLYMARPOLREGU21_DT	   ,
												'B');



END LOOP;




EXCEPTION

WHEN OTHERS THEN NULL;

END;

*/

EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;

        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);

        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CERTIFICATE', 'PROC_1_VSL_CERT_FOR', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');
END;
/