create or replace PROCEDURE PROC_1_ICA_MIGRATION (PV_RUN_ID  in number)IS

/***********************************************************************************************************
procedure name : PROC_1_ICA_MIGRATION
Created By     : C.N.BHASKAR
Date           : 29-Aug-2019
Purpose        : Inserting  the data from ST_ICA_MIGRATION to 
                 SI_ICA_MIGRATION(Intermediate table) to APPLICATION_SUBMISSION(Target Table)
Modified by    :
Modified date  :

*************************************************************************************************************/

	/***********************************************************************************************************
	Defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table
	*************************************************************************************************************/

type REC_ICA_MIGRATION is RECORD
( 
V_APPLN_REF_ID			                SI_ICA_MIGRATION.APPLN_REF_ID%type,
V_ARR_APPLN_REF_ID		                SI_ICA_MIGRATION.ARR_APPLN_REF_ID%type,
V_COY_RCB                               SI_ICA_MIGRATION.COY_RCB%type,
V_VESSEL_ID				                SI_ICA_MIGRATION.VESSEL_ID%type,
V_APPLN_DECISION					    SI_ICA_MIGRATION.APPLN_DECISION%type,
V_EST_ARR_DATE                          SI_ICA_MIGRATION.EST_ARR_DATE%type,
V_ACTUAL_ARR_DATE                       SI_ICA_MIGRATION.ACTUAL_ARR_DATE%type,
V_EST_DEP_DATE                          SI_ICA_MIGRATION.EST_DEP_DATE%type,
V_ACTUAL_DEP_DATE                       SI_ICA_MIGRATION.ACTUAL_DEP_DATE%type


);

    TYPE type_ICA_MIGRATION IS  TABLE OF REC_ICA_MIGRATION;

    lv_ICA_MIGRATION  type_ICA_MIGRATION;


    v_err_code NUMBER;
    v_err_msg VARCHAR2(500);
    v_sqlerrm VARCHAR2(2500);
    V_YEAR_DAY VARCHAR2(40);
    arr_p_yymm VARCHAR2(100);
    eta_p_yyyydd VARCHAR2(100);
    l_val NUMBER;

    v_msw_vsl_call_id_out NUMBER;
    v_flag_out VARCHAR2(100);
    v_msw_appln_ref_id_x VARCHAR2(20);
    v_del_arrgd NUMBER;
    v_del_depgd NUMBER;
    v_src_count NUMBER;
    v_tgt_count  number;
    V_VSL_REF_ID_OUT   varchar2(20);
    LV_JSON    CLOB;


cursor CUR_ICA_MIGRATION is   

select *
from 
SI_ICA_MIGRATION
order by EST_ARR_DATE ;


begin  --outer begin

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_ICA_MIGRATION', 'PROC_1_ICA_MIGRATION','INSERTION INTO SI_ICA_MIGRATION  STARTS' , 'START',null,null,null,'T');



FOR i IN (
 select * from St_ICA_MIGRATION where trim(APPLN_DECISION) = 'A'
 )

LOOP               

BEGIN                                            -- inner begin  of SI  tablee 

 INSERT INTO SI_ICA_MIGRATION (
APPLN_REF_ID,
ARR_APPLN_REF_ID,
COY_RCB,
VESSEL_ID,
APPLN_DECISION,
EST_ARR_DATE,
ACTUAL_ARR_DATE,
EST_DEP_DATE,
ACTUAL_DEP_DATE

)

VALUES ( 
i.APPLN_REF_ID,
i.ARR_APPLN_REF_ID,
i.COY_RCB,
i.VESSEL_ID,
i.APPLN_DECISION,
i.EST_ARR_DATE,
i.ACTUAL_ARR_DATE,
i.EST_DEP_DATE,
i.ACTUAL_DEP_DATE
);

exception  --inner exception of SI table 

 WHEN OTHERS THEN                                                     -- inner exception for handling any errors in the SI table 
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_ICA_MIGRATION',

  'PROC_1_ICA_MIGRATION',

  'APPLN_REF_ID:'||	i.APPLN_REF_ID	||'<{||}>'||
   'ARR_APPLN_REF_ID:'||	i.ARR_APPLN_REF_ID ||'<{||}>'||
   'COY_RCB:'||i.COY_RCB||'<{||}>'||
   'VESSEL_ID:'||	i.VESSEL_ID||'<{||}>'||
   'APPLN_DECISION:'||	i.APPLN_DECISION  ||'<{||}>'||
   'EST_ARR_DATE:'|| i.EST_ARR_DATE ||'<{||}>'||  
    'ACTUAL_ARR_DATE:'||i.ACTUAL_ARR_DATE||'<{||}>'|| 
     'EST_DEP_DATE:'|| i.EST_DEP_DATE ||'<{||}>'||  
    'ACTUAL_DEP_DATE:'||i.ACTUAL_DEP_DATE 

  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

i.APPLN_REF_ID	||'<{||}>'||
i.ARR_APPLN_REF_ID ||'<{||}>'||
i.COY_RCB||'<{||}>'||
i.VESSEL_ID||'<{||}>'||
i.APPLN_DECISION  ||'<{||}>'||
i.EST_ARR_DATE ||'<{||}>'||  
i.ACTUAL_ARR_DATE||'<{||}>'|| 
i.EST_DEP_DATE ||'<{||}>'||  
i.ACTUAL_DEP_DATE 
,
 'T'
 );

end ;   -- inner end of SI table 

end loop; -- end loop of for which inserts the data into the SI table 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_ICA_MIGRATION', 'PROC_1_ICA_MIGRATION','INSERTION INTO SI_ICA_MIGRATION  ENDS' , 'ENDS',null,null,null,'T');



---------------------------------------------------------------------------------------------------------------------------------


OPEN CUR_ICA_MIGRATION;

loop     -- loop of the cursor  CUR_ICA_MIGRATION

  FETCH CUR_ICA_MIGRATION BULK COLLECT INTO lv_ICA_MIGRATION LIMIT 100000;

               EXIT WHEN lv_ICA_MIGRATION.count = 0;


                  FOR i IN lv_ICA_MIGRATION.FIRST..lv_ICA_MIGRATION.LAST 


                  loop       --loop of lv_ICA_MIGRATION.FIRST..lv_ICA_MIGRATION.LAST 




                     Select TO_CHAR(lv_ICA_MIGRATION(i).V_ACTUAL_ARR_DATE,'YYYY')|| TO_CHAR(lv_ICA_MIGRATION(i).V_ACTUAL_ARR_DATE,'DD') 
                       into V_YEAR_DAY 
                       from dual;





                     IF V_YEAR_DAY != eta_p_yyyydd  and  eta_p_yyyydd is not null  THEN


                                   EXECUTE IMMEDIATE 'select ICA_SUB_SEQ.NEXTVAL from dual'
                                      INTO l_val;
                                   EXECUTE IMMEDIATE 'alter sequence ICA_SUB_SEQ increment by -'|| l_val || ' minvalue 0';

                                   EXECUTE IMMEDIATE 'select  ICA_SUB_SEQ.NEXTVAL from dual'
                                      INTO l_val;
                                   EXECUTE IMMEDIATE 'alter sequence ICA_SUB_SEQ increment by 1 minvalue 0';


                      END IF;

  eta_p_yyyydd :=     V_YEAR_DAY;

   V_MSW_APPLN_REF_ID_X :=  substr(lv_ICA_MIGRATION(i).V_APPLN_REF_ID,1,2)||TO_CHAR(lv_ICA_MIGRATION(i).V_ACTUAL_ARR_DATE,'YYYY')||TO_CHAR(lv_ICA_MIGRATION(i).V_ACTUAL_ARR_DATE,'MM')||TO_CHAR(lv_ICA_MIGRATION(i).V_ACTUAL_ARR_DATE,'DD')||TO_CHAR(ICA_SUB_SEQ.NEXTVAL,'FM0000' ) ;


/************************************************************************************************************************************************

JSON  starts

************************************************************************************************************************************************/


LV_JSON := '{';
LV_JSON :=  LV_JSON || '"vesselCallId": "'||'NULL'||'",';
LV_JSON :=  LV_JSON ||  '"vesselId":'|| lv_ICA_MIGRATION(i).v_VESSEL_ID||',';
LV_JSON :=  LV_JSON ||  '"createdOn":"'||sysdate||'",';
LV_JSON :=  LV_JSON || '"createdBy":"'||'DEFAULT_DATA'||'",';
LV_JSON :=  LV_JSON ||  '"lastUpdatedOn":"'||sysdate||'",';
LV_JSON :=  LV_JSON ||  '"lastUpdatedBy":"'||'DEFAULT_DATA'||'",';
LV_JSON :=  LV_JSON || '"expectedTimeOfArrival":"'|| lv_ICA_MIGRATION(i).V_EST_ARR_DATE ||'",';
LV_JSON :=  LV_JSON || '"expectedTimeOfDeparture":"'||lv_ICA_MIGRATION(i).V_EST_DEP_DATE||'",';
LV_JSON :=  LV_JSON || '"applicationSubmissionId":'|| 0;
LV_JSON :=  LV_JSON ||'}';





/************************************************************************************************************************************************

JSON  ends 

************************************************************************************************************************************************/




/************************************************************************************************************************************************

insert into APPLICATION_SUBMISSION starts

************************************************************************************************************************************************/

begin 

INSERT INTO APPLICATION_SUBMISSION (                APPLN_SUBMISSN_ID_N,
                                                    MSW_APPLN_REF_ID_X,
													VSL_CALL_ID_N,
													EXTL_APPLN_REF_ID_X,
													MSW_VSL_ID_N,
													ETA_DT,
													ETD_DT,
													APPLN_TY_C,
													APPLN_DATA_X,
													ST_C,
													PROCESSING_REM_X,
													PROCESSED_BY_X,
													PROCESSED_ON_DT,
													CUTOFF_DT,
													LOCK_VER_N,
													CRT_ON_DT,
													CRT_BY_X,
													UPT_ON_DT,
													UPT_BY_X,
													DELETED_I,
                                                    ORG_C,
                                                   VSL_REF_ID_N,
                                                   REASON)


											VALUES(APP_SUB_SEQ.NEXTVAL,
                                                   V_MSW_APPLN_REF_ID_X,
												   null,
												   lv_ICA_MIGRATION(i).V_APPLN_REF_ID,
												   lv_ICA_MIGRATION(i).v_VESSEL_ID,
												   lv_ICA_MIGRATION(i).V_EST_ARR_DATE,
												   lv_ICA_MIGRATION(i).V_EST_DEP_DATE,
												   substr(lv_ICA_MIGRATION(i).V_APPLN_REF_ID,1,2),
												   LV_JSON ,  --NULL,
												  'APPROVED',
												   NULL,
												   NULL,
												   NULL,
												   NULL,
												   0,
												   SYSDATE,
												   'DATA MIGRATION',
												   NULL,
												   NULL,
												   0,
                                                   'ICA',
                                                   null,
                                                   null);


LV_JSON := null;



exception

when others  then  null;

 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
('APPLICATION_SUBMISSION',

'PROC_1_ICA_MIGRATION',

'APPLN_SUBMISSN_ID_N:' || APP_SUB_SEQ.currval ||'<{||}>'||
'MSW_APPLN_REF_ID_X:' || V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
'VSL_CALL_ID_N:' || null ||'<{||}>'|| 
'EXTL_APPLN_REF_ID_X:'|| lv_ICA_MIGRATION(i).V_APPLN_REF_ID  ||'<{||}>'||
'MSW_VSL_ID_N:' || lv_ICA_MIGRATION(i).v_VESSEL_ID  ||'<{||}>'||
'ETA_DT:' || lv_ICA_MIGRATION(i).V_EST_ARR_DATE  ||'<{||}>'||
'ETD_DT:' || lv_ICA_MIGRATION(i).V_EST_DEP_DATE  ||'<{||}>'||
'APPLN_TY_C:' || 'ICA'  ||'<{||}>'||
'APPLN_DATA_X:' || LV_JSON  ||'<{||}>'||
'ST_C:'  || 'PROCESSED'  ||'<{||}>'||
'PROCESSING_REM_X:' || null  ||'<{||}>'||
'PROCESSED_BY_X:' || null  ||'<{||}>'||
'PROCESSED_ON_DT:' || null  ||'<{||}>'||
'CUTOFF_DT:' || null  ||'<{||}>'||
'LOCK_VER_N:' || 0  ||'<{||}>'||
'CRT_ON_DT:' || sysdate  ||'<{||}>'||
'CRT_BY_X:' || 'DATA MIGRATION'  ||'<{||}>'||
'UPT_ON_DT:' || null  ||'<{||}>'||
'UPT_BY_X:'  || null  ||'<{||}>'||
'DELETED_I:' || 0   ||'<{||}>'||
'ORG_C:'  || 'ICA'   ||'<{||}>'||
'VSL_REF_ID_N:' || null ||'<{||}>'||
'REASON:' || null 

,
'ERROR',
PV_RUN_ID,
V_SQLERRM,

 APP_SUB_SEQ.currval ||'<{||}>'||
 V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
null||'<{||}>'|| 
lv_ICA_MIGRATION(i).V_APPLN_REF_ID  ||'<{||}>'||
lv_ICA_MIGRATION(i).v_VESSEL_ID  ||'<{||}>'||
lv_ICA_MIGRATION(i).V_EST_ARR_DATE  ||'<{||}>'||
lv_ICA_MIGRATION(i).V_EST_DEP_DATE  ||'<{||}>'||
 'ICA'  ||'<{||}>'||
 LV_JSON  ||'<{||}>'||
 'PROCESSED'  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 0  ||'<{||}>'||
sysdate  ||'<{||}>'||
'DATA MIGRATION'  ||'<{||}>'||
 null  ||'<{||}>'||
null  ||'<{||}>'||
 0   ||'<{||}>'||
'ICA'  ||'<{||}>'||
 null ||'<{||}>'||
 null 



,
'T');









end;


/************************************************************************************************************************************************

insert into APPLICATION_SUBMISSION Ends

************************************************************************************************************************************************/









                  end loop;    -- end loop of lv_ICA_MIGRATION.FIRST..lv_ICA_MIGRATION.LAST   
commit;

end loop; -- end of CUR_ICA_MIGRATION


close CUR_ICA_MIGRATION;



SELECT COUNT(*)
INTO    v_src_count
FROM    ST_ICA_MIGRATION ;


SELECT COUNT(*)
INTO V_TGT_COUNT
FROM SI_ICA_MIGRATION ;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_ICA_MIGRATION', V_SRC_COUNT, 'SI_ICA_MIGRATION', V_TGT_COUNT,'N');	




        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into SI_ICA_MIGRATION table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_ICA_MIGRATION table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_ICA_MIGRATION table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_ICA_MIGRATION table' ,
        'AMBIGIOUS',null,null,null,null);

end if;


------------------------------------------------------------------------------------------------------------




SELECT COUNT(*)
INTO    v_src_count
FROM    SI_ICA_MIGRATION ;



SELECT COUNT(*)
INTO V_TGT_COUNT
FROM APPLICATION_SUBMISSION ;



        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into APPLICATION_SUBMISSION table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into APPLICATION_SUBMISSION table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into APPLICATION_SUBMISSION table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ICA', 'PROC_1_ICA_MIGRATION', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into APPLICATION_SUBMISSION table' ,
        'AMBIGIOUS',null,null,null,null);

end if;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_ICA_MIGRATION', V_SRC_COUNT, 'APPLICATION_SUBMISSION', V_TGT_COUNT,'Y');	



exception  --outer exception 

when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

              PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARR_DEP_GD_APPLICATION', 'PROC_1_ICA_MIGRATION', V_SQLERRM, 'FAIL',null,null,null,'T');

end ;  -- outer end
/