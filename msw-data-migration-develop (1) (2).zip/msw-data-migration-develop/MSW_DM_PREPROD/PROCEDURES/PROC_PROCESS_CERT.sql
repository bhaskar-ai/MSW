create or replace PROCEDURE PROC_PROCESS_CERT (
   -- filename VARCHAR2,
    pv_run_id IN   NUMBER
) IS

    lv_cnt_st              NUMBER;
    lv_cnt_si              NUMBER;
    lv_cnt_tar             NUMBER;
    LV_DIR                 VARCHAR2(500) ;

/***********************************************************************************************************
procedure name : PROC_PROCESS_DOC
Created By     : Mariamma Joseph
Date           : 03-Oct-2019
Purpose        : Process Vessel Cartificate
Modified by    :
Modified date  :
*************************************************************************************************************/
    CURSOR cur_doc IS
    SELECT
        VSL_CERT_ID_N,
        CV_ATTH_ID_N,
        FILE_M,
        MIME_TY_C,
        SFTP_PATH_X


    FROM
        vessel_certificate
        WHERE
        FILE_M IS NOT NULL;

    CURSOR cur_doc_tar IS
    SELECT
        appln_doc_id_n,
        msw_doc_id_n,
        docid_n,
        file_name,
        file_path,
        file_type
    FROM
        si_msw_doc_mapping_vsl_cert;

--***************** Declaring Types ****************------

    TYPE rec_doc IS RECORD (
        lv_dg_appln_doc_id_n   si_msw_doc_mapping_vsl_cert.appln_doc_id_n%TYPE,
--lv_MSW_DOC_ID_N	    SI_MSW_DOC_MAPPING.MSW_DOC_ID_N%type,
        lv_docid_n             si_msw_doc_mapping.docid_n%TYPE,
        lv_file_name           si_msw_doc_mapping.file_name%TYPE,
        lv_file_path           si_msw_doc_mapping.file_path%TYPE,
        lv_file_type           si_msw_doc_mapping.file_type%TYPE
    );
    TYPE type_doc_tbl IS
        TABLE OF rec_doc;
    lv_doc_tbl             type_doc_tbl;

----------------------------
    TYPE rec_doc_tar IS RECORD (
        lv_appln_doc_id_n   si_msw_doc_mapping_vsl_cert.appln_doc_id_n%TYPE,
        lv_msw_doc_id_n        si_msw_doc_mapping.msw_doc_id_n%TYPE,
        lv_docid_n             si_msw_doc_mapping.docid_n%TYPE,
        lv_file_name           si_msw_doc_mapping.file_name%TYPE,
        lv_file_path           si_msw_doc_mapping.file_path%TYPE,
        lv_file_type           si_msw_doc_mapping.file_type%TYPE
    );
    TYPE type_doc_tbl_tar IS
        TABLE OF rec_doc_tar;
    lv_doc_tbl_tar         type_doc_tbl_tar;
    f_lob                  BFILE;
    b_lob                  BLOB;
    image_name             VARCHAR2(30);
    mime_type              VARCHAR2(30);
    dot_pos                NUMBER;
    v_sq_doc_id_n           NUMBER;
   -- filename varchar2(500):= 'DOC_MANAGEMENT' ;
BEGIN
    SELECT
        COUNT(*)
    INTO lv_cnt_st
    FROM
        vessel_certificate;

    OPEN cur_doc;
    pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', 'Insertion into Table SI_MSW_DOC_MAPPING', 'START'
    , pv_run_id, NULL, NULL, 'T');

    LOOP
        FETCH cur_doc BULK COLLECT INTO lv_doc_tbl LIMIT 10000;
        EXIT WHEN lv_doc_tbl.count = 0;
        FOR i IN lv_doc_tbl.first..lv_doc_tbl.last LOOP
            BEGIN
                INSERT INTO si_msw_doc_mapping_vsl_cert (
                    appln_doc_id_n,
                    docid_n,
                    file_name,
                    file_path,
                    file_type
                ) VALUES (
                    lv_doc_tbl(i).lv_dg_appln_doc_id_n,
                    lv_doc_tbl(i).lv_docid_n,
                    lv_doc_tbl(i).lv_file_name,
                    lv_doc_tbl(i).lv_file_path,
                    lv_doc_tbl(i).lv_file_type
                );

            EXCEPTION
                WHEN OTHERS THEN
                    pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', sqlerrm
                                                                                                   || dbms_utility.format_error_backtrace
                                                                                                   || dbms_utility.format_error_stack
                                                                                                   , 'ERROR', NULL, sqlerrm, NULL
                                                                                                   , 'T');
            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cur_doc;
    SELECT
        COUNT(*)
    INTO lv_cnt_si
    FROM
        si_msw_doc_mapping;

    IF ( lv_cnt_si = lv_cnt_st ) AND lv_cnt_st <> 0 AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_si
                                                                                       || ' out of '
                                                                                       || lv_cnt_st
                                                                                       || ' records loaded successfully in SI Table', 'SUCCESS'
                                                                                       , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_si <> lv_cnt_st AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_si
                                                                                       || ' out of '
                                                                                       || lv_cnt_st
                                                                                       || ' records loaded successfully in SI Table', 'PARTIALLY SUCCESSFULL'
                                                                                       , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_si <> lv_cnt_st OR lv_cnt_si = lv_cnt_st ) AND ( lv_cnt_si = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_si
                                                                                       || ' out of '
                                                                                       || lv_cnt_st
                                                                                       || ' records loaded successfully in SI Table', 'FAIL',
                                                                                       pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('DANGEROUS_GOODS_APPLICATION_DOCUMENT', lv_cnt_st, 'SI_MSW_DOC_MAPPING', lv_cnt_si

    , 'N');

------------------------------------ Inserting data DOC Target Table ---------------------------------------
    OPEN cur_doc_tar;
    pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', 'Insertion into Table DOC', 'START'
                                                    , pv_run_id, NULL, NULL, 'T');

    SELECT DIRECTORY_PATH INTO LV_DIR 
    FROM ALL_DIRECTORIES  WHERE DIRECTORY_NAME = 'DOC_MANAGEMENT'; 

    LOOP
        FETCH cur_doc_tar BULK COLLECT INTO lv_doc_tbl_tar LIMIT 10000;
        EXIT WHEN lv_doc_tbl_tar.count = 0;
        FOR j IN lv_doc_tbl_tar.first..lv_doc_tbl_tar.last 

        LOOP


        BEGIN

            v_sq_doc_id_n := SYN_SEQ_DOC.nextval; --SYN_SEQ_DOC_ID_N.NEXTVAL ; -- both referring to the same Seq. ISEQ$$_89874
            dot_pos := INSTR(lv_doc_tbl_tar(j).lv_file_name,'.');
            image_name := lv_doc_tbl_tar(j).lv_file_name;       --'filename';
            mime_type := 'image/'||SUBSTR( lv_doc_tbl_tar(j).lv_file_name,dot_pos+1,length(lv_doc_tbl_tar(j).lv_file_name) );

            INSERT INTO doc (
                    doc_id_n,
                    lock_ver_n,
                    doc_title_m,
                    file_ty_c,
                    acc_cnt_n,
                    strg_loc_x,
                    crt_by_n,
                    crt_on_dt,
                    deleted_i,
                    usr_file_m,
                    file_data
                ) VALUES (
                    v_sq_doc_id_n ,
                    0,
                    image_name, 
                    lv_doc_tbl_tar(j).lv_file_type,
                    0,
                    LV_DIR, 
                    'DATA MIGRATION',
                    SYSDATE,
                    0,
                    mime_type,  
                    empty_blob() )
                RETURN FILE_DATA INTO b_lob;

            f_lob := BFILENAME('DOC_MANAGEMENT',lv_doc_tbl_tar(j).lv_file_name);
            dbms_lob.fileopen(f_lob,dbms_lob.file_readonly);
            dbms_lob.loadfromfile(b_lob,f_lob,dbms_lob.getlength(f_lob) );
            dbms_lob.fileclose(f_lob);

            Update vessel_certificate A
            set A.MSW_DOC_ID = v_sq_doc_id_n
            where A.VSL_CERT_ID_N = lv_doc_tbl_tar(j).lv_appln_doc_id_n ;

--dbms_output.put_line('lv_dg_appln_doc_id_n '||lv_doc_tbl_tar(j).lv_dg_appln_doc_id_n ) ;
--dbms_output.put_line('v_sq_doc_id_n '||v_sq_doc_id_n) ; 

            EXCEPTION
                WHEN OTHERS THEN
                    pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', sqlerrm
                                                                                                   || dbms_utility.format_error_backtrace
                                                                                                   || dbms_utility.format_error_stack
                                                                                                   , 'ERROR', NULL, sqlerrm, NULL
                                                                                                   , 'T');
            END;

        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cur_doc_tar;
      /*
        Update DANGEROUS_GOODS_APPLICATION_DOCUMENT A
            set A.DOC_ID_N = (SELECT b.doc_id_n  FROM doc b
                                where a.dg_appln_doc_id_n = b.doc_id_n)  ;

        COMMIT ;
      */
    SELECT
        COUNT(*)
    INTO lv_cnt_tar
    FROM
        doc;

    IF ( lv_cnt_tar = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_tar
                                                                                       || ' out of '
                                                                                       || lv_cnt_si
                                                                                       || ' records loaded successfully in Target Table ', 'SUCCESS'
                                                                                       , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_tar <> lv_cnt_si AND lv_cnt_tar <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_tar
                                                                                       || ' out of '
                                                                                       || lv_cnt_si
                                                                                       || ' records loaded successfully in Target Table ', 'PARTIALLY SUCCESSFULL'
                                                                                       , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_tar <> lv_cnt_si OR lv_cnt_tar = lv_cnt_si ) AND ( lv_cnt_tar = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('DOCUMENT', 'PROC_PROCESS_DOC', lv_cnt_tar
                                                                                       || ' out of '
                                                                                       || lv_cnt_si
                                                                                       || ' records loaded successfully in Target Table ', 'FAIL',
                                                                                       pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('SI_MSW_DOC_MAPPING', lv_cnt_si, 'DOC', lv_cnt_tar, 'N');
    pkg_datamigration_generic.proc_migration_recon('DANGEROUS_GOODS_APPLICATION_DOCUMENT', lv_cnt_st, 'DOC', lv_cnt_tar, 'Y');
END proc_process_cert;
/