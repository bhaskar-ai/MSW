create or replace PROCEDURE PROC_1_PUSH_USR_DTLS IS
    
/***********************************************************************************************************
PROCEDURE NAME : PROC_1_PUSH_USR
CREATED BY     : SOURANGSHU DHAR
DATE           : 10-SEP-2019
PURPOSE        : TO PUSH USR_DTL TABLE RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO RESPECTIVE TARGET SCHEMAS AUTHENTICATION_SERVICE.USR_DTL
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****

    CURSOR cr_usr_dtls IS
    SELECT
        id_n,
        usr_logon_id_n,
        usr_id_ty_c,
        usr_id_n,
        usr_m,
        usr_email_addr_x,
        usr_tel_n,
        usr_st_c,
        usr_pswd_m,
        co_uen_n,
        lock_ver_n,
        deleted_i,
        crt_on_dt,
        lst_upd_on_dt,
        crt_by_n,
        lst_upd_by_n,
        failed_attempts_i
    FROM
        usr_dtls;
/*
    CURSOR cr_usr_privledge IS
    SELECT
        usr_dtls_id_n,
        usr_privilege_id_n
    FROM
        usr_privileges;
*/
    TYPE rec_usr_dtl IS RECORD (
        v_id_n                usr_dtls.id_n%TYPE,
        v_usr_logon_id_n      usr_dtls.usr_logon_id_n%TYPE,
        v_usr_id_ty_c         usr_dtls.usr_id_ty_c%TYPE,
        v_usr_id_n            usr_dtls.usr_id_n%TYPE,
        v_usr_m               usr_dtls.usr_m%TYPE,
        v_usr_email_addr_x    usr_dtls.usr_email_addr_x%TYPE,
        v_usr_tel_n           usr_dtls.usr_tel_n%TYPE,
        v_usr_st_c            usr_dtls.usr_st_c%TYPE,
        v_usr_pswd_m          usr_dtls.usr_pswd_m%TYPE,
        v_co_uen_n            usr_dtls.co_uen_n%TYPE,
        v_lock_ver_n          usr_dtls.lock_ver_n%TYPE,
        v_deleted_i           usr_dtls.deleted_i%TYPE,
        v_crt_on_dt           usr_dtls.crt_on_dt%TYPE,
        v_lst_upd_on_dt       usr_dtls.lst_upd_on_dt%TYPE,
        v_crt_by_n            usr_dtls.crt_by_n%TYPE,
        v_lst_upd_by_n        usr_dtls.lst_upd_by_n%TYPE,
        v_failed_attempts_i   usr_dtls.failed_attempts_i%TYPE
    );
    /*
    TYPE rec_usr_priviledges IS RECORD (
        usr_dtls_id_n         usr_privileges.usr_dtls_id_n%TYPE,
        usr_privilege_id_n    usr_privileges.usr_privilege_id_n%TYPE
    );
    */
    TYPE type_usr_dtl IS
        TABLE OF rec_usr_dtl;
    lv_usr_dtls           type_usr_dtl;
    /*
    TYPE type_usr_priviledges IS
        TABLE OF rec_usr_priviledges;
    lv_usr_priviledges    type_usr_priviledges;
    */
    lv_cnt_dm_ud_dtls     NUMBER;
    lv_cnt_tt_ud_dtls     NUMBER;
   -- lv_cnt_dm_ud_priv     NUMBER;
   -- lv_cnt_tt_ud_priv     NUMBER;
    v_err_code            NUMBER;
    v_err_msg             VARCHAR2(500);
    v_sqlerrm             VARCHAR2(2500);
    v_exp_rows            VARCHAR2(1000);
BEGIN
    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_dtls
    FROM
        usr_dtls;
/*
    SELECT
        COUNT(*)
    INTO lv_cnt_dm_ud_priv
    FROM
        usr_privileges;
*/
    OPEN cr_usr_dtls;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.USR_DTLS'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.USR_DTLS and inseting into target table AUTHENTICATION_SERVICE.USR_DTLS ************------------------        
        FETCH cr_usr_dtls BULK COLLECT INTO lv_usr_dtls LIMIT 10000;
        EXIT WHEN lv_usr_dtls.count = 0;
        FOR i IN lv_usr_dtls.first..lv_usr_dtls.last LOOP			
-------------************ SYN_USR_DTLS is synonym of AUTHENTICATION_SERVICE.USR_DTLS  ************------------------  
            BEGIN
                INSERT INTO syn_usr_dtls (
                    id_n,
                    usr_logon_id_n,
                    usr_id_ty_c,
                    usr_id_n,
                    usr_m,
                    usr_email_addr_x,
                    usr_tel_n,
                    usr_st_c,
                    usr_pswd_m,
                    co_uen_n,
                    lock_ver_n,
                    deleted_i,
                    crt_on_dt,
                    lst_upd_on_dt,
                    crt_by_n,
                    lst_upd_by_n,
                    failed_attempts_i
                ) VALUES (
                    lv_usr_dtls(i).v_id_n,
                    lv_usr_dtls(i).v_usr_logon_id_n,
                    lv_usr_dtls(i).v_usr_id_ty_c,
                    lv_usr_dtls(i).v_usr_id_n,
                    lv_usr_dtls(i).v_usr_m,
                    lv_usr_dtls(i).v_usr_email_addr_x,
                    lv_usr_dtls(i).v_usr_tel_n,
                    lv_usr_dtls(i).v_usr_st_c,
                    lv_usr_dtls(i).v_usr_pswd_m,
                    lv_usr_dtls(i).v_co_uen_n,
                    lv_usr_dtls(i).v_lock_ver_n,
                    lv_usr_dtls(i).v_deleted_i,
                    lv_usr_dtls(i).v_crt_on_dt,
                    lv_usr_dtls(i).v_lst_upd_on_dt,
                    lv_usr_dtls(i).v_crt_by_n,
                    lv_usr_dtls(i).v_lst_upd_by_n,
                    lv_usr_dtls(i).v_failed_attempts_i
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' ID_N: '
                                  || lv_usr_dtls(i).v_id_n
                                  || ' USR_LOGON_ID_N: '
                                  || lv_usr_dtls(i).v_usr_logon_id_n
                                  || ' USR_ID_TY_C: '
                                  || lv_usr_dtls(i).v_usr_id_ty_c
                                  || ' USR_ID_N: '
                                  || lv_usr_dtls(i).v_usr_id_n
                                  || ' USR_M: '
                                  || lv_usr_dtls(i).v_usr_m
                                  || ' USR_EMAIL_ADDR_X: '
                                  || lv_usr_dtls(i).v_usr_email_addr_x
                                  || ' USR_TEL_N: '
                                  || lv_usr_dtls(i).v_usr_tel_n
                                  || ' USR_ST_C: '
                                  || lv_usr_dtls(i).v_usr_st_c
                                  || ' USR_PSWD_M: '
                                  || lv_usr_dtls(i).v_usr_pswd_m
                                  || ' CO_UEN_N: '
                                  || lv_usr_dtls(i).v_co_uen_n
                                  || ' LOCK_VER_N: '
                                  || lv_usr_dtls(i).v_lock_ver_n
                                  || ' DELETED_I: '
                                  || lv_usr_dtls(i).v_deleted_i
                                  || ' CRT_ON_DT: '
                                  || lv_usr_dtls(i).v_crt_on_dt
                                  || ' LST_UPD_ON_DT: '
                                  || lv_usr_dtls(i).v_lst_upd_on_dt
                                  || ' CRT_BY_N: '
                                  || lv_usr_dtls(i).v_crt_by_n
                                  || ' LST_UPD_BY_N: '
                                  || lv_usr_dtls(i).v_lst_upd_by_n
                                  || ' FAILED_ATTEMPTS_I: '
                                  || lv_usr_dtls(i).v_failed_attempts_i;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', v_err_msg, 'ERROR'

                    , NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_usr_dtls;
    /*
    OPEN cr_usr_privledge;
    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_PRIVLEDGE', 'PROC_2_PUSH_USR', 'INSERTION INTO TARGET TABLE AUTHENTICATION_SERVICE.USR_PRIVLEDGE'
    , 'START', NULL, NULL, NULL, NULL);

    LOOP
-------------************ Fetching records form MSW_DATA_MIGRATION.ORG_PRIVLEDGE and inseting into target table AUTHENTICATION_SERVICE.ORG_PRIVLEDGE ************------------------        
        FETCH cr_usr_privledge BULK COLLECT INTO lv_usr_priviledges LIMIT 10000;
        EXIT WHEN lv_usr_priviledges.count = 0;
        FOR k IN lv_usr_priviledges.first..lv_usr_priviledges.last LOOP			
-------------************ SYN_ORG_PRIVLEDGE is synonym of AUTHENTICATION_SERVICE.ORG_PRIVLEDGE  ************------------------  
            BEGIN
                INSERT INTO syn_usr_privileges (
                    usr_dtls_id_n,
                    usr_privilege_id_n
                ) VALUES (
                    lv_usr_priviledges(k).usr_dtls_id_n,
                    lv_usr_priviledges(k).usr_privilege_id_n
                );

            EXCEPTION
                WHEN OTHERS THEN
                    v_err_code := sqlcode;
                    v_err_msg := substr(sqlerrm, 1, 200);
                    v_sqlerrm := v_err_code
                                 || v_err_msg
                                 || dbms_utility.format_error_stack;
                    v_exp_rows := ' USR_DTLS_ID_N: '
                                  || lv_usr_priviledges(k).usr_dtls_id_n
                                  || ' USR_PRIVILEGE_ID_N: '
                                  || lv_usr_priviledges(k).usr_privilege_id_n;

                    pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_PRIVLEDGE', 'PROC_1_PUSH_ORG_PRIVLEDGE'

                    , v_err_msg, 'ERROR', NULL, v_sqlerrm, v_exp_rows, 'T');

            END;
        END LOOP;

        COMMIT;
    END LOOP;

    CLOSE cr_usr_privledge;
    */
    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_dtls
    FROM
        syn_usr_dtls;
/*
    SELECT
        COUNT(*)
    INTO lv_cnt_tt_ud_priv
    FROM
        syn_usr_privileges;
*/
    IF ( lv_cnt_tt_ud_dtls = lv_cnt_dm_ud_dtls ) AND lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_dtls
                                                                                                         || ' OUT OF '
                                                                                                         || lv_cnt_tt_ud_dtls
                                                                                                         || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.USR_DTLS'
                                                                                                         , 'SUCCESS', NULL, NULL,
                                                                                                         NULL, NULL);
    ELSIF lv_cnt_dm_ud_dtls <> lv_cnt_tt_ud_dtls AND lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_dtls
                                                                                                         || ' OUT OF '
                                                                                                         || lv_cnt_tt_ud_dtls
                                                                                                         || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.USR_DTLS'
                                                                                                         , 'PARTIALLY SUCCESSFULL'
                                                                                                         , NULL, NULL, NULL, NULL
                                                                                                         );
    ELSIF lv_cnt_dm_ud_dtls <> 0 AND lv_cnt_tt_ud_dtls = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_dtls
                                                                                                         || ' OUT OF '
                                                                                                         || lv_cnt_tt_ud_dtls
                                                                                                         || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.USR_DTLS'
                                                                                                         , 'FAIL', NULL, NULL, NULL
                                                                                                         , NULL);
    END IF;
/*
    IF ( lv_cnt_tt_ud_priv = lv_cnt_dm_ud_priv ) AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_PRIVLEDGE', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'SUCCESS', NULL, NULL
                                                                                                              , NULL, NULL);
    ELSIF lv_cnt_dm_ud_priv <> lv_cnt_tt_ud_priv AND lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_PRIVLEDGE', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'PARTIALLY SUCCESSFULL'
                                                                                                              , NULL, NULL, NULL,
                                                                                                              NULL);
    ELSIF lv_cnt_dm_ud_priv <> 0 AND lv_cnt_tt_ud_priv = 0 THEN
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_PRIVLEDGE', 'PROC_2_PUSH_USR', lv_cnt_dm_ud_priv
                                                                                                              || ' OUT OF '
                                                                                                              || lv_cnt_tt_ud_priv
                                                                                                              || ' ROWS  HAVE BEEN INSERTED INTO AUTHENTICATION_SERVICE.ORG_PRIVLEDGE'
                                                                                                              , 'FAIL', NULL, NULL
                                                                                                              , NULL, NULL);
    END IF;
*/
    pkg_datamigration_generic.proc_migration_recon('DM_USR_DTLS', lv_cnt_dm_ud_dtls, 'USR_DTLS'

    , lv_cnt_tt_ud_dtls, 'Y');
    --pkg_datamigration_generic.proc_migration_recon('DM_USR_PRIVLEDGE', lv_cnt_dm_ud_priv, 'USR_PRIVLEDGE', lv_cnt_tt_ud_priv, 'Y');
EXCEPTION
    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 200)
                     || dbms_utility.format_error_backtrace;
        v_sqlerrm := v_err_code || v_err_msg;
        pkg_datamigration_generic.proc_trace_exception('MSW_DATA_MIGRATION.USR_DTLS', 'PROC_2_PUSH_USR', v_sqlerrm, 'ERROR', NULL
        , NULL, NULL, 'T');

END PROC_1_PUSH_USR_DTLS;
/