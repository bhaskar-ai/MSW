sh Load_Masters_Apps.sh 2>&1 | tee transform.log
