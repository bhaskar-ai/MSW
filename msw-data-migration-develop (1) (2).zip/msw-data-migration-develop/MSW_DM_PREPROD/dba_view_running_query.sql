set linesize 1000;
set pagesize 10000;
set heading on;
SET TRIMOUT on;
SET ECHO ON;

column USERNAME format a50;
spool dba_view_running_query.txt

select S.USERNAME, s.sid,s.serial#, t.sql_id, sql_text
from v$sqltext_with_newlines t,V$SESSION s, v$process p
where t.address =s.sql_address
and t.hash_value = s.sql_hash_value
and s.status = 'ACTIVE'
and s.username <> 'SYSTEM'
AND s.paddr = p.addr
order by s.sid,t.piece;

spool off;