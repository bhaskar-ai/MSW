sh runSrcSQLLoader.sh 2>&1 | tee 02_load_source_data.log
