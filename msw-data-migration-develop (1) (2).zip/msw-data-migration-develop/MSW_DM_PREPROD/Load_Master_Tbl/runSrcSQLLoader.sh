#!/bin/bash

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;
spool off;
EOF
varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vsl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
result=$?
sleep 5
sqlldr control=CV_vsl.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=VSL.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat VSL.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat VSL.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vsl','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vsl',$total_read,'ST_CV_vsl',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vsl.'
exit
fi
else
echo 'Data Already Loaded for CV_vsl'
exit
fi


sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCert' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_CV_vslCert.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=CV_vslCert.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_vslCert.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_vslCert.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCert','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vslCert',$total_read,'ST_CV_vslCert',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vslCert.'
exit
fi
else 
echo 'Data Already loaded for CV_vslCert'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_GDAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_GDAppln.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_GDAppln.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_GDAppln.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_GDAppln.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_GDAppln','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_GDAppln',$total_read,'ST_CV_GDAppln',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_GDAppln.'
#exit
fi
else
echo 'Data Already loaded for CV_GDAppln'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_pendingAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_pendingAppln.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_pendingAppln.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_pendingAppln.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_pendingAppln.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_pendingAppln','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_pendingAppln',$total_read,'ST_CV_pendingAppln',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_pendingAppln.'
#exit
fi
else
echo 'Data Already loaded for CV_pendingAppln'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_depGD' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_depGD.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_depGD.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_depGD.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_depGD.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_depGD','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_depGD',$total_read,'ST_CV_depGD',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_depGD.'
#exit
fi
else
echo 'Data Already loaded for CV_depGD'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_arrGD' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_arrGD.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_arrGD.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_arrGD.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_arrGD.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_arrGD','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_arrGD',$total_read,'ST_CV_arrGD',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_arrGD.'
#exit
fi
else
echo 'Data Already loaded for CV_arrGD'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_portClrceCertIssd' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_portClrceCertIssd.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_portClrceCertIssd.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_portClrceCertIssd.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_portClrceCertIssd.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_portClrceCertIssd','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_portClrceCertIssd',$total_read,'ST_CV_portClrceCertIssd',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_portClrceCertIssd.'
#exit
fi
else
echo 'Data Already loaded for CV_portClrceCertIssd'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCall' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_vslCall.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_vslCall.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_vslCall.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_vslCall.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCall','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vslCall',$total_read,'ST_CV_vslCall',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vslCall.'
#exit
fi
else
echo 'Data Already loaded for CV_vslCall'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_declrShyard' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_declrShyard.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_declrShyard.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_declrShyard.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_declrShyard.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_declrShyard','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_declrShyard',$total_read,'ST_CV_declrShyard',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_declrShyard.'
#exit
fi
else
echo 'Data Already loaded for CV_declrShyard.'
#exit
fi
sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_portClrceCertIssdHist' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_portClrceCertIssdHist.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_portClrceCertIssdHist.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_portClrceCertIssdHist.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_portClrceCertIssdHist.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_portClrceCertIssdHist','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_portClrceCertIssdHist',$total_read,'ST_CV_portClrceCertIssdHist',$load_cnt,'S');
EOF
else
echo 'Data load failed for CV_portClrceCertIssdHist.'
#exit
fi
else
echo 'Data Already loaded for CV_portClrceCertIssdHist.'
#exit
fi
sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_last10MeasuresFrMRLog' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_last10MeasuresFrMRLog.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_last10MeasuresFrMRLog.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_last10MeasuresFrMRLog.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_last10MeasuresFrMRLog.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_last10MeasuresFrMRLog','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_last10MeasuresFrMRLog',$total_read,'ST_PANS_last10MeasuresFrMRLog',$load_cnt,'S');
EOF
else
echo 'Data load failed for PANS_last10MeasuresFrMRLog.'
#exit
fi
else
echo 'Data Already loaded for PANS_last10MeasuresFrMRLog.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_pm4' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_pm4.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_pm4.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_pm4.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_pm4.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_pm4','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_pm4',$total_read,'ST_DG_pm4',$load_cnt,'S');
EOF
else
echo 'Data load failed for DG_pm4.'
#exit
fi
else
echo 'Data Already loaded dg_pm4.'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_PM4SUPPORTINGDOC' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_PM4SupportingDoc.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_PM4SUPPORTINGDOC.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_PM4SUPPORTINGDOC.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_PM4SUPPORTINGDOC.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_PM4SUPPORTINGDOC','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_DG_PM4SupportingDoc',$total_read,'ST_DG_PM4SupportingDoc',$load_cnt,'S');
EOF
else
echo 'Data load failed DG_PM4SUPPORTINGDOC.'
#exit
fi
else
echo 'Data Already loaded DG_PM4SUPPORTINGDOC.'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CM_docMetadata' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CM_docMetadata.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CM_docMetadata.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CM_docMetadata.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CM_docMetadata.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CM_docMetadata','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CM_docMetadata',$total_read,'ST_CM_docMetadata',$load_cnt,'S');
EOF
else
echo 'Data load failed CM_docMetadata.'
#exit
fi
else
echo 'Data Already loaded CM_docMetadata.'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_vslcall' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_vslCall.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_vslcall.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_vslcall.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_vslcall.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_vslcall','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_vslCall',$total_read,'ST_DG_vslCall',$load_cnt,'S');
EOF
else
echo 'Data load failed DG_vslcall.'
#exit
fi
else
echo 'Data Already loaded DG_vslcall.'
#exit
fi

sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PM4SUPPORTINGDOC_MAPPING' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PM4SUPPORTINGDOC_MAPPING.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PM4SUPPORTINGDOC_MAPPING.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PM4SUPPORTINGDOC_MAPPING.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PM4SUPPORTINGDOC_MAPPING.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PM4SUPPORTINGDOC_MAPPING','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PM4SUPPORTINGDOC_MAPPING',$total_read,'ST_PM4SUPPORTINGDOC_MAPPING',$load_cnt,'S');
EOF
else
echo 'Data load failed PM4SUPPORTINGDOC_MAPPING.'
#exit
fi
else
echo 'Data Already loaded PM4SUPPORTINGDOC_MAPPING.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_LAST10CALLSFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr readsize=2000000000 bindsize=2000000000 control=PANS_LAST10CALLSFRMRLOG.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_LAST10CALLSFRMRLOG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_LAST10CALLSFRMRLOG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_LAST10CALLSFRMRLOG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_LAST10CALLSFRMRLOG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_LAST10CALLSFRMRLOG',$total_read,'ST_PANS_LAST10CALLSFRMRLOG',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_LAST10CALLSFRMRLOG.'
#exit
fi
else
echo 'Data Already loaded for PANS_LAST10CALLSFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PANS_LAST10SHPTOSHPACTFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_LAST10SHPTOSHPACTFRMRLOG.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_LAST10SHPTOSHPACTFRMRLOG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_LAST10SHPTOSHPACTFRMRLOG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_LAST10SHPTOSHPACTFRMRLOG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PANS_LAST10SHPTOSHPACTFRMRLOG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_LAST10SHPTOSHPACTFRMRLOG',$total_read,'ST_PANS_LAST10SHPTOSHPACTFRMRLOG',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_LAST10SHPTOSHPACTFRMRLOG..'
#exit
fi
else
echo 'Data Already loaded PANS_LAST10SHPTOSHPACTFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_LAST10SHPTOSHPSECFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_LAST10SHPTOSHPSECFRMRLOG.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_LAST10SHPTOSHPSECFRMRLOG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_LAST10SHPTOSHPSECFRMRLOG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_LAST10SHPTOSHPSECFRMRLOG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_LAST10SHPTOSHPSECFRMRLOG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_LAST10SHPTOSHPSECFRMRLOG',$total_read,'ST_PANS_LAST10SHPTOSHPSECFRMRLOG',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_LAST10SHPTOSHPSECFRMRLOG..'
#exit
fi
else
echo 'Data Already loaded PANS_LAST10SHPTOSHPSECFRMRLOG.'
#exit
fi

#sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_PANSINFOFRMRLOG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_PANSINFOFRMRLOG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_PANSINFOFRMRLOG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_PANSINFOFRMRLOG',$total_read,'ST_PANS_PANSINFOFRMRLOG',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG..'
exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG.'
exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG2' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG2.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_PANSINFOFRMRLOG2.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_PANSINFOFRMRLOG2.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_PANSINFOFRMRLOG2.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG2','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_PANSINFOFRMRLOG2',$total_read,'ST_PANS_PANSINFOFRMRLOG2',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG2.'
#exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG2.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG3' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG3.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PANS_PANSINFOFRMRLOG3.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PANS_PANSINFOFRMRLOG3.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PANS_PANSINFOFRMRLOG3.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG3','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PANS_PANSINFOFRMRLOG3',$total_read,'ST_PANS_PANSINFOFRMRLOG3',$load_cnt,'S');
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG3.'
#exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG3.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_bwmc' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_bwmc.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PTMS_bwmc.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PTMS_bwmc.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PTMS_bwmc.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_bwmc','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PTMS_bwmc',$total_read,'ST_PTMS_bwmc',$load_cnt,'S');
EOF
else
echo 'Data load failed PTMS_bwmc.'
#exit
fi
else
echo 'Data Already loaded PTMS_bwmc.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_NOAFREFORM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_NOAFREFORM.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PTMS_NOAFREFORM.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PTMS_NOAFREFORM.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PTMS_NOAFREFORM.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_NOAFREFORM','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PTMS_NOAFREFORM',$total_read,'ST_PTMS_NOAFREFORM',$load_cnt,'S');
EOF
else
echo 'Data load failed.'
#exit
fi
else
echo 'Data Already loaded for PTMS_NOAFREFORM.'
#exit
fi

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_NOAFREFORMHIST' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_NOAFREFORMHIST.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PTMS_NOAFREFORMHIST.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PTMS_NOAFREFORMHIST.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PTMS_NOAFREFORMHIST.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_NOAFREFORMHIST','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PTMS_NOAFREFORMHIST',$total_read,'ST_PTMS_NOAFREFORM',$load_cnt,'S');
EOF
else
echo 'Data load failed.'
#exit
fi
else
echo 'Data Already loaded for PTMS_NOAFREFORMHIST.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_NOAFREFORMHIST' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_NOAFREFORMHIST.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PTMS_NOAFREFORM.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PTMS_NOAFREFORMHIST.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PTMS_NOAFREFORMHIST.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_NOAFREFORMHIST','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PTMS_NOAFREFORMHIST',$total_read,'ST_PTMS_NOAFREFORMHIST',$load_cnt,'S');
EOF
else
echo 'Data load failed for PTMS_NOAFREFORMHIST.'
#exit
fi
else
echo 'Data Already loaded for PTMS_NOAFREFORMHIST.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceDtl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_ntceDtl.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=HN_ntceDtl.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat HN_ntceDtl.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat HN_ntceDtl.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceDtl','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('HN_ntceDtl',$total_read,'ST_HN_ntceDtl',$load_cnt,'S');
EOF
else
echo 'Data load failed HN_ntceDtl..'
#exit
fi
else
echo 'Data Already loaded HN_ntceDtl.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceHdr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_ntceHdr.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=HN_ntceHdr.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat HN_ntceHdr.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat HN_ntceHdr.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceHdr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('HN_ntceHdr',$total_read,'ST_HN_ntceHdr',$load_cnt,'S');
EOF
else
echo 'Data load failed HN_ntceHdr.'
#exit
fi
else
echo 'Data Already loaded HN_ntceHdr.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_SUBSTPARAM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_substParam.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=HN_substParam.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat HN_substParam.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat HN_substParam.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_SUBSTPARAM','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('HN_substParam',$total_read,'ST_HN_substParam',$load_cnt,'S');
EOF
else
echo 'Data load failed HN_SUBSTPARAM.'
#exit
fi
else
echo 'Data Already loaded HN_SUBSTPARAM.'
#exit
fi


sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_subRisk' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_subRisk.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_subRisk.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_subRisk.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_subRisk.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_subRisk','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_subRisk',$total_read,'ST_DG_subRisk',$load_cnt,'S');
EOF
else
echo 'Data load failed DG_subRisk.'
#exit
fi
else
echo 'Data Already loaded DG_subRisk.'
#exit
fi



sleep 5
sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_CHEM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_CHEM.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_CHEM.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_CHEM.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_CHEM.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_CHEM','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_CHEM',$total_read,'ST_DG_CHEM',$load_cnt,'S');
EOF
else
echo 'Data load failed to load into DG_CHEM..'
#exit
fi
else
echo 'Data Already loaded DG_CHEM.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_PSN' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_PSN.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=DG_PSN.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_PSN.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_PSN.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_PSN','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_PSN',$total_read,'ST_DG_PSN',$load_cnt,'S');
EOF
else
echo 'Data load failed to load into DG_PSN..'
#exit
fi
else
echo 'Data Already loaded DG_PSN.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_cruiseOperCtrl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_cruiseOperCtrl.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_cruiseOperCtrl.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_cruiseOperCtrl.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_cruiseOperCtrl.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_cruiseOperCtrl','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_cruiseOperCtrl',$total_read,'ST_CV_cruiseOperCtrl',$load_cnt,'S');
EOF
else
echo 'Data load failed to load into CV_cruiseOperCtrl.'
#exit
fi
else
echo 'Data Already loaded CV_cruiseOperCtrl'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_chgAgtAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_chgAgtAppln.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_chgAgtAppln.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_chgAgtAppln.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_chgAgtAppln.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_chgAgtAppln','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_chgAgtAppln',$total_read,'ST_CV_chgAgtAppln',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_chgAgtAppln.'
#exit
fi
else
echo 'Data Already loaded CV_chgAgtAppln.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_vslCall' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_vslCall.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=PTMS_vslCall.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PTMS_vslCall.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PTMS_vslCall.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_vslCall','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PTMS_vslCall',$total_read,'ST_PTMS_vslCall',$load_cnt,'S');
EOF
else
echo 'Data load failed PTMS_vslCall.'
#exit
fi
else
echo 'Data Already loaded PTMS_vslCall.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCertSubmissn' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_vslCertSubmissn.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_vslCertSubmissn.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_vslCertSubmissn.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_vslCertSubmissn.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCertSubmissn','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vslCertSubmissn',$total_read,'ST_CV_vslCertSubmissn',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vslCertSubmissn.'
#exit
fi
else
echo 'Data Already loaded CV_vslCertSubmissn.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCertSubmissnAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_vslCertSubmissnAppln.ctl userid=MSW_DATA_MIGRATION_UAT_DM/PASSWORD  log=CV_vslCertSubmissnAppln.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_vslCertSubmissnAppln.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_vslCertSubmissnAppln.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCertSubmissnAppln','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vslCertSubmissnAppln',$total_read,'ST_CV_vslCertSubmissnAppln',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vslCertSubmissnAppln.'
#exit
fi
else
echo 'Data Already loaded CV_vslCertSubmissnAppln.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_USRORG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_PU_usrOrg.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_PU_USRORG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_PU_USRORG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_PU_USRORG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_USRORG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_PU_usrOrg',$total_read,'ST_ST_PU_usrOrg',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_USRORG.'
#exit
fi
else
echo 'Data Already loaded PU_USRORG.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_portClrceSchmMstr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_PU_portClrceSchmMstr.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_PU_portClrceSchmMstr.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_PU_portClrceSchmMstr.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_PU_portClrceSchmMstr.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_portClrceSchmMstr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_PU_portClrceSchmMstr',$total_read,'ST_ST_PU_portClrceSchmMstr',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_portClrceSchmMstr.'
#exit
fi
else
echo 'Data Already loaded PU_portClrceSchmMstr.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_BONDSTATUS' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_BONDSTATUS.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_BONDSTATUS.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat BONDSTATUS.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat BONDSTATUS.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','BONDSTATUS','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('BONDSTATUS',$total_read,'ST_BONDSTATUS',$load_cnt,'S');
EOF
else
echo 'Data load failed ST_BONDSTATUS.'
#exit
fi
else
echo 'Data Already loaded ST_BONDSTATUS.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_ICA_USERROLES' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=USERROLE.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_ICA_USERROLES.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_ICA_USERROLES.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_ICA_USERROLES.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','USERROLE','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('USERROLE',$total_read,'ST_ICA_USERROLES',$load_cnt,'S');
EOF
else
echo 'Data load failed ST_ICA_USERROLES.'
#exit
fi
else
echo 'Data Already loaded ST_ICA_USERROLES.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_usr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_USR.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=XR_USR.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat XR_USR.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat XR_USR.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_usr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_USR',$total_read,'ST_XR_USR',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_usr.'
#exit
fi
else
echo 'Data Already loaded XR_usr.'
#exit
fi



sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_CoReg' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_COREG.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_XR_CoReg.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_XR_CoReg.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_XR_CoReg.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_CoReg','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_COREG',$total_read,'ST_XR_COREG',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_CoReg.'
#exit
fi
else
echo 'Data Already loaded XR_CoReg.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_COADDR' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_COADDR.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=ST_XR_COADDR.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_XR_COADDR.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_XR_COADDR.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_COADDR','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_COADDR',$total_read,'ST_XR_COADDR',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_COADDR.'
#exit
fi
else
echo 'Data Already loaded XR_COADDR.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profile' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profile.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_profile.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profile.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profile.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profile','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profile',$total_read,'ST_PU_profile',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profile.'
#exit
fi
else
echo 'Data Already loaded PU_profile.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profileContactMapper' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profileContactMapper.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_profileContactMapper.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profileContactMapper.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profileContactMapper.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profileContactMapper','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profileContactMapper',$total_read,'ST_PU_profileContactMapper',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profileContactMapper.'
#exit
fi
else
echo 'Data Already loaded PU_profileContactMapper.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrContact' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrContact.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_usrContact.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrContact.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrContact.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrContact','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrContact',$total_read,'ST_PU_usrContact',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrContact.'
#exit
fi
else
echo 'Data Already loaded PU_usrContact.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrIndv' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrIndv.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_usrIndv.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrIndv.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrIndv.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`

sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrIndv','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrIndv',$total_read,'ST_PU_usrIndv',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrIndv.'
#exit
fi
else
echo 'Data Already loaded PU_usrIndv.'
#exit
fi


sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profileAddrMapper' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profileAddrMapper.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_profileAddrMapper.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profileAddrMapper.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profileAddrMapper.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profileAddrMapper','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profileAddrMapper',$total_read,'ST_PU_PROFILEADDRMAPPER',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profileAddrMapper.'
#exit
fi
else
echo 'Data Already loaded PU_profileAddrMapper.'
#exit
fi

sleep 5

sqlplus -s MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrAddr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrAddr.ctl userid = MSW_DATA_MIGRATION_UAT_DM/PASSWORD log=PU_usrAddr.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrAddr.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrAddr.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_UAT_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrAddr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrAddr',$total_read,'ST_PU_USRADDR',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrAddr.'
#exit
fi
else
echo 'Data Already loaded PU_usrAddr.'
#exit
fi


sh rebuildindexes.sh

exit $result
