#!/bin/bash

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;
spool off;
EOF
varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profile' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profile.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_profile.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profile.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profile.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profile','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profile',$total_read,'ST_PU_profile',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profile.'
#exit
fi
else
echo 'Data Already loaded PU_profile.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profileContactMapper' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profileContactMapper.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_profileContactMapper.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profileContactMapper.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profileContactMapper.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profileContactMapper','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profileContactMapper',$total_read,'ST_PU_profileContactMapper',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profileContactMapper.'
#exit
fi
else
echo 'Data Already loaded PU_profileContactMapper.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrContact' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrContact.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_usrContact.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrContact.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrContact.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrContact','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrContact',$total_read,'ST_PU_usrContact',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrContact.'
#exit
fi
else
echo 'Data Already loaded PU_usrContact.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrIndv' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrIndv.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_usrIndv.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrIndv.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrIndv.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`

sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrIndv','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrIndv',$total_read,'ST_PU_usrIndv',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrIndv.'
#exit
fi
else
echo 'Data Already loaded PU_usrIndv.'
#exit
fi


sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profileAddrMapper' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profileAddrMapper.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_profileAddrMapper.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_profileAddrMapper.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_profileAddrMapper.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profileAddrMapper','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_profileAddrMapper',$total_read,'ST_PU_PROFILEADDRMAPPER',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_profileAddrMapper.'
#exit
fi
else
echo 'Data Already loaded PU_profileAddrMapper.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrAddr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrAddr.ctl userid = msw_data_migration/HcK8T7HN$ log=PU_usrAddr.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat PU_usrAddr.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat PU_usrAddr.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrAddr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('PU_usrAddr',$total_read,'ST_PU_USRADDR',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_usrAddr.'
#exit
fi
else
echo 'Data Already loaded PU_usrAddr.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_portClrceSchmMstr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_PU_portClrceSchmMstr.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_PU_portClrceSchmMstr.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_PU_portClrceSchmMstr.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_PU_portClrceSchmMstr.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_portClrceSchmMstr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_PU_portClrceSchmMstr',$total_read,'ST_ST_PU_portClrceSchmMstr',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_portClrceSchmMstr.'
#exit
fi
else
echo 'Data Already loaded PU_portClrceSchmMstr.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_USRORG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_PU_usrOrg.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_PU_USRORG.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_PU_USRORG.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_PU_USRORG.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_USRORG','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_PU_usrOrg',$total_read,'ST_ST_PU_usrOrg',$load_cnt,'S');
EOF
else
echo 'Data load failed PU_USRORG.'
#exit
fi
else
echo 'Data Already loaded PU_USRORG.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_COADDR' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_COADDR.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_XR_COADDR.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_XR_COADDR.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_XR_COADDR.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_COADDR','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_COADDR',$total_read,'ST_XR_COADDR',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_COADDR.'
#exit
fi
else
echo 'Data Already loaded XR_COADDR.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_CoReg' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_COREG.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_XR_CoReg.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_XR_CoReg.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_XR_CoReg.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_CoReg','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_COREG',$total_read,'ST_XR_COREG',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_CoReg.'
#exit
fi
else
echo 'Data Already loaded XR_CoReg.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='XR_usr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=XR_USR.ctl userid = msw_data_migration/HcK8T7HN$ log=XR_USR.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat XR_USR.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat XR_USR.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','XR_usr','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('XR_USR',$total_read,'ST_XR_USR',$load_cnt,'S');
EOF
else
echo 'Data load failed XR_usr.'
#exit
fi
else
echo 'Data Already loaded XR_usr.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_BONDSTATUS' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_BONDSTATUS.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_BONDSTATUS.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat BONDSTATUS.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat BONDSTATUS.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','BONDSTATUS','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('BONDSTATUS',$total_read,'ST_BONDSTATUS',$load_cnt,'S');
EOF
else
echo 'Data load failed ST_BONDSTATUS.'
#exit
fi
else
echo 'Data Already loaded ST_BONDSTATUS.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_ICA_USERROLES' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=USERROLE.ctl userid = msw_data_migration/HcK8T7HN$ log=ST_ICA_USERROLES.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_ICA_USERROLES.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_ICA_USERROLES.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','USERROLE','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('USERROLE',$total_read,'ST_ICA_USERROLES',$load_cnt,'S');
EOF
else
echo 'Data load failed ST_ICA_USERROLES.'
#exit
fi
else
echo 'Data Already loaded ST_ICA_USERROLES.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vsl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
result=$?
sleep 5
sqlldr control=CV_vsl.ctl userid=msw_data_migration/HcK8T7HN$ log=VSL.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat VSL.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat VSL.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vsl','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vsl',$total_read,'ST_CV_vsl',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vsl.'
exit
fi
else
echo 'Data Already Loaded for CV_vsl'
exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCert' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_CV_vslCert.ctl userid=msw_data_migration/HcK8T7HN$ log=CV_vslCert.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat CV_vslCert.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat CV_vslCert.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCert','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('CV_vslCert',$total_read,'ST_CV_vslCert',$load_cnt,'S');
EOF
else
echo 'Data load failed CV_vslCert.'
exit
fi
else 
echo 'Data Already loaded for CV_vslCert'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_PSN' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_PSN.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_PSN.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_PSN.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_PSN.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_PSN','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_PSN',$total_read,'DG_PSN',$load_cnt,'S');
EOF
else
echo 'Data load failed to load into DG_PSN..'
#exit
fi
else
echo 'Data Already loaded DG_PSN.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_subRisk' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_subRisk.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_subRisk.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_subRisk.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_subRisk.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_subRisk','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_subRisk',$total_read,'DG_subRisk',$load_cnt,'S');
EOF
else
echo 'Data load failed DG_subRisk.'
#exit
fi
else
echo 'Data Already loaded DG_subRisk.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_CHEM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_CHEM.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_CHEM.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat DG_CHEM.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat DG_CHEM.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_CHEM','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('DG_CHEM',$total_read,'DG_CHEM',$load_cnt,'S');
EOF
else
echo 'Data load failed to load into DG_CHEM..'
#exit
fi
else
echo 'Data Already loaded DG_CHEM.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_SUBSTPARAM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_substParam.ctl userid=msw_data_migration/HcK8T7HN$  log=HN_substParam.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat HN_substParam.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat HN_substParam.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_SUBSTPARAM','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('HN_substParam',$total_read,'ST_HN_substParam',$load_cnt,'S');
EOF
else
echo 'Data load failed HN_SUBSTPARAM.'
#exit
fi
else
echo 'Data Already loaded HN_SUBSTPARAM.'
#exit
fi

exit $result