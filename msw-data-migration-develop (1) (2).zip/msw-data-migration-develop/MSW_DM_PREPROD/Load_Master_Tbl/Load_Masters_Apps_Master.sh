#!/bin/bash
echo "Start of Data Migration"
echo "Start datetime: " date
SECONDS=0
sqlplus -s MSW_DATA_MIGRATION/HcK8T7HN <<EOF
spool on
spool DATA_MIGRATION.log
@ Load_Masters_Apps_Master.sql;
spool off;
EOF
echo "End datetime: " date
duration=$SECONDS
echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."
echo "End of Data Migration"

