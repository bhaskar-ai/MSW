#!/bin/bash
sqlldr control=ST_CV_vslCert.ctl userid=msw_data_migration/HcK8T7HN$ log=CV_vslCert.Log
result=$?

if [[ $result -eq 0 ]]
then
echo 'Data loaded successfully.'
else
echo 'Data load failed.'
exit
fi

sleep 10

sqlldr control=ST_CV_vsl.ctl userid=msw_data_migration/HcK8T7HN$ log=CV_vsl.Log
result=$?

if [[ $result -eq 0 ]]
then
echo 'Data loaded successfully.'
else
echo 'Data load failed.'
exit
fi


exit $result
