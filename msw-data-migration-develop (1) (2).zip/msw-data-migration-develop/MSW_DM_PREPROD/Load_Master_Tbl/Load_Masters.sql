set serveroutput on;
declare 
lv_cnt number;
begin
proc_1_vsl(lv_cnt,1);
if lv_cnt = 0 then 

 proc_1_vsl_cert_for(lv_cnt,1);
 if lv_cnt=0 then 
 proc_1_vsl_cert_Attr(1);
 dbms_output.put_line('ALl the master tables loaded successfully.');
 else 
   dbms_output.put_line('Vessel Cerificate Table not loaded successfully.');
 end if;
 else dbms_output.put_line('Vessel Table not loaded successfully.');
end if;

end;
/
