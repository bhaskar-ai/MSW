#!/bin/bash

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;
spool off;
EOF
varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vsl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
result=$?
sleep 5
sqlldr control=CV_vsl.ctl userid=msw_data_migration/HcK8T7HN$ log=VSL.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vsl','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_vsl.'
#exit
fi
else
echo 'Data Already Loaded for CV_vsl'
#exit
fi

sleep 5
sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCert' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_vslCert.ctl userid=msw_data_migration/HcK8T7HN$ log=CV_vslCert.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCert','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_vslCert.'
#exit
fi
else 
echo 'Data Already loaded for CV_vslCert'
#exit
fi

sleep 5


sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_SUBSTPARAM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_substParam.ctl userid=msw_data_migration/HcK8T7HN$  log=HN_substParam.log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_SUBSTPARAM','Y',SYSDATE);
EOF
else
echo 'Data load failed HN_SUBSTPARAM.'
#exit
fi
else
echo 'Data Already loaded HN_SUBSTPARAM.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_subRisk' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_SUBRISK.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_subRisk.log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_subRisk','Y',SYSDATE);
EOF
else
echo 'Data load failed DG_subRisk.'
#exit
fi
else
echo 'Data Already loaded DG_subRisk.'
#exit
fi

sleep 5
sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_CHEM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_CHEM.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_CHEM.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_CHEM','Y',SYSDATE);
EOF
else
echo 'Data load failed to load into DG_CHEM..'
#exit
fi
else
echo 'Data Already loaded DG_CHEM.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_PSN' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_PSN.ctl userid=msw_data_migration/HcK8T7HN$  log=DG_PSN.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_PSN','Y',SYSDATE);
EOF
else
echo 'Data load failed to load into DG_PSN..'
#exit
fi
else
echo 'Data Already loaded DG_PSN.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CM_docMetadata' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CM_docMetadata.ctl userid=msw_data_migration/HcK8T7HN$  log=CM_docMetadata.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN$ <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CM_docMetadata','Y',SYSDATE);
EOF
else
echo 'Data load failed to load into CM_docMetadata..'
#exit
fi
else
echo 'Data Already loaded CM_docMetadata.'
#exit
fi

exit $result