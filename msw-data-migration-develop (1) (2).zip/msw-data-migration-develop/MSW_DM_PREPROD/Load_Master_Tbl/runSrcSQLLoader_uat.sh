#!/bin/bash

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;
spool off;
EOF
varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vsl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
result=$?
sleep 5
sqlldr control=CV_vsl.ctl userid=msw_data_migration_uat/uattest123 log=VSL.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vsl','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_vsl.'
exit
fi
else
echo 'Data Already Loaded for CV_vsl'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCert' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_CV_vslCert.ctl userid=msw_data_migration_uat/uattest123 log=CV_vslCert.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCert','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_vslCert.'
exit
fi
else 
echo 'Data Already loaded for CV_vslCert'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_GDAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_GDAppln.ctl userid=msw_data_migration_uat/uattest123  log=CV_GDAppln.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_GDAppln','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_GDAppln.'
exit
fi
else
echo 'Data Already loaded for CV_GDAppln'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_pendingAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_pendingAppln.ctl userid=msw_data_migration_uat/uattest123  log=CV_pendingAppln.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_pendingAppln','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_pendingAppln.'
exit
fi
else
echo 'Data Already loaded for CV_pendingAppln'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_depGD' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_depGD.ctl userid=msw_data_migration_uat/uattest123  log=CV_depGD.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_depGD','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_depGD.'
exit
fi
else
echo 'Data Already loaded for CV_depGD'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_arrGD' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_arrGD.ctl userid=msw_data_migration_uat/uattest123  log=CV_arrGD.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_arrGD','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_arrGD.'
exit
fi
else
echo 'Data Already loaded for CV_arrGD'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_portClrceCertIssd' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_portClrceCertIssd.ctl userid=msw_data_migration_uat/uattest123  log=CV_portClrceCertIssd.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_portClrceCertIssd','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_portClrceCertIssd.'
exit
fi
else
echo 'Data Already loaded for CV_portClrceCertIssd'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCall' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_vslCall.ctl userid=msw_data_migration_uat/uattest123  log=CV_vslCall.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCall','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_vslCall.'
exit
fi
else
echo 'Data Already loaded for CV_vslCall'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_declrShyard' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_declrShyard.ctl userid=msw_data_migration_uat/uattest123  log=CV_declrShyard.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_declrShyard','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_declrShyard.'
#exit
fi
else
echo 'Data Already loaded for CV_declrShyard.'
#exit
fi
sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_portClrceCertIssdHist' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_portClrceCertIssdHist.ctl userid=msw_data_migration_uat/uattest123  log=CV_portClrceCertIssdHist.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_portClrceCertIssdHist','Y',SYSDATE);
EOF
else
echo 'Data load failed for CV_portClrceCertIssdHist.'
#exit
fi
else
echo 'Data Already loaded for CV_portClrceCertIssdHist.'
#exit
fi
sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_last10MeasuresFrMRLog' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_last10MeasuresFrMRLog.ctl userid=msw_data_migration_uat/uattest123  log=PANS_last10MeasuresFrMRLog.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_last10MeasuresFrMRLog','Y',SYSDATE);
EOF
else
echo 'Data load failed for PANS_last10MeasuresFrMRLog.'
#exit
fi
else
echo 'Data Already loaded for PANS_last10MeasuresFrMRLog.'
#exit
fi

#sleep 5

#sqlplus -s msw_data_migration_uat/uattest123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='st_dg_chem' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=dg_chem.ctl userid=msw_data_migration_uat/uattest123  log=dg_chem.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','dg_chem','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded for dg_chem.ctl'
#exit
#fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_pm4' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_pm4.ctl userid=msw_data_migration_uat/uattest123  log=DG_pm4.log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_pm4','Y',SYSDATE);
EOF
else
echo 'Data load failed for DG_pm4.'
#exit
fi
else
echo 'Data Already loaded dg_pm4.'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_PM4SUPPORTINGDOC' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_PM4SupportingDoc.ctl userid=msw_data_migration_uat/uattest123  log=DG_PM4SUPPORTINGDOC.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_PM4SUPPORTINGDOC','Y',SYSDATE);
EOF
else
echo 'Data load failed DG_PM4SUPPORTINGDOC.'
#exit
fi
else
echo 'Data Already loaded DG_PM4SUPPORTINGDOC.'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CM_docMetadata' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CM_docMetadata.ctl userid=msw_data_migration_uat/uattest123  log=CM_docMetadata.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CM_docMetadata','Y',SYSDATE);
EOF
else
echo 'Data load failed CM_docMetadata.'
#exit
fi
else
echo 'Data Already loaded CM_docMetadata.'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='DG_vslcall' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=DG_vslcall.ctl userid=msw_data_migration_uat/uattest123  log=DG_vslcall.log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','DG_vslcall','Y',SYSDATE);
EOF
else
echo 'Data load failed DG_vslcall.'
#exit
fi
else
/sleep 5/sleep 5/gcho 'Data Already loaded DG_vslcall.'
#exit
fi

sleep 5
sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PM4SUPPORTINGDOC_MAPPING' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=pm4SupportingDoc_mapping.ctl userid=msw_data_migration_uat/uattest123  log=PM4SUPPORTINGDOC_MAPPING.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PM4SUPPORTINGDOC_MAPPING','Y',SYSDATE);
EOF
else
echo 'Data load failed PM4SUPPORTINGDOC_MAPPING.'
#exit
fi
else
echo 'Data Already loaded PM4SUPPORTINGDOC_MAPPING.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_LAST10CALLSFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr readsize=2000000000 bindsize=2000000000 control=PANS_LAST10CALLSFRMRLOG.ctl userid=msw_data_migration_uat/uattest123  log=PANS_LAST10CALLSFRMRLOG.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_LAST10CALLSFRMRLOG','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_LAST10CALLSFRMRLOG.'
exit
fi
else
echo 'Data Already loaded for PANS_LAST10CALLSFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PANS_LAST10SHPTOSHPACTFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_LAST10SHPTOSHPACTFRMRLOG.ctl userid=msw_data_migration_uat/uattest123  log=PANS_LAST10SHPTOSHPACTFRMRLOG.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PANS_LAST10SHPTOSHPACTFRMRLOG','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_LAST10SHPTOSHPACTFRMRLOG..'
exit
fi
else
echo 'Data Already loaded PANS_LAST10SHPTOSHPACTFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_LAST10SHPTOSHPSECFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_LAST10SHPTOSHPSECFRMRLOG.ctl userid=msw_data_migration_uat/uattest123  log=PANS_LAST10SHPTOSHPSECFRMRLOG.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_LAST10SHPTOSHPSECFRMRLOG','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_LAST10SHPTOSHPSECFRMRLOG..'
#exit
fi
else
echo 'Data Already loaded PANS_LAST10SHPTOSHPSECFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG.ctl userid=msw_data_migration_uat/uattest123  log=PANS_PANSINFOFRMRLOG.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG..'
exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG2' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG2.ctl userid=msw_data_migration_uat/uattest123  log=PANS_PANSINFOFRMRLOG2.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG2','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG2.'
#exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG2.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG3' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PANS_PANSINFOFRMRLOG3.ctl userid=msw_data_migration_uat/uattest123  log=PANS_PANSINFOFRMRLOG3.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG3','Y',SYSDATE);
EOF
else
echo 'Data load failed PANS_PANSINFOFRMRLOG3.'
exit
fi
else
echo 'Data Already loaded PANS_PANSINFOFRMRLOG3.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_bwmc' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_bwmc.ctl userid=msw_data_migration_uat/uattest123  log=PTMS_bwmc.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_bwmc','Y',SYSDATE);
EOF
else
echo 'Data load failed.'
exit
fi
else
echo 'Data Already loaded.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_NOAFREFORM' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PTMS_NOAFREFORM.ctl userid=msw_data_migration_uat/uattest123  log=PTMS_NOAFREFORM.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_NOAFREFORM','Y',SYSDATE);
EOF
else
echo 'Data load failed.'
#exit
fi
else
echo 'Data Already loaded for PTMS_NOAFREFORM.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceDtl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_ntceDtl.ctl userid=msw_data_migration_uat/uattest123  log=HN_ntceDtl.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceDtl','Y',SYSDATE);
EOF
else
echo 'Data load failed HN_ntceDtl..'
#exit
fi
else
echo 'Data Already loaded HN_ntceDtl.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceHdr' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=HN_ntceHdr.ctl userid=msw_data_migration_uat/uattest123  log=HN_ntceHdr.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceHdr','Y',SYSDATE);
EOF
else
echo 'Data load failed HN_ntceHdr.'
#exit
fi
else
echo 'Data Already loaded HN_ntceHdr.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_chgAgtAppln' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=CV_chgAgtAppln.ctl userid=msw_data_migration_uat/uattest123  log=CV_chgAgtAppln.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_chgAgtAppln','Y',SYSDATE);
EOF
else
echo 'Data load failed CV_chgAgtAppln.'
#exit
fi
else
echo 'Data Already loaded CV_chgAgtAppln.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profile' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profile.ctl userid=msw_data_migration_uat/uattest123  log=PU_profile.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profile','Y',SYSDATE);
EOF
else
echo 'Data load failed PU_profile.'
#exit
fi
else
echo 'Data Already loaded PU_profile.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_profileContactMapper' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_profileContactMapper.ctl userid=msw_data_migration_uat/uattest123  log=PU_profileContactMapper.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_profileContactMapper','Y',SYSDATE);
EOF
else
echo 'Data load failed PU_profileContactMapper.'
#exit
fi
else
echo 'Data Already loaded PU_profileContactMapper.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrContact' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrContact.ctl userid=msw_data_migration_uat/uattest123  log=PU_usrContact.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrContact','Y',SYSDATE);
EOF
else
echo 'Data load failed PU_usrContact.'
#exit
fi
else
echo 'Data Already loaded PU_usrContact.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrIndv' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrIndv.ctl userid=msw_data_migration_uat/uattest123  log=PU_usrIndv.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrIndv','Y',SYSDATE);
EOF
else
echo 'Data load failed PU_usrIndv.'
#exit
fi
else
echo 'Data Already loaded PU_usrIndv.'
#exit
fi

sleep 5

sqlplus -s msw_data_migration_uat/uattest123 <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PU_usrOrg' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=PU_usrOrg.ctl userid=msw_data_migration_uat/uattest123  log=PU_usrOrg.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration_uat/uattest123 <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PU_usrOrg','Y',SYSDATE);
EOF
else
echo 'Data load failed PU_usrOrg.'
#exit
fi
else
echo 'Data Already loaded PU_usrOrg.'
#exit
fi

sleep 5
exit $result
