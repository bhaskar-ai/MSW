#!/bin/bash

sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;
spool off;
EOF
varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'

sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_ORGCD_UEN' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_ORGCD_UEN.ctl userid = MSW_DATA_MIGRATION_DM/PASSWORD log=ST_ORGCD_UEN.log
result=$?
if [[ $result -eq 0 ]]
then
total_read=`cat ST_ORGCD_UEN.log|grep 'Total logical records read:'|grep -o '[0-9]*'`
load_cnt=`cat ST_ORGCD_UEN.log|grep 'Rows successfully loaded.'|grep -o '[0-9]*'`
sqlplus -s  MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_ORGCD_UEN','Y',SYSDATE);
execute PKG_DATAMIGRATION_GENERIC.PROC_migration_Recon('ST_ORGCD_UEN',$total_read,'ST_ORGCD_UEN',$load_cnt,'S');
EOF
else
echo 'Data load failed ST_ORGCD_UEN.'
#exit
fi
else
echo 'Data Already loaded ST_ORGCD_UEN.'
#exit
fi

exit $result