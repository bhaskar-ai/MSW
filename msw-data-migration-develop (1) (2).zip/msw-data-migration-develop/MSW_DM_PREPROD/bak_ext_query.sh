o "Start of Data Extaction"
sqlplus / as sysdba <<EOF
set pagesize 50000;
set define off;
set markup html on
spool /tmp/uat_db.xls

select * from all_tab_columns where owner in ('MSW_DATA_MIGRATION',
'MSW_E_SUBMISSN',
'MSW_NOTIFN_SCV',
'MSW_CODESET_SCV',
'MSW_SYS_CNFG_SVC',
'MSW_VSL_SVC',
'MSW_NEA_INTEGRATION',
'MSW_HNS_SVC',
'MSW_DGDS_INTEGRATION',
'MSW_DATA_AGGREGATION',
'MSW_ICA_INTEGRATION',
'MSW_DOC_MGT',
'MSW_CVS_INTEGRATION',
'MSW_TASK_SCHEDULER',
'MSW_USR_SVC',
'MSW_PANS_NOAS_INTEGRATION'
) order by owner, table_name,column_name;

spool off
EOF

