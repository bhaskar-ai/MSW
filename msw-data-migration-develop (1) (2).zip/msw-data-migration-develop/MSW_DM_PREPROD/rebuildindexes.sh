#!/bin/bash
sqlplus -s msw_data_migration_dm/PASSWORD$<<EOF
@Rebuildindexes.sql
EOF
echo "End of Rebuilding Index script"
