#!/bin/bash
echo "Start of Data Extaction"
#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/VESSEL.xls
#select MSW_VSL_ID_N,VSL_REC_ID_N,VSL_M,OFFICIAL_N,VSL_FLAG_C,(select  VSL_TY_C from vessel_type where VSL_TYPE_ID_N=v.VSL_TYPE_ID_N) as VESSEL_TYPE,(select  VSL_CRAFT_TY_C from craft_type where CRAFT_TYPE_ID_N=v.CRAFT_TYPE_ID_N) as CRAFT_TYPE,VSL_DWT_N,ST_C,VSL_CRAFT_LIC_N,VSL_ATTAINABLE_HGT_Q,VSL_YR_BLT_N,PORT_OF_REGY_C,PORT_N,VSL_LEN_Q,LOA_Q,VSL_DEPTH_Q,VSL_BRE_Q,MECHANIC_PROPEL_I,VSL_MMSI_N,LOCK_VER_N,CRT_ON_DT,CRT_BY_X,UPT_ON_DT,UPT_BY_X,GRS_TNG_N,NET_TNG_N,VSL_CALL_SIGN_N,VSL_IMO_N,VSL_OWNR,DELETED_I,DELIVERY_DT,BOW_BRIDGE,BOW_THRUSTER,STERN_THRUSTER,DBL_HULL_CONSTRUCT_I,APPR_FOR_SEA_TRIAL_I,LAUNCH_ON_DT,MERGE_FR_TO_VSL_REC_ID,BARTER_TRADE_I,BARE_BOAT_CHARTER_OUT_I,TRANSIT_I,UNOFFICIAL_VSL_M,UNOFFCIAL_VSL_CALL_SIGN,UNOFFICIAL_VSL_TY_C,UNOFFICIAL_VSL_FLAG_C,UNOFFICIAL_VSL_GT,GT_FROM_E_PAN_Q,GT_FROM_E_PAN_DT,BUILDER_M,OWNER_CTRY_C,VSL_BUILT_PLACE_C from VESSEL V;
#spool off
#EOF

#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 700 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/VESSEL_CERTIFICATE.xls
#select * from VESSEL_CERTIFICATE;
#spool off
#EOF

#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 700 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/VESSEL_CERTIFICATE_ATTRIBUTES.xls
#select * from VESSEL_CERTIFICATE_ATTRIBUTES;
#spool off
#EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/arrival_gd_application.xls
select * from arrival_gd_application;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/arrival_gd_purpose_of_call.xls
select * from arrival_gd_purpose_of_call;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/arrival_gd_purpose_of_call_shipyard_loc.xls
select * from  arrival_gd_purpose_of_call_shipyard_loc;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/departure_gd_application.xls
select * from departure_gd_application;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/departure_gd_purpose_of_call.xls
select * from departure_gd_purpose_of_call;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/dep_gd_p_clrce_certL.xls
select * from dep_gd_p_clrce_cert;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/HNS_APPLICATION_SUBSTANCE.xls
select * from HNS_APPLICATION_SUBSTANCE;
spool off
EOF

#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/HNS_APPLICATION.xls
#select * from HNS_APPLICATION;
#spool off
#EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
col COMPB_GRP_C for a10
col WASTE_I for a7
col TANK_CNTR_I for a15
col SUBR_EMAIL_I for a15
col SUBR_SMS_I for a15
col DGS_DECLRD_I for a15
col RESIDUE_I for a10
set markup html on
spool /tmp/DM_DATA_LOG/DANGEROUS_GOODS_APPLICATION.xls
select APPLN_REF_N ,EXTL_APPLN_REF_X ,APPLCNT_ID_X ,MSW_APPLN_REF_ID_X ,VSL_CALL_ID_N ,CONT_PERS_M ,MOBILE_N ,ETA_DT ,RTA_DT ,IN_VOY_X ,OUT_VOY_X ,ETD_DT ,OPERN_C ,LOCN_C ,CNTR_X ,UCR_X ,IMO_CL_C ,UN_X ,PSN_N ,TN_N ,PKG_TY_C ,PKG_TY_OTHERS_X ,FLASH_PT_N ,COMPB_GRP_C ,WT_N ,WASTE_I ,RESIDUE_I ,BL_X ,SUB_RISK_C ,TANK_CNTR_I ,ST_C ,PROCESSING_REM_X ,PROCESSED_BY_X ,PROCESSED_ON_DT ,DELETED_I ,LOCK_VER_N ,CRT_BY_X ,CRT_ON_DT ,UPT_BY_X ,UPT_ON_DT ,SUBR_EMAIL_I ,EMAIL_X ,SUBR_SMS_I ,USR_INPUT_VSL_M ,DGS_DECLRD_I ,CFT_LIC_X  from DANGEROUS_GOODS_APPLICATION;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/DANGEROUS_GOODS_APPLICATION_DOCUMENT.xls
select * from DANGEROUS_GOODS_APPLICATION_DOCUMENT;
spool off
EOF


#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 700 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/tbl_trace_migration.xls
#select * from tbl_trace_migration where rownum<5000;
#spool off
#EOF

#sqlplus -s msw_data_migration/HcK8T7HN <<EOF
#set lines 700 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/tbl_migration_recon.xls
#select * from tbl_migration_recon;
#spool off
#EOF
