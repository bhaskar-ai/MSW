#!/bin/bash
echo "Start of Report"
sqlplus -s msw_data_migration_dhar/HcK8T7HN <<EOF
set lines 200 pages 200
set markup html on
spool /tmp/dm_recon.xls
select * from table(fnc_recon_rep());
spool off;
EOF
echo "End of Report"

