set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--DBMS_OUTPUT.PUT_line('1');
--Documents
PROC_PROCESS_CERT(lv_runid);
PROC_PROCESS_DOC(lv_runid);
PROC_PROCESS_DOC_DEP_GD(lv_runid);
--Push Documents
PROC_1_PUSH_DOC;
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
end;
/
