create or replace SYNONYM vsl_srl for    VESSEL_SERVICE.ISEQ$$_97014 ;

create or replace synonym vsl_typ_srl for  VESSEL_SERVICE.ISEQ$$_97008;

create or replace synonym crft_typ_srl for  VESSEL_SERVICE.ISEQ$$_97011;

create or replace synonym seq_vsl_cert_Att for VESSEL_SERVICE.ISEQ$$_97020;

create or replace synonym seq_vsl_cert for VESSEL_SERVICE.ISEQ$$_97017;

create or replace synonym SEQ_PAN_purp for PANS_NOAS_INTEGRATION.ISEQ$$_97033;

create or replace synonym SEQ_PAN_SHP_ACT for PANS_NOAS_INTEGRATION.ISEQ$$_97036;

create or replace synonym SEQ_PAN_SHP_CERT for PANS_NOAS_INTEGRATION.ISEQ$$_97039;

create or replace synonym SEQ_PAN_APP for PANS_NOAS_INTEGRATION.ISEQ$$_97030;

create or replace synonym ARR_GD_APPLN_SEQ for CVS_INTEGRATION.ISEQ$$_100815;

create or replace synonym ARR_GD_POC_SEQ for CVS_INTEGRATION.ISEQ$$_100818;

create or replace synonym seq_dep_gd_app for CVS_INTEGRATION.ISEQ$$_100824;

create or replace synonym seq_dep_gd_poc for CVS_INTEGRATION.ISEQ$$_100827;

create or replace synonym seq_depgd_porttlid_n for CVS_INTEGRATION.ISEQ$$_100845;

create or replace synonym seq_dg_appl for DGDS_INTEGRATION.ISEQ$$_101438;

create or replace synonym seq_dg_appl_doc for DGDS_INTEGRATION.ISEQ$$_101441;

create or replace synonym hns_app_seq for HNS_SERVICE.ISEQ$$_101351;

create or replace synonym hns_appsub_seq for HNS_SERVICE.ISEQ$$_101354;