#!/bin/bash
echo "Start of Data Extraction"

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/APPLICATION_SUBMISSION_GDD.xls
#SELECT * FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C='GDD';
#spool off
#EOF


#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/VESSEL_CALL_GDD.xls
#select * from VESSEL_CALL WHERE VSL_CALL_ID_N IN (SELECT VSL_CALL_ID_N FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C='GDD');
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/VESSEL_REFERENCE_GDD.xls
#select * from VESSEL_REFERENCE WHERE VSL_REF_ID_N IN (SELECT VSL_REF_ID_N FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C='GDD');
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/departure_gd_application.xls
#select * from departure_gd_application;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/departure_gd_purpose_of_call.xls
#select * from departure_gd_purpose_of_call;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_Pre_Prod_Log/dep_gd_p_clrce_cert.xls
#select * from dep_gd_p_clrce_cert;
#spool off
#EOF

sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
set lines 25000 pages 200
set markup html on
spool /tmp/DM_Pre_Prod_Log/Recon_GDD.xls
SELECT * FROM tbl_migration_recon where upper(target_tbl) like '%DEP%' order by serial_no;
spool off
EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/PAN_PURPOSE_OF_CALL.xls
#SELECT * FROM PAN_PURPOSE_OF_CALL;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/PAN_SHIP_ACTIVITY.xls
#SELECT * FROM PAN_SHIP_ACTIVITY;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/PAN_SHIP_CERTIFICATE.xls
#SELECT * FROM PAN_SHIP_CERTIFICATE;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/PAST_PORT_CALLS.xls
#SELECT * FROM PAST_PORT_CALLS;
#spool off
#EOF
