#!/bin/bash
echo "Start of Data Migration"
echo "Start datetime: " date
SECONDS=0
sqlplus -s msw_data_migration_dm/PASSWORD<<EOF
spool on
spool DATA_MIGRATION.log
--Masters and User Profile
--@ Load_Masters.sql;
--ICA Migration 
--@ Load_ICA.sql;
@ Load_Masters_Apps.sql;
--Transacformation with Vessel Call Tagging for Transaction Tables
--@Load_Transactions_VesselCall_Tag.sql;
--Transformation and without Vessel Call tagging
--@Load_Transactions.sql;
/*Document Migration. Please call it after Load_Transactions_VesselCall_Tag.sql or Load_Transactions.sql */
--@Load_Documents.sql;
--UEN with null 
@Load_UEN.sql;
spool off;
EOF
echo "End datetime: " date
duration=$SECONDS
echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."
echo "End of Data Migration"

