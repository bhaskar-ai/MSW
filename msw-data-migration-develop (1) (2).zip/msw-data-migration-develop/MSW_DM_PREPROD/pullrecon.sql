set linesize 150;
set pagesize 10000;
set heading on;
SET TRIMOUT on;
SET ECHO ON;

--column OWNER format a30;
--column table_name format a30;
--column DATA_DEFAULT format a50;

SPOOL recon_prd.txt

SELECT SERIAL_NO, DM_TIME, SOURCE_TABLE, SOURCE_TBL_COUNT, TARGET_TBL, TARGET_TBL_COUNT, FLAG FROM MSW_DATA_MIGRATION.TBL_MIGRATION_RECON;

SPOOL OFF;