#!/bin/bash
echo "Start of Verification"
sqlplus -s MSW_DATA_MIGRATION_DM/PASSWORD <<EOF
SET PAGESIZE 50000
Set define off;
set echo on;
SET MARKUP HTML ON

SPOOL DMVerificationResult.xls
@ VerificationSQLs.sql

set echo off;
SET MARKUP HTML OFF
SPOOL OFF;

EOF
echo 'End of Script'