#!/bin/bash
echo "Start of Deployment"
sqlplus -s msw_data_migration/HcK8T7HN$ <<EOF
spool on
spool  clean_up_deploy.log
@ clean_up_deploy.sql;
spool off;
EOF
echo 'End of Script'
