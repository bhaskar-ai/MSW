set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--User Profile
PROC_1_ORG_CODE(lv_runid);
PROC_1_USR_DTLS(lv_runid);
PROC_1_USR_DTLS_PU(lv_runid);
PROC_1_ORG_DTLS(lv_runid);
PROC_1_ORG_DTLS_PU(lv_runid);
PROC_1_ORG_PRIVILEGES(lv_runid);
PROC_1_ORG_ST_AUDIT(lv_runid);
-- Master
proc_1_vsl(lv_cnt,lv_runid);
proc_1_vsl_cert_for(lv_cnt,lv_runid);
proc_1_vsl_cert_Attr(lv_runid);
PROC_1_SUBSTANCE(lv_runid);
PROC_1_CRUISE_OPERATOR_CONTROL(lv_runid);
PROC_2_PATCH_VESSEL_AGENT;
-- Push User Profile
PROC_5_PUSH_ORG;
PROC_5_PUSH_ORG_ST_AUDIT;
PROC_2_PUSH_USR;
-- Push Master
PROC_3_PUSH_MASTERS;
PROC_2_PUSH_DGCHEM_DGPSN;
PROC_1_PUSH_DGSUBRISK;
PROC_1_PUSH_SUBSTANCE;
PROC_1_PUSH_COC;
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
end;
/
