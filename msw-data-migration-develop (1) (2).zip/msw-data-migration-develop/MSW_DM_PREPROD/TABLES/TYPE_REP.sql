create or replace type &DM_SCHEMA_NAME..typ_Recon_rep
as object 
(
APPL_NAME	        VARCHAR2(10) ,
SRC_TBL	            VARCHAR2(40) ,
SRC_FILE_REC_CNT	NUMBER(10) ,
SRC_TBL_LOAD_CNT	NUMBER(10) ,
DIFF_SRC_CNT	    NUMBER(10) ,
DM_LOGIC	        VARCHAR2(200) ,
DM_SI_CNT	        NUMBER(10) ,
DM_TARGET_TBL_NAME	VARCHAR2(40),
DM_TARGET_CNT	    NUMBER(10) , 
MSW_TARGET_CNT	    NUMBER(10) ,
DIFF_DM_MSW_CNT	    NUMBER(10));

/
create or replace type &DM_SCHEMA_NAME..tbl_typ_Recon_rep
as table of &DM_SCHEMA_NAME..typ_Recon_rep;
/