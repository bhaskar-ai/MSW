set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--DBMS_OUTPUT.PUT_line('1');
--UEN Null
PROC_1_ORG_CODE_UPDATE(lv_runid);
PROC_1_ORG_DTLS_UPDATE(lv_runid);
PROC_1_ORG_ST_AUDIT_UPDATE(lv_runid);
--Push UEN Null
--Please uncomment after testing is done in DM schema
--PROC_3_PUSH_ORG;
--PROC_5_PUSH_ORG_ST_AUDIT;
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
end;
/
