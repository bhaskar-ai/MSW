spool './cleanup_script.log';
set linesize 200;
--set trimspool on;
set trimout on;
set pagesize 50000;

------------------
-- Disable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' disable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/


truncate table APPLICATION_SUBMISSION;
truncate table ARRIVAL_GD_APPLICATION;
truncate table ARRIVAL_GD_PURPOSE_OF_CALL;
truncate table ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC;
truncate table AUTH_PROFILE;
truncate table CREW_CO_REQ;
truncate table CRIUSE_OPERATOR_CONTROL;
truncate table CHANGE_AGENCY_APPLICATION;
truncate table DANGEROUS_GOODS_APPLICATION;
truncate table DANGEROUS_GOODS_APPLICATION_DOCUMENT;
truncate table DEP_GD_P_CLRCE_CERT;
truncate table DEP_GD_PURP_OF_CALL_SYARD_LOC;
truncate table DEPARTURE_GD_APPLICATION;
truncate table DEPARTURE_GD_PURPOSE_OF_CALL;
truncate table DG_CHEM;
truncate table DG_PSN;
truncate table DG_PSA_JPC;
truncate table DG_SUBRISK;
truncate table DOC;
truncate table GD_DOC;
truncate table HNS_APPLICATION;
truncate table HNS_APPLICATION_SUBSTANCE;
truncate table ICA_USR_REQUEST;
truncate table ORG_CODE;
truncate table ORG_DTLS;
truncate table ORG_PRIVILEGES;
truncate table ORG_ST_AUDIT;
truncate table PAN_APPLICATION;
truncate table PAN_PURPOSE_OF_CALL;
truncate table PAN_SHIP_ACTIVITY;
truncate table PAN_SHIP_CERTIFICATE;
truncate table PAST_PORT_CALLS;
truncate table SI_ARR_DEP_GD2;
truncate table SI_ARR_GD;
truncate table SI_AS_VC_VR;
truncate table SI_CV_CHGAGTAPPLN;
truncate table SI_CV_CRUISEOPERCTRL;
truncate table SI_CV_VSL;
truncate table SI_CV_VSLCERT;
truncate table SI_DEP_DEPOC;
truncate table SI_DEP_GD_P_CLRCE_CERT;
truncate table SI_DEP_GD_PURP_OF_CALL_SYARD_LOC;
truncate table SI_DEP_GD_SHP_CERT;
truncate table SI_DG_APPLICATION;
truncate table SI_HNS_APP;
truncate table SI_DG_UNTAGGED;
truncate table SI_GD_DOC_MAPPING;
truncate table SI_HNS_APP_UNTAGGED;
truncate table SI_ICA_MIGRATION;
truncate table SI_MSW_DOC_MAPPING;
truncate table SI_MSW_DOC_MAPPING_VSL_CERT;
truncate table SI_ORG_DTLS;
truncate table SI_ORG_PRIVILEGES;
truncate table SI_ORG_ST_AUDIT;
truncate table SI_JSON;
truncate table SI_PAN_APPLICATION;
truncate table SI_PAN_PURPOSE_OF_CALL;
truncate table SI_PAN_SHIP_ACTIVITY;
truncate table SI_PAN_SHIP_CERTIFICATE;
truncate table SI_PAN_UNTAGGED;
truncate table SI_PAST_PORT_CALLS;
truncate table SI_SHIPYARD;
truncate table SI_VESSEL_CERTIFICATE_ATTRIBUTE;
truncate table ST_BONDSTATUS;
truncate table ST_CM_DOCMETADATA;
truncate table ST_CV_ARRGD;
truncate table ST_CV_CHGAGTAPPLN;
truncate table ST_CV_CRUISEOPERCTRL;
truncate table ST_CV_DECLRSHYARD;
truncate table ST_CV_DEPGD;
truncate table ST_CV_GDAPPLN;
truncate table ST_CV_PENDINGAPPLN;
truncate table ST_CV_PORTCLRCECERTISSD;
truncate table ST_CV_PORTCLRCECERTISSDHIST;
--truncate table ST_CV_VSL;
truncate table ST_CV_VSLCALL;
truncate table ST_CV_VSLCERT;
truncate table ST_CV_VSLCERTSUBMISSN;
truncate table ST_CV_VSLCERTSUBMISSNAPPLN;
truncate table ST_DG_PM4;
truncate table ST_DG_PM4SUPPORTINGDOC;
truncate table ST_DG_VSLCALL;
truncate table ST_HN_NTCEDTL;
truncate table ST_HN_NTCEHDR;
truncate table ST_HN_SUBSTPARAM;
truncate table ST_ICA_MIGRATION;
truncate table ST_ICA_USERROLES;
truncate table ST_PANS_LAST10CALLSFRMRLOG;
truncate table ST_PANS_LAST10MEASURESFRMRLOG;
truncate table ST_PANS_LAST10SHPTOSHPACTFRMRLOG;
truncate table ST_PANS_LAST10SHPTOSHPSECFRMRLOG;
--truncate table ST_PANS_PANSINFOFRMRLOG;
truncate table ST_PANS_PANSINFOFRMRLOG2;
truncate table ST_PANS_PANSINFOFRMRLOG3;
truncate table ST_PM4SUPPORTINGDOC_MAPPING;
truncate table ST_PTMS_BWMC;
truncate table ST_PTMS_NOAFREFORM;
truncate table ST_PTMS_NOAFREFORMHIST;
truncate table ST_PTMS_VSLCALL;
truncate table ST_PU_PORTCLRCESCHMMSTR;
truncate table ST_PU_PROFILE;
truncate table ST_PU_PROFILEADDRMAPPER;
truncate table ST_PU_PROFILECONTACTMAPPER;
truncate table ST_PU_USRADDR;
truncate table ST_PU_USRCONTACT;
truncate table ST_PU_USRINDV;
truncate table ST_PU_USRORG;
truncate table ST_XR_COADDR;
truncate table ST_XR_COREG;
truncate table ST_XR_USR;
truncate table SUBSTANCE;
truncate table TBL_MIGRATION_RECON;
truncate table TBL_RUN_DETAILS;
truncate table TBL_TRACE_MIGRATION;
truncate table USR_DTLS;
truncate table USR_PRIVILEGES;
truncate table VESSEL;
truncate table VESSEL_CALL;
truncate table VESSEL_CERTIFICATE;
truncate table VESSEL_CERTIFICATE_ATTRIBUTES;
truncate table VESSEL_REFERENCE;


------------------
-- Enable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' enable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/

--Disable Index
alter index indx_depgd unusable ;
alter index indx_vslcall   unusable ;
alter index indx_gdappln   unusable ;
--ALTER INDEX INDX_TRC_DATE_MIG unusable;
ALTER INDEX indx_ARRGD  unusable;
alter index INDX_APP_SUB unusable ;
alter index INDX_PENDAPPLN   unusable ;
alter index INDX_VSLREC   unusable ;
ALTER INDEX PAN_APPL_PK unusable;
--ALTER INDEX PK_CM_DOCMETADATA  unusable;
alter index PK_CRAFT_TYPE unusable ;
alter index PK_VESSEL_CERTIFICATE   unusable ;
alter index PK_VESSEL_TYPE   unusable ;
ALTER INDEX IND_APP_SUB_ID unusable;
ALTER INDEX IND_DG_APP_REF  unusable;
alter index IND_PANSINFOFRMRLOG unusable ;
alter index IND_PANSINFOFRMRLOG2   unusable ;
alter index IND_PANSINFOFRMRLOG3   unusable ;
ALTER INDEX IND_PTMS_BWMC unusable;
ALTER INDEX IND_NOAFREFORMHIST  unusable;
ALTER INDEX IND_DG_PM4 unusable;
ALTER INDEX IND_ST_DG_VSLCALL  unusable;
ALTER INDEX IND_ST_ICA_MIG  unusable;
ALTER INDEX INDX_VSL_ID_TYPE unusable;
ALTER INDEX INDX_VSLREF unusable;
ALTER INDEX INDX_VSL_CALL unusable;
ALTER INDEX INDX_CV_DECL unusable;
ALTER INDEX INDX_ARR_GD_APP unusable;
ALTER INDEX INDX_ARR_GD_PC unusable;
ALTER INDEX INDX_DEP_GD_PC unusable;
ALTER INDEX INDX_PTMS_VCALL unusable;
ALTER INDEX INDX_SI_GD unusable;
ALTER INDEX INDX_VCERT_DOCMETA unusable;
alter index indx_pan_ext_ref unusable;
alter index indx_pan_10meas unusable;
alter index indx_pan_10call unusable;
alter index indx_pan_10sho_act unusable;
alter index indx_pan_10shp_sec unusable;
alter index indx_pan_purcall unusable;
alter index indx_pan_sh_act unusable;
alter index indx_pan_sh_cert unusable;
alter index indx_past_port_call unusable;
alter index indx_app_vsl_id unusable;

-- Count every table
select
   table_name,
   to_number(
   extractvalue(
      xmltype(
         dbms_xmlgen.getxml('select count(*) c from '||table_name))
    ,'/ROWSET/ROW/C')) count
from 
   user_tables
order by 
   count desc, table_name;
   
   
 --spool off;
 
 exit;
