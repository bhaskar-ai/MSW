sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set linesize 200;
set trimspool on;
set trimout on;
set pagesize 50000;
set markup html on
spool /tmp/DM_DATA_LOG/tbl_trace_migration.xls
select * from tbl_trace_migration;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set linesize 200;
set trimspool on;
set trimout on;
set pagesize 50000;
set markup html on
spool /tmp/DM_DATA_LOG/tbl_migration_recon.xls
select * from tbl_migration_recon;
spool off
EOF

