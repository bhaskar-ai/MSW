create or replace FUNCTION DATE_OR_NULL
     (p_date IN VARCHAR2)
   RETURN DATE
    AS
    BEGIN
      RETURN TO_DATE (p_date, 'mm/dd/yyyy hh24:mi');
  EXCEPTION
      WHEN OTHERS THEN RETURN NULL;
    END date_or_null;
	/