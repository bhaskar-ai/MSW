create or replace function fnc_recon_rep 
return tbl_typ_Recon_rep pipelined 
is
LV_APPL_NAME	        VARCHAR2(10); 
LV_SRC_TBL	            VARCHAR2(40); 
LV_SRC_FILE_REC_CNT		NUMBER(10); 
LV_SRC_TBL_LOAD_CNT		NUMBER(10); 
LV_DIFF_SRC_CNT	    	NUMBER(10); 
LV_DM_LOGIC	        	VARCHAR2(200); 
LV_DM_SI_CNT	        NUMBER(10); 
LV_DM_TARGET_TBL_NAME	VARCHAR2(40);
LV_DM_TARGET_CNT	    NUMBER(10);  
LV_MSW_TARGET_CNT	    NUMBER(10); 
LV_DIFF_DM_MSW_CNT	    NUMBER(10);
lv_si_tbl VARCHAR2(40);
out_rec typ_Recon_rep:=typ_Recon_rep(null,null,null,null,null,null,null,null,null,null,null );
begin
for i in(select * from tbl_migration_recon where (FLAG='Y' and SOURCE_TABLE not like 'DM_%'
and upper(TARGET_TBL) in('VESSEL','VESSEL_CERTIFICATE','VESSEL_CERTIFICATE_ATTRIBUTES')
) 
or (FLAG='S' and upper(TARGET_TBL) in('HN_SUBSTPARAM','DG_SUBRISK','DG_CHEM','DG_PSN'))
order by SERIAL_NO)
Loop
--dbms_output.put_line('Test');
IF upper(I.TARGET_TBL) IN ('HN_SUBSTPARAM','DG_SUBRISK','DG_CHEM','DG_PSN') THEN 
BEGIN
select SOURCE_TABLE,SOURCE_TBL_COUNT,TARGET_TBL_COUNT
into 
LV_SRC_TBL,LV_SRC_FILE_REC_CNT,LV_SRC_TBL_LOAD_CNT
from tbl_migration_recon where FLAG='S' and upper(target_tbl)=upper(i.SOURCE_TABLE) ;
LV_DM_TARGET_CNT:=LV_SRC_TBL_LOAD_CNT;
EXCEPTION 
WHEN OTHERS THEN
LV_SRC_TBL:=NULL;
END;

ELSif substr(upper(i.SOURCE_TABLE),1,3) = 'ST_' then 
begin
select upper(SOURCE_TABLE),SOURCE_TBL_COUNT,TARGET_TBL_COUNT
into 
LV_SRC_TBL,LV_SRC_FILE_REC_CNT,LV_SRC_TBL_LOAD_CNT
from tbl_migration_recon where FLAG='S' and upper(target_tbl)=upper(i.SOURCE_TABLE) ;
lv_si_tbl:=NULL;
exception 
when others then
lv_SRC_TBL:=sqlerrm;  
end;
else 
null;--lv_SRC_TBL:='else';
end if;
BEGIN
select SOURCE_TABLE,SOURCE_TBL_COUNT,TARGET_TBL_COUNT 
into 
lv_si_tbl,LV_DM_SI_CNT,LV_DM_TARGET_CNT
from tbl_migration_recon where FLAG='N' and upper(TARGET_TBL)=upper(i.TARGET_TBL);
EXCEPTION 
WHEN OTHERS THEN
lv_si_tbl:='';
--lv_si_tbl:=SQLERRM;
END;
--IF CONDITION FORTRANSFORMATION LOGIC
/*if i.target_tbl like '%PURPOSE_OF_CALL%' then 
lv_DM_LOGIC:='TOTAL PURPOSE OF CALL RECORDS(marked Y) AT SOURCE';  
else
lv_DM_LOGIC:=i.SOURCE_TABLE;
end if;
*/

if i.TARGET_TBL='VESSEL' then
dbms_output.put_line('Test inside if');
end if;

if substr(lv_SRC_TBL,1,2) in ('PA','PT') then 
lv_APPL_NAME:=	'PAN' ;   
elsif substr(lv_SRC_TBL,1,2) ='CV' then 
lv_APPL_NAME:=	'CV' ;
elsif substr(lv_SRC_TBL,1,2) ='DG' then
lv_APPL_NAME:=	'DG' ;
elsif  substr(lv_SRC_TBL,1,2) ='HN' then
lv_APPL_NAME:=	'HNS' ;
else
lv_APPL_NAME:=	substr(lv_SRC_TBL,1,2);
end if;

out_rec.APPL_NAME:=lv_APPL_NAME;
out_rec.SRC_TBL	:= lv_SRC_TBL ;        
out_rec.SRC_FILE_REC_CNT:=i.SOURCE_TBL_COUNT;
out_rec.SRC_TBL_LOAD_CNT:=i.TARGET_TBL_COUNT;	
out_rec.DIFF_SRC_CNT:=	nvl( i.SOURCE_TBL_COUNT,0)-nvl(i.TARGET_TBL_COUNT,0);
out_rec.DM_LOGIC:=lv_si_tbl;
out_rec.DM_SI_CNT:=LV_DM_SI_CNT;
out_rec.DM_TARGET_CNT:=LV_DM_TARGET_CNT;
out_rec.DM_TARGET_TBL_NAME:=i.TARGET_TBL;

BEGIN
select TARGET_TBL_COUNT INTO LV_MSW_TARGET_CNT from tbl_migration_recon where 
TARGET_TBL=i.TARGET_TBL and SOURCE_TABLE ='DM_'||i.TARGET_TBL;
EXCEPTION
WHEN OTHERS THEN 
LV_MSW_TARGET_CNT:=0;
END;


out_rec.MSW_TARGET_CNT:=  LV_MSW_TARGET_CNT;
out_rec.DIFF_DM_MSW_CNT:=  nvl( LV_DM_TARGET_CNT,0)-nvl(LV_MSW_TARGET_CNT,0);


pipe row(out_rec);
end loop;
return;
end;
/