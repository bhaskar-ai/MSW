create or replace FUNCTION FNC_JSON_VAL_DGD
(
PV_DGD  DANGEROUS_GOODS_APPLICATION%ROWTYPE,
PV_DGD_DOC  DANGEROUS_GOODS_APPLICATION_DOCUMENT%ROWTYPE--,
--PV_C7_DGD  DANGEROUS_GOODS_APPLICATION_DOCUMENT%ROWTYPE
)
RETURN CLOB
IS
LVAL    CLOB;
V_WASTE_I VARCHAR2(10);
V_RESIDUE_I VARCHAR2(10);
V_EMAIL_I VARCHAR2(10);
V_SMS_I VARCHAR2(10);
V_ETA_DT VARCHAR2(30);
V_RTA_DT VARCHAR2(30);
V_CRT_ON_DT VARCHAR2(30);
V_LST_UPT_DT VARCHAR2(30);
LVSL_CALL_ID_N  VARCHAR2(25);
LMSW_VSL_ID_N   VARCHAR2(25);
BEGIN

select decode(PV_DGD.waste_i,0,'false',1,'true') into V_WASTE_I from dual;
select decode(PV_DGD.residue_i,0,'false',1,'true') into V_RESIDUE_I from dual;

select decode(PV_DGD.SUBR_EMAIL_I,0,'false',1,'true') into V_EMAIL_I from dual;
select decode(PV_DGD.SUBR_SMS_I,0,'false',1,'true') into V_SMS_I from dual;
select to_char(PV_DGD.rta_dt,'YYYY-MM-DD HH24:MI:SS') into V_RTA_DT from dual;
select to_char(PV_DGD.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS') into V_CRT_ON_DT from dual;
select to_char(PV_DGD.ETA_DT,'YYYY-MM-DD HH24:MI:SS') into V_ETA_DT from dual;--
select to_char(PV_DGD.upt_on_dt,'YYYY-MM-DD HH24:MI:SS') into V_LST_UPT_DT from dual;

--DBMS_OUTPUT.PUT_LINE('This string starts here.');
LVAL:='{';
LVAL:=LVAL||'"vesselCallId":'||PV_DGD.VSL_CALL_ID_N||',';
LVAL:=LVAL||'"applicantId":"'||PV_DGD.APPLN_REF_N||'",';
--LVAL:=LVAL||'"blNumber":"'||PV_DGD.BL_X||'",';
--LVAL:=LVAL||'"class7Dg":{';
--LVAL:=LVAL||'"sequenceNumber":'||PV_C7_DGD.SEQ_N||',';
--LVAL:=LVAL||'"substanceCode":"'||PV_C7_DGD.SUBST_C||'",';
--LVAL:=LVAL||'}';--End of Class7dg


--LVAL:=LVAL||'"craftLighterNo":"'||PV_DGD.CFT_LIC_X||'",';
LVAL:=LVAL||'"createdBy":"'||PV_DGD.CRT_BY_X||'",';
LVAL:=LVAL||'"createdOn":"'||V_CRT_ON_DT||'",';
--DgApplication Document
LVAL:=LVAL||'"dgdApplicationDocuments":[{';
LVAL:=LVAL||'"createdBy":"'||PV_DGD_DOC.CRT_BY_X||'",';
LVAL:=LVAL||'"createdOn":"'||PV_DGD_DOC.CRT_ON_DT||'",';
LVAL:=LVAL||'"documentId":'||PV_DGD_DOC.DOC_ID_N||',';
LVAL:=LVAL||'"documentType":"'||PV_DGD_DOC.TY_C||'",';
LVAL:=LVAL||'"documentTypeOther":"'||PV_DGD_DOC.DOC_OTHER_TY_C||'",';
LVAL:=LVAL||'"lockVersion:"'||0;
LVAL:=LVAL||'}],';
--End of Dg Application Doc
--LVAL:=LVAL||'"dgdApplicationStatus":"'||PV_DGD.TN_N||'",';? Not found
--LVAL:=LVAL||'"emailAddress":"'||PV_DGD.EMAIL_X||'",';

--LVAL:=LVAL||'"expectedTimeOfDeparture":"'||PV_DGD.RTA_DT||'",';
--LVAL:=LVAL||'"externalApplicationReference":"'||PV_DGD.EXTL_APPLN_REF_X||'",';
--LVAL:=LVAL||'"flashPoint":'||PV_DGD.FLASH_PT_N||',';
--LVAL:=LVAL||'"containerNumber":"'||PV_DGD.TN_N||'",';
LVAL:=LVAL||'"lockVersion:"'||0||',';
LVAL:=LVAL||'"weight:"'||PV_DGD.wt_n||',';
LVAL:=LVAL||'"containerNumber":"'||PV_DGD.cntr_x||'",';
LVAL:=LVAL||'"imoClass":"'||PV_DGD.imo_cl_c||'",';
LVAL:=LVAL||'"unNumber":"'||PV_DGD.un_x||'",';
LVAL:=LVAL||'"goodsPackageType":"'||PV_DGD.pkg_ty_c||'",';
LVAL:=LVAL||'"hasWaste":"'||V_WASTE_I||'",';
LVAL:=LVAL||'"hasResidue":"'||V_RESIDUE_I||'",';
LVAL:=LVAL||'"inVoyage":"'||PV_DGD.in_voy_x||'",';
LVAL:=LVAL||'"outVoyage":"'||PV_DGD.out_voy_x||'",';
LVAL:=LVAL||'"operationType":"'||PV_DGD.opern_c||'",';
LVAL:=LVAL||'"locationOfOperation":"'||PV_DGD.locn_c||'",';
LVAL:=LVAL||'"craftLicenseNo":"'||PV_DGD.cft_lic_x||'",';
LVAL:=LVAL||'"contactPerson":"'||PV_DGD.CONT_PERS_M||'",';
LVAL:=LVAL||'"mobileNumber":"'||PV_DGD.mobile_n||'",';
LVAL:=LVAL||'"expectedTimeOfArrival":"'||V_ETA_DT||'",';
LVAL:=LVAL||'"reportedTimeOfArrival":"'||V_RTA_DT||'",';
LVAL:=LVAL||'"lastUpdatedOn":"'||V_LST_UPT_DT||'",';
LVAL:=LVAL||'"mswApplicationReference":"'||PV_DGD.MSW_APPLN_REF_ID_X||'",';
LVAL:=LVAL||'"vesselCallId":'||PV_DGD.VSL_CALL_ID_N||',';
--LVAL:=LVAL||'"vesselId":'||LVSL_CALL_ID_N||',';--Vessel_id ?



LVAL:=LVAL||'"subscribeEmail":'||V_EMAIL_I||',';
LVAL:=LVAL||'"subscribeSms":'||V_SMS_I;

LVAL:=LVAL||'}';
--DBMS_OUTPUT.PUT_LINE('LVAL IS:'||LVAL);
RETURN (LVAL);
END;
/