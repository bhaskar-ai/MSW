create or replace FUNCTION FNC_JSON_VAL_HNS
(
PV_HNS  HNS_APPLICATION%ROWTYPE,
PV_HNS_SUB  HNS_APPLICATION_SUBSTANCE%ROWTYPE
)
RETURN CLOB
IS
LVAL    VARCHAR2(4000); --clob
V_SUBR_EMAIL_I varchar2(50);
V_SUBR_SMS_I VARCHAR2(50);
V_ETA_DT VARCHAR2(30);
V_ETD_DT VARCHAR2(30);
V_CRT_DT VARCHAR2(30);
V_OPERN_DT VARCHAR2(30);
V_CRT_DT_SUB VARCHAR2(30);
V_LST_UPT_DT VARCHAR2(30);
BEGIN
select decode(PV_HNS.SUBR_EMAIL_I,0,'false',1,'true') into V_SUBR_EMAIL_I from dual;
select decode(PV_HNS.SUBR_SMS_I,0,'false',1,'true') into V_SUBR_SMS_I from dual;
select to_char(PV_HNS.ETA_DT,'YYYY-MM-DD HH24:MI:SS') into V_ETA_DT from dual;
select to_char(PV_HNS.ETD_DT,'YYYY-MM-DD HH24:MI:SS') into V_ETD_DT from dual;
select to_char(PV_HNS.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS') into V_CRT_DT from dual;
select to_char(PV_HNS.UPT_ON_DT,'YYYY-MM-DD HH24:MI:SS') into V_LST_UPT_DT from dual;
select to_char(PV_HNS_SUB.OPERN_DT,'YYYY-MM-DD HH24:MI:SS') into V_OPERN_DT from dual;
select to_char(PV_HNS_SUB.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS') into V_CRT_DT_SUB from dual;


--DBMS_OUTPUT.PUT_LINE('This string breakshere.');
--LVAL:='{';
--LVAL:=LVAL||'"vesselCallId":'||PV_HNS.MSW_VSL_ID_N||',';
LVAL:=LVAL||'"mswApplicationReference":"'||trim(PV_HNS.MSW_APPLN_REF_ID_X)||'",';
LVAL:=LVAL||'"applicantId":"'||trim(PV_HNS.APPLN_REF_N)||'",';
LVAL:=LVAL||'"vesselId":'||trim(PV_HNS.MSW_VSL_ID_N)||',';--Vessel_id ?
LVAL:=LVAL||'"contactPerson":"'||trim(PV_HNS.CONT_PERS_M)||'",';
LVAL:=LVAL||'"companyName":"'||trim(PV_HNS.CO_M)||'",';
LVAL:=LVAL||'"emailAddress":"'||trim(PV_HNS.EMAIL_X)||'",';
LVAL:=LVAL||'"cargoType":"'||trim(PV_HNS.CGO_TY_C)||'",';
LVAL:=LVAL||'"mobileNumber":"'||trim(PV_HNS.MOBILE_N)||'",';
LVAL:=LVAL||'"craftLicenceNo":"'||trim(PV_HNS.CFT_LIC_N)||'",';
--LVAL:=LVAL||'"expectedTimeOfArrival":"2018-09-21 21:20:00",';
--LVAL:=LVAL||'"expectedTimeOfDeparature":"2018-09-22 21:20:00",';
LVAL:=LVAL||'"expectedTimeOfArrival":"'||trim(V_ETA_DT)||'",';
LVAL:=LVAL||'"expectedTimeOfDeparature":"'||trim(V_ETD_DT)||'",';
--LVAL:=LVAL||'"createdOn":"2018-09-21 21:20:00",';
LVAL:=LVAL||'"createdOn":"'||trim(V_CRT_DT)||'",';
LVAL:=LVAL||'"createdBy":" '||trim(PV_HNS.CRT_BY_X)||' ",';
LVAL:=LVAL||'"lastPortCountry":"'||trim(PV_HNS.LST_PORT_CTRY_X)||'",';
LVAL:=LVAL||'"lastPortCode":"'||trim(PV_HNS.LAST_PORT_C)||'",';
--LVAL:=LVAL||'"containerNumber":"'||PV_HNS||'",';
--LVAL:=LVAL||'"subscribeEmail":'||PV_HNS.SUBR_EMAIL_I||',';
LVAL:=LVAL||'"subscribeEmail":'||trim(V_SUBR_EMAIL_I)||',';
--LVAL:=LVAL||'"subscribeSms":'||PV_HNS.SUBR_SMS_I||',';
LVAL:=LVAL||'"subscribeSms":'||trim(V_SUBR_SMS_I)||',';
LVAL:=LVAL||'"voyageNumber":"'||trim(PV_HNS.VOY_N_X)||'",';
LVAL:=LVAL||'"lastUpdatedOn":"'||trim(V_LST_UPT_DT)||'",';
LVAL:=LVAL||'"lastUpdatedBy":"'||trim(PV_HNS.UPT_BY_X)||'",';
LVAL:=LVAL||'"infringementStatus":"'||trim(PV_HNS.INFRNGMNT_C)||'",';

LVAL:=LVAL||'"hnsApplicationSubstances":[{';
LVAL:=LVAL||'"sequenceNumber":'||trim(PV_HNS_SUB.SEQ_N)||',';
LVAL:=LVAL||'"substanceCode":"'||trim(PV_HNS_SUB.SUBST_C)||'",';
LVAL:=LVAL||'"substanceName":"'||trim(PV_HNS_SUB.SUBST_M)||'",';
LVAL:=LVAL||'"unNumber":"'||trim(PV_HNS_SUB.UN_N)||'",';
LVAL:=LVAL||'"pollutionCategory":"'||trim(PV_HNS_SUB.POLLN_CAT_C)||'",';
LVAL:=LVAL||'"cargoGroup":"'||trim(PV_HNS_SUB.CGO_GRP_C)||'",';
--LVAL:=LVAL||'"operationDate":"2018-09-21 21:20:00",';
LVAL:=LVAL||'"operationDate":"'||trim(V_OPERN_DT)||'",';
LVAL:=LVAL||'"flashPoint":"'||trim(PV_HNS_SUB.FLASH_PT_N)||'",';
LVAL:=LVAL||'"ibcHazardCode":"'||trim(PV_HNS_SUB.HZ_IBC_C)||'",';
LVAL:=LVAL||'"quantity":"'||trim(PV_HNS_SUB.SUBST_QTY_Q)||'",';
LVAL:=LVAL||'"stowageOnBoard":"'||trim(PV_HNS_SUB.STW_ONBD_X)||'",';
LVAL:=LVAL||'"createdBy":"'|| trim(PV_HNS_SUB.CRT_BY_X)||' ",';
--LVAL:=LVAL||'"createdOn":"2018-09-22 21:20:00",';
LVAL:=LVAL||'"createdOn":"'||trim(V_CRT_DT_SUB)||'",';
LVAL:=LVAL||'"operationType":"'||trim(PV_HNS_SUB.OPERN_C)||'",';
LVAL:=LVAL||'"locationOfOperation":"'||trim(PV_HNS_SUB.LOCN_C)||'"';
LVAL:=LVAL||'}]';
LVAL:=LVAL||'}';
--DBMS_OUTPUT.PUT_LINE('LVAL IS:'||LVAL);
RETURN (LVAL);
END;
/