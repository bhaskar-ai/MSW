--Vessel Schema
--VESSEL_CERTIFICATE	VSL_CERT_ID_N	
grant select on MSW_VSL_SVC.ISEQ$$_88259  to msw_data_migration; 

--VESSEL_CERTIFICATE_ATTRIBUTES	
--VSL_CERT_ATTRB_ID_N
grant select on 	MSW_VSL_SVC.ISEQ$$_88262 to msw_data_migration; 

--Master table grants;
grant select,insert on MSW_VSL_SVC.VSL to msw_data_migration;

grant select on MSW_VSL_SVC.VSL_TY to msw_data_migration;

grant select on MSW_VSL_SVC.CRAFT_TY to msw_data_migration;
grant select,insert on MSW_VSL_SVC.VSL_CERT to msw_data_migration;
grant select,insert on MSW_VSL_SVC.VSL_CERT_ATTRB to msw_data_migration;
grant select,insert on MSW_VSL_SVC.CRUISE_OPER_CTRL TO msw_data_migration;

--Grants on E Application submission
grant select on msw_e_submissn.ISEQ$$_92386 to msw_data_migration;
grant select on MSW_E_SUBMISSN.ISEQ$$_92383 to msw_data_migration;
grant select on MSW_E_SUBMISSN.ISEQ$$_92413 to msw_data_migration;

grant select,insert on msw_e_submissn.appln_submissn to msw_data_migration;
grant select,insert on msw_e_submissn.vsl_call to msw_data_migration;
grant select,insert on msw_e_submissn.vsl_ref to msw_data_migration;

-----CVS  table grants
grant select on MSW_CVS_INTEGRATION.ISEQ$$_88281 to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_88284" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_88290" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_88293" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_88311" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_88341" to msw_data_migration;

grant select,insert on MSW_CVS_INTEGRATION.ARR_GD_APPLN to msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.ARR_GD_PURP_OF_CALL to msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.ARR_GD_PURP_OF_CALL_SYARD_LOC TO msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.DEP_GD_APPLN to msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.DEP_GD_PURP_OF_CALL to msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.DEP_GD_P_CLRCE_CERT TO msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.DEP_GD_PURP_OF_CALL_SYARD_LOC TO msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.DEP_GD_SHP_CERT TO msw_data_migration;
grant select,insert on MSW_CVS_INTEGRATION.CHG_OF_AGT TO msw_data_migration;


--DGDS tables
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_92484 to msw_data_migration;
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_92487 to msw_data_migration;
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_92509 to msw_data_migration;
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_92513 to msw_data_migration;
grant select on "MSW_DGDS_INTEGRATION"."ISEQ$$_92500" to msw_data_migration;
grant select on "MSW_DGDS_INTEGRATION"."ISEQ$$_96563" to msw_data_migration;

grant select,insert on MSW_DGDS_INTEGRATION.DG_SUBRISK to msw_data_migration;
grant select,insert on MSW_DGDS_INTEGRATION.DG_APPLN to msw_data_migration;
grant select,insert on MSW_DGDS_INTEGRATION.DG_APPLN_DOC to msw_data_migration;
grant select,insert on MSW_DGDS_INTEGRATION.DG_CHEM to msw_data_migration;
grant select,insert on MSW_DGDS_INTEGRATION.DG_PSN to msw_data_migration;
grant select,insert on MSW_DGDS_INTEGRATION.DG_PSA_JPC to msw_data_migration;

-- HNS tables
grant select on MSW_HNS_SVC.ISEQ$$_92462 to msw_data_migration;
grant select on MSW_HNS_SVC.ISEQ$$_92465 to msw_data_migration;
grant select,insert on msw_hns_svc.hns_appln_substance to msw_data_migration;
grant select,insert on msw_hns_svc.hns_appln to msw_data_migration;

GRANT SELECT ON MSW_HNS_SVC.ISEQ$$_92471 TO MSW_DATA_MIGRATION;
grant select,insert on msw_hns_svc.SUBSTANCE TO MSW_DATA_MIGRATION;

--PAN tables
grant select on "MSW_PANS_NOAS_INTEGRATION"."ISEQ$$_92441" to msw_data_migration;
grant select on "MSW_PANS_NOAS_INTEGRATION"."ISEQ$$_92444" to msw_data_migration;
grant select on "MSW_PANS_NOAS_INTEGRATION"."ISEQ$$_92447" to msw_data_migration;
grant select on "MSW_PANS_NOAS_INTEGRATION"."ISEQ$$_92438" to msw_data_migration;
grant select on "MSW_PANS_NOAS_INTEGRATION"."ISEQ$$_92435" to msw_data_migration;

grant select,insert on MSW_PANS_NOAS_INTEGRATION.PAN_APPLN to msw_data_migration;
grant select,insert on MSW_PANS_NOAS_INTEGRATION.PAN_SHP_ACT to msw_data_migration;
grant select,insert on MSW_PANS_NOAS_INTEGRATION.PAN_SHP_CERT to msw_data_migration;
grant select,insert on MSW_PANS_NOAS_INTEGRATION.PAN_PURP_OF_CALL to msw_data_migration;
grant select,insert on MSW_PANS_NOAS_INTEGRATION.PAST_P_CALLS to msw_data_migration;

GRANT SELECT,INSERT ON MSW_AUTH_SVC.USR_DTLS TO MSW_DATA_MIGRATION;
