#!/bin/bash
sqlplus -s msw_data_migration_DM/PASSWORD<<EOF
@indexes.sql
EOF
echo "End of Cleanup script"
