set linesize 150;
set pagesize 10000;
set heading on;
SET TRIMOUT on;
SET ECHO ON;

@load_env.sql;

column table_name format a50;

exec DBMS_UTILITY.ANALYZE_SCHEMA('&AUTHENTICATION_SCHEMA_NAME.','COMPUTE');

exec DBMS_UTILITY.ANALYZE_SCHEMA('&VSL_SCHEMA_NAME.','COMPUTE');

exec DBMS_UTILITY.ANALYZE_SCHEMA('&DGDS_SCHEMA_NAME.','COMPUTE');

exec DBMS_UTILITY.ANALYZE_SCHEMA('&HNS_SCHEMA_NAME.','COMPUTE');

exec DBMS_UTILITY.ANALYZE_SCHEMA('&DM_SCHEMA_NAME.','COMPUTE');

spool dba_gen_all_tbl_count.txt
select table_name, num_rows counter from dba_tables where owner = '&AUTHENTICATION_SCHEMA_NAME.';

select table_name, num_rows counter from dba_tables where owner = '&VSL_SCHEMA_NAME.';

select table_name, num_rows counter from dba_tables where owner = '&DGDS_SCHEMA_NAME.';

select table_name, num_rows counter from dba_tables where owner = '&HNS_SCHEMA_NAME.';

select table_name, num_rows counter from dba_tables where owner = '&DM_SCHEMA_NAME.';

spool off;