#!/bin/bash
echo "Start of Data Extraction"
#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 25000 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/VESSEL.xls
#select MSW_VSL_ID_N,VSL_REC_ID_N,VSL_M,OFFICIAL_N,VSL_FLAG_C,(select  VSL_TY_C from vessel_type where VSL_TYPE_ID_N=v.VSL_TYPE_ID_N) as VESSEL_TYPE,(select  VSL_CRAFT_TY_C from craft_type where CRAFT_TYPE_ID_N=v.CRAFT_TYPE_ID_N) as CRAFT_TYPE,VSL_DWT_N,ST_C,VSL_CRAFT_LIC_N,VSL_ATTAINABLE_HGT_Q,VSL_YR_BLT_N,PORT_OF_REGY_C,PORT_N,VSL_LEN_Q,LOA_Q,VSL_DEPTH_Q,VSL_BRE_Q,MECHANIC_PROPEL_I,VSL_MMSI_N,LOCK_VER_N,CRT_ON_DT,CRT_BY_X,UPT_ON_DT,UPT_BY_X,GRS_TNG_N,NET_TNG_N,VSL_CALL_SIGN_N,VSL_IMO_N,VSL_OWNR,DELETED_I,DELIVERY_DT,BOW_BRIDGE,BOW_THRUSTER,STERN_THRUSTER,DBL_HULL_CONSTRUCT_I,APPR_FOR_SEA_TRIAL_I,LAUNCH_ON_DT,MERGE_FR_TO_VSL_REC_ID,BARTER_TRADE_I,BARE_BOAT_CHARTER_OUT_I,TRANSIT_I,UNOFFICIAL_VSL_M,UNOFFCIAL_VSL_CALL_SIGN,UNOFFICIAL_VSL_TY_C,UNOFFICIAL_VSL_FLAG_C,UNOFFICIAL_VSL_GT,GT_FROM_E_PAN_Q,GT_FROM_E_PAN_DT,BUILDER_M,OWNER_CTRY_C,VSL_BUILT_PLACE_C from VESSEL V;
#spool off
#EOF

#sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
#set lines 700 pages 200
#set markup html on
#spool /tmp/DM_DATA_LOG/VESSEL_CERTIFICATE.xls
#select * from VESSEL_CERTIFICATE;
#spool off
#EOF

sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
set lines 700 pages 200
set markup html on
spool /tmp/DM_Pre_Prod_Log/tbl_migration_recon.xls
select * from tbl_migration_recon order by serial_no;
spool off
EOF

