set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
-- Transaction
PROC_2_ARRGD_PURCAL(lv_runid);
PROC_1_ARRIVAL_GD_SHIPYARD_LOC(lv_runid);
PROC_AGD_JSON;
PROC_UPD_APP_DATA('AGD');
PROC_2_DEPGD_DEPOC(lv_runid);
PROC_1_DEP_GD_P_CLRCE_CERT(lv_runid);
PROC_1_DEP_GD_SHIPYARD_LOC(lv_runid);
PROC_2_DEPGD_SHP_CERT(lv_runid);
PROC_DEP_JSON;
PROC_UPD_APP_DATA('GDD');
PROC_CGD_JSON;
PROC_UPD_APP_DATA('CGD');
PROC_2_PAN_APP_VCALL(lv_runid);
PROC_1_PSC(lv_runid);
PROC_1_PSA(lv_runid);
PROC_1_PASS_PORT(lv_runid);
PROC_1_PAN_JSON;
PROC_UPD_APP_DATA('PAN');
PROC_2_DG_APPL_VSLCALL(lv_runid);
PROC_DG_JSON;
PROC_UPD_APP_DATA('DGD');
PROC_2_HNS_APPL_VSLCALL(lv_runid);
-- Push Transactional
PROC_3_PUSH_ARRGD;
PROC_3_PUSH_DEPGD;
PROC_2_PUSH_DGDS;
PROC_1_PUSH_DG_PSA_JPC;
PROC_2_PUSH_PA_POC;
PROC_3_PUSH_PSC_PSA_PPC;
PROC_2_PUSH_HNS;
PROC_3_PUSH_VC_AS_VR;
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
end;
/
