@set_env_uat_dm.sql
--For Production Environment
--@set_env_prd.sql; 