set serveroutput on;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--DBMS_OUTPUT.PUT_line('1');
--ICA
PROC_1_ICA_USR_REQUEST(lv_runid);
PROC_1_CREW_CO_REQ(lv_runid);
--Push ICA
PROC_1_PUSH_ORG_PRIVILEGES;
PROC_1_PUSH_USR_PRIVILEGES;
PROC_1_PUSH_ICA_USR_REQUEST;
PROC_1_PUSH_CREW_CO_REQ;
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
end;
/
