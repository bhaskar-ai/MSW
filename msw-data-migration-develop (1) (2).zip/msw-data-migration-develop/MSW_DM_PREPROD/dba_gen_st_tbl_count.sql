set linesize 150;
set pagesize 10000;
set heading on;
SET TRIMOUT on;
SET ECHO ON;

@load_env.sql;

column table_name format a50;

exec DBMS_UTILITY.ANALYZE_SCHEMA('&DM_SCHEMA_NAME.','COMPUTE');

spool dba_gen_st_tbl_count.txt

select table_name, num_rows counter from dba_tables where owner = '&DM_SCHEMA_NAME.' AND table_name LIKE 'ST_%';

spool off;