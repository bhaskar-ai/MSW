sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 700 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/tbl_trace_migration.xls
select * from tbl_trace_migration where rownum<5000;
spool off
EOF

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
set lines 700 pages 200
set markup html on
spool /tmp/DM_DATA_LOG/tbl_migration_recon.xls
select * from tbl_migration_recon;
spool off
EOF

