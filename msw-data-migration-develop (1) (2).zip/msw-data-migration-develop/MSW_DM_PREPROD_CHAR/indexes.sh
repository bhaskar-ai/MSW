#!/bin/bash
sqlplus -s msw_data_migration/HcK8T7HN<<EOF
@indexes.sql
EOF
echo "End of Cleanup script"
