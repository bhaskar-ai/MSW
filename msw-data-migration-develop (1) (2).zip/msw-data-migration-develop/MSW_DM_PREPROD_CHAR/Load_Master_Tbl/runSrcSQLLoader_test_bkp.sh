#!/bin/bash

sqlplus -s msw_data_migration/HcK8T7HN <<EOF
spool on;
spool runid.txt
select fnc_run_dm('LOAD') from dual;

spool off;
EOF

varrunid=`cat runid.txt | grep -o '[0-9]*'`
echo $varrunid
echo 'End of this script'
sqlplus -s msw_data_migration/HcK8T7HN <<EOF
spool on;
spool runcnt.txt
SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vsl' AND FLOW='LOAD';
spool off;
EOF
varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
echo 'Count'
echo $varcnt
if [[ $varcnt -eq 0 ]]
then
sqlldr control=ST_CV_vslCert.ctl userid=msw_data_migration/HcK8T7HN log=CV_vslCert.Log
result=$?
if [[ $result -eq 0 ]]
then
sqlplus -s  msw_data_migration/HcK8T7HN <<EOF
insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCert','Y',SYSDATE);
EOF
else
echo 'Data load failed.'
exit
fi
else 
echo 'Data Already loaded.'
exit
fi

#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_GDAppln' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_GDAppln.ctl userid=msw_data_migration/dev123@orcl log=CV_GDAppln.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_GDAppln','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_pendingAppln' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_pendingAppln.ctl userid=msw_data_migration/dev123@orcl log=CV_pendingAppln.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_pendingAppln','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_depGD' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_depGD.ctl userid=msw_data_migration/dev123@orcl log=CV_depGD.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_depGD','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_arrGD' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_arrGD.ctl userid=msw_data_migration/dev123@orcl log=CV_arrGD.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_arrGD','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_portClrceCertIssd' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_portClrceCertIssd.ctl userid=msw_data_migration/dev123@orcl log=CV_portClrceCertIssd.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_portClrceCertIssd','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='CV_vslCall' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=CV_vslCall.ctl userid=msw_data_migration/dev123@orcl log=CV_vslCall.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','CV_vslCall','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='st_dg_chem' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=st_dg_chem.ctl userid=msw_data_migration/dev123@orcl log=st_dg_chem.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','st_dg_chem','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='st_dg_pm4' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=st_dg_pm4.ctl userid=msw_data_migration/dev123@orcl log=st_dg_pm4.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','st_dg_pm4','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_DG_PM4SUPPORTINGDOC' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=ST_DG_PM4SUPPORTINGDOC.ctl userid=msw_data_migration/dev123@orcl log=ST_DG_PM4SUPPORTINGDOC.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_DG_PM4SUPPORTINGDOC','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='st_dg_subrisk' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=st_dg_subrisk.ctl userid=msw_data_migration/dev123@orcl log=st_dg_subrisk.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','st_dg_subrisk','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='st_dg_vslcall' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=st_dg_vslcall.ctl userid=msw_data_migration/dev123@orcl log=st_dg_vslcall.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','st_dg_vslcall','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PM4SUPPORTINGDOC_MAPPING' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=ST_PM4SUPPORTINGDOC_MAPPING.ctl userid=msw_data_migration/dev123@orcl log=ST_PM4SUPPORTINGDOC_MAPPING.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PM4SUPPORTINGDOC_MAPPING','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PANS_LAST10CALLSFRMRLOG' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=ST_PANS_LAST10CALLSFRMRLOG.ctl userid=msw_data_migration/dev123@orcl log=ST_PANS_LAST10CALLSFRMRLOG.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PANS_LAST10CALLSFRMRLOG','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PANS_LAST10SHPTOSHPACTFRMRLOG' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=ST_PANS_LAST10SHPTOSHPACTFRMRLOG.ctl userid=msw_data_migration/dev123@orcl log=ST_PANS_LAST10SHPTOSHPACTFRMRLOG.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PANS_LAST10SHPTOSHPACTFRMRLOG','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='ST_PANS_LAST10SHPTOSHPSECFRMRLOG' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=ST_PANS_LAST10SHPTOSHPSECFRMRLOG.ctl userid=msw_data_migration/dev123@orcl log=ST_PANS_LAST10SHPTOSHPSECFRMRLOG.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','ST_PANS_LAST10SHPTOSHPSECFRMRLOG','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=PANS_PANSINFOFRMRLOG.ctl userid=msw_data_migration/dev123@orcl log=PANS_PANSINFOFRMRLOG.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG2' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=PANS_PANSINFOFRMRLOG2.ctl userid=msw_data_migration/dev123@orcl log=PANS_PANSINFOFRMRLOG2.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG2','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PANS_PANSINFOFRMRLOG3' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=PANS_PANSINFOFRMRLOG3.ctl userid=msw_data_migration/dev123@orcl log=PANS_PANSINFOFRMRLOG3.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PANS_PANSINFOFRMRLOG3','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_bwmc' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=PTMS_bwmc.ctl userid=msw_data_migration/dev123@orcl log=PTMS_bwmc.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_bwmc','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='PTMS_NOAFREFORM' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=PTMS_NOAFREFORM.ctl userid=msw_data_migration/dev123@orcl log=PTMS_NOAFREFORM.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','PTMS_NOAFREFORM','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceDtl' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=HN_ntceDtl.ctl userid=msw_data_migration/dev123@orcl log=HN_ntceDtl.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceDtl','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
#sqlplus -s msw_data_migration/dev123 <<EOF
#spool on;
#spool runcnt.txt
#SELECT COUNT(*)  FROM TBL_RUN_DETAILS WHERE RUNID=$varrunid AND  TABLE_NAME='HN_ntceHdr' AND FLOW='LOAD';
#spool off;
#EOF
#varcnt=`cat runcnt.txt | grep -o '[0-9]*'`
#echo 'Count'
#echo $varcnt
#if [[ $varcnt -eq 0 ]]
#then
#sqlldr control=HN_ntceHdr.ctl userid=msw_data_migration/dev123@orcl log=HN_ntceHdr.Log
#result=$?
#if [[ $result -eq 0 ]]
#then
#sqlplus -s  msw_data_migration/dev123 <<EOF
#insert into TBL_RUN_DETAILS values ($varrunid,'LOAD','HN_ntceHdr','Y',SYSDATE);
#EOF
#else
#echo 'Data load failed.'
#exit
#fi
#else
#echo 'Data Already loaded.'
#exit
#fi
#
#sleep 5
#
exit $result
