sqlplus msw_data_migration/HcK8T7HN @./cleanup_script.sql
