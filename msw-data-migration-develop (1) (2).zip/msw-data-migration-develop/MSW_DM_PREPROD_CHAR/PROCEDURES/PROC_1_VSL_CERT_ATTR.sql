create or replace PROCEDURE proc_1_vsl_cert_Attr (PV_RUN_ID in number)IS


/***********************************************************************************************************
Declaring variables for Target table
*************************************************************************************************************/

CURSOR cur_vslcrtAttr IS

    SELECT
       VSLCERTID_N,
       REGST_C,
       PERSALLW_Q,
       SOPEPSMPEPONBD_I,
       INCOMPLYMARPOLREGU19_I,
       INCOMPLYMARPOLREGU20_I,
       INCOMPLYMARPOLREGU21_I,
       INCOMPLYMARPOLREGU20_DT,
       INCOMPLYMARPOLREGU21_DT
    from  si_vessel_certificate_attribute;

-- defining the 'record type'  type to serve as the datatype of collection variable  of main table

    TYPE rec_vslcrt_Attr IS RECORD (
      v_vslCertId_n	si_vessel_certificate_attribute.VSLCERTID_N%type,
      v_regSt_c	si_vessel_certificate_attribute.REGST_C%type,
      v_persAllw_q	si_vessel_certificate_attribute.PERSALLW_Q%type,
      v_sopepSmpepOnbd_i	si_vessel_certificate_attribute.SOPEPSMPEPONBD_I%type,
      v_inComplyMarpolRegu19_i	si_vessel_certificate_attribute.INCOMPLYMARPOLREGU19_I%type,
      v_inComplyMarpolRegu20_i	si_vessel_certificate_attribute.INCOMPLYMARPOLREGU20_I%type,
      v_inComplyMarpolRegu21_i	si_vessel_certificate_attribute.INCOMPLYMARPOLREGU21_I%type,
      v_inComplyMarpolRegu20_dt	si_vessel_certificate_attribute.INCOMPLYMARPOLREGU20_DT%type,
      v_inComplyMarpolRegu21_dt	si_vessel_certificate_attribute.INCOMPLYMARPOLREGU21_DT%type
 );


    TYPE type_vslcrt_attr IS TABLE OF rec_vslcrt_Attr;

    lv_vsl_cert        type_vslcrt_attr;

    v_sq_vslCrtId      INTEGER;
    v_src_count        INTEGER;
    v_tgt_count        INTEGER;
    v_err_code         NUMBER;
    v_err_msg          VARCHAR2(2000);
    v_sqlerrm          VARCHAR2(4000);
    v_blkexptn_count   NUMBER(20,0);
    v_blkexptn_desc    varchar2(4000);
    V_exp_rows         varchar2(4000);
    V_exp_rows1        varchar2(1000);
    V_exp_rows2        varchar2(1000);
    V_exp_rows3        varchar2(1000);
    V_exp_rows4        varchar2(1000);
    V_exp_rows5        varchar2(1000);
    V_exp_rows6        varchar2(1000);
    V_exp_rows7        varchar2(1000);
    V_exp_rows8        varchar2(1000);
    V_exp_rows9        varchar2(1000);
    v_err_row          varchar2(4000);


Begin

/***********************************************************************************************************
procedure name : proc_1_vsl_cert_Attr
Created By     : C.N.Bhaskar
Date           : 26-mar-2019
Purpose        : Inserting  the data from staging table (ST_CV_vslCert a,ST_CV_vsl b ,VESSEL_CERTIFICATE) into  si_vessel_certificate_attribute(Intermediate table) to VESSEL_CERTIFICATE_ATTRIBUTES(Target Table)
Modified by    :
Modified date  :

*************************************************************************************************************/

/***********************************************************************************************************
INSERTING DATA FROM STAGING TABLE INTO INTERMEDIATE TABLE
*************************************************************************************************************/
pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr','Insertion into si_vessel_certificate_attribute starts' , 'START',null,null,null,'T');


for i in (select c.VSL_CERT_ID_N,
                 a.regSt_c,
                 a.persAllw_q,
                 a.sopepSmpepOnbd_i,
                 b.inComplyMarpolRegu19_i,
                 a.inComplyMarpolRegu20_i,
                 a.inComplyMarpolRegu21_i,
                 a.inComplyMarpolRegu20_dt,
                 a.inComplyMarpolRegu21_dt

            from
                 ST_CV_vslCert a,
                 ST_CV_vsl b ,
                 VESSEL_CERTIFICATE c,
                 vessel v

            where

                 v.VSL_REC_ID_N = a.vslRecID_n
              and  v.msw_vsl_id_n=c.msw_vsl_id_n
                 and c.CERT_TY_C = a.certTy_c
               and b.vslRecID_n = a.vslRecID_n
               --and b.vslRecID_n = c.VSL_REC_ID_N
               )

loop

begin
insert into si_vessel_certificate_attribute (VSLCERTID_N,
                                            REGST_C,
                                            PERSALLW_Q,
                                            SOPEPSMPEPONBD_I,
                                            INCOMPLYMARPOLREGU19_I,
                                            INCOMPLYMARPOLREGU20_I,
                                            INCOMPLYMARPOLREGU21_I,
                                            INCOMPLYMARPOLREGU20_DT,
                                            INCOMPLYMARPOLREGU21_DT
                                            )
                                            values (i.VSL_CERT_ID_N,
                                                    i.regSt_c,
                                                    i.persAllw_q,
                                                    i.sopepSmpepOnbd_i,
                                                    i.inComplyMarpolRegu19_i,
                                                    i.inComplyMarpolRegu20_i,
                                                    i.inComplyMarpolRegu21_i,
                                                    i.inComplyMarpolRegu20_dt,
                                                    i.inComplyMarpolRegu21_dt);

exception
    WHEN OTHERS THEN
            v_err_code := sqlcode;

            v_err_msg := substr(sqlerrm, 1, 200);

            v_sqlerrm := v_err_code || v_err_msg;

v_err_row := 'VSLCERTID_N:'||i.VSL_CERT_ID_N||'*|'||'REGST_C:'||i.regSt_c||'*|'||'PERSALLW_Q:'||i.persAllw_q||'*|'||'SOPEPSMPEPONBD_I:'|| i.sopepSmpepOnbd_i||'*|'||'INCOMPLYMARPOLREGU19_I:'||i.inComplyMarpolRegu19_i||'*|'||'INCOMPLYMARPOLREGU20_I:'||i.inComplyMarpolRegu20_i||'*|'||'INCOMPLYMARPOLREGU21_I:'||i.inComplyMarpolRegu21_i||'*|'||v_sqlerrm||'*|'||
        'Error'||'*|'||dbms_utility.format_error_backtrace;

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',v_err_row, 'ERROR',null,v_err_msg,i.VSL_CERT_ID_N||'*|'||i.regSt_c||'*|'||i.persAllw_q||'*|'||i.sopepSmpepOnbd_i||'*|'||i.inComplyMarpolRegu19_i||'*|'||i.inComplyMarpolRegu20_i||'*|'||i.inComplyMarpolRegu21_i,'B');

end;
end loop;

commit;

--Reconciling the staging table cnt  and intermediate  table count
          select count(*)
            into v_src_count
            from st_cv_vslcert ;



        SELECT COUNT(*)
        INTO v_tgt_count
        FROM si_vessel_certificate_attribute;

        pkg_datamigration_generic.proc_migration_recon('st_cv_vslcert', v_src_count, 'si_vessel_certificate_attribute',
                                                        v_tgt_count,'N');


        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then

         pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into si_vessel_certificate_attribute table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_vessel_certificate_attribute table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_vessel_certificate_attribute table' ,
        'FAIL',null,null,null,null);

        else

     pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_vessel_certificate_attribute table' ,
        'AMBIGIOUS',null,null,null,null);

end if;





/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vslCert   starts
******************************************************************************************************************************************************/
begin

for i in (
select
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT
from ST_CV_vslCert
where vslRecID_n not in (   select VSLRECID_N from ST_CV_vsl )

)
loop


 pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'proc_1_vsl_cert_Attr',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_vslCert AND ST_CV_vsl DUE TO JOIN CONDITION FAILURE',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                   i.CERTTY_C	||'*|'|| i.VSLRECID_N	||'*|'|| i.ISSD_DT	||'*|'||  i.DUE_DT	||'*|'||   i.REGST_C	||'*|'|| i.ISSDBY_C	||'*|'||
                                                   i.ISSAUTHYCTRY_C	||'*|'|| i.ISSGCL_C	||'*|'|| i.PERSALLW_Q	||'*|'|| i.SOPEPSMPEPONBD_I	||'*|'|| i.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   i.INCOMPLYMARPOLREGU21_I	||'*|'|| i.BCCAPPLN_N	||'*|'||
                                                   i.BCCAPPLNST_C	||'*|'|| i.BCCISSD_DT	||'*|'|| i.INSURTY_C	||'*|'|| i.INSURVALTILL_DT	||'*|'|| i.DOCIDATTH_N	||'*|'||
                                                   i.CERTST_C	||'*|'||i.LASTAPPRBY_N	||'*|'|| i.LASTAPPRBY_M	||'*|'|| i.CRTBY_N	||'*|'|| i.CRTBY_M	||'*|'|| i.CRTBYDEPT_M	||'*|'||
                                                   i.CRTON_DT	||'*|'|| i.UPDBY_N	||'*|'|| i.UPDBY_M	||'*|'|| i.UPDBYDEPT_M	||'*|'|| i.UPDON_DT	||'*|'|| i.INTLREM_X	||'*|'||
                                                   i.ISSGCL_M	||'*|'|| i.INCOMPLYMARPOLREGU20_DT	||'*|'|| i.INCOMPLYMARPOLREGU21_DT    ,
                                               'D');



end loop;


exception  when others then null;
end;


/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vslCert   Ends
******************************************************************************************************************************************************/







/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vsl   starts
******************************************************************************************************************************************************/
begin

for i in (
select
VSLRECID_N	,
VSL_M	,
VSLFLAG_C	,
VSLTY_C	,
VSLIMO_N	,
VSLGT_Q	,
VSLNT_Q	,
VSLLEN_Q	,
VSLBRE_Q	,
VSLPREV_M	,
VSLCALLSIGN_N	,
VSLRECST_I	,
VSLCRAFTTY_C	,
VSLACCT_N	,
VSLDWT_N	,
VSLCRAFTLIC_N	,
VSLCRAFTLICVALYFR_D	,
VSLCRAFTLICVALYTO_D	,
VSLCRAFTLICDELIC_D	,
VSLCRAFTLICST_C	,
VSLCRAFTLICUSES_X	,
VSLATTAINABLEHGT_Q	,
USERVEFID_N	,
SYSALLW_I	,
VSLMMSI_N	,
CLCEXP_DT	,
VSLYRBLT_N	,
VSLDELVY_D	,
ISSCVALIDTILL_D	,
ISSCISSGAUTHY_C	,
SOCVALIDTILL_D	,
SOCISSGAUTHY_C	,
PSCVALIDTILL_D	,
PSCISSGAUTHY_C	,
PSCPERSALLW_N	,
BCCEXP_DT	,
PUID_N	,
AGT_M	,
CRAFTGT_Q	,
PORTOFREGY_C	,
PORT_N	,
OFFICIAL_N	,
BUILDER_M	,
OWNR_M	,
OWNRCTRY_C	,
VSLPLBLT_C	,
UNOFFICIALVSL_M	,
UPDUNOFFICIALVSLM_DT	,
UNOFFICIALVSLCALLSIGN_N	,
UNOFFICIALVSLTY_C	,
UNOFFICIALVSLFLAG_C	,
UNOFFICIALVSLGT_Q	,
CRAFTBRE_Q	,
LEN_Q	,
LOA_Q	,
LOAUPDON_DT	,
VSLDEPTH_Q	,
BOWBRIDGE_Q	,
BOWTHRUSTER_N	,
STERNTHRUSTER_N	,
HULLMAKE_C	,
DBLHULLCONSTRUCT_I	,
APPRFORSEATRIAL_I	,
INCOMPLYMARPOLREGU19_I	,
MECHANICPROPEL_I	,
GTEPAN_Q	,
GTEPAN_DT	,
LAUNCHON_DT	,
BARTERTRADE_I	,
BAREBOATCHARTEROUT_I	,
RECVRF_I	,
TRANSIT_I	,
INTLREM_X	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
MERGEFRTOVSLRECID_N	,
EDISENT_I	,
CRAFTHGT_Q

from ST_CV_vsl
where VSLRECID_N not in (   select VSLRECID_N from ST_CV_vslCert )

)



loop


 pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'proc_1_vsl_cert_Attr',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_vsl AND ST_VSL_CERT DUE TO JOIN CONDITION FAILURE',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                  i.VSLRECID_N	||'*|'||i.VSL_M	||'*|'||i.VSLFLAG_C	||'*|'||i.VSLTY_C	||'*|'||i.VSLIMO_N	||'*|'||
i.VSLGT_Q	||'*|'||i.VSLNT_Q	||'*|'||i.VSLLEN_Q	||'*|'||i.VSLBRE_Q	||'*|'||i.VSLPREV_M	||'*|'||i.VSLCALLSIGN_N	||'*|'||i.VSLRECST_I	||'*|'||i.VSLCRAFTTY_C	||'*|'||
i.VSLACCT_N	||'*|'||i.VSLDWT_N	||'*|'||i.VSLCRAFTLIC_N	||'*|'||i.VSLCRAFTLICVALYFR_D	||'*|'||i.VSLCRAFTLICVALYTO_D	||'*|'||i.VSLCRAFTLICDELIC_D	||'*|'||
i.VSLCRAFTLICST_C	||'*|'||i.VSLCRAFTLICUSES_X	||'*|'||i.VSLATTAINABLEHGT_Q	||'*|'||i.USERVEFID_N	||'*|'||i.SYSALLW_I	||'*|'||i.VSLMMSI_N	||'*|'||i.CLCEXP_DT	||'*|'||i.VSLYRBLT_N	||'*|'||i.VSLDELVY_D	||'*|'||i.ISSCVALIDTILL_D	||'*|'||
i.ISSCISSGAUTHY_C	||'*|'||i.SOCVALIDTILL_D	||'*|'||i.SOCISSGAUTHY_C	||'*|'||i.PSCVALIDTILL_D	||'*|'||i.PSCISSGAUTHY_C	||'*|'||i.PSCPERSALLW_N	||'*|'||i.BCCEXP_DT	||'*|'||
i.PUID_N	||'*|'||i.AGT_M	||'*|'||i.CRAFTGT_Q	||'*|'||i.PORTOFREGY_C	||'*|'||i.PORT_N	||'*|'||i.OFFICIAL_N	||'*|'||i.BUILDER_M	||'*|'||
i.OWNR_M	||'*|'||i.OWNRCTRY_C	||'*|'||i.VSLPLBLT_C	||'*|'||i.UNOFFICIALVSL_M	||'*|'||i.UPDUNOFFICIALVSLM_DT	||'*|'||
i.UNOFFICIALVSLCALLSIGN_N	||'*|'||i.UNOFFICIALVSLTY_C	||'*|'||i.UNOFFICIALVSLFLAG_C	||'*|'||i.UNOFFICIALVSLGT_Q	||'*|'||i.CRAFTBRE_Q	||'*|'||
i.LEN_Q	||'*|'||i.LOA_Q	||'*|'||i.LOAUPDON_DT	||'*|'||i.VSLDEPTH_Q	||'*|'||i.BOWBRIDGE_Q	||'*|'||i.BOWTHRUSTER_N	||'*|'||i.STERNTHRUSTER_N	||'*|'||i.HULLMAKE_C	||'*|'||i.DBLHULLCONSTRUCT_I	||'*|'||i.APPRFORSEATRIAL_I	||'*|'||i.INCOMPLYMARPOLREGU19_I	||'*|'||i.MECHANICPROPEL_I	||'*|'||i.GTEPAN_Q	||'*|'||i.GTEPAN_DT	||'*|'||
i.LAUNCHON_DT	||'*|'||i.BARTERTRADE_I	||'*|'||i.BAREBOATCHARTEROUT_I
||'*|'||i.RECVRF_I	||'*|'||i.TRANSIT_I	||'*|'||i.INTLREM_X	||'*|'||i.LASTAPPRBY_N	||'*|'||i.LASTAPPRBY_M	||'*|'||i.CRTBY_N	||'*|'||i.CRTBY_M	||'*|'||i.CRTBYDEPT_M	||'*|'||i.CRTON_DT	||'*|'||i.UPDBY_N	||'*|'||i.UPDBY_M	||'*|'||i.UPDBYDEPT_M	||'*|'||i.UPDON_DT	||'*|'||i.MERGEFRTOVSLRECID_N	||'*|'||i.EDISENT_I	||'*|'||i.CRAFTHGT_Q
    ,
                                               'D');



end loop;


exception  when others then null;
end;


/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vsl   Ends
******************************************************************************************************************************************************/

/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vslCert and query Starts
******************************************************************************************************************************************************/



begin

for i in
(
select
CERTTY_C	,
VSLRECID_N	,
ISSD_DT	,
DUE_DT	,
REGST_C	,
ISSDBY_C	,
ISSAUTHYCTRY_C	,
ISSGCL_C	,
PERSALLW_Q	,
SOPEPSMPEPONBD_I	,
INCOMPLYMARPOLREGU20_I	,
INCOMPLYMARPOLREGU21_I	,
BCCAPPLN_N	,
BCCAPPLNST_C	,
BCCISSD_DT	,
INSURTY_C	,
INSURVALTILL_DT	,
DOCIDATTH_N	,
CERTST_C	,
LASTAPPRBY_N	,
LASTAPPRBY_M	,
CRTBY_N	,
CRTBY_M	,
CRTBYDEPT_M	,
CRTON_DT	,
UPDBY_N	,
UPDBY_M	,
UPDBYDEPT_M	,
UPDON_DT	,
INTLREM_X	,
ISSGCL_M	,
INCOMPLYMARPOLREGU20_DT	,
INCOMPLYMARPOLREGU21_DT

from ST_CV_vslCert where vslRecID_n not in (    select a.vslRecID_n
                                                 from ST_CV_vslCert a,
                                                 ST_CV_vsl b ,
                                                 VESSEL_CERTIFICATE c,
                                                 vessel v
                                                where v.VSL_REC_ID_N = a.vslRecID_n
                                                and  v.msw_vsl_id_n=c.msw_vsl_id_n
                                                and c.CERT_TY_C = a.certTy_c
                                                and b.vslRecID_n = a.vslRecID_n)

)


loop


 pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES',
                                                'proc_1_vsl_cert_Attr',
                                                'UNCOMMON RECORDS BETWEEN  ST_CV_vslCert AND WHOLE QUERY DUE TO JOIN CONDITION FAILURE',
                                                null,
                                                 PV_RUN_ID,
                                                  null,
                                                   i.CERTTY_C	||'*|'|| i.VSLRECID_N	||'*|'|| i.ISSD_DT	||'*|'||  i.DUE_DT	||'*|'||   i.REGST_C	||'*|'|| i.ISSDBY_C	||'*|'||
                                                   i.ISSAUTHYCTRY_C	||'*|'|| i.ISSGCL_C	||'*|'|| i.PERSALLW_Q	||'*|'|| i.SOPEPSMPEPONBD_I	||'*|'|| i.INCOMPLYMARPOLREGU20_I	||'*|'||
                                                   i.INCOMPLYMARPOLREGU21_I	||'*|'|| i.BCCAPPLN_N	||'*|'||
                                                   i.BCCAPPLNST_C	||'*|'|| i.BCCISSD_DT	||'*|'|| i.INSURTY_C	||'*|'|| i.INSURVALTILL_DT	||'*|'|| i.DOCIDATTH_N	||'*|'||
                                                   i.CERTST_C	||'*|'||i.LASTAPPRBY_N	||'*|'|| i.LASTAPPRBY_M	||'*|'|| i.CRTBY_N	||'*|'|| i.CRTBY_M	||'*|'|| i.CRTBYDEPT_M	||'*|'||
                                                   i.CRTON_DT	||'*|'|| i.UPDBY_N	||'*|'|| i.UPDBY_M	||'*|'|| i.UPDBYDEPT_M	||'*|'|| i.UPDON_DT	||'*|'|| i.INTLREM_X	||'*|'||
                                                   i.ISSGCL_M	||'*|'|| i.INCOMPLYMARPOLREGU20_DT	||'*|'|| i.INCOMPLYMARPOLREGU21_DT    ,
                                               'B');



end loop;


exception  when others then null;
end;


/**************************************************************************************************************************************************
Listing out the un common records from the joining condition from ST_CV_vslCert and query Ends
******************************************************************************************************************************************************/




















/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/
   --find the count of intermediate table(source table) to compare the count with the that of target table




    OPEN cur_vslcrtAttr;

           pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr','Insertion into VESSEL_CERTIFICATE_ATTRIBUTES starts' , 'START',null,null,null,null);

       loop
begin
   --loading the data of cursor into the collection variable in the batches of the value specified in limit
        --   v_sq_vslCrtId := seq_vsl_cert_Att.nextval;

             FETCH cur_vslcrtAttr BULK COLLECT INTO lv_vsl_cert LIMIT 5000;

              EXIT WHEN lv_vsl_cert.count = 0;
   -- inserting the data from the collection variable into the target table in the batches of the value specified in limit

                 FORALL i IN lv_vsl_cert.first..lv_vsl_cert.last SAVE EXCEPTIONS

                   INSERT INTO VESSEL_CERTIFICATE_ATTRIBUTES
                               (
                                VSL_CERT_ATTRB_ID_N,
                                VSL_CERT_ID_N,
                                REG_ST_C,
                                PERS_ALLW_Q,
                                SOPEP_SMPEP_ONBD_I,
                                IN_COMPLY_MARPOL_REGU19_I,
                                IN_COMPLY_MARPOL_REGU20_I,
                                IN_COMPLY_MARPOL_REGU21_I,
                                CRT_ON_DT,
                                CRT_BY_X	,
                                UPT_ON_DT,
                                UPT_BY_X,
                                LOCK_VER_N,
                                DELETED_I,
                                IN_COMPLY_MARPOL_REGU20_DT,
                                IN_COMPLY_MARPOL_REGU21_DT)

                  VALUES (seq_vsl_cert_Att.nextval,
                          lv_vsl_cert(i).v_vslCertId_n,
                          decode(lv_vsl_cert(i).v_regSt_c,1,'Permanent',2,'Provisional'),
                          lv_vsl_cert(i).v_persAllw_q,
                          DECODE(lv_vsl_cert(i).v_sopepSmpepOnbd_i,'Y',1,'N',0),
                          DECODE(lv_vsl_cert(i).v_inComplyMarpolRegu19_i,'Y',1,'N',0),
                          DECODE(lv_vsl_cert(i).v_inComplyMarpolRegu20_i,'Y',1,'N',0),
                          DECODE(lv_vsl_cert(i).v_inComplyMarpolRegu21_i,'Y',1,'N',0),
                          SYSDATE,
                          'DATA MIGRATION',
                          SYSDATE,
                          'DATA MIGRATION',
                          0,
                          0,
                          lv_vsl_cert(i).v_inComplyMarpolRegu20_dt,
                          lv_vsl_cert(i).v_inComplyMarpolRegu21_dt);

    -- defining the inner exception to prevent the control breaking out of loop abruptly in case of failure
          EXCEPTION


             WHEN OTHERS THEN

                v_err_code := sqlcode;

                v_err_msg := substr(sqlerrm, 1, 200);

                v_sqlerrm := v_err_code || v_err_msg||dbms_utility.format_error_stack;

                v_blkexptn_count := SQL%bulk_exceptions.count;



         FOR i IN 1..v_blkexptn_count

               LOOP
                  -- Print out details of each error during bulk insert
                 v_blkexptn_desc := 'Error#: '
                               || i
                                  || '; Row Number : '
                                  || SQL%bulk_exceptions(i).error_index
                                        || ' message: '
                                           ||
                                      sqlerrm ||SQL%bulk_exceptions(i).error_code
                                       ||' i2T' ||SQLERRM(0 - SQL%BULK_EXCEPTIONS(i).error_code);

                          V_exp_rows1 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_vslCertId_n;
                          V_exp_rows2 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_regSt_c;
                          V_exp_rows3 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_persAllw_q;
                          V_exp_rows4 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_sopepSmpepOnbd_i;
                          V_exp_rows5 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_inComplyMarpolRegu19_i;
                          V_exp_rows6 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_inComplyMarpolRegu20_i;
                          V_exp_rows7 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_inComplyMarpolRegu21_i;
                          V_exp_rows8 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_inComplyMarpolRegu20_dt;
                          V_exp_rows9 :=   lv_vsl_cert(SQL%bulk_exceptions(i).error_index).v_inComplyMarpolRegu21_dt;

                V_exp_rows := V_exp_rows1||','||V_exp_rows2 ||','||  V_exp_rows3 ||','|| V_exp_rows4 ||','|| V_exp_rows5 ||','||
                               V_exp_rows6 ||','|| V_exp_rows7;


            pkg_datamigration_generic.proc_trace_exception
            ('VESSEL_CERTIFICATE_ATTRIBUTES',
            'proc_1_vsl_cert_Attr',
            v_blkexptn_desc||
                'VSL_CERT_ATTRB_ID_N:'||seq_vsl_cert_Att.currval||'*|'||
            'VSL_CERT_ID_N:'||lv_vsl_cert(i).v_vslCertId_n||'*|'||
'REG_ST_C:'||lv_vsl_cert(i).v_regSt_c||'*|'||
'PERS_ALLW_Q:'||lv_vsl_cert(i).v_persAllw_q||'*|'||
 'SOPEP_SMPEP_ONBD_I:'	||lv_vsl_cert(i).v_sopepSmpepOnbd_i||'*|'||
'IN_COMPLY_MARPOL_REGU19_I:'||lv_vsl_cert(i).v_inComplyMarpolRegu19_i	||'*|'||
'IN_COMPLY_MARPOL_REGU20_I:'||lv_vsl_cert(i).v_inComplyMarpolRegu20_i	||'*|'||
 'IN_COMPLY_MARPOL_REGU21_I:'||lv_vsl_cert(i).v_inComplyMarpolRegu21_i	||'*|'||
 'CRT_ON_DT:'||SYSDATE ||'*|'||
  'CRT_BY_X:'||'DATA MIGRATION' ||'*|'||
  'UPT_ON_DT:'||SYSDATE	||'*|'||
 'UPT_BY_X:'||'DATA MIGRATION'||'*|'||
 'LOCK_VER_N:'||0||'*|'||
 'DELETED_I:'||0||'*|'||
 'IN_COMPLY_MARPOL_REGU20_DT:'||lv_vsl_cert(i).v_inComplyMarpolRegu20_dt||'*|'||
 'IN_COMPLY_MARPOL_REGU21_DT:'||lv_vsl_cert(i).v_inComplyMarpolRegu21_dt,
 'ERROR'
,PV_RUN_ID
,v_sqlerrm,
seq_vsl_cert_Att.currval||'*|'||lv_vsl_cert(i).v_vslCertId_n||'*|'||lv_vsl_cert(i).v_regSt_c||'*|'||lv_vsl_cert(i).v_persAllw_q||'*|'||
lv_vsl_cert(i).v_sopepSmpepOnbd_i||'*|'||lv_vsl_cert(i).v_inComplyMarpolRegu19_i	||'*|'||lv_vsl_cert(i).v_inComplyMarpolRegu20_i	||'*|'||
lv_vsl_cert(i).v_inComplyMarpolRegu21_i	||'*|'||SYSDATE ||'*|'||'DATA MIGRATION' ||'*|'||SYSDATE	||'*|'||'DATA MIGRATION'||'*|'||0||'*|'||'F',
'T');

             end loop;

               COMMIT;

            end;


        END LOOP;
        close cur_vslcrtAttr;

    --Taking count of each and imdividual source and target table for reconcialation purpose

    SELECT COUNT(*)
      INTO v_src_count
      FROM si_vessel_certificate_attribute;


        SELECT COUNT(*)
        INTO v_tgt_count
        FROM VESSEL_CERTIFICATE_ATTRIBUTES;

        pkg_datamigration_generic.proc_migration_recon('si_vessel_certificate_attribute', v_src_count, 'VESSEL_CERTIFICATE_ATTRIBUTES', v_tgt_count,'N');


        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then

         pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into VESSEL_CERTIFICATE_ATTRIBUTES table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into VESSEL_CERTIFICATE_ATTRIBUTES table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into VESSEL_CERTIFICATE_ATTRIBUTES table' ,
        'FAIL',null,null,null,null);

        else

     pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr',
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into VESSEL_CERTIFICATE_ATTRIBUTES table' ,
        'AMBIGIOUS',null,null,null,null);

end if;





            SELECT COUNT(*)
      INTO v_src_count
      FROM st_cv_vslcert;



        SELECT COUNT(*)
        INTO v_tgt_count
        FROM VESSEL_CERTIFICATE_ATTRIBUTES;

        pkg_datamigration_generic.proc_migration_recon('ST_CV_vslCert', v_src_count, 'VESSEL_CERTIFICATE_ATTRIBUTES', v_tgt_count,'Y');





EXCEPTION
    WHEN OTHERS THEN
            v_err_code := sqlcode;

                v_err_msg := substr(sqlerrm, 1, 200);

                v_sqlerrm := v_err_code || v_err_msg;

        pkg_datamigration_generic.proc_trace_exception('VESSEL_CERTIFICATE_ATTRIBUTES', 'proc_1_vsl_cert_Attr', v_sqlerrm||
        'Error'||dbms_utility.format_error_backtrace, 'ERROR',null,null,null,'T');
END;
/