create or replace PROCEDURE proc_1_vsl(PV_ERR_CNT OUT VARCHAR2,PV_RUN_ID IN NUMBER)  IS

    lv_cnt_st              NUMBER;
    lv_cnt_si              NUMBER;
      lv_vslty_id            NUMBER;
     lv_crftty_id           NUMBER;
    lv_cnt_src             NUMBER;
    lv_cnt_tar             NUMBER;
    v_m_err_code         NUMBER;
    v_m_err_msg          VARCHAR2(200);
/***********************************************************************************************************
procedure name : proc_1_vsl
Created By     : Sourangshu Dhar
Date           : 17-Apr-2019
Purpose        : To insert data into VESSEL Table .
Modified by    :
Modified date  : 
*************************************************************************************************************/
---**** cursor for fetching data from Source Staging Table ****
    CURSOR cr_si_cv_vsl IS
    SELECT
        a.vslrecid_n,
        a.vsl_m,
        a.official_n,
        a.vslflag_c,
        a.vsldwt_n,a.vslrecst_i,
        --decode(a.vslrecst_i,'1','DELETE','4','MERGED', NULL ,'ACTIVE') vslrecst_i,
        a.vslcraftlic_n,
        a.vslattainablehgt_q,
        a.vslyrblt_n,
        a.portofregy_c,
        a.port_n,
        a.vsllen_q,
        a.loa_q,
        a.vsldepth_q,
        a.vslbre_q,
        a.mechanicpropel_i,
        a.vslmmsi_n,
        a.vslty_c,
        a.vslcraftty_c,
        a.vslgt_q,
        a.vslnt_q,
        a.vslcallsign_n,
        a.vslimo_n,
        a.ownr_m,
        a.VSLDELVY_D,
        a.LAUNCHON_DT,
        a.GTEPAN_DT,
        a.BOWBRIDGE_Q,
        a.BOWTHRUSTER_N,
        a.STERNTHRUSTER_N,
        a.DBLHULLCONSTRUCT_I,
        a.APPRFORSEATRIAL_I,
        a.MERGEFRTOVSLRECID_N,
        a.BARTERTRADE_I,
        a.BAREBOATCHARTEROUT_I,
        a.TRANSIT_I,
        a.UNOFFICIALVSL_M,
        a.UNOFFICIALVSLCALLSIGN_N,
        a.UNOFFICIALVSLTY_C,
        a.UNOFFICIALVSLFLAG_C,
        a.UNOFFICIALVSLGT_Q,
        a.GTEPAN_Q,
        a.BUILDER_M,
        a.OWNRCTRY_C,
        a.VSLPLBLT_C,
        a.vslCraftLicValyFr_d,
        a.vslCraftLicValyTo_d,
        a.vslCraftLicDelic_d,
        a.vslCraftLicSt_c,
        a.vslCraftLicUses_x
    FROM
        st_cv_vsl a;

--******* cursor for fetching data from Intermediate Table ****

    CURSOR cr_vsl IS
    SELECT
        vslrecid_n,
        vsl_m,
        official_n,
        vslflag_c,
        vsldwt_n,
        vslrecst_i,
        vslcraftlic_n,
        vslattainablehgt_q,
        vslyrblt_n,
        portofregy_c,
        port_n,
        vsllen_q,
        loa_q,
        vsldepth_q,
        vslbre_q,
        mechanicpropel_i,
        vslmmsi_n,
        vsltypeid_n,
        crafttypeid_n,
        vslgt_q,
        vslnt_q,
        vslcallsign_n,
        vslimo_n,
        ownr_m,VSLDELVY_D,
        LAUNCHON_DT,
        GTEPAN_DT,
        BOWBRIDGE_Q,
        BOWTHRUSTER_N,
        STERNTHRUSTER_N,
        DBLHULLCONSTRUCT_I,
        APPRFORSEATRIAL_I,
        MERGEFRTOVSLRECID_N,
        BARTERTRADE_I,
        BAREBOATCHARTEROUT_I,
        TRANSIT_I,
        UNOFFICIALVSL_M,
        UNOFFICIALVSLCALLSIGN_N,
        UNOFFICIALVSLTY_C,
        UNOFFICIALVSLFLAG_C,
        UNOFFICIALVSLGT_Q,
        GTEPAN_Q,
        BUILDER_M,
        OWNRCTRY_C,
        VSLPLBLT_C,
        VSLCRAFTLICVALYFR_D,
        VSLCRAFTLICVALYTO_D,
        VSLCRAFTLICDELIC_D,
        VSLCRAFTLICST_C,
        VSLCRAFTLICUSES_X
    FROM
        si_cv_vsl;
-------------************ Declaring Record Types ************------------------

    TYPE rec_cv_vsl_src IS RECORD (
        vslrecid_n_r           NUMBER(7),
        vsl_m_r                VARCHAR2(35),
        official_n_r           VARCHAR2(11),
        vslflag_c_r            CHAR(2),
        vsldwt_n_r             NUMBER(6),
        vslrecst_i_r           CHAR(1),
        vslcraftlic_n_r        CHAR(8),
        vslattainablehgt_q_r   NUMBER(4),
        vslyrblt_n_r           NUMBER(4),
        portofregy_c_r         VARCHAR2(5),
        port_n_r               VARCHAR2(8),
        vsllen_q_r             NUMBER(5),
        loa_q_r                NUMBER(5),
        vsldepth_q_r           NUMBER(5),
        vslbre_q_r             NUMBER(5),
        mechanicpropel_i_r     CHAR(1),
        vslmmsi_n_r            NUMBER(9),
        --    vsltypeid_n_r          NUMBER(20),
         --   crafttypeid_n_r        NUMBER(20),
        vslty_c_r              VARCHAR2(10)
         --   LV_VSLTY_ID            varchar2(10)
    );
    TYPE typ_cv_vsl_src IS
        TABLE OF rec_cv_vsl_src INDEX BY PLS_INTEGER;
    lv_cv_vsl_src          typ_cv_vsl_src;
    TYPE rec_cv_vsl IS RECORD (
        vslrecid_n_r           si_cv_vsl.vslrecid_n%TYPE,
        vsl_m_r                si_cv_vsl.vsl_m%TYPE,
        official_n_r           si_cv_vsl.official_n%TYPE,
        vslflag_c_r            si_cv_vsl.vslflag_c%TYPE,
        vsldwt_n_r             si_cv_vsl.vsldwt_n%TYPE,
        vslrecst_i_r           si_cv_vsl.vslrecst_i%TYPE,
        vslcraftlic_n_r        si_cv_vsl.vslcraftlic_n%TYPE,
        vslattainablehgt_q_r   si_cv_vsl.vslattainablehgt_q%TYPE,
        vslyrblt_n_r           si_cv_vsl.vslyrblt_n%TYPE,
        portofregy_c_r         si_cv_vsl.portofregy_c%TYPE,
        port_n_r               si_cv_vsl.port_n%TYPE,
        vsllen_q_r             si_cv_vsl.vsllen_q%TYPE,
        loa_q_r                si_cv_vsl.loa_q%TYPE,
        vsldepth_q_r           si_cv_vsl.vsldepth_q%TYPE,
        vslbre_q_r             si_cv_vsl.vslrecid_n%TYPE,
        mechanicpropel_i_r     si_cv_vsl.mechanicpropel_i%TYPE,
        vslmmsi_n_r            si_cv_vsl.vslmmsi_n%TYPE,
        vsltypeid_n_r          si_cv_vsl.vsltypeid_n%TYPE,
        crafttypeid_n_r        si_cv_vsl.crafttypeid_n%TYPE,
        vslgt_q_r              si_cv_vsl.vslgt_q%TYPE,
        vslnt_q_r              si_cv_vsl.vslnt_q%TYPE,
        vslcallsign_n_r        si_cv_vsl.vslcallsign_n%TYPE,
        vslimo_n_r             si_cv_vsl.vslimo_n%TYPE,
        ownr_m_r               si_cv_vsl.ownr_m%TYPE,
        VSLDELVY_D_R             si_cv_vsl.VSLDELVY_D%TYPE,
        LAUNCHON_DT_R            si_cv_vsl.LAUNCHON_DT%TYPE,
        GTEPAN_DT_R              si_cv_vsl.GTEPAN_DT%TYPE,
        BOWBRIDGE_Q_R            si_cv_vsl.BOWBRIDGE_Q%TYPE,
        BOWTHRUSTER_N_R          si_cv_vsl.BOWTHRUSTER_N%TYPE,
        STERNTHRUSTER_N_R        si_cv_vsl.STERNTHRUSTER_N%TYPE,
        DBLHULLCONSTRUCT_I_R     si_cv_vsl.DBLHULLCONSTRUCT_I%TYPE,
        APPRFORSEATRIAL_I_R      si_cv_vsl.APPRFORSEATRIAL_I%TYPE,
        MERGEFRTOVSLRECID_N_R    si_cv_vsl.MERGEFRTOVSLRECID_N%TYPE,
        BARTERTRADE_I_R          si_cv_vsl.BARTERTRADE_I%TYPE,
        BAREBOATCHARTEROUT_I_R   si_cv_vsl.BAREBOATCHARTEROUT_I%TYPE,
        TRANSIT_I_R              si_cv_vsl.TRANSIT_I%TYPE,
        UNOFFICIALVSL_M_R        si_cv_vsl.UNOFFICIALVSL_M%TYPE,
        UNOFFICIALVSLCALLSIGN_N_R    si_cv_vsl.UNOFFICIALVSLCALLSIGN_N%TYPE,
        UNOFFICIALVSLTY_C_R      si_cv_vsl.UNOFFICIALVSLTY_C%TYPE,
        UNOFFICIALVSLFLAG_C_R    si_cv_vsl.UNOFFICIALVSLFLAG_C%TYPE,
        UNOFFICIALVSLGT_Q_R      si_cv_vsl.UNOFFICIALVSLGT_Q%TYPE,
        GTEPAN_Q_R               si_cv_vsl.GTEPAN_Q%TYPE,
        BUILDER_M_R              si_cv_vsl.BUILDER_M%TYPE,
        OWNRCTRY_C_R             si_cv_vsl.OWNRCTRY_C%TYPE,
        VSLPLBLT_C_R             si_cv_vsl.VSLPLBLT_C%TYPE,
        VSLCRAFTLICVALYFR_D_R       si_cv_vsl.VSLCRAFTLICVALYFR_D%TYPE,
        VSLCRAFTLICVALYTO_D_R       si_cv_vsl.VSLCRAFTLICVALYTO_D%TYPE,
        VSLCRAFTLICDELIC_D_R        si_cv_vsl.VSLCRAFTLICDELIC_D%TYPE,
        VSLCRAFTLICST_C_R           si_cv_vsl.VSLCRAFTLICST_C%TYPE,
        VSLCRAFTLICUSES_X_R         si_cv_vsl.VSLCRAFTLICUSES_X%TYPE
    );
    TYPE typ_cv_vsl IS
        TABLE OF rec_cv_vsl INDEX BY PLS_INTEGER;
    lv_cv_vsl              typ_cv_vsl;
    v_err_code         NUMBER;
    v_err_msg          VARCHAR2(2000);
    v_sqlerrm          VARCHAR2(4000);
    v_blkexptn_count   NUMBER(20,0);
    v_blkexptn_desc    varchar2(4000);
    V_exp_rows         varchar2(4000);
    v_m_sqlerrm          VARCHAR2(2500);
 /*   V_exp_rows1        varchar2(1000);
    V_exp_rows2        varchar2(1000);
    V_exp_rows3        varchar2(1000);
    V_exp_rows4        varchar2(1000);
    V_exp_rows5        varchar2(1000);
    V_exp_rows6        varchar2(1000);
    V_exp_rows7        varchar2(1000);
    V_exp_rows8        varchar2(1000);
    V_exp_rows9        varchar2(1000);
    V_exp_rows10        varchar2(1000);
    V_exp_rows11        varchar2(1000);
    V_exp_rows12        varchar2(1000);
    V_exp_rows13        varchar2(1000);
    V_exp_rows14        varchar2(1000);
    V_exp_rows15        varchar2(1000);
    V_exp_rows16        varchar2(1000);
    V_exp_rows17        varchar2(1000);
    V_exp_rows18        varchar2(1000);
    V_exp_rows19        varchar2(1000);
    V_exp_rows20        varchar2(1000);
    V_exp_rows21        varchar2(1000);
    V_exp_rows22        varchar2(1000);
    V_exp_rows23        varchar2(1000);
    V_exp_rows24        varchar2(1000);
    V_exp_rows25        varchar2(1000); */
    v_err_row          varchar2(4000);
    V_EXP_ROWS_SI           varchar2(4000);
BEGIN
    SELECT
        COUNT(*)
    INTO lv_cnt_st
    FROM
        st_cv_vsl;

     --   OPEN c1;

    pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', 'Insertion into Table SI_CV_VSL', 'START',PV_RUN_ID,NULL,NULL,'T');
    FOR i IN cr_si_cv_vsl LOOP
        BEGIN
            /*
                FETCH c1 BULK COLLECT INTO lv_cv_vsl_src LIMIT 10;
                EXIT WHEN lv_cv_vsl_src.count = 0;
                FORALL i IN lv_cv_vsl_src.first..lv_cv_vsl_src.last */

-------------************ fetching vsltypeid_n and crafttypeid_n field ************------------------
      
                lv_vslty_id := NULL ;
                lv_crftty_id := NULL ;
            IF i.vslcraftty_c IS NOT NULL THEN
                BEGIN
                SELECT
                       --VSL_TYPE_ID_N,
                       CRAFT_TYPE_ID_N
                INTO
                    --lv_vslty_id,
                    lv_crftty_id
                FROM
                    craft_type
                WHERE
                    VSL_CRAFT_TY_C = trim(i.vslcraftty_c);  --Transformation rule VESSEL.VSLTYPEID_N and VESSEL.CRAFTTYPEID_N
                 exception 
                 when others then
                 lv_crftty_id := NULL ; 
                  pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', 
                  'Craft Type does not exist in Craft_Type Table'||sqlerrm||dbms_utility.format_error_backtrace,
                  'ERROR',PV_RUN_ID,null,null ,'T');
                  --dbms_output.put_line('Error for Craft type'|| i.vslcraftty_c||'--'||sqlerrm|| dbms_utility.format_error_backtrace);
                 END ; 

             END IF;
             
             begin
                SELECT
                    VSL_TYPE_ID_N
                INTO lv_vslty_id
                FROM
                    vessel_type
                WHERE
                    VSL_TY_C = trim(i.vslty_c);

          
             EXCEPTION WHEN OTHERS THEN
                lv_vslty_id := NULL ;
                pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL',
                'Vessel Type does not exist in Vessel_Type Table'||i.vslty_c||'--'||sqlerrm||dbms_utility.format_error_backtrace,
                'ERROR',PV_RUN_ID,null,null ,'T');
                 --dbms_output.put_line('Error for Vessel Type'||sqlerrm|| dbms_utility.format_error_backtrace);
                --continue ;
                END ;  
-------------************ Insertion into SI_CV_VSL Table ************------------------

            INSERT INTO si_cv_vsl (
                vslrecid_n,
                vsl_m,
                official_n,
                vslflag_c,
                vsldwt_n,
                vslrecst_i,
                vslcraftlic_n,
                vslattainablehgt_q,
                vslyrblt_n,
                portofregy_c,
                port_n,
                vsllen_q,
                loa_q,
                vsldepth_q,
                vslbre_q,
                mechanicpropel_i,
                vslmmsi_n,
                vsltypeid_n,
                crafttypeid_n,
                vslgt_q,
                vslnt_q,
                vslcallsign_n,
                vslimo_n,
                ownr_m,VSLDELVY_D,
                LAUNCHON_DT,
                GTEPAN_DT,
                BOWBRIDGE_Q,
                BOWTHRUSTER_N,
                STERNTHRUSTER_N,
                DBLHULLCONSTRUCT_I,
                APPRFORSEATRIAL_I,
                MERGEFRTOVSLRECID_N,
                BARTERTRADE_I,
                BAREBOATCHARTEROUT_I,
                TRANSIT_I,
                UNOFFICIALVSL_M,
                UNOFFICIALVSLCALLSIGN_N,
                UNOFFICIALVSLTY_C,
                UNOFFICIALVSLFLAG_C,
                UNOFFICIALVSLGT_Q,
                GTEPAN_Q,
                BUILDER_M,
                OWNRCTRY_C,
                VSLPLBLT_C,
                VSLCRAFTLICVALYFR_D,
                VSLCRAFTLICVALYTO_D,
                VSLCRAFTLICDELIC_D,
                VSLCRAFTLICST_C,
                VSLCRAFTLICUSES_X
            ) VALUES (
                i.vslrecid_n,
                i.vsl_m,
                i.official_n,
                i.vslflag_c,
                i.vsldwt_n,
                i.vslrecst_i,
                i.vslcraftlic_n,
                i.vslattainablehgt_q,
                i.vslyrblt_n,
                i.portofregy_c,
                i.port_n,
                i.vsllen_q,
                i.loa_q,
                i.vsldepth_q,
                i.vslbre_q,
                i.mechanicpropel_i,
                i.vslmmsi_n,
                lv_vslty_id,
                lv_crftty_id,
                i.vslgt_q,
                i.vslnt_q,
                i.vslcallsign_n,
                i.vslimo_n,
                i.ownr_m,
                i.VSLDELVY_D,
                i.LAUNCHON_DT,
                i.GTEPAN_DT,
                i.BOWBRIDGE_Q,
                i.BOWTHRUSTER_N,
                i.STERNTHRUSTER_N,
                i.DBLHULLCONSTRUCT_I,
                i.APPRFORSEATRIAL_I,
                i.MERGEFRTOVSLRECID_N,
                i.BARTERTRADE_I,
                i.BAREBOATCHARTEROUT_I,
                i.TRANSIT_I,
                i.UNOFFICIALVSL_M,
                i.UNOFFICIALVSLCALLSIGN_N,
                i.UNOFFICIALVSLTY_C,
                i.UNOFFICIALVSLFLAG_C,
                i.UNOFFICIALVSLGT_Q,
                i.GTEPAN_Q,
                i.BUILDER_M,
                i.OWNRCTRY_C,
                i.VSLPLBLT_C,
                i.VSLCRAFTLICVALYFR_D,
                i.VSLCRAFTLICVALYTO_D,
                i.VSLCRAFTLICDELIC_D,
                i.VSLCRAFTLICST_C,
                i.VSLCRAFTLICUSES_X

                    /*
                        lv_cv_vsl_src(i).vslrecid_n_r,
                        lv_cv_vsl_src(i).vsl_m_r,
                        lv_cv_vsl_src(i).official_n_r,
                        lv_cv_vsl_src(i).vslflag_c_r,
                        lv_cv_vsl_src(i).vsldwt_n_r,
                        lv_cv_vsl_src(i).vslrecst_i_r,
                        lv_cv_vsl_src(i).vslcraftlic_n_r,
                        lv_cv_vsl_src(i).vslattainablehgt_q_r,
                        lv_cv_vsl_src(i).vslyrblt_n_r,
                        lv_cv_vsl_src(i).portofregy_c_r,
                        lv_cv_vsl_src(i).port_n_r,
                        lv_cv_vsl_src(i).vsllen_q_r,
                        lv_cv_vsl_src(i).loa_q_r,
                        lv_cv_vsl_src(i).vsldepth_q_r,
                        lv_cv_vsl_src(i).vslbre_q_r,
                        lv_cv_vsl_src(i).mechanicpropel_i_r,
                        lv_cv_vsl_src(i).vslmmsi_n_r,
                        LV_VSLTY_ID, null */
                    --    lv_cv_vsl_src(i).vsltypeid_n_r,
                     --   lv_cv_vsl_src(i).crafttypeid_n_r
            );

        EXCEPTION
            WHEN OTHERS THEN
             v_m_err_code := sqlcode;

                v_m_err_msg := substr(sqlerrm, 1, 200);

                v_m_sqlerrm := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| v_m_err_code || v_m_err_msg;
                
        V_EXP_ROWS_SI:=                     i.vslrecid_n||'*|'||
                                            i.vsl_m||'*|'||
                                            i.official_n||'*|'||
                                            i.vslflag_c||'*|'||
                                            i.vsldwt_n||'*|'||
                                            i.vslrecst_i||'*|'||
                                            i.vslcraftlic_n||'*|'||
                                            i.vslattainablehgt_q||'*|'||
                                            i.vslyrblt_n||'*|'||
                                            i.portofregy_c||'*|'||
                                            i.port_n||'*|'||
                                            i.vsllen_q||'*|'||
                                            i.loa_q||'*|'||
                                            i.vsldepth_q||'*|'||
                                            i.vslbre_q||'*|'||
                                            i.mechanicpropel_i||'*|'||
                                            i.vslmmsi_n||'*|'||
                                            Lv_vslty_id||'*|'||
                                            lv_crftty_id||'*|'||
                                            i.vslgt_q||'*|'||
                                            i.vslnt_q||'*|'||
                                            i.vslcallsign_n||'*|'||
                                            i.vslimo_n||'*|'||
                                            i.ownr_m ||'*|'||
                                            i.VSLDELVY_D||'*|'||
                                            i.LAUNCHON_DT||'*|'||
                                            i.GTEPAN_DT||'*|'||
                                            i.BOWBRIDGE_Q||'*|'||
                                            i.BOWTHRUSTER_N||'*|'||
                                            i.STERNTHRUSTER_N||'*|'||
                                            i.DBLHULLCONSTRUCT_I||'*|'||
                                            i.APPRFORSEATRIAL_I||'*|'||
                                            i.MERGEFRTOVSLRECID_N||'*|'||
                                            i.BARTERTRADE_I||'*|'||
                                            i.BAREBOATCHARTEROUT_I||'*|'||
                                            i.TRANSIT_I||'*|'||
                                            i.UNOFFICIALVSL_M||'*|'||
                                            i.UNOFFICIALVSLCALLSIGN_N||'*|'||
                                            i.UNOFFICIALVSLTY_C||'*|'||
                                            i.UNOFFICIALVSLFLAG_C||'*|'||
                                            i.UNOFFICIALVSLGT_Q||'*|'||
                                            i.GTEPAN_Q||'*|'||
                                            i.BUILDER_M||'*|'||
                                            i.OWNRCTRY_C||'*|'||
                                            i.VSLPLBLT_C ||'*|'||
                                            i.VSLCRAFTLICVALYFR_D||'*|'||
                                            i.VSLCRAFTLICVALYTO_D||'*|'||
                                            i.VSLCRAFTLICDELIC_D||'*|'||
                                            i.VSLCRAFTLICST_C||'*|'||
                                            i.VSLCRAFTLICUSES_X ;

            pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', v_m_sqlerrm, 'ERROR',PV_RUN_ID,v_m_err_msg,V_EXP_ROWS_SI ,'T');
        END;
    END LOOP;

    --pkg_datamigration_generic.proc_trace_exception('SI_CV_VSL', 'PROC_1_VSL', lv_cnt_si||' out of '||lv_cnt_st||' records loaded successfully', 'SUCCESS');
    COMMIT;
    SELECT
        COUNT(*)
    INTO lv_cnt_si
    FROM
        si_cv_vsl;
    --    pkg_datamigration_generic.proc_trace_exception('SI_CV_VSL', 'PROC_1_VSL', lv_cnt_si||' out of '||lv_cnt_st||' records loaded successfully', 'SUCCESS');

    if (lv_cnt_si =  lv_cnt_st ) and lv_cnt_st <>  0  and lv_cnt_si <> 0 then

         pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_si||' out of '||lv_cnt_st||' records loaded successfully', 'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    elsif lv_cnt_si  <> lv_cnt_st and lv_cnt_si <> 0 then

        pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_si ||' out of ' ||lv_cnt_st ||' records loaded successfully' ,'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (lv_cnt_si  <> lv_cnt_st or lv_cnt_si  = lv_cnt_st ) and (lv_cnt_si = 0) then

        pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_si ||' out of ' ||lv_cnt_st ||' records loaded successfully' ,'FAIL',PV_RUN_ID,NULL,NULL,'T');

    end if;

    pkg_datamigration_generic.proc_migration_recon('ST_cv_vsl', lv_cnt_st, 'SI_CV_VSL', lv_cnt_si,'N');

---**** Insertion into Target Staging Tables ******
       OPEN cr_vsl;
         pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', 'Insertion into Table VESSEL', 'START',PV_RUN_ID,NULL,NULL,'T');
/*       FOR j in cr_vsl  */
        LOOP
            BEGIN
---**** Insertion into VESSEL Table ******

                FETCH cr_vsl BULK COLLECT INTO lv_cv_vsl LIMIT 1000;
                EXIT WHEN lv_cv_vsl.count = 0;
               --Commented by Maria  FORALL j IN lv_cv_vsl.first..lv_cv_vsl.last SAVE EXCEPTIONS
               for j IN lv_cv_vsl.first..lv_cv_vsl.last
                   loop

            begin
                    INSERT INTO VESSEL (
                        msw_vsl_id_n,
                        vsl_rec_id_n,
                       vsl_m,
                        official_n,
                        vsl_flag_c ,
                        vsl_type_id_n,
                        craft_type_id_n,
                        vsl_dwt_n,
                        st_c    ,
                        vsl_craft_lic_n,
                        vsl_attainable_hgt_q,
                        vsl_yr_blt_n,
                        port_of_regy_c,
                        port_n,
                        vsl_len_q,
                        loa_q,
                        vsl_depth_q,
                        vsl_bre_q,
                        mechanic_propel_i,
                        vsl_mmsi_n, --LOCK_VER_N, CRT_ON_DT, CRT_BY_X, UPT_ON_DT, UPT_BY_X,
                        VSL_GT_Q,
                        VSL_NT_Q,
                        vsl_call_sign_n,
                        vsl_imo_n,
                        vsl_ownr ,  -- DELETED_I
                        DELIVERY_DT,
                        BOW_BRIDGE,
                        BOW_THRUSTER,
                        STERN_THRUSTER,
                        DBL_HULL_CONSTRUCT_I,
                        APPR_FOR_SEA_TRIAL_I,
                        LAUNCH_ON_DT,
                        MERGE_FR_TO_VSL_REC_ID,
                        BARTER_TRADE_I,
                        BARE_BOAT_CHARTER_OUT_I,
                        TRANSIT_I,
                        UNOFFICIAL_VSL_M,
                        UNOFFCIAL_VSL_CALL_SIGN,
                        UNOFFICIAL_VSL_TY_C,
                        UNOFFICIAL_VSL_FLAG_C,
                        UNOFFICIAL_VSL_GT,
                        GT_FROM_E_PAN_Q,
                        GT_FROM_E_PAN_DT,
                        BUILDER_M,
                        OWNER_CTRY_C,
                        VSL_BUILT_PLACE_C , LOCK_VER_N,CRT_ON_DT, CRT_BY_X, UPT_ON_DT,UPT_BY_X,
                        DELETED_I   ,
                        VSL_CRAFT_LIC_VALY_FR_DT,
                        VSL_CRAFT_LIC_VALY_TO_DT,
                        VSL_CRAFT_LIC_DELIC_DT,
                        VSL_CRAFT_LIC_ST_C,
                        VSL_CRAFT_LIC_USES_X
                    ) VALUES (
                        vsl_srl.NEXTVAL,
                        lv_cv_vsl(j).vslrecid_n_r,
                        lv_cv_vsl(j).vsl_m_r,
                       lv_cv_vsl(j).official_n_r,
                        lv_cv_vsl(j).vslflag_c_r,
                        lv_cv_vsl(j).vsltypeid_n_r,
                        lv_cv_vsl(j).crafttypeid_n_r,
                       lv_cv_vsl(j).vsldwt_n_r,
                       -- lv_cv_vsl(j).vslrecst_i_r,
                       decode(lv_cv_vsl(j).vslrecst_i_r,'1','DELETE','4','MERGED', 'ACTIVE'),
                        lv_cv_vsl(j).vslcraftlic_n_r,
                        lv_cv_vsl(j).vslattainablehgt_q_r,
                        lv_cv_vsl(j).vslyrblt_n_r,
                        lv_cv_vsl(j).portofregy_c_r,
                        lv_cv_vsl(j).port_n_r,
                        lv_cv_vsl(j).vsllen_q_r,
                        lv_cv_vsl(j).loa_q_r,
                        lv_cv_vsl(j).vsldepth_q_r,
                        lv_cv_vsl(j).vslbre_q_r,
                        DECODE(lv_cv_vsl(j).mechanicpropel_i_r,'Y',1,'N',0),
                        lv_cv_vsl(j).vslmmsi_n_r,
                        lv_cv_vsl(j).vslgt_q_r,
                        lv_cv_vsl(j).vslnt_q_r,
                        lv_cv_vsl(j).vslcallsign_n_r,
                        lv_cv_vsl(j).vslimo_n_r,
                        lv_cv_vsl(j).ownr_m_r,
                        lv_cv_vsl(j).VSLDELVY_D_R  ,
                        lv_cv_vsl(j).BOWBRIDGE_Q_R    ,
                        lv_cv_vsl(j).BOWTHRUSTER_N_R   ,
                        lv_cv_vsl(j).STERNTHRUSTER_N_R  ,
                        DECODE(lv_cv_vsl(j).DBLHULLCONSTRUCT_I_R,'Y',1,'N',0),
                        DECODE(lv_cv_vsl(j).APPRFORSEATRIAL_I_R,'Y',1,'N',0)  ,
                        lv_cv_vsl(j).LAUNCHON_DT_R  ,
                        lv_cv_vsl(j).MERGEFRTOVSLRECID_N_R ,
                        lv_cv_vsl(j).BARTERTRADE_I_R        ,
                        DECODE(lv_cv_vsl(j).BAREBOATCHARTEROUT_I_R,'Y',1,'N',0)  ,
                        DECODE(lv_cv_vsl(j).TRANSIT_I_R,'Y',1,'N',0)              ,
                        lv_cv_vsl(j).UNOFFICIALVSL_M_R        ,
                        lv_cv_vsl(j).UNOFFICIALVSLCALLSIGN_N_R,
                        lv_cv_vsl(j).UNOFFICIALVSLTY_C_R      ,
                        lv_cv_vsl(j).UNOFFICIALVSLFLAG_C_R    ,
                        lv_cv_vsl(j).UNOFFICIALVSLGT_Q_R      ,
                        lv_cv_vsl(j).GTEPAN_Q_R               ,
                        lv_cv_vsl(j).GTEPAN_DT_R     ,
                        lv_cv_vsl(j).BUILDER_M_R              ,
                        lv_cv_vsl(j).OWNRCTRY_C_R             ,
                        lv_cv_vsl(j).VSLPLBLT_C_R ,  0, SYSDATE,  'DATA MIGRATION',  SYSDATE,'DATA MIGRATION',
                        0       ,  
                        lv_cv_vsl(j).VSLCRAFTLICVALYFR_D_R ,
                        lv_cv_vsl(j).VSLCRAFTLICVALYTO_D_R ,
                        lv_cv_vsl(j).VSLCRAFTLICDELIC_D_R ,
                        lv_cv_vsl(j).VSLCRAFTLICST_C_R ,
                        lv_cv_vsl(j).VSLCRAFTLICUSES_X_R  
                    );
                    
        /*
            EXCEPTION
                WHEN OTHERS THEN
                    pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', dbms_utility.format_error_backtrace||sqlerrm, 'ERROR',PV_RUN_ID,SQLERRM,NULL,'T');   */
---------------------------------------------------------
           
           --Added by Maria
           exception
           WHEN OTHERS THEN


                v_err_code := sqlcode;

                v_err_msg := substr(sqlerrm, 1, 200);

                v_sqlerrm := dbms_utility.format_error_backtrace||v_err_code || v_err_msg||dbms_utility.format_error_stack;
           --Maria
           
          

        /*Commented Maria FOR k IN 1..v_blkexptn_count

               LOOP
                  -- Print out details of each error during bulk insert
                  Commented Maria*/
                 

                V_exp_rows :=   lv_cv_vsl(j).vslrecid_n_r||'*|'||
                                lv_cv_vsl(j).vsl_m_r||'*|'||
                                lv_cv_vsl(j).official_n_r||'*|'||
                                lv_cv_vsl(j).vslflag_c_r||'*|'||
                                lv_cv_vsl(j).vsltypeid_n_r||'*|'||
                                lv_cv_vsl(j).crafttypeid_n_r||'*|'||
                                lv_cv_vsl(j).vsldwt_n_r||'*|'||
                                lv_cv_vsl(j).vslrecst_i_r||'*|'||
                                lv_cv_vsl(j).vslcraftlic_n_r||'*|'||
                                lv_cv_vsl(j).vslattainablehgt_q_r||'*|'||
                                lv_cv_vsl(j).vslyrblt_n_r||'*|'||
                                lv_cv_vsl(j).portofregy_c_r||'*|'||
                                lv_cv_vsl(j).port_n_r||'*|'||
                                lv_cv_vsl(j).vsllen_q_r||'*|'||
                                lv_cv_vsl(j).loa_q_r||'*|'||
                                lv_cv_vsl(j).vsldepth_q_r||'*|'||
                                lv_cv_vsl(j).vslbre_q_r||'*|'||
                                lv_cv_vsl(j).mechanicpropel_i_r||'*|'||
                                lv_cv_vsl(j).vslmmsi_n_r||'*|'||
                                lv_cv_vsl(j).vslgt_q_r||'*|'||
                                lv_cv_vsl(j).vslnt_q_r||'*|'||
                                lv_cv_vsl(j).vslcallsign_n_r||'*|'||
                                lv_cv_vsl(j).vslimo_n_r||'*|'||
                                lv_cv_vsl(j).ownr_m_r||'*|'||
                                lv_cv_vsl(j).vsldelvy_d_r||'*|'||
                                lv_cv_vsl(j).bowbridge_q_r||'*|'||
                                lv_cv_vsl(j).bowthruster_n_r||'*|'||
                                lv_cv_vsl(j).sternthruster_n_r||'*|'||
                                lv_cv_vsl(j).dblhullconstruct_i_r||'*|'||
                                lv_cv_vsl(j).apprforseatrial_i_r||'*|'||
                                lv_cv_vsl(j).launchon_dt_r||'*|'||
                                lv_cv_vsl(j).mergefrtovslrecid_n_r||'*|'||
                                lv_cv_vsl(j).bartertrade_i_r||'*|'||
                                lv_cv_vsl(j).bareboatcharterout_i_r||'*|'||
                                lv_cv_vsl(j).transit_i_r||'*|'||
                                lv_cv_vsl(j).unofficialvsl_m_r||'*|'||
                                lv_cv_vsl(j).unofficialvslcallsign_n_r||'*|'||
                                lv_cv_vsl(j).unofficialvslty_c_r||'*|'||
                                lv_cv_vsl(j).unofficialvslflag_c_r||'*|'||
                                lv_cv_vsl(j).unofficialvslgt_q_r||'*|'||
                                lv_cv_vsl(j).gtepan_q_r||'*|'||
                                lv_cv_vsl(j).gtepan_dt_r||'*|'||
                                lv_cv_vsl(j).builder_m_r||'*|'||
                                lv_cv_vsl(j).ownrctry_c_r||'*|'||
                                lv_cv_vsl(j).vslplblt_c_r ||'*|'||
                                lv_cv_vsl(j).VSLCRAFTLICVALYFR_D_R ||'*|'||
                                lv_cv_vsl(j).VSLCRAFTLICVALYTO_D_R ||'*|'||
                                lv_cv_vsl(j).VSLCRAFTLICDELIC_D_R ||'*|'||
                                lv_cv_vsl(j).VSLCRAFTLICST_C_R ||'*|'||
                                lv_cv_vsl(j).VSLCRAFTLICUSES_X_R ;  


            pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', v_sqlerrm, 'ERROR',PV_RUN_ID,SQLERRM,V_exp_rows,'T');
end;
             end loop;

               COMMIT;
-----------------------------------------------------------------
            END;
        END LOOP;
    close cr_vsl ;
        --  pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_tar||' out of '||lv_cnt_si||' records loaded successfully', 'SUCCESS');
        SELECT
            COUNT(*)
        INTO lv_cnt_tar
        FROM
            VESSEL;
       -- pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_tar||' out of '||lv_cnt_si||' records loaded successfully', 'SUCCESS');

 if (lv_cnt_tar =  lv_cnt_si ) and lv_cnt_si <>  0  and lv_cnt_tar <> 0 then

         pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_tar||' out of '||lv_cnt_si||' records loaded successfully', 'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

        elsif lv_cnt_tar  <> lv_cnt_si and lv_cnt_tar <> 0 then

        pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_tar ||' out of ' ||lv_cnt_si ||' records loaded successfully' ,'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (lv_cnt_tar  <> lv_cnt_si or lv_cnt_tar  = lv_cnt_si ) and (lv_cnt_tar = 0) then

        pkg_datamigration_generic.proc_trace_exception('VESSEL', 'PROC_1_VSL', lv_cnt_tar ||' out of ' ||lv_cnt_si ||' records loaded successfully' ,'FAIL',PV_RUN_ID,NULL,NULL,'T');

end if;

        pkg_datamigration_generic.proc_migration_recon('SI_CV_VSL', lv_cnt_si, 'VESSEL', lv_cnt_tar,'N');

        pkg_datamigration_generic.proc_migration_recon('ST_CV_VSL', lv_cnt_st, 'VESSEL', lv_cnt_tar,'Y');

        if lv_cnt_st > 0 and (lv_cnt_st - lv_cnt_tar) = 0 then
            PV_ERR_CNT := 0;
        else
            PV_ERR_CNT :=  -1;
        end if ;

        --PV_ERR_CNT := lv_cnt_si - lv_cnt_tar ;

END proc_1_vsl;
/