create or replace procedure PROC_1_CHANGE_AGENCY_APPLCN  (PV_RUN_ID  in number) IS  

/***********************************************************************************************************
procedure name : PROC_1_CHANGE_AGENCY_APPLCN
Created By     : C.N.BHASKAR
Date           : 10-May2019
Purpose        : Inserting data into CHANGE_AGENCY_APPLICATION
Modified by    :C.N.Bhaskar
Modified date  :09-july-2019

*************************************************************************************************************/



TYPE rec_tg_chgagtappln IS RECORD (

v_APPLNREF_N		si_cv_chgagtappln.APPLNREF_N%TYPE,
v_VSLRECID_N		si_cv_chgagtappln.VSLRECID_N%TYPE,
v_EFFVE_DT		    si_cv_chgagtappln.EFFVE_DT%TYPE,
v_TRANSTY_C		    si_cv_chgagtappln.TRANSTY_C%TYPE,
v_GDV_N		        si_cv_chgagtappln.GDV_N%TYPE,
v_FRPUID_N		    si_cv_chgagtappln.FRPUID_N%TYPE,
v_FRAGTDECLRAC_N	si_cv_chgagtappln.FRAGTDECLRAC_N%TYPE,
v_FRCONTACTPERS_M	si_cv_chgagtappln.FRCONTACTPERS_M%TYPE,
v_FROFFTEL_N		si_cv_chgagtappln.FROFFTEL_N%TYPE,
v_FRMOBILE_N		si_cv_chgagtappln.FRMOBILE_N%TYPE,
v_FREMAILADDR_X		si_cv_chgagtappln.FREMAILADDR_X%TYPE,
v_FRFAX_N		    si_cv_chgagtappln.FRFAX_N%TYPE,
v_TOPUID_N		    si_cv_chgagtappln.TOPUID_N%TYPE,
v_TOAGTDECLRAC_N	si_cv_chgagtappln.TOAGTDECLRAC_N%TYPE,
v_TOCONTACTPERS_M	si_cv_chgagtappln.TOCONTACTPERS_M%TYPE,
v_TOOFFTEL_N		si_cv_chgagtappln.TOOFFTEL_N%TYPE,
v_TOMOBILE_N		si_cv_chgagtappln.TOMOBILE_N%TYPE,
v_TOEMAILADDR_X		si_cv_chgagtappln.TOEMAILADDR_X%TYPE,
v_TOFAX_N		    si_cv_chgagtappln.TOFAX_N%TYPE,
v_EFFVEON_DT		si_cv_chgagtappln.EFFVEON_DT%TYPE,
v_REM_X		        si_cv_chgagtappln.REM_X%TYPE,
v_INTLREM_X		    si_cv_chgagtappln.INTLREM_X%TYPE,
v_FRAGTDOCIDATTH_N	si_cv_chgagtappln.FRAGTDOCIDATTH_N%TYPE,
v_TOAGTDOCIDATTH_N	si_cv_chgagtappln.TOAGTDOCIDATTH_N%TYPE,
v_AGTDECLR_M		si_cv_chgagtappln.AGTDECLR_M%TYPE,
v_AGTDECLRID_N		si_cv_chgagtappln.AGTDECLRID_N%TYPE,
v_AGTDECLRDESGN_M	si_cv_chgagtappln.AGTDECLRDESGN_M%TYPE,
v_CRTON_DT		    si_cv_chgagtappln.CRTON_DT%TYPE,
v_CRTBY_M		    si_cv_chgagtappln.CRTBY_M%TYPE,
v_UPDON_DT		    si_cv_chgagtappln.UPDON_DT%TYPE,
v_UPDBY_M		    si_cv_chgagtappln.UPDBY_M%TYPE

    );

TYPE type_tg_chgagtappln IS TABLE OF rec_tg_chgagtappln;
lv_tg_chgagtappln   type_tg_chgagtappln;



CURSOR CUR_CHANGEAGENCY
IS 
select 
*
from si_cv_chgagtappln;


v_src_count  number;  
v_tgt_count   number;
V_ERR_CODE   number;
V_MSW_APPLN_REF_ID_X   varchar2(2000);
V_ERR_MSG varchar2(4000);
V_SQLERRM varchar2(4000);






BEgin --outer begin for proc_1_change_agency_applcn



/***********************************************************************************************************
Insertion into si_cv_chgagtappln starts 

*************************************************************************************************************/





PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN','Insertion into si_cv_chgagtappln starts' , 'START',null,null,null,'T'); 




FOR J IN
(
select 
APPLNREF_N,
VSLRECID_N,
EFFVE_DT,
TRANSTY_C,
GDV_N,
FRPUID_N,
FRAGTDECLRAC_N,
FRCONTACTPERS_M,
FROFFTEL_N,
FRMOBILE_N,
FREMAILADDR_X,
FRFAX_N,
TOPUID_N,
TOAGTDECLRAC_N,
TOCONTACTPERS_M,
TOOFFTEL_N,
TOMOBILE_N,
TOEMAILADDR_X,
TOFAX_N,
EFFVEON_DT,
REM_X,
INTLREM_X,
FRAGTDOCIDATTH_N,
TOAGTDOCIDATTH_N,
AGTDECLR_M,
AGTDECLRID_N,
AGTDECLRDESGN_M,
CRTON_DT,
CRTBY_M,
UPDON_DT,
UPDBY_M


from st_cv_chgagtappln)


LOOP

BEGIN 

insert into si_cv_chgagtappln  

values
(J.APPLNREF_N,
J.VSLRECID_N,
J.EFFVE_DT,
J.TRANSTY_C,
J.GDV_N,
J.FRPUID_N,
J.FRAGTDECLRAC_N,
J.FRCONTACTPERS_M,
J.FROFFTEL_N,
J.FRMOBILE_N,
J.FREMAILADDR_X,
J.FRFAX_N,
J.TOPUID_N,
J.TOAGTDECLRAC_N,
J.TOCONTACTPERS_M,
J.TOOFFTEL_N,
J.TOMOBILE_N,
J.TOEMAILADDR_X,
J.TOFAX_N,
J.EFFVEON_DT,
J.REM_X,
J.INTLREM_X,
J.FRAGTDOCIDATTH_N,
J.TOAGTDOCIDATTH_N,
J.AGTDECLR_M,
J.AGTDECLRID_N,
J.AGTDECLRDESGN_M,
J.CRTON_DT,
J.CRTBY_M,
J.UPDON_DT,
J.UPDBY_M

);



exception   -- inner exception   for si_cv_chgagtappln

when others    then 

V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'si_cv_chgagtappln',
  'proc_1_change_agency_applcn',
'APPLNREF_N:'||J.APPLNREF_N||'<{||}>'||
'VSLRECID_N:'||J.VSLRECID_N||'<{||}>'||
'EFFVE_DT:'	||J.EFFVE_DT||'<{||}>'||
'TRANSTY_C:'|| J.TRANSTY_C||'<{||}>'||
'GDV_N:'|| J.GDV_N||'<{||}>'||
'FRPUID_N:'||J.FRPUID_N||'<{||}>'||
'FRAGTDECLRAC_N	:'|| J.FRAGTDECLRAC_N||'<{||}>'||
'FRCONTACTPERS_M:'|| J.FRCONTACTPERS_M||'<{||}>'||
'FROFFTEL_N	:'|| J.FROFFTEL_N||'<{||}>'||
'FRMOBILE_N	:'|| J.FRMOBILE_N||'<{||}>'||
'FREMAILADDR_X:'|| J.FREMAILADDR_X||'<{||}>'||
'FRFAX_N:'|| J.FRFAX_N||'<{||}>'||
'TOPUID_N:'	|| J.TOPUID_N||'<{||}>'||
'TOAGTDECLRAC_N	:' ||	J.TOAGTDECLRAC_N||'<{||}>'||
'TOCONTACTPERS_M:' ||	J.TOCONTACTPERS_M||'<{||}>'||
'TOOFFTEL_N:'|| J.TOOFFTEL_N||'<{||}>'||
'TOMOBILE_N:'|| J.TOMOBILE_N||'<{||}>'||
'TOEMAILADDR_X:'|| J.TOEMAILADDR_X||'<{||}>'||
'TOFAX_N:'|| J.TOFAX_N||'<{||}>'||
'EFFVEON_DT:'|| J.EFFVEON_DT||'<{||}>'||
'REM_X:'|| J.REM_X||'<{||}>'||
'INTLREM_X:'|| J.INTLREM_X||'<{||}>'||
'FRAGTDOCIDATTH_N:'||	J.FRAGTDOCIDATTH_N||'<{||}>'||
'TOAGTDOCIDATTH_N:'	|| J.TOAGTDOCIDATTH_N||'<{||}>'||
'AGTDECLR_M:'|| J.AGTDECLR_M||'<{||}>'||
'AGTDECLRID_N:'|| J.AGTDECLRID_N||'<{||}>'||
'AGTDECLRDESGN_M:'|| J.AGTDECLRDESGN_M||'<{||}>'||
'CRTON_DT:'	|| J.CRTON_DT||'<{||}>'||
'CRTBY_M:'	|| J.CRTBY_M||'<{||}>'||
'UPDON_DT:'	||J.UPDON_DT||'<{||}>'||
'UPDBY_M:'	|| J.UPDBY_M
  ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
J.APPLNREF_N||'<{||}>'||
J.VSLRECID_N||'<{||}>'||
J.EFFVE_DT||'<{||}>'||
J.TRANSTY_C||'<{||}>'||
J.GDV_N||'<{||}>'||
J.FRPUID_N||'<{||}>'||
J.FRAGTDECLRAC_N||'<{||}>'||
J.FRCONTACTPERS_M||'<{||}>'||
J.FROFFTEL_N||'<{||}>'||
J.FRMOBILE_N||'<{||}>'||
J.FREMAILADDR_X||'<{||}>'||
J.FRFAX_N||'<{||}>'||
J.TOPUID_N||'<{||}>'||
J.TOAGTDECLRAC_N||'<{||}>'||
J.TOCONTACTPERS_M||'<{||}>'||
J.TOOFFTEL_N||'<{||}>'||
J.TOMOBILE_N||'<{||}>'||
J.TOEMAILADDR_X||'<{||}>'||
J.TOFAX_N||'<{||}>'||
J.EFFVEON_DT||'<{||}>'||
J.REM_X||'<{||}>'||
J.INTLREM_X||'<{||}>'||
J.FRAGTDOCIDATTH_N||'<{||}>'||
J.TOAGTDOCIDATTH_N||'<{||}>'||
J.AGTDECLR_M||'<{||}>'||
J.AGTDECLRID_N||'<{||}>'||
J.AGTDECLRDESGN_M||'<{||}>'||
J.CRTON_DT||'<{||}>'||
J.CRTBY_M||'<{||}>'||
J.UPDON_DT||'<{||}>'||
J.UPDBY_M
 ,
 'B'
 );

     -- inner end   for si_cv_chgagtappln


     END;

END LOOP;

COMMIT;


PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn','Insertion into si_cv_chgagtappln ENDS' , 'STOP',null,null,null,'T'); 

/***********************************************************************************************************
Insertion into si_cv_chgagtappln ends  

*************************************************************************************************************/



-----------------------------------------------------------------------------------------------------------------------------------------------------------------------



PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'PROC_1_CHANGE_AGENCY_APPLCN','INSERTION INTO  CHANGE_AGENCY_APPLICATION STARTS' , 'START',null,null,null,'T'); 






--V_MSW_APPLN_REF_ID_X := 'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.NEXTVAL,'FM00000' ) ;

OPEN CUR_CHANGEAGENCY;

LOOP   -- CURSOR LOOP STARTS 



FETCH CUR_CHANGEAGENCY  BULK COLLECT  INTO lv_tg_chgagtappln  limit 1000;


          EXIT WHEN lv_tg_chgagtappln.count = 0;


                  FOR i IN lv_tg_chgagtappln.FIRST..lv_tg_chgagtappln.LAST 


                  LOOP     --   FOR LOOP STARTS  WHICH INSERT DATA INTO THE   TARGET TABLE 

                  BEGIN 

                  insert into CHANGE_AGENCY_APPLICATION  values(
                  seq_chagtappl.nextval,
                         2 , --need to change when the apropriate maPPing comes
'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.NEXTVAL,'FM00000' ),
lv_tg_chgagtappln(i).v_APPLNREF_N,
'MPA',
lv_tg_chgagtappln(i).v_VSLRECID_N	,
lv_tg_chgagtappln(i).v_EFFVE_DT	,
lv_tg_chgagtappln(i).v_TRANSTY_C	,
lv_tg_chgagtappln(i).v_GDV_N	,
lv_tg_chgagtappln(i).v_FRPUID_N	,
lv_tg_chgagtappln(i).v_FRAGTDECLRAC_N	,
lv_tg_chgagtappln(i).v_FRCONTACTPERS_M	,
lv_tg_chgagtappln(i).v_FROFFTEL_N	,
lv_tg_chgagtappln(i).v_FRMOBILE_N	,
lv_tg_chgagtappln(i).v_FREMAILADDR_X	,
lv_tg_chgagtappln(i).v_FRFAX_N	,
lv_tg_chgagtappln(i).v_TOPUID_N	,
lv_tg_chgagtappln(i).v_TOAGTDECLRAC_N	,
lv_tg_chgagtappln(i).v_TOCONTACTPERS_M	,
lv_tg_chgagtappln(i).v_TOOFFTEL_N	,
lv_tg_chgagtappln(i).v_TOMOBILE_N	,
lv_tg_chgagtappln(i).v_TOEMAILADDR_X	,
lv_tg_chgagtappln(i).v_TOFAX_N	,
lv_tg_chgagtappln(i).v_EFFVEON_DT	,
lv_tg_chgagtappln(i).v_REM_X	,
lv_tg_chgagtappln(i).v_INTLREM_X	,
lv_tg_chgagtappln(i).v_FRAGTDOCIDATTH_N	,
lv_tg_chgagtappln(i).v_TOAGTDOCIDATTH_N	,
lv_tg_chgagtappln(i).v_AGTDECLR_M	,
lv_tg_chgagtappln(i).v_AGTDECLRID_N	,
lv_tg_chgagtappln(i).v_AGTDECLRDESGN_M	,
lv_tg_chgagtappln(i).v_CRTON_DT	,
lv_tg_chgagtappln(i).v_CRTBY_M	,
lv_tg_chgagtappln(i).v_UPDON_DT	,
lv_tg_chgagtappln(i).v_UPDBY_M	



);

EXCEPTION

when others    then 

V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'CHANGE_AGENCY_APPLICATION',
  'proc_1_change_agency_applcn',
seq_chagtappl.CURRVAL	||'<{||}>'||
 2  	||'<{||}>'|| --need to change when the apropriate maooing comes
'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.CURRVAL,'FM00000' )||'<{||}>'||
lv_tg_chgagtappln(i).v_APPLNREF_N	||'<{||}>'||
'MPA'	||'<{||}>'||
lv_tg_chgagtappln(i).v_VSLRECID_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_EFFVE_DT	||'<{||}>'||
lv_tg_chgagtappln(i).v_TRANSTY_C	||'<{||}>'||
lv_tg_chgagtappln(i).v_GDV_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRPUID_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRAGTDECLRAC_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRCONTACTPERS_M	||'<{||}>'||
lv_tg_chgagtappln(i).v_FROFFTEL_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRMOBILE_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_FREMAILADDR_X	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRFAX_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOPUID_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOAGTDECLRAC_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOCONTACTPERS_M	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOOFFTEL_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOMOBILE_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOEMAILADDR_X	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOFAX_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_EFFVEON_DT	||'<{||}>'||
lv_tg_chgagtappln(i).v_REM_X	||'<{||}>'||
lv_tg_chgagtappln(i).v_INTLREM_X	||'<{||}>'||
lv_tg_chgagtappln(i).v_FRAGTDOCIDATTH_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_TOAGTDOCIDATTH_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_AGTDECLR_M	||'<{||}>'||
lv_tg_chgagtappln(i).v_AGTDECLRID_N	||'<{||}>'||
lv_tg_chgagtappln(i).v_AGTDECLRDESGN_M	||'<{||}>'||
lv_tg_chgagtappln(i).v_CRTON_DT	||'<{||}>'||
lv_tg_chgagtappln(i).v_CRTBY_M	||'<{||}>'||
lv_tg_chgagtappln(i).v_UPDON_DT	||'<{||}>'||
lv_tg_chgagtappln(i).v_UPDBY_M	

  ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,

seq_chagtappl.CURRVAL	||'<{||}>'||
 2  	||'<{||}>'|| --need to change when the apropriate maooing comes
'MSW'||'SCA'||TO_CHAR(SYSDATE,'YY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(MSW_SEQ_CHAGTAPPL.CURRVAL,'FM00000' )	||'<{||}>'||
lv_tg_chgagtappln(i).	v_APPLNREF_N	||'<{||}>'||
'MPA'	||'<{||}>'||
	lv_tg_chgagtappln(i).v_VSLRECID_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_EFFVE_DT	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TRANSTY_C	||'<{||}>'||
	lv_tg_chgagtappln(i).v_GDV_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRPUID_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRAGTDECLRAC_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRCONTACTPERS_M	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FROFFTEL_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRMOBILE_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FREMAILADDR_X	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRFAX_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOPUID_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOAGTDECLRAC_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOCONTACTPERS_M	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOOFFTEL_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOMOBILE_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOEMAILADDR_X	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOFAX_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_EFFVEON_DT	||'<{||}>'||
	lv_tg_chgagtappln(i).v_REM_X	||'<{||}>'||
	lv_tg_chgagtappln(i).v_INTLREM_X	||'<{||}>'||
	lv_tg_chgagtappln(i).v_FRAGTDOCIDATTH_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_TOAGTDOCIDATTH_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_AGTDECLR_M	||'<{||}>'||
	lv_tg_chgagtappln(i).v_AGTDECLRID_N	||'<{||}>'||
	lv_tg_chgagtappln(i).v_AGTDECLRDESGN_M	||'<{||}>'||
	lv_tg_chgagtappln(i).v_CRTON_DT	||'<{||}>'||
	lv_tg_chgagtappln(i).v_CRTBY_M	||'<{||}>'||
	lv_tg_chgagtappln(i).v_UPDON_DT	||'<{||}>'||
	lv_tg_chgagtappln(i).v_UPDBY_M	
 ,
 'B'
 );



END;





   END LOOP;   -- END LOOP STARTS  OF  INNER FOR LOOP   INT THE TARGET TABLE 


END LOOP;   -- CURSOR LOOP ENDS




/***********************************************************************************************************
Reconciling the count of stagng table  and source intermediate table 
*************************************************************************************************************/
 --FIND THE COUNT OF query (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF source inrermewdiate 


SELECT COUNT(*)
INTO v_src_count
FROM  st_cv_chgagtappln;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM  si_cv_chgagtappln;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_chgagtappln', V_SRC_COUNT, 'si_cv_chgagtappln', V_TGT_COUNT,'N');	  



    if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into si_cv_chgagtappln table' ,
        'SUCCESS',null,null,null,null);


        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_cv_chgagtappln table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);



    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_cv_chgagtappln table' ,
        'FAIL',null,null,null,null);


        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into si_cv_chgagtappln table' ,
        'AMBIGIOUS',null,null,null,null);


end if;

/***********************************************************************************************************
Reconciling the count of source query and source intermediate table   ends
*************************************************************************************************************/






/***********************************************************************************************************
Reconciling the count of sourceintermediate  table  and target table 
*************************************************************************************************************/
 --FIND THE COUNT OF query (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF source inrermewdiate 


SELECT COUNT(*)
INTO v_src_count
FROM  si_cv_chgagtappln;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM  CHANGE_AGENCY_APPLICATION;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('si_cv_chgagtappln', V_SRC_COUNT, 'CHANGE_AGENCY_APPLICATION', V_TGT_COUNT,'N');	  



    if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into CHANGE_AGENCY_APPLICATION table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into CHANGE_AGENCY_APPLICATION table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into CHANGE_AGENCY_APPLICATION table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into CHANGE_AGENCY_APPLICATION table' ,
        'AMBIGIOUS',null,null,null,null);

end if;

/***********************************************************************************************************
Reconciling the count of source query and source intermediate table   ends
*************************************************************************************************************/


/***********************************************************************************************************
Reconciling the count of staging   table  and target  table starts
*************************************************************************************************************/
 --FIND THE COUNT OF query (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF source inrermewdiate 


SELECT COUNT(*)
INTO v_src_count
FROM st_cv_chgagtappln ;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM  CHANGE_AGENCY_APPLICATION;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_chgagtappln', V_SRC_COUNT, 'CHANGE_AGENCY_APPLICATION', V_TGT_COUNT,'Y');	  



/***********************************************************************************************************
Reconciling the count of staging   table  and sI  table ends
*************************************************************************************************************/









exception      --outer exception for proc_1_change_agency_applcn
when others then 
      V_ERR_CODE := SQLCODE;

                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||dbms_utility.format_error_backtrace;

                V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('CHANGE_AGENCY_APPLICATION', 'proc_1_change_agency_applcn', V_SQLERRM, 'FAIL',null,null,null,'T');

end;                --outer end  for proc_1_change_agency_applcn
/