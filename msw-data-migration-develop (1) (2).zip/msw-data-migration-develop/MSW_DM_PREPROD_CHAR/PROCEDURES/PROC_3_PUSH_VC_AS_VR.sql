create or replace PROCEDURE PROC_3_PUSH_VC_AS_VR  IS

/***********************************************************************************************************
procedure name : PROC_3_PUSH_VC_AS_VR
Created By     : Rohit Khool
Date           : 29-Jul-2019
Purpose        : To push records from VESSEL_CALL, APPLICATION SUBMISSION table to target schema E_APPLICATION_SERVICE.
Modified by    : 09-Aug-2019
Modified date  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****
    CURSOR CR_VC IS

    SELECT
        VSL_CALL_ID_N,
		MSW_VSL_ID_N,
		ETA_DT,
		ETD_DT,
		RTA_DT,
		RTD_DT,
		DELETED_I,
		LOCK_VER_N,
		CRT_ON_DT,
		CRT_BY_N,
		UPT_ON_DT,
		UPT_BY_X,
		ST_C,
		MVMT_ID_N,
		VSL_MVMT_ST,
		VSL_REF_ID_N

    FROM
        VESSEL_CALL ;

	TYPE REC_VC IS RECORD
	(V_VSL_CALL_ID_N	VESSEL_CALL.VSL_CALL_ID_N%TYPE,
	V_MSW_VSL_ID_N		VESSEL_CALL.MSW_VSL_ID_N%TYPE,
	V_ETA_DT			VESSEL_CALL.ETA_DT%TYPE,
	V_ETD_DT			VESSEL_CALL.ETD_DT%TYPE,
	V_RTA_DT			VESSEL_CALL.RTA_DT%TYPE,
	V_RTD_DT			VESSEL_CALL.RTD_DT%TYPE,
	V_DELETED_I			VESSEL_CALL.DELETED_I%TYPE,
	V_LOCK_VER_N		VESSEL_CALL.LOCK_VER_N%TYPE,
	V_CRT_ON_DT			VESSEL_CALL.CRT_ON_DT%TYPE,
	V_CRT_BY_N			VESSEL_CALL.CRT_BY_N%TYPE,
	V_UPT_ON_DT			VESSEL_CALL.UPT_ON_DT%TYPE,
	V_UPT_BY_X			VESSEL_CALL.UPT_BY_X%TYPE,
	V_ST_C				VESSEL_CALL.ST_C%TYPE,
	V_MVMT_ID_N			VESSEL_CALL.MVMT_ID_N%TYPE,
	V_VSL_MVMT_ST		VESSEL_CALL.VSL_MVMT_ST%TYPE,
	V_VSL_REF_ID_N		VESSEL_CALL.VSL_REF_ID_N%TYPE
	);

	CURSOR CR_AS IS
	SELECT
		APPLN_SUBMISSN_ID_N,
		MSW_APPLN_REF_ID_X,
		VSL_CALL_ID_N,
		EXTL_APPLN_REF_ID_X,
		MSW_VSL_ID_N,
		ETA_DT,
		ETD_DT,
		APPLN_TY_C,
		APPLN_DATA_X,
		ST_C,
		PROCESSING_REM_X,
		PROCESSED_BY_X,
		PROCESSED_ON_DT,
		CUTOFF_DT,
		LOCK_VER_N,
		CRT_ON_DT,
		CRT_BY_X,
		UPT_ON_DT,
		UPT_BY_X,
		DELETED_I,
		ORG_C,
		VSL_REF_ID_N,
		REASON

	FROM APPLICATION_SUBMISSION ;


	TYPE REC_AS IS RECORD
	(V_APPLN_SUBMISSN_ID_N		APPLICATION_SUBMISSION.APPLN_SUBMISSN_ID_N%TYPE,
	V_MSW_APPLN_REF_ID_X		APPLICATION_SUBMISSION.MSW_APPLN_REF_ID_X%TYPE,
	V_VSL_CALL_ID_N				APPLICATION_SUBMISSION.VSL_CALL_ID_N%TYPE,
	V_EXTL_APPLN_REF_ID_X		APPLICATION_SUBMISSION.EXTL_APPLN_REF_ID_X%TYPE,
	V_MSW_VSL_ID_N				APPLICATION_SUBMISSION.MSW_VSL_ID_N%TYPE,
	V_ETA_DT					APPLICATION_SUBMISSION.ETA_DT%TYPE,
	V_ETD_DT					APPLICATION_SUBMISSION.ETD_DT%TYPE,
	V_APPLN_TY_C				APPLICATION_SUBMISSION.APPLN_TY_C%TYPE,
	V_APPLN_DATA_X				APPLICATION_SUBMISSION.APPLN_DATA_X%TYPE,
	V_ST_C						APPLICATION_SUBMISSION.ST_C%TYPE,
	V_PROCESSING_REM_X			APPLICATION_SUBMISSION.PROCESSING_REM_X%TYPE,
	V_PROCESSED_BY_X			APPLICATION_SUBMISSION.PROCESSED_BY_X%TYPE,
	V_PROCESSED_ON_DT			APPLICATION_SUBMISSION.PROCESSED_ON_DT%TYPE,
	V_CUTOFF_DT					APPLICATION_SUBMISSION.CUTOFF_DT%TYPE,
	V_LOCK_VER_N				APPLICATION_SUBMISSION.LOCK_VER_N%TYPE,
	V_CRT_ON_DT					APPLICATION_SUBMISSION.CRT_ON_DT%TYPE,
	V_CRT_BY_X					APPLICATION_SUBMISSION.CRT_BY_X%TYPE,
	V_UPT_ON_DT					APPLICATION_SUBMISSION.UPT_ON_DT%TYPE,
	V_UPT_BY_X					APPLICATION_SUBMISSION.UPT_BY_X%TYPE,
	V_DELETED_I					APPLICATION_SUBMISSION.DELETED_I%TYPE,
	V_ORG_C						APPLICATION_SUBMISSION.ORG_C%TYPE,
	V_VSL_REF_ID_N_AS			APPLICATION_SUBMISSION.VSL_REF_ID_N%TYPE,
	V_REASON					APPLICATION_SUBMISSION.REASON%TYPE
	);

	CURSOR CR_VR IS
    SELECT
	VSL_REF_ID_N,
	MSW_VSL_ID_N,
	VSL_REC_ID_N,
	VSL_M,
	PORT_OF_REGY_C,
	VSL_IMO_N,
	VSL_CALL_SIGN_N,
	VSL_CRAFT_LIC_N,
	VSL_GT_Q,
	VSL_NT_Q,
	VSL_FLAG_C,
	VSL_TY_C,
	LOA_Q,
	DELETED_I,
	LOCK_VER_N
	FROM VESSEL_REFERENCE ;

	TYPE REC_VR IS RECORD
	(
	V_VSL_REF_ID_N		VESSEL_REFERENCE.VSL_REF_ID_N%TYPE,
	V_MSW_VSL_ID_N		VESSEL_REFERENCE.MSW_VSL_ID_N%TYPE,
	V_VSL_REC_ID_N		VESSEL_REFERENCE.VSL_REC_ID_N%TYPE,
	V_VSL_M				VESSEL_REFERENCE.VSL_M%TYPE,
	V_PORT_OF_REGY_C	VESSEL_REFERENCE.PORT_OF_REGY_C%TYPE,
	V_VSL_IMO_N			VESSEL_REFERENCE.VSL_IMO_N%TYPE,
	V_VSL_CALL_SIGN_N	VESSEL_REFERENCE.VSL_CALL_SIGN_N%TYPE,
	V_VSL_CRAFT_LIC_N	VESSEL_REFERENCE.VSL_CRAFT_LIC_N%TYPE,
	V_VSL_GT_Q			VESSEL_REFERENCE.VSL_GT_Q%TYPE,
	V_VSL_NT_Q			VESSEL_REFERENCE.VSL_NT_Q%TYPE,
	V_VSL_FLAG_C		VESSEL_REFERENCE.VSL_FLAG_C%TYPE,
	V_VSL_TY_C			VESSEL_REFERENCE.VSL_TY_C%TYPE,
	V_LOA_Q				VESSEL_REFERENCE.LOA_Q%TYPE,
	V_DELETED_I			VESSEL_REFERENCE.DELETED_I%TYPE,
	V_LOCK_VER_N		VESSEL_REFERENCE.LOCK_VER_N%TYPE
	);

	TYPE TYPE_VC  IS TABLE OF REC_VC;
	LV_VC				TYPE_VC;

	TYPE TYPE_AS  IS TABLE OF REC_AS;
	LV_AS				TYPE_AS;

	TYPE TYPE_VR  IS TABLE OF REC_VR;
	LV_VR				TYPE_VR;


	LV_CNT_DM_VC        NUMBER;
	LV_CNT_TT_VC		NUMBER;	
	LV_CNT_DM_AS       NUMBER;
	LV_CNT_TT_AS		NUMBER;	
	LV_CNT_DM_VR       NUMBER;
	LV_CNT_TT_VR		NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);
    V_EXP_ROWS          VARCHAR2(1000);

BEGIN
   LV_CNT_TT_VC :=0;
   LV_CNT_TT_AS :=0;
   LV_CNT_TT_VR :=0;

	SELECT
    COUNT(*) INTO LV_CNT_DM_VC
    FROM
    VESSEL_CALL;

	SELECT
    COUNT(*) INTO LV_CNT_DM_AS
    FROM
    APPLICATION_SUBMISSION;

	SELECT
    COUNT(*) INTO LV_CNT_DM_VR
    FROM
    VESSEL_REFERENCE;

OPEN  CR_VC;
	pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR', 'Insertion into target Table VESSEL_CALL', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.VESSEL_CALL and inseting into target table E_APPLICATION_SERVICE.VSL_CALL ************------------------        


			FETCH CR_VC BULK COLLECT INTO LV_VC LIMIT 10000;
            EXIT WHEN LV_VC.count = 0;
			--FORALL i IN LV_VC.first..LV_VC.last SAVE EXCEPTIONS  
			FOR i IN LV_VC.first..LV_VC.last
			LOOP
-------------************ SYN_VC is synonym of E_APPLICATION_SERVICE.VSL_CALL  ************------------------  
			BEGIN

            INSERT INTO SYN_VC (
								VSL_CALL_ID_N,
								MSW_VSL_ID_N,
								MVMT_ID_N,
								ETA_DT,
								RTA_DT,
								ETD_DT,
								RTD_DT,
								ST_C,
								CRT_ON_DT,
								CRT_BY_N,
								LST_UPD_ON_DT,
								LST_UPD_BY_N,
								LOCK_VER_N,
								DELETED_I,
								VSL_MVMT_ST,
								VSL_REF_ID_N	
								) 

						VALUES (
								LV_VC(i).V_VSL_CALL_ID_N,
								LV_VC(i).V_MSW_VSL_ID_N,
								LV_VC(i).V_MVMT_ID_N,
								LV_VC(i).V_ETA_DT,
								LV_VC(i).V_RTA_DT,
								LV_VC(i).V_ETD_DT,
								LV_VC(i).V_RTD_DT,	
                               -- LV_VC(i).V_ST_C,
								NVL(LV_VC(i).V_ST_C,'IN_PROGRESS'),--need to check this
								LV_VC(i).V_CRT_ON_DT,
								LV_VC(i).V_CRT_BY_N,
								--LV_VC(i).V_UPT_ON_DT,
                                NVL(LV_VC(i).V_UPT_ON_DT,SYSDATE),
								LV_VC(i).V_UPT_BY_X,
								LV_VC(i).V_LOCK_VER_N,								
								LV_VC(i).V_DELETED_I,								
								LV_VC(i).V_VSL_MVMT_ST,
								--LV_VC(i).V_VSL_REF_ID_N
                                LV_VC(i).V_VSL_REF_ID_N
								);
        LV_CNT_TT_VC :=LV_CNT_TT_VC+1;

        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                v_exp_rows := 'VSL_CALL_ID_N  '||LV_VC(i).V_VSL_CALL_ID_N||
								'MSW_VSL_ID_N  '||LV_VC(i).V_MSW_VSL_ID_N||
								'ETA_DT  '||LV_VC(i).V_ETA_DT||
								'ETD_DT  '||LV_VC(i).V_ETD_DT||
								'RTA_DT  '||LV_VC(i).V_RTA_DT||
								'RTD_DT  '||LV_VC(i).V_RTD_DT||
								'DELETED_I  '||LV_VC(i).V_DELETED_I||
								'LOCK_VER_N  '||LV_VC(i).V_LOCK_VER_N||
								'CRT_ON_DT  '||LV_VC(i).V_CRT_ON_DT||
								'CRT_BY_N  '||LV_VC(i).V_CRT_BY_N||
								'UPT_ON_DT  '||LV_VC(i).V_UPT_ON_DT||
								'UPT_BY_X  '||LV_VC(i).V_UPT_BY_X||
								'ST_C  '||LV_VC(i).V_ST_C||
								'MVMT_ID_N  '||LV_VC(i).V_MVMT_ID_N||
								'VSL_MVMT_ST  '||LV_VC(i).V_VSL_MVMT_ST||
								'VSL_REF_ID_N  '||LV_VC(i).V_VSL_REF_ID_N ;


             pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR',   V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,v_exp_rows,'T');

			END;

			END LOOP;


    END LOOP;
	CLOSE CR_VC;	
    /*
	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_VC
     FROM
     SYN_VC;
    */
	IF( LV_CNT_TT_VC =  LV_CNT_DM_VC ) AND LV_CNT_DM_VC <>  0  AND  LV_CNT_TT_VC <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VC||' OUT OF ' || LV_CNT_DM_VC ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_CALL' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_VC  <> LV_CNT_TT_VC AND  LV_CNT_DM_VC <> 0 AND  LV_CNT_TT_VC <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VC||' OUT OF ' || LV_CNT_DM_VC ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_CALL' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_VC  <> 0 AND  LV_CNT_TT_VC = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VC||' OUT OF ' || LV_CNT_DM_VC ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_CALL' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   



    pkg_datamigration_generic.proc_migration_recon('DM_VESSEL_CALL', LV_CNT_DM_VC, 'VSL_CALL', LV_CNT_TT_VC,'Y');


	/***********************************************************************************************************
	Pushing records into E_APPLICATION_SERVICE.APPLN_SUBMISSN
    ***********************************************************************************************************/

	OPEN  CR_AS;
	pkg_datamigration_generic.proc_trace_exception('DM_APPLICATION_SUBMISSION', 'PROC_3_PUSH_VC_AS_VR', 'Insertion into target Table E_APPLICATION_SERVICE.APPLN_SUBMISSN', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.APPLICATION_SUBMISSION and inseting into target table E_APPLICATION_SERVICE.APPLN_SUBMISSN ************------------------        


			FETCH CR_AS BULK COLLECT INTO LV_AS LIMIT 10000;
            EXIT WHEN LV_AS.count = 0;
			--FORALL i IN LV_AS.first..LV_AS.last SAVE EXCEPTIONS  
			FOR i IN LV_AS.first..LV_AS.last
			LOOP
-------------************ SYN_AS is synonym of E_APPLICATION_SERVICE.APPLN_SUBMISSN  ************------------------  
			BEGIN


            INSERT INTO SYN_AS (
								APPLN_SUBMISSN_ID_N,
								MSW_APPLN_REF_ID_N,
								VSL_CALL_ID_N,
								MSW_VSL_ID_N,
								ETA_DT,
								ETD_DT,
								APPLN_TY_C,
								APPLN_DATA_X,
								ST_C,
								EXTL_APPLN_REF_ID_X,
								PROCESSED_BY_X,
								PROCESSED_ON_DT,
								PROCESSING_REM_X,
								CUTOFF_DT,
								CRT_ON_DT,
								CRT_BY_N,
								LST_UPD_ON_DT,
								LST_UPD_BY_N,
								LOCK_VER_N,
								DELETED_I,
								ORG_C,
								VSL_REF_ID_N,
								RSN_X
								) 

						VALUES (
								LV_AS(i).V_APPLN_SUBMISSN_ID_N	,
								LV_AS(i).V_MSW_APPLN_REF_ID_X	,
								LV_AS(i).V_VSL_CALL_ID_N	,
								LV_AS(i).V_MSW_VSL_ID_N	,
								LV_AS(i).V_ETA_DT	,
								LV_AS(i).V_ETD_DT	,
								LV_AS(i).V_APPLN_TY_C	,
								LV_AS(i).V_APPLN_DATA_X	,
								LV_AS(i).V_ST_C	,
								LV_AS(i).V_EXTL_APPLN_REF_ID_X	,
								LV_AS(i).V_PROCESSED_BY_X	,
								LV_AS(i).V_PROCESSED_ON_DT	,
								LV_AS(i).V_PROCESSING_REM_X	,
								LV_AS(i).V_CUTOFF_DT	,
								LV_AS(i).V_CRT_ON_DT	,
								LV_AS(i).V_CRT_BY_X	,
								LV_AS(i).V_UPT_ON_DT	,
								LV_AS(i).V_UPT_BY_X	,
								LV_AS(i).V_LOCK_VER_N	,
								LV_AS(i).V_DELETED_I	,
								'MSW_DM',
								LV_AS(i).V_VSL_REF_ID_N_AS,
								LV_AS(i).V_REASON								
								);

    LV_CNT_TT_AS :=LV_CNT_TT_AS+1;

        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                v_exp_rows := ' APPLN_SUBMISSN_ID_N  '|| LV_AS(i).V_APPLN_SUBMISSN_ID_N||
								' MSW_APPLN_REF_ID_N  '|| LV_AS(i).V_MSW_APPLN_REF_ID_X||
								' VSL_CALL_ID_N  '|| LV_AS(i).V_VSL_CALL_ID_N||
								' MSW_VSL_ID_N  '|| LV_AS(i).V_MSW_VSL_ID_N||
								' ETA_DT  '|| LV_AS(i).V_ETA_DT||
								' ETD_DT  '|| LV_AS(i).V_ETD_DT||
								' APPLN_TY_C  '|| LV_AS(i).V_APPLN_TY_C||
								' APPLN_DATA_X  '|| LV_AS(i).V_APPLN_DATA_X||
								' ST_C  '|| LV_AS(i).V_ST_C||
								' EXTL_APPLN_REF_ID_X  '|| LV_AS(i).V_EXTL_APPLN_REF_ID_X||
								' PROCESSED_BY_X  '|| LV_AS(i).V_PROCESSED_BY_X||
								' PROCESSED_ON_DT  '|| LV_AS(i).V_PROCESSED_ON_DT||
								' PROCESSING_REM_X  '|| LV_AS(i).V_PROCESSING_REM_X||
								' CUTOFF_DT  '|| LV_AS(i).V_CUTOFF_DT||
								' CRT_ON_DT  '|| LV_AS(i).V_CRT_ON_DT||
								' CRT_BY_N  '|| LV_AS(i).V_CRT_BY_X||
								' LST_UPD_ON_DT  '|| LV_AS(i).V_UPT_ON_DT||
								' LST_UPD_BY_N  '|| LV_AS(i).V_UPT_BY_X||
								' LOCK_VER_N  '|| LV_AS(i).V_LOCK_VER_N||
								' DELETED_I  '|| LV_AS(i).V_DELETED_I||
								' ORG_C  '|| 'MSW'||
								'VSL_REF_ID_N '	||	LV_AS(i).V_VSL_REF_ID_N_AS	||
								' RSN_X '|| LV_AS(i).V_REASON;



             pkg_datamigration_generic.proc_trace_exception('DM_APPLICATION_SUBMISSION', 'PROC_3_PUSH_VC_AS_VR',   V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,v_exp_rows,'T');

			END;

			END LOOP;


    END LOOP;
	CLOSE CR_AS;	
   /* 
	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_AS
     FROM
     SYN_AS;
    */
	IF( LV_CNT_TT_AS =  LV_CNT_DM_AS ) AND LV_CNT_DM_AS <>  0  AND  LV_CNT_TT_AS <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_APPLICATION_SUBMISSION', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_AS||' OUT OF ' || LV_CNT_DM_AS ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.APPLN_SUBMISSN' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_AS  <> LV_CNT_TT_AS AND  LV_CNT_DM_AS <> 0 AND  LV_CNT_TT_AS <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_APPLICATION_SUBMISSION', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_AS||' OUT OF ' || LV_CNT_DM_AS ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.APPLN_SUBMISSN' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_AS  <> 0 AND  LV_CNT_TT_AS = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_APPLICATION_SUBMISSION', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_AS||' OUT OF ' || LV_CNT_DM_AS ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.APPLN_SUBMISSN' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   


    pkg_datamigration_generic.proc_migration_recon('DM_APPLICATION_SUBMISSION', LV_CNT_DM_AS, 'APPLN_SUBMISSN', LV_CNT_TT_AS,'Y');


	/***********************************************************************************************************
	Pushing records into E_APPLICATION_SERVICE.VSL_REF
    ***********************************************************************************************************/

	OPEN  CR_VR;
	pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_REFERENCE', 'PROC_3_PUSH_VC_AS_VR', 'Insertion into target Table E_APPLICATION_SERVICE.VSL_REF', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.VESSEL_REFERENCE and inseting into target table E_APPLICATION_SERVICE.VSL_REF ************------------------        


			FETCH CR_VR BULK COLLECT INTO LV_VR LIMIT 10000;
            EXIT WHEN LV_VR.count = 0;
			--FORALL i IN LV_VR.first..LV_VR.last SAVE EXCEPTIONS  
			FOR i IN LV_VR.first..LV_VR.last
			LOOP
-------------************ SYN_VR is synonym of E_APPLICATION_SERVICE.VSL_REF  ************------------------  
			BEGIN


            INSERT INTO SYN_VR (
								VSL_REF_ID_N,
								MSW_VSL_ID_N,
								VSL_REC_ID_N,
								VSL_M,
								PORT_OF_REGY_C,
								VSL_IMO_N,
								VSL_CALL_SIGN_N,
								VSL_CRAFT_LIC_N,
								VSL_GT_Q,
								VSL_NT_Q,
								VSL_FLAG_C,
								VSL_TY_C,
								LOA_Q,
								DELETED_I,
								LOCK_VER_N
								) 

						VALUES (
								LV_VR(i).V_VSL_REF_ID_N,
								LV_VR(i).V_MSW_VSL_ID_N,
								LV_VR(i).V_VSL_REC_ID_N,
								LV_VR(i).V_VSL_M,
								LV_VR(i).V_PORT_OF_REGY_C,
								LV_VR(i).V_VSL_IMO_N,
								LV_VR(i).V_VSL_CALL_SIGN_N,
								LV_VR(i).V_VSL_CRAFT_LIC_N,
								LV_VR(i).V_VSL_GT_Q,
								LV_VR(i).V_VSL_NT_Q,
								LV_VR(i).V_VSL_FLAG_C,
								NVL(LV_VR(i).V_VSL_TY_C,'MSW_DM'),
								LV_VR(i).V_LOA_Q,
								LV_VR(i).V_DELETED_I,
								LV_VR(i).V_LOCK_VER_N							
								);

    LV_CNT_TT_VR :=LV_CNT_TT_VR+1;

        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                v_exp_rows := '  VSL_REF_ID_N  '||LV_VR(i).V_VSL_REF_ID_N||
								'  MSW_VSL_ID_N  '||LV_VR(i).V_MSW_VSL_ID_N||
								'  VSL_REC_ID_N  '||LV_VR(i).V_VSL_REC_ID_N||
								'  VSL_M  '||LV_VR(i).V_VSL_M||
								'  PORT_OF_REGY_C  '||LV_VR(i).V_PORT_OF_REGY_C||
								'  VSL_IMO_N  '||LV_VR(i).V_VSL_IMO_N||
								'  VSL_CALL_SIGN_N  '||LV_VR(i).V_VSL_CALL_SIGN_N||
								'  VSL_CRAFT_LIC_N  '||LV_VR(i).V_VSL_CRAFT_LIC_N||
								'  VSL_GT_Q  '||LV_VR(i).V_VSL_GT_Q||
								'  VSL_NT_Q  '||LV_VR(i).V_VSL_NT_Q||
								'  VSL_FLAG_C  '||LV_VR(i).V_VSL_FLAG_C||
								'  VSL_TY_C  '||LV_VR(i).V_VSL_TY_C||
								'  LOA_Q  '||LV_VR(i).V_LOA_Q||
								'  DELETED_I  '||LV_VR(i).V_DELETED_I||
								'  LOCK_VER_N  '||LV_VR(i).V_LOCK_VER_N;




             pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_REFERENCE', 'PROC_3_PUSH_VC_AS_VR',   V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,v_exp_rows,'T');

			END;

			END LOOP;


    END LOOP;
	CLOSE CR_VR;	
   /* 
	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_AS
     FROM
     SYN_VR;
    */
	IF( LV_CNT_TT_VR =  LV_CNT_DM_VR ) AND LV_CNT_DM_VR <>  0  AND  LV_CNT_TT_VR <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_REFERENCE', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VR||' OUT OF ' || LV_CNT_DM_VR ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_REF' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_VR  <> LV_CNT_TT_VR AND  LV_CNT_DM_VR <> 0 AND  LV_CNT_TT_VR <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_REFERENCE', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VR||' OUT OF ' || LV_CNT_DM_VR ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_REF' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_VR  <> 0 AND  LV_CNT_TT_VR = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_VESSEL_REFERENCE', 'PROC_3_PUSH_VC_AS_VR',
        LV_CNT_TT_VR||' OUT OF ' || LV_CNT_DM_VR ||' ROWS  HAVE BEEN INSERTED INTO E_APPLICATION_SERVICE.VSL_REF' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

	COMMIT;

    pkg_datamigration_generic.proc_migration_recon('DM_VESSEL_REFERENCE', LV_CNT_DM_VR, 'VSL_REF', LV_CNT_TT_VR,'Y');


	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_VESSEL_CALL', 'PROC_3_PUSH_VC_AS_VR', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_3_PUSH_VC_AS_VR;
/