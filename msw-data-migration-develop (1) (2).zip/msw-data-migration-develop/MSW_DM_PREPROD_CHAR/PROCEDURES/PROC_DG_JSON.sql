create or replace PROCEDURE PROC_DG_JSON  IS
/***********************************************************************************************************
procedure name : PROC_3_PUSH_VC_AS_VR
Created By     : Rohit Khool
Date           : 13-AUG-2019
Purpose        : To populate json value
Modified by    : 
Modified date  :
*************************************************************************************************************/




CURSOR CR_DG_JSON IS
SELECT
DG.APPLN_REF_N,
DECODE(DG.WASTE_I,0,'false',1,'true') AS WASTE_I ,
DECODE(DG.RESIDUE_I,0,'false',1,'true') AS  RESIDUE_I ,
DECODE(DG.SUBR_EMAIL_I,0,'false',1,'true') AS EMAIL_I ,
DECODE(DG.SUBR_SMS_I,0,'false',1,'true')  AS SMS_I ,
TO_CHAR(DG.RTA_DT,'YYYY-MM-DD HH24:MI:SS') AS RTA_DT ,
TO_CHAR(DG.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS') AS CRT_ON_DT ,
TO_CHAR(DG.ETA_DT,'YYYY-MM-DD HH24:MI:SS') AS ETA_DT ,
TO_CHAR(DG.UPT_ON_DT,'YYYY-MM-DD HH24:MI:SS') AS LST_UPT_DT ,
DG.VSL_CALL_ID_N,
DG.APPLCNT_ID_X,
DG.CRT_BY_X,
DG.WT_N,
DG.CNTR_X,
DG.IMO_CL_C,
DG.UN_X,
DG.PKG_TY_C,
DG.IN_VOY_X,
DG.OUT_VOY_X,
DG.OPERN_C,
DG.LOCN_C,
DG.CFT_LIC_X,
DG.CONT_PERS_M,
DG.MOBILE_N,
DG.MSW_APPLN_REF_ID_X,
APS.MSW_VSL_ID_N  ,
APS.APPLN_SUBMISSN_ID_N,
DGD.DOC_ID_N,
DGD.TY_C,
DGD.CRT_BY_X AS CRT_BY_DGD,
TO_CHAR(DGD.CRT_ON_DT,'YYYY-MM-DD HH24:MI:SS'),
DGD.LOCK_VER_N,
DG.EMAIL_X,
DG.PSN_N,
DG.FLASH_PT_N,
DECODE(DG.TANK_CNTR_I,0,'false',1,'true') AS TANK_I 

FROM DANGEROUS_GOODS_APPLICATION DG, APPLICATION_SUBMISSION APS ,DANGEROUS_GOODS_APPLICATION_DOCUMENT dgd
WHERE  APS.VSL_CALL_ID_N = DG.VSL_CALL_ID_N
and dg.appln_ref_n = dgd.appln_ref_n(+) 
--and dg.appln_ref_n =1191342
order by dg.APPLN_REF_N;

TYPE REC_DG_JSON IS RECORD
(
V_APPLN_REF_N 	DANGEROUS_GOODS_APPLICATION.APPLN_REF_N%TYPE,
V_WASTE_I		VARCHAR2(10),
V_RESIDUE_I		VARCHAR2(10),
V_EMAIL_I		VARCHAR2(10),
V_SMS_I			VARCHAR2(10),
V_RTA_DT		VARCHAR2(30),
V_CRT_ON_DT     VARCHAR2(30),
V_ETA_DT     	VARCHAR2(30),
V_LST_UPT_DT	VARCHAR2(30),
V_VSL_CALL_ID_N 		DANGEROUS_GOODS_APPLICATION.VSL_CALL_ID_N%TYPE,
V_APPLCNT_ID_X			DANGEROUS_GOODS_APPLICATION.APPLCNT_ID_X%TYPE,
V_CRT_BY_X 				DANGEROUS_GOODS_APPLICATION.CRT_BY_X%TYPE,
V_WT_N					DANGEROUS_GOODS_APPLICATION.WT_N%TYPE,
V_CNTR_X 				DANGEROUS_GOODS_APPLICATION.CNTR_X%TYPE,
V_IMO_CL_C				DANGEROUS_GOODS_APPLICATION.IMO_CL_C%TYPE,
V_UN_X					DANGEROUS_GOODS_APPLICATION.UN_X%TYPE,
V_PKG_TY_C				DANGEROUS_GOODS_APPLICATION.PKG_TY_C%TYPE,
V_IN_VOY_X 				DANGEROUS_GOODS_APPLICATION.IN_VOY_X%TYPE,
V_OUT_VOY_X				DANGEROUS_GOODS_APPLICATION.OUT_VOY_X%TYPE,
V_OPERN_C				DANGEROUS_GOODS_APPLICATION.OPERN_C%TYPE,
V_LOCN_C				DANGEROUS_GOODS_APPLICATION.LOCN_C%TYPE,
V_CFT_LIC_X 			DANGEROUS_GOODS_APPLICATION.CFT_LIC_X%TYPE,
V_CONT_PERS_M			DANGEROUS_GOODS_APPLICATION.CONT_PERS_M%TYPE,
V_MOBILE_N				DANGEROUS_GOODS_APPLICATION.MOBILE_N%TYPE,
V_MSW_APPLN_REF_ID_X	DANGEROUS_GOODS_APPLICATION.MSW_APPLN_REF_ID_X%TYPE,
V_VSL_ID 				APPLICATION_SUBMISSION.MSW_VSL_ID_N%TYPE,
V_APPLN_SUBMISSN_ID_N   APPLICATION_SUBMISSION.APPLN_SUBMISSN_ID_N%TYPE,
V_DOC_ID_N				DANGEROUS_GOODS_APPLICATION_DOCUMENT.DOC_ID_N%TYPE,
V_TY_C					DANGEROUS_GOODS_APPLICATION_DOCUMENT.TY_C%TYPE,
V_CRT_BY_DGD			DANGEROUS_GOODS_APPLICATION_DOCUMENT.CRT_BY_X%TYPE,
V_CRT_ON_DT_DGD			VARCHAR2(30),
V_LOCK_VER_N			DANGEROUS_GOODS_APPLICATION_DOCUMENT.LOCK_VER_N%TYPE,
V_EMAIL_X               DANGEROUS_GOODS_APPLICATION.EMAIL_X%TYPE,
V_PSN_N                 DANGEROUS_GOODS_APPLICATION.PSN_N%TYPE,
V_FLASH_PT_N            DANGEROUS_GOODS_APPLICATION.FLASH_PT_N%TYPE,
V_TANK_CNTR_I          VARCHAR2(10)
);

TYPE TYPE_DG_JSON  IS TABLE OF REC_DG_JSON;
LV_DG_JSON				TYPE_DG_JSON;

V_ERR_CODE          NUMBER;
V_ERR_MSG           VARCHAR2(500);
V_SQLERRM           VARCHAR2(2500);
V_EXP_ROWS          VARCHAR2(1000);
V_APPLN_REF			NUMBER;
V_APPLN_REF_O		NUMBER;
V_APPLN_SUBMISSN_ID	NUMBER;
L_CR_CNT            NUMBER;
L_LP_CNT            NUMBER;
LV_CNT_TT_JSON      NUMBER;
LV_CNT_ST_JSON      NUMBER;
LVAL    CLOB;


BEGIN

LV_CNT_ST_JSON :=0;
OPEN  CR_DG_JSON;
	pkg_datamigration_generic.proc_trace_exception('DG_JSON', 'PROC_DG_JSON', 'Insertion into target Table VESSEL_CALL', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.DANGEROUS_GOODS_APPLICATION and MSW_DATA_MIGRATION.DANGEROUS_GOODS_APPLICATION_DOCUMENT ************------------------        

        V_APPLN_REF_O :=NULL;
		
			FETCH CR_DG_JSON BULK COLLECT INTO LV_DG_JSON LIMIT 10000;
            EXIT WHEN LV_DG_JSON.count = 0;
            L_LP_CNT :=0;
			FOR i IN LV_DG_JSON.first..LV_DG_JSON.last
			LOOP
            
            BEGIN 


            L_CR_CNT :=LV_DG_JSON.last;   
            
            
			V_APPLN_REF :=LV_DG_JSON(i).V_APPLN_REF_N;
            
           

			IF  (V_APPLN_REF_O IS  NULL) OR (V_APPLN_REF <> V_APPLN_REF_O AND	V_APPLN_REF_O IS NOT NULL)
			THEN 

				IF (V_APPLN_REF <> V_APPLN_REF_O AND	V_APPLN_REF_O IS NOT NULL) 
				THEN 

				LVAL:=LVAL||']}';
				
					BEGIN
					INSERT INTO SI_JSON(APPLN_SUBMISSN_ID_N,APPLN_DATA_X,DATE_TIME,APPLN_TYPE)
					VALUES(V_APPLN_SUBMISSN_ID,LVAL,SYSDATE,'DGD');
					EXCEPTION
                    WHEN OTHERS
                    THEN
					V_ERR_CODE := SQLCODE;
					V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
					V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

					PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('JSON_DG', 'PROC_DG_JSON',DBMS_UTILITY.FORMAT_ERROR_BACKTRACE||DBMS_UTILITY.FORMAT_ERROR_STACK
											, 'ERROR', NULL, V_SQLERRM, NULL, 'T');
					END;
				LVAL := NULL;
				END IF;

        
			LVAL:='{';
			LVAL:=LVAL||'"vesselCallId":'||LV_DG_JSON(i).V_VSL_CALL_ID_N||',';
			LVAL:=LVAL||'"applicantId":"'||LV_DG_JSON(i).V_APPLCNT_ID_X||'",';
			LVAL:=LVAL||'"createdBy":"'||LV_DG_JSON(i).V_CRT_BY_X||'",';
			LVAL:=LVAL||'"createdOn":"'||LV_DG_JSON(i).V_CRT_ON_DT||'",';
			LVAL:=LVAL||'"lockVersion":'||0||',';
			LVAL:=LVAL||'"weight":'||LV_DG_JSON(i).V_wt_n||',';
			LVAL:=LVAL||'"containerNumber":"'||LV_DG_JSON(i).V_cntr_x||'",';
			LVAL:=LVAL||'"imoClass":"'||LV_DG_JSON(i).V_imo_cl_c||'",';
			LVAL:=LVAL||'"unNumber":"'||LV_DG_JSON(i).V_un_x||'",';
			LVAL:=LVAL||'"goodsPackageType":"'||LV_DG_JSON(i).V_pkg_ty_c||'",';
			LVAL:=LVAL||'"hasWaste":"'||LV_DG_JSON(i).V_WASTE_I||'",';
			LVAL:=LVAL||'"hasResidue":"'||LV_DG_JSON(i).V_RESIDUE_I||'",';
			LVAL:=LVAL||'"inVoyage":"'||LV_DG_JSON(i).V_in_voy_x||'",';
			LVAL:=LVAL||'"outVoyage":"'||LV_DG_JSON(i).V_out_voy_x||'",';
			LVAL:=LVAL||'"operationType":"'||LV_DG_JSON(i).V_opern_c||'",';
			LVAL:=LVAL||'"locationOfOperation":"'||LV_DG_JSON(i).V_locn_c||'",';
			LVAL:=LVAL||'"craftLicenseNo":"'||LV_DG_JSON(i).V_cft_lic_x||'",';
            LVAL:=LVAL||'"psnCode":"'||LV_DG_JSON(i).V_PSN_N||'",';
            
            LVAL:=LVAL||'"flashPoint":"'||LV_DG_JSON(i).V_FLASH_PT_N||'",';
            LVAL:=LVAL||'"isoTank":"'||LV_DG_JSON(i).V_TANK_CNTR_I||'",';
            
			LVAL:=LVAL||'"contactPerson":"'||LV_DG_JSON(i).V_CONT_PERS_M||'",';
			LVAL:=LVAL||'"mobileNumber":"'||LV_DG_JSON(i).V_mobile_n||'",';
            LVAL:=LVAL||'"emailAddress":"'||LV_DG_JSON(i).V_EMAIL_X||'",';
			LVAL:=LVAL||'"expectedTimeOfArrival":"'||LV_DG_JSON(i).V_ETA_DT||'",';
			LVAL:=LVAL||'"reportedTimeOfArrival":"'||LV_DG_JSON(i).V_RTA_DT||'",';
			LVAL:=LVAL||'"lastUpdatedOn":"'||LV_DG_JSON(i).V_LST_UPT_DT||'",';
			LVAL:=LVAL||'"mswApplicationReference":"'||LV_DG_JSON(i).V_MSW_APPLN_REF_ID_X||'",';
			LVAL:=LVAL||'"vesselId":'||LV_DG_JSON(i).V_VSL_ID||',';--Vessel_id ?
			LVAL:=LVAL||'"subscribeEmail":'||LV_DG_JSON(i).V_EMAIL_I||',';
			LVAL:=LVAL||'"subscribeSms":'||LV_DG_JSON(i).V_SMS_I||',';
			LVAL:=LVAL||'"dgdApplicationDocuments":[';
            IF LV_DG_JSON(i).V_DOC_ID_N IS NOT NULL
            THEN
			LVAL:=LVAL||'{"createdBy":"'||LV_DG_JSON(i).V_CRT_BY_DGD||'",';
			LVAL:=LVAL||'"createdOn":"'||LV_DG_JSON(i).V_CRT_ON_DT_DGD||'",';
			LVAL:=LVAL||'"documentId":'||LV_DG_JSON(i).V_DOC_ID_N||',';
			LVAL:=LVAL||'"documentType":"'||LV_DG_JSON(i).V_TY_C||'",';
			LVAL:=LVAL||'"lockVersion":'||0 ||'}';
            END IF;

			END IF;


---Logic for inserting multiple document section

				IF V_APPLN_REF = V_APPLN_REF_O and LV_DG_JSON(i).V_DOC_ID_N IS NOT NULL THEN 
                
				LVAL:=LVAL||',{"createdBy":"'||LV_DG_JSON(i).V_CRT_BY_DGD||'",';
				LVAL:=LVAL||'"createdOn":"'||LV_DG_JSON(i).V_CRT_ON_DT_DGD||'",';
				LVAL:=LVAL||'"documentId":'||LV_DG_JSON(i).V_DOC_ID_N||',';
				LVAL:=LVAL||'"documentType":"'||LV_DG_JSON(i).V_TY_C||'",';
				LVAL:=LVAL||'"lockVersion":'||0 ||'}';		
            
				END IF ;
				
            L_LP_CNT :=L_LP_CNT+1;
			V_APPLN_REF_O :=V_APPLN_REF;
			V_APPLN_SUBMISSN_ID :=LV_DG_JSON(i).V_APPLN_SUBMISSN_ID_N;
			
--Closing json if its last records  loop          
            IF L_CR_CNT = L_LP_CNT THEN
            LVAL:=LVAL||']}';
                BEGIN
					INSERT INTO SI_JSON(APPLN_SUBMISSN_ID_N,APPLN_DATA_X,DATE_TIME,APPLN_TYPE)
					VALUES(V_APPLN_SUBMISSN_ID,LVAL,SYSDATE,'DGD');
				   
					EXCEPTION         
					WHEN OTHERS THEN 
				
					V_ERR_CODE := SQLCODE;
					V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
					V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

					pkg_datamigration_generic.proc_trace_exception('JSON_DG', 'PROC_DG_JSON',dbms_utility.format_error_backtrace||dbms_utility.format_error_stack
											, 'ERROR', null, V_SQLERRM, NULL, 'T');
                END;
            END IF;

            LV_CNT_ST_JSON:=LV_CNT_ST_JSON+1;
       
            EXCEPTION
            
            WHEN OTHERS THEN 
        
			V_ERR_CODE := SQLCODE;
			V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
			V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

			pkg_datamigration_generic.proc_trace_exception('JSON_DG_FORMATTING', 'PROC_DG_JSON',dbms_utility.format_error_backtrace||dbms_utility.format_error_stack
									, 'ERROR', null, V_SQLERRM, NULL, 'T');
            
    
            END;

			END LOOP;


    END LOOP;
	COMMIT;
CLOSE CR_DG_JSON;	

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_JSON
     FROM
     SI_JSON;

pkg_datamigration_generic.proc_migration_recon('JSON_DG', LV_CNT_ST_JSON, 'SI_JSON', LV_CNT_TT_JSON,'Y');

EXCEPTION  
WHEN OTHERS THEN 

V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

pkg_datamigration_generic.proc_trace_exception('JSON_DG_OUTER', 'PROC_DG_JSON',dbms_utility.format_error_backtrace||dbms_utility.format_error_stack
                        , 'ERROR', null, V_SQLERRM, NULL, 'T');


END;
/