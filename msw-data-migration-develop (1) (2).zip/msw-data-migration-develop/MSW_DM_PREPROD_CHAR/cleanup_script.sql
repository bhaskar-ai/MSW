spool './cleanup_script.log';
set linesize 200;
set trimspool on;
set trimout on;
set pagesize 50000;

------------------
-- Disable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' disable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/


truncate table APPLICATION_SUBMISSION;
truncate table ARRIVAL_GD_APPLICATION;
truncate table ARRIVAL_GD_PURPOSE_OF_CALL;
truncate table ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC;
truncate table CHANGE_AGENCY_APPLICATION;
truncate table DANGEROUS_GOODS_APPLICATION;
truncate table DANGEROUS_GOODS_APPLICATION_DOCUMENT;
truncate table DEP_GD_P_CLRCE_CERT;
truncate table DEPARTURE_GD_APPLICATION;
truncate table DEPARTURE_GD_PURPOSE_OF_CALL;
truncate table DG_CHEM;
truncate table DG_PSN;
truncate table HNS_APPLICATION;
truncate table HNS_APPLICATION_SUBSTANCE;
truncate table PAN_APPLICATION;
truncate table PAN_PURPOSE_OF_CALL;
truncate table PAN_SHIP_ACTIVITY;
truncate table PAN_SHIP_CERTIFICATE;
truncate table PAST_PORT_CALLS;
truncate table SI_ARR_DEP_GD2;
truncate table SI_ARR_GD;
truncate table SI_CV_CHGAGTAPPLN;
truncate table SI_CV_VSL;
truncate table SI_CV_VSLCERT;
truncate table SI_DEP_DEPOC;
truncate table SI_DEP_GD_P_CLRCE_CERT;
truncate table SI_DG_APPLICATION;
truncate table SI_HNS_APP;
truncate table SI_JSON;
truncate table SI_PAN_APPLICATION;
truncate table SI_PAN_PURPOSE_OF_CALL;
truncate table SI_PAN_SHIP_ACTIVITY.sql;
truncate table SI_PAN_SHIP_CERTIFICATE;
truncate table SI_PAST_PORT_CALLS;
truncate table SI_SHIPYARD;
truncate table SI_VESSEL_CERTIFICATE_ATTRIBUTE;
truncate table ST_CM_DOCMETADATA;
truncate table ST_CV_ARRGD;
truncate table ST_CV_CHGAGTAPPLN;
truncate table ST_CV_DECLRSHYARD;
truncate table ST_CV_DEPGD;
truncate table ST_CV_GDAPPLN;
truncate table ST_CV_PENDINGAPPLN;
truncate table ST_CV_PORTCLRCECERTISSD;
truncate table ST_CV_PORTCLRCECERTISSDHIST;
truncate table ST_CV_VSL;
truncate table ST_CV_VSLCALL;
truncate table ST_CV_VSLCERT;
truncate table ST_DG_PM4;
truncate table ST_DG_PM4SUPPORTINGDOC;
truncate table ST_DG_VSLCALL;
truncate table ST_HN_NTCEDTL;
truncate table ST_HN_NTCEHDR;
truncate table ST_PANS_LAST10CALLSFRMRLOG;
truncate table ST_PANS_LAST10MEASURESFRMRLOG;
truncate table ST_PANS_LAST10SHPTOSHPACTFRMRLOG;
truncate table ST_PANS_LAST10SHPTOSHPSECFRMRLOG;
truncate table ST_PANS_PANSINFOFRMRLOG;
truncate table ST_PANS_PANSINFOFRMRLOG2;
truncate table ST_PANS_PANSINFOFRMRLOG3;
truncate table ST_PM4SUPPORTINGDOC_MAPPING;
truncate table ST_PTMS_BWMC;
truncate table ST_PTMS_NOAFREFORM;
truncate table ST_PTMS_NOAFREFORMHIST;
truncate table TBL_MIGRATION_RECON;
truncate table TBL_RUN_DETAILS;
truncate table TBL_TRACE_MIGRATION;
truncate table USR_DTLS;
truncate table VESSEL;
truncate table VESSEL_CALL;
truncate table VESSEL_CERTIFICATE;
truncate table VESSEL_CERTIFICATE_ATTRIBUTES;
truncate table VESSEL_REFERENCE;

------------------
-- Enable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' enable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/

--Disable Index
alter index indx_depgd unusable ;
alter index indx_vslcall   unusable ;
alter index indx_gdappln   unusable ;
ALTER INDEX INDX_TRC_DATE_MIG unusable;

-- Count every table
select
   table_name,
   to_number(
   extractvalue(
      xmltype(
         dbms_xmlgen.getxml('select count(*) c from '||table_name))
    ,'/ROWSET/ROW/C')) count
from 
   user_tables
order by 
   count desc, table_name;
   
   
 spool off;
 
 exit;
