create table vessel_type as select * from vessel_service.vsl_ty;

ALTER TABLE vessel_type
ADD CONSTRAINT PK_VESSEL_TYPE PRIMARY KEY (VSL_TYPE_ID_N);

create table craft_type as select * from vessel_service.craft_ty;

ALTER TABLE craft_type
ADD CONSTRAINT PK_CRAFT_TYPE PRIMARY KEY (CRAFT_TYPE_ID_N);

ALTER TABLE craft_type
ADD CONSTRAINT FK_VESSEL_TYPE_CRAFT
  FOREIGN KEY (VSL_TYPE_ID_N)
  REFERENCES VESSEL_TYPE(VSL_TYPE_ID_N);