alter index indx_depgd  REBUILD   ;
alter index indx_vslcall   REBUILD ;
alter index indx_gdappln   REBUILD ;
