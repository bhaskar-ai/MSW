create index indx_depgd on st_CV_depGD(REF_N,GDV_N)  COMPUTE STATISTICS;
create index indx_depgd_depst on st_CV_depGD(depGDSt_c,crton_dt) COMPUTE STATISTICS;
create index indx_vslcall on ST_CV_VSLCALL(GDV_N) COMPUTE STATISTICS;
create index indx_gdappln on st_CV_GDAppln(APPLNREF_N) COMPUTE STATISTICS;
