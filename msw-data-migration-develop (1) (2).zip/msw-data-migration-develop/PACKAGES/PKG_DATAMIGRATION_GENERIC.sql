create or replace PACKAGE PKG_DATAMIGRATION_GENERIC AS
  -- trace  the migration status 
PROCEDURE PROC_trace_exception(PVMOD in  VARCHAR2,PVSRCPROG in VARCHAR2,PVERR_DESC in VARCHAR2,PSTATUS in  VARCHAR2,P_RUNID in NUMBER,P_ORA_ERROR in VARCHAR2,P_RECORD_DETAILS in VARCHAR2,P_ERROR_TYPE VARCHAR2);
--Reconcile the data of source and target table  
procedure PROC_migration_Recon(P_TBL_SOURCE VARCHAR2,P_TBL_SRC_COUNT number,P_TBL_TGT VARCHAR2,P_TBL_TGT_COUNT number,P_FLAG char);

END PKG_DATAMIGRATION_GENERIC ;
/

create or replace PACKAGE BODY PKG_DATAMIGRATION_GENERIC
 AS
 
 /***********************************************************************************************************
procedure name : PROC_trace_exception
Created By     : C.N.Bhaskar
Date           : 22-mar-2019
Purpose        : To insert Errors in Exception table 
Modified by    :
Modified date  :

*************************************************************************************************************/

procedure PROC_trace_exception(PVMOD VARCHAR2,
                               PVSRCPROG VARCHAR2,
                               PVERR_DESC VARCHAR2,
                               PSTATUS VARCHAR2,
                               P_RUNID NUMBER,
                               P_ORA_ERROR VARCHAR2,
                               P_RECORD_DETAILS VARCHAR2,
                               P_ERROR_TYPE VARCHAR2)

IS 

V_JUL  varchar2(200) ;
V_TRACE VARCHAR2(2000); 

begin

--creation of julian date which is appended to sequence  to generate trace id 

select TO_CHAR(SYSDATE,'J') 
into V_JUL 
from dual;  

--concatinating  julian date with  the sequence to generate traceid 

V_TRACE := V_JUL||seq_error.nextval;


--inserting data into error table 


insert into tbl_trace_migration  values (V_TRACE,PVMOD,PVSRCPROG,PVERR_DESC,sysdate,PSTATUS,P_RUNID,P_ORA_ERROR,P_RECORD_DETAILS,P_ERROR_TYPE);
commit;

EXCEPTION 

WHEN OTHERS THEN NULL;


end  PROC_trace_exception;


/***********************************************************************************************************
procedure name : PROC_migration_Recon
Created By     : C.N.Bhaskar
Date           : 22-mar-2019
Purpose        : To Reconcile record count in source tbl and target tbl
Modified by    :
Modified date  :

*************************************************************************************************************/


procedure PROC_migration_Recon(P_TBL_SOURCE VARCHAR2,
                               P_TBL_SRC_COUNT number,
                               P_TBL_TGT VARCHAR2,
                               P_TBL_TGT_COUNT number,
                               P_FLAG char)

IS 

V_JUL  varchar2(200) ;
V_TRACE VARCHAR2(2000); 

begin

--creation of julian date which is appended to sequence  to generate trace id 

select TO_CHAR(SYSDATE,'J') 
into V_JUL 
from dual;  

--concatinating  julian date with  the sequence to generate traceid 

V_TRACE := V_JUL||seq_recon.nextval;


--inserting data into TBL_MIGRATION_RECON table 


insert into TBL_MIGRATION_RECON  values (V_TRACE,sysdate,P_TBL_SOURCE,P_TBL_SRC_COUNT,P_TBL_TGT,P_TBL_TGT_COUNT,P_FLAG);
commit;

EXCEPTION 

WHEN OTHERS THEN NULL;

end  PROC_migration_Recon;


END PKG_DATAMIGRATION_GENERIC;
/