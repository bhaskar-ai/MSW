#!/bin/bash
echo "Start of Deployment"
sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
spool on
spool  Deploy.log
@ Deploy.sql;
spool off;
EOF
echo 'End of Script'
