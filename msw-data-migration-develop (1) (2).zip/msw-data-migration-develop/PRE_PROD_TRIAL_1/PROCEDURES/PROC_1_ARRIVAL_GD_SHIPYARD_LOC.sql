create or replace PROCEDURE PROC_1_ARRIVAL_GD_SHIPYARD_LOC (PV_RUN_ID  in number)IS

/***********************************************************************************************************
procedure name : PROC_1_ARRIVAL_GD_SHIPYARD_LOC
Created By     : C.N.BHASKAR
Date           : 17-july-2019
Purpose        : Inserting  the data from ST_CV_GDAppln,ST_CV_pendingAppln,ST_CV_vslCall (main table) to 
                 SI_SHIPYARD   and  ARRIVAL_GD_SHIPYARD_LOC
Modified by    :
Modified date  :

*************************************************************************************************************/

	/***********************************************************************************************************
	Defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table
	*************************************************************************************************************/

    TYPE rec_gd_application IS RECORD 

    (    V_ARR_GD_PURP_OF_CALL_ID_N    si_shipyard.arr_gd_purp_of_call_id_n%type,
         V_SHYARDLOCN_C                si_shipyard.shyardlocn_c%type,
         V_SHYARDLOCNDESC_X            si_shipyard.shyardlocndesc_x%type

    );

    TYPE type_gd_application IS TABLE OF rec_gd_application;

    lv_gd_appllication type_gd_application;

    v_err_code NUMBER;
    v_err_msg VARCHAR2(500);
    v_sqlerrm VARCHAR2(2500);


    v_src_count NUMBER;
    v_tgt_count  number;

cursor CUR_SHIPYARD is   

select *
from 
SI_SHIPYARD;



begin  --outer begin

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_SHIPYARD', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC','INSERTION INTO SI_SHIPYARD  STARTS' , 'START',null,null,null,'T');



FOR i IN

(
select 

pcall.ARR_GD_PURP_OF_CALL_ID_N,
yard.SHYARDLOCN_C,
yard.SHYARDLOCNDESC_X


from st_CV_declrShyard yard,
(
select app.GDV_n from st_CV_arrGD arr ,st_CV_GDAppln app,st_CV_vslCall call,st_CV_pendingAppln pend
,(
  select distinct app.GDV_n, MAX( app.crtOn_dt) as maxCrtOn_dt from st_CV_arrGD arr ,
   st_CV_GDAppln app where  app.GDV_n = arr.GDV_n 
  and  arr.arrGDSt_c in ('1','5') and app.GDTy_c in ('A', 'C')
  group by app.GDV_n
  ) lastedGDApp
where
app.GDV_n = arr.GDV_n 
 and call.GDV_n = arr.GDV_n 
 and  pend.applnRef_n = app.applnRef_n
   and  lastedGDApp.GDV_n = app.GDV_n and lastedGDApp.maxCrtOn_dt = app.crtOn_dt

 union
select app.GDV_n from st_CV_depGD dep, st_CV_GDAppln app,st_CV_vslCall call ,st_CV_pendingAppln pend
  where
  app.applnRef_n = dep.ref_n 
  and call.GDV_n = dep.GDV_n 
  and pend.applnRef_n = app.applnRef_n
and  depGDSt_c in ('1','5')
)   finalGDAppln ,arrival_gd_purpose_of_call pcall,arrival_gd_application agd
where
finalGDAppln.GDV_n = yard.GDV_n
and agd.gdv_n=yard.GDV_n
and agd.APPLN_REF_N= pcall.APPLN_REF_N
and pcall.purpcall_c = 'Repair/Docking/Outfitting'

  )

LOOP               

BEGIN                                            -- inner begin  of SI  tablee 

 INSERT INTO SI_SHIPYARD (
ARR_GD_PURP_OF_CALL_ID_N,
SHYARDLOCN_C,
SHYARDLOCNDESC_X
)

VALUES ( 

i.ARR_GD_PURP_OF_CALL_ID_N,
i.SHYARDLOCN_C,
i.SHYARDLOCNDESC_X

);

exception  --inner exception of SI table 

 WHEN OTHERS THEN                                                     -- inner exception for handling any errors in the SI table 
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_SHIPYARD',
  'PROC_1_ARRIVAL_GD_SHIPYARD_LOC',
'ARR_GD_PURP_OF_CALL_ID_N:'||i.ARR_GD_PURP_OF_CALL_ID_N	||'<{||}>'||
'SHYARDLOCN_C:'||i.SHYARDLOCN_C	||'<{||}>'||
'SHYARDLOCNDESC_X:'||i.SHYARDLOCNDESC_X	
  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

i.ARR_GD_PURP_OF_CALL_ID_N	||'<{||}>'||
i.SHYARDLOCN_C	||'<{||}>'||
i.SHYARDLOCNDESC_X	

,
 'T'
 );

end ;   -- inner end of SI table 

end loop; -- end loop of for which inserts the data into the SI table 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_SHIPYARD', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC','INSERTION INTO SI_SHIPYARD  ENDS' , 'ENDS',null,null,null,'T');



---------------------------------------------------------------------------------------------------------------------------------


OPEN CUR_SHIPYARD;

loop     -- loop of the cursor  CUR_SHIPYARD

  FETCH CUR_SHIPYARD BULK COLLECT INTO LV_GD_APPLLICATION LIMIT 5000;

               EXIT WHEN LV_GD_APPLLICATION.count = 0;


                  FOR i IN LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 


                  loop       --loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 



begin   -- inner begin to insert the values into the ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC  table

insert into ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC

(ARR_GD_PURP_OF_CALL_SHIPYARD_LOC_ID_N,
ARR_GD_PURP_OF_CALL_ID_N,
SHIPYARD_LOC_C,
SHIPYARD_LOC_DESC_X,
LOCK_VER_N,
DELETED_I)

values
(seq_shipyard_loc.nextval,
lv_gd_appllication(i).V_ARR_GD_PURP_OF_CALL_ID_N,
lv_gd_appllication(i).V_SHYARDLOCN_C,
lv_gd_appllication(i).V_SHYARDLOCNDESC_X,
0,
0);






exception   -- inner exception to insert the values into the ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC  table

when others then null;
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 


 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_SHIPYARD',
  'PROC_1_ARRIVAL_GD_SHIPYARD_LOC',

'ARR_GD_PURP_OF_CALL_SHIPYARD_LOC_ID_N:'||seq_shipyard_loc.currval ||'<{||}>'||
'ARR_GD_PURP_OF_CALL_ID_N:'||lv_gd_appllication(i).V_ARR_GD_PURP_OF_CALL_ID_N ||'<{||}>'||
'SHIPYARD_LOC_C:'|| lv_gd_appllication(i).V_SHYARDLOCN_C ||'<{||}>'||
'SHIPYARD_LOC_DESC_X:'|| lv_gd_appllication(i).V_SHYARDLOCNDESC_X ||'<{||}>'||
'LOCK_VER_N:'||0 ||'<{||}>'||
'DELETED_I:'||0

  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

seq_shipyard_loc.currval ||'<{||}>'||
lv_gd_appllication(i).V_ARR_GD_PURP_OF_CALL_ID_N ||'<{||}>'||
lv_gd_appllication(i).V_SHYARDLOCN_C ||'<{||}>'||
lv_gd_appllication(i).V_SHYARDLOCNDESC_X ||'<{||}>'||
0 ||'<{||}>'||
0

,
 'T'
 );


end;  -- inner end  to insert the values into the ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC  table

commit;


                  end loop;    -- end loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST   


end loop; -- end of CUR_SHIPYARD


close CUR_SHIPYARD;

/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure starts 
*************************************************************************************************************/

SELECT COUNT(*)
INTO    v_src_count
FROM ST_CV_DECLRSHYARD;   
--st_cv_gdappln appln
--where   appln.GDTY_C in('A','C') ;



SELECT COUNT(*)
INTO V_TGT_COUNT
FROM
SI_SHIPYARD ;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_DECLRSHYARD', V_SRC_COUNT, 'SI_SHIPYARD', V_TGT_COUNT,'N');	




        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into SI_SHIPYARD table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_SHIPYARD table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_SHIPYARD table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_SHIPYARD table' ,
        'AMBIGIOUS',null,null,null,null);

end if;

/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure ends 
*************************************************************************************************************/

/***********************************************************************************************************
Reconciling the count of source intermediate GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/

SELECT COUNT(*)
INTO v_src_count
FROM
SI_SHIPYARD;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_SHIPYARD', V_SRC_COUNT, 'ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', V_TGT_COUNT,'N');	  



        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC table' ,
        'AMBIGIOUS',null,null,null,null);

end if;

/***********************************************************************************************************
Reconcilation of source intermediate GD Arrival  and target table of GD Departure  ends
*************************************************************************************************************/


/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/


SELECT COUNT(*)
INTO    v_src_count
FROM ST_CV_DECLRSHYARD;    

--st_cv_gdappln appln
--where   appln.GDTY_C in('A','C') ;


     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_CV_DECLRSHYARD', V_SRC_COUNT, 'ARRIVAL_GD_PURPOSE_OF_CALL_SHIPYARD_LOC', V_TGT_COUNT,'Y');	  


/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure ends 
*************************************************************************************************************/
exception  --outer exception 

when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

              PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARR_DEP_GD_APPLICATION', 'PROC_1_ARRIVAL_GD_SHIPYARD_LOC', V_SQLERRM, 'FAIL',null,null,null,'T');

end ;  -- outer end
/
