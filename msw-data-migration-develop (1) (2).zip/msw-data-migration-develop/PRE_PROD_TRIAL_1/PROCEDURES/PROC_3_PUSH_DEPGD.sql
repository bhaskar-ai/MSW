create or replace PROCEDURE PROC_3_PUSH_DEPGD IS

    
    
/***********************************************************************************************************
PROCEDURE NAME : PROC_3_PUSH_DEPGD
CREATED BY     : C.N.BHASKAR
DATE           : 17-AUG-2019
PURPOSE        : PUSH ARRIVAL_GD RECORDS FROM MSW_DATA_MIGRATION SCHEMA TO TARGET SCHEMA CVS_INTEGRATION
MODIFIED BY    :
MODIFIED DATE  :
*************************************************************************************************************/

---**** cursor for fetching data from target  Table ****

	CURSOR CUR_DEPGD IS
	SELECT
        AGT_DECLR_AC_N	,
        APPLN_REF_N	,
        APPLN_ST_C	,
        BUNKR_GR_C	,
        BUNKR_Q	,
        CGO_Q	,
        CHARTERER_NAT_C	,
        COMPANY_NAME	,
        CREW_Q	,
        CRT_BY_N	,
        CRT_ON_DT	,
        CST_N	,
        DELETED_I	,
        DEPARTURE_LOCATION	,
        DEP_DECLR_DT	,
        EXTL_APPLN_REF_ID_X	,
        GDV_N	,
        INTL_REM_X	,
        LOCKVER_N	,
        MOTHER_GDV_N	,
        MPA_ACCOUNT_NAMES	,
        MSTR_ON_DEP_X	,
        MSW_APPLN_REF_ID_X	,
        NX_PORT_C	,
        NX_PORT_CTRY_C	,
        NX_PORT_M	,
        PAX_Q	,
        PERS_Q	,
        PROCESSED_BY_X	,
        PROCESSED_ON_DT	,
        PROCESSING_REM_X	,
        SLN_C	,
        UPT_BY_X	,
        UPT_ON_DT	,
        VSL_GT_ON_DEP_Q	


	FROM DEPARTURE_GD_APPLICATION;

	TYPE REC_DEPGD IS RECORD
	(   v_agt_declr_ac_n         departure_gd_application.agt_declr_ac_n%type	,
        V_APPLN_REF_N			 DEPARTURE_GD_APPLICATION.APPLN_REF_N%type	,
        V_APPLN_ST_C			 DEPARTURE_GD_APPLICATION.APPLN_ST_C%type	,
        V_BUNKR_GR_C			DEPARTURE_GD_APPLICATION.BUNKR_GR_C%type	,
        V_BUNKR_Q				DEPARTURE_GD_APPLICATION.BUNKR_Q%type	,
        V_CGO_Q				    DEPARTURE_GD_APPLICATION.CGO_Q%type	,
        V_CHARTERER_NAT_C		DEPARTURE_GD_APPLICATION.CHARTERER_NAT_C%type	,
        V_COMPANY_NAME			DEPARTURE_GD_APPLICATION.COMPANY_NAME%type	,
        V_CREW_Q				DEPARTURE_GD_APPLICATION.CREW_Q%type	,
        V_CRT_BY_N				DEPARTURE_GD_APPLICATION.CRT_BY_N%type	,
        V_CRT_ON_DT				DEPARTURE_GD_APPLICATION.CRT_ON_DT%type	,
        V_CST_N				    DEPARTURE_GD_APPLICATION.CST_N%type	,
        V_DELETED_I				DEPARTURE_GD_APPLICATION.DELETED_I%type	,
        V_DEPARTURE_LOCATION	DEPARTURE_GD_APPLICATION.DEPARTURE_LOCATION%type	,
        V_DEP_DECLR_DT			DEPARTURE_GD_APPLICATION.DEP_DECLR_DT%type	,
        V_EXTL_APPLN_REF_ID_X	DEPARTURE_GD_APPLICATION.EXTL_APPLN_REF_ID_X%type	,
        V_GDV_N				    DEPARTURE_GD_APPLICATION.GDV_N%type	,
        V_INTL_REM_X			DEPARTURE_GD_APPLICATION.INTL_REM_X%type	,
        V_LOCKVER_N				DEPARTURE_GD_APPLICATION.LOCKVER_N%type	,
        V_MOTHER_GDV_N			DEPARTURE_GD_APPLICATION.MOTHER_GDV_N%type	,
        V_MPA_ACCOUNT_NAMES		DEPARTURE_GD_APPLICATION. MPA_ACCOUNT_NAMES%type	,
        V_MSTR_ON_DEP_X			DEPARTURE_GD_APPLICATION. MSTR_ON_DEP_X%type	,
        V_MSW_APPLN_REF_ID_X	DEPARTURE_GD_APPLICATION.MSW_APPLN_REF_ID_X	%type	,
        V_NX_PORT_C				DEPARTURE_GD_APPLICATION.NX_PORT_C%type	,
        V_NX_PORT_CTRY_C		DEPARTURE_GD_APPLICATION.NX_PORT_CTRY_C	%type	,
        V_NX_PORT_M				DEPARTURE_GD_APPLICATION.NX_PORT_M%type	,
        V_PAX_Q				    DEPARTURE_GD_APPLICATION.PAX_Q%type	,
        V_PERS_Q				DEPARTURE_GD_APPLICATION.PERS_Q%type	,
        V_PROCESSED_BY_X		DEPARTURE_GD_APPLICATION. PROCESSED_BY_X%type	,
        V_PROCESSED_ON_DT		DEPARTURE_GD_APPLICATION.PROCESSED_ON_DT%type	,
        V_PROCESSING_REM_X		DEPARTURE_GD_APPLICATION. PROCESSING_REM_X%type	,
        V_SLN_C				    DEPARTURE_GD_APPLICATION.SLN_C%type	,
        V_UPT_BY_X				DEPARTURE_GD_APPLICATION.UPT_BY_X%type	,
        V_UPT_ON_DT				DEPARTURE_GD_APPLICATION.UPT_ON_DT%type	,
        v_vsl_gt_on_dep_q      departure_gd_application.vsl_gt_on_dep_q%TYPE	
	

	);


	CURSOR CUR_DEP_POC IS
	SELECT
            APPLN_REF_N,	
            DELETED_I,	
            DEP_GD_PURP_OF_CALL_ID_N,	
            LOCK_VER_N,	
            OTHERS_PURPOSE_X,	
	        PURPCALL_C,	
            PURPCALL_OTHERS_TOW_VSL_M,	
	        PURP_CALL_OTHERS_TOW_X	

     FROM departure_gd_purpose_of_call;

	TYPE REC_DEPGD_POC IS RECORD
	(	
  
    V_APPLN_REF_N		            departure_gd_purpose_of_call.APPLN_REF_N%type,
    V_DELETED_I		                departure_gd_purpose_of_call.DELETED_I%type,
    V_DEP_GD_PURP_OF_CALL_ID_N		departure_gd_purpose_of_call.DEP_GD_PURP_OF_CALL_ID_N%type,
    V_LOCK_VER_N		            departure_gd_purpose_of_call.LOCK_VER_N%type,
    V_OTHERS_PURPOSE_X		        departure_gd_purpose_of_call.OTHERS_PURPOSE_X%type,
    V_PURPCALL_C		            departure_gd_purpose_of_call.PURPCALL_C%type,
    V_PURPCALL_OTHERS_TOW_VSL_M		departure_gd_purpose_of_call.PURPCALL_OTHERS_TOW_VSL_M%type,
    V_PURP_CALL_OTHERS_TOW_X		departure_gd_purpose_of_call.PURP_CALL_OTHERS_TOW_X%type

	);

	CURSOR CUR_DEP_GD_PORT IS
	SELECT
        APPLN_REF_N	,
        CGO_Q	,
        CRT_BY_N	,
        CRT_ON_DT	,
        DELETED_I	,
        DEPDECLR_DT	,
        DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
        DOC_ID_ATTH_N	,
        GDV_N	,
        LAST_UPDATED_BY_N	,
        LAST_UPDATED_ON_DT	,
        LOCK_VER_N	,
        MSTRONDEP_X	,
        MSW_DOC_ID_N	,
        NXCTRY_M	,
        NXPORT_M	,
        OFFICIAL_GDV_N	,
        ORG_C	,
        PCCSEQ_N	,
        PCC_CANCEL_DT	,
        PCC_EXPY_DT	,
        PCC_I	,
        PCC_ISSD_BY_M	,
        PCC_ISSD_DT	,
        PCC_LATE_CANCL_I	,
        PCC_N	,
        PCC_PRNT_I	,
        PCC_ST_C	,
        VSLCALLSIGN_N	,
        VSLFLAG_M	,
        VSLGT_Q	,
        VSLIMO_N	,
        VSLMMSI_N	,
        VSL_M	


	FROM DEP_GD_P_CLRCE_CERT;


	TYPE REC_DEPGD_PORT IS RECORD

(V_APPLN_REF_N		DEP_GD_P_CLRCE_CERT.APPLN_REF_N	%type	,
V_CGO_Q		       DEP_GD_P_CLRCE_CERT.CGO_Q%type	,
V_CRT_BY_N		    DEP_GD_P_CLRCE_CERT.CRT_BY_N%type	,
V_CRT_ON_DT		DEP_GD_P_CLRCE_CERT.CRT_ON_DT%type	,
V_DELETED_I		DEP_GD_P_CLRCE_CERT.DELETED_I%type	,
V_DEPDECLR_DT		DEP_GD_P_CLRCE_CERT.DEPDECLR_DT%type	,
V_DEP_GD_PORT_CLEARENCE_CERT_ID_N		DEP_GD_P_CLRCE_CERT.DEP_GD_PORT_CLEARENCE_CERT_ID_N%type	,
V_DOC_ID_ATTH_N		DEP_GD_P_CLRCE_CERT.DOC_ID_ATTH_N%type	,
V_GDV_N		DEP_GD_P_CLRCE_CERT.GDV_N%type	,
V_LAST_UPDATED_BY_N		DEP_GD_P_CLRCE_CERT.LAST_UPDATED_BY_N%type	,
V_LAST_UPDATED_ON_DT		DEP_GD_P_CLRCE_CERT.LAST_UPDATED_ON_DT%type	,
V_LOCK_VER_N		DEP_GD_P_CLRCE_CERT.LOCK_VER_N%type	,
V_MSTRONDEP_X		DEP_GD_P_CLRCE_CERT.MSTRONDEP_X%type	,
V_MSW_DOC_ID_N		DEP_GD_P_CLRCE_CERT. MSW_DOC_ID_N%type	,
V_NXCTRY_M		DEP_GD_P_CLRCE_CERT.NXCTRY_M%type	,
V_NXPORT_M		DEP_GD_P_CLRCE_CERT.NXPORT_M%type	,
V_OFFICIAL_GDV_N		DEP_GD_P_CLRCE_CERT.OFFICIAL_GDV_N%type	,
V_ORG_C		DEP_GD_P_CLRCE_CERT.ORG_C%type	,
V_PCCSEQ_N		DEP_GD_P_CLRCE_CERT.PCCSEQ_N%type	,
V_PCC_CANCEL_DT		DEP_GD_P_CLRCE_CERT.PCC_CANCEL_DT%type	,
V_PCC_EXPY_DT		DEP_GD_P_CLRCE_CERT.PCC_EXPY_DT%type	,
V_PCC_I		DEP_GD_P_CLRCE_CERT.PCC_I%type	,
V_PCC_ISSD_BY_M		DEP_GD_P_CLRCE_CERT. PCC_ISSD_BY_M%type	,
V_PCC_ISSD_DT		DEP_GD_P_CLRCE_CERT.PCC_ISSD_DT%type	,
V_PCC_LATE_CANCL_I		DEP_GD_P_CLRCE_CERT.PCC_LATE_CANCL_I%type	,
V_PCC_N		DEP_GD_P_CLRCE_CERT.PCC_N%type	,
V_PCC_PRNT_I		DEP_GD_P_CLRCE_CERT.PCC_PRNT_I%type	,
V_PCC_ST_C		DEP_GD_P_CLRCE_CERT.PCC_ST_C%type	,
V_VSLCALLSIGN_N		DEP_GD_P_CLRCE_CERT.VSLCALLSIGN_N%type	,
V_VSLFLAG_M		DEP_GD_P_CLRCE_CERT.VSLFLAG_M%type	,
V_VSLGT_Q		DEP_GD_P_CLRCE_CERT.VSLGT_Q%type	,
V_VSLIMO_N		DEP_GD_P_CLRCE_CERT.VSLIMO_N%type	,
V_VSLMMSI_N		DEP_GD_P_CLRCE_CERT.VSLMMSI_N%type	,
V_VSL_M		DEP_GD_P_CLRCE_CERT.VSL_M%type	


	);

	TYPE TYPE_DEPGD IS TABLE OF REC_DEPGD;
	LV_DEPGD		TYPE_DEPGD;

	TYPE TYPE_DEPGD_POC  IS TABLE OF REC_DEPGD_POC;
	LV_DEPGD_POC		TYPE_DEPGD_POC;

	TYPE TYPE_DEPGD_PORT  IS TABLE OF REC_DEPGD_PORT;
	LV_DEPGD_PORT		TYPE_DEPGD_PORT;

	LV_CNT_DEPGD       NUMBER;
	LV_CNT_DEPGD_TGT		NUMBER;
	LV_CNT_DEPGD_POC   NUMBER;
	LV_CNT_DEPGD_POC_TGT	NUMBER;
	LV_CNT_DEPGD_PORT  NUMBER;
	LV_CNT_DEPGD_PORT_TGT	NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);
	V_BLKEXPTN_COUNT    NUMBER(20, 0);
	V_BLKEXPTN_DESC     VARCHAR2(3000);
    V_EXP_ROWS          VARCHAR2(4000);


BEGIN
    LV_CNT_DEPGD_TGT:=0;
    LV_CNT_DEPGD_POC_TGT:=0;
    LV_CNT_DEPGD_PORT_TGT:=0;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD
    FROM 
    DEPARTURE_GD_APPLICATION;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD_POC
    FROM 
    departure_gd_purpose_of_call;

	SELECT
    COUNT(*) INTO LV_CNT_DEPGD_PORT
    FROM 
    DEP_GD_P_CLRCE_CERT;



	OPEN CUR_DEPGD;
	PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DDEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD', 'Insertion into target Table DEPARTURE_GD_APPLICATION', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form DEPARTURE_GD_APPLICATION and inseting into target table CVS_INTEGRATION.DEPARTURE_GD_APPLICATION ************------------------        

			FETCH CUR_DEPGD BULK COLLECT INTO LV_DEPGD LIMIT 10000;
            EXIT WHEN LV_DEPGD.count = 0;
			--FORALL i IN LV_ARRGD.first..LV_ARRGD.last SAVE EXCEPTIONS       
			FOR i IN LV_DEPGD.first..LV_DEPGD.last
			LOOP
-------------************ SYN_ARRGD is synonym of CVS_INTEGRATION.DEPARTURE_GD_APPLICATION  ************------------------  
			BEGIN
			INSERT INTO SYN_DEPGD(
									AGT_DECLR_AC_DESC_X	,
                                    AGT_DECLR_AC_N	,
                                    APPLCNT_ID_N	,
                                    APPLN_REF_N	,
                                    APPLN_ST_C	,
                                    ARRIVAL_APPLN_REF_N	,
                                    BUNKR_GR_C	,
                                    BUNKR_Q	,
                                    CGO_Q	,
                                    CHARTERER_NAT_C	,
                                    CHARTERER_NAT_DESC_X	,
                                    CO_M	,
                                    CRT_BY_N	,
                                    CRT_ON_DT	,
                                    CR_Q	,
                                    CST_N	,
                                    DELETED_I	,
                                    DEP_DECLR_DT	,
                                    DEP_LOCN	,
                                    DEP_LOCN_DESC_X	,
                                    EXTL_APPLN_REF_X	,
                                    GDV_N	,
                                    INTL_REM_X	,
                                    LOCK_VER_N	,
                                    LST_UPD_BY_N	,
                                    LST_UPD_ON_DT	,
                                    MDO_I	,
                                    MFO_I	,
                                    MGO_I	,
                                    MOTHER_GDV_N	,
                                    MPA_AC_M	,
                                    MSTR_ON_DEP_X	,
                                    MSW_APPLN_REF_X	,
                                    NX_P_C	,
                                    NX_P_CTRY_C	,
                                    NX_P_CTRY_DESC_X	,
                                    NX_P_DESC_X	,
                                    NX_P_M	,
                                    OFFICIAL_GDV_N	,
                                    PAX_Q	,
                                    PERS_Q	,
                                    PROCESSED_BY_N	,
                                    PROCESSED_ON_DT	,
                                    PROCESSING_REM_X	,
                                    SLN_C	,
                                    SLN_DESC_X	,
                                    VSL_GT_ON_DEP_Q	

									)
							VALUES ('9'	,
                                        LV_DEPGD(i).v_AGT_DECLR_AC_N	,
                                        '9'	,
                                        LV_DEPGD(i).v_APPLN_REF_N	,
                                        LV_DEPGD(i).v_APPLN_ST_C	,
                                        9	,
                                        LV_DEPGD(i).v_BUNKR_GR_C	,
                                        LV_DEPGD(i).v_BUNKR_Q	,
                                        LV_DEPGD(i).v_CGO_Q	,
                                        LV_DEPGD(i).v_CHARTERER_NAT_C	,
                                        '9',
                                        LV_DEPGD(i).v_COMPANY_NAME	,
                                        LV_DEPGD(i).v_CRT_BY_N	,
                                        LV_DEPGD(i).v_CRT_ON_DT	,
                                        LV_DEPGD(i).v_CREW_Q	,
                                        LV_DEPGD(i).v_CST_N	,
                                        LV_DEPGD(i).v_DELETED_I	,
                                        LV_DEPGD(i).v_DEP_DECLR_DT	,
                                        LV_DEPGD(i).v_DEPARTURE_LOCATION	,
                                        '9'	,
                                        LV_DEPGD(i).v_EXTL_APPLN_REF_ID_X	,
                                        LV_DEPGD(i).v_GDV_N	,
                                        LV_DEPGD(i).v_INTL_REM_X	,
                                        LV_DEPGD(i).v_LOCKVER_N	,
                                        LV_DEPGD(i).v_UPT_BY_X	,
                                        LV_DEPGD(i).v_UPT_ON_DT	,
                                        9	,
                                        9	,
                                        9	,
                                        LV_DEPGD(i).v_MOTHER_GDV_N	,
                                        LV_DEPGD(i).v_MPA_ACCOUNT_NAMES	,
                                        LV_DEPGD(i).v_MSTR_ON_DEP_X	,
                                        LV_DEPGD(i).v_MSW_APPLN_REF_ID_X	,
                                        LV_DEPGD(i).v_NX_PORT_C	,
                                        LV_DEPGD(i).v_NX_PORT_CTRY_C	,
                                        '9'	,
                                        '9'	,
                                        LV_DEPGD(i).v_NX_PORT_M	,
                                        '9'	,
                                        LV_DEPGD(i).v_PAX_Q	,
                                        LV_DEPGD(i).v_PERS_Q	,
                                        LV_DEPGD(i).v_PROCESSED_BY_X	,
                                        LV_DEPGD(i).v_PROCESSED_ON_DT	,
                                        LV_DEPGD(i).v_PROCESSING_REM_X	,
                                        LV_DEPGD(i).v_SLN_C	,
                                        '9'	,
                                        LV_DEPGD(i).v_VSL_GT_ON_DEP_Q	
                                        
                                                                            
                                                                            );
            LV_CNT_DEPGD_TGT :=LV_CNT_DEPGD_TGT+1;

			EXCEPTION
				WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

  pkg_datamigration_generic.proc_trace_exception('SYN_DEPGD', 
  
                                                   'PROC_3_PUSH_DEPGD', 
                                                   
                                                'AGT_DECLR_AC_DESC_X:'||	null	||'<{||}>'||
                                                'AGT_DECLR_AC_N:'||LV_DEPGD(i).v_AGT_DECLR_AC_N	||'<{||}>'||
                                                'APPLCNT_ID_N:'|| null	||'<{||}>'||
                                                'APPLN_REF_N:'||LV_DEPGD(i).v_APPLN_REF_N	||'<{||}>'||
                                                'APPLN_ST_C:'||LV_DEPGD(i).v_APPLN_ST_C	||'<{||}>'||
                                                'ARRIVAL_APPLN_REF_N:'|| null	||'<{||}>'||
                                                'BUNKR_GR_C:'||	LV_DEPGD(i).v_BUNKR_GR_C	||'<{||}>'||
                                                'BUNKR_Q:'|| LV_DEPGD(i).v_BUNKR_Q	||'<{||}>'||
                                                'CGO_Q:'||LV_DEPGD(i).v_CGO_Q	||'<{||}>'||
                                                'CHARTERER_NAT_C:'||LV_DEPGD(i).v_CHARTERER_NAT_C	||'<{||}>'||
                                                'CHARTERER_NAT_DESC_X:'||  LV_DEPGD(i).v_COMPANY_NAME	||'<{||}>'||
                                                'CO_M:'|| null	||'<{||}>'||
                                                'CRT_BY_N:'|| LV_DEPGD(i).v_CRT_BY_N	||'<{||}>'||
                                                'CRT_ON_DT:'||LV_DEPGD(i).v_CRT_ON_DT	||'<{||}>'||
                                                'CR_Q:'||LV_DEPGD(i).v_CREW_Q	||'<{||}>'||
                                                'CST_N:'||LV_DEPGD(i).v_CST_N	||'<{||}>'||
                                                'DELETED_I:'|| LV_DEPGD(i).v_DELETED_I	||'<{||}>'||
                                                'DEP_DECLR_DT:'||LV_DEPGD(i).v_DEP_DECLR_DT	||'<{||}>'||
                                                'DEP_LOCN:'||LV_DEPGD(i).v_DEPARTURE_LOCATION	||'<{||}>'||
                                                'DEP_LOCN_DESC_X:'||  null	||'<{||}>'||
                                                'EXTL_APPLN_REF_X:'|| LV_DEPGD(i).v_EXTL_APPLN_REF_ID_X	||'<{||}>'||
                                                'GDV_N:'|| LV_DEPGD(i).v_GDV_N	||'<{||}>'||
                                                'INTL_REM_X	:'|| LV_DEPGD(i).v_INTL_REM_X	||'<{||}>'||
                                                'LOCK_VER_N	:'|| LV_DEPGD(i).v_LOCKVER_N	||'<{||}>'||
                                                'LST_UPD_BY_N:'|| LV_DEPGD(i).v_UPT_BY_X	||'<{||}>'||
                                                'LST_UPD_ON_DT:'||  LV_DEPGD(i).v_UPT_ON_DT	||'<{||}>'||
                                                'MDO_I:'||	 null	||'<{||}>'||
                                                'MFO_I:'||	 null	||'<{||}>'||
                                                'MGO_I:'||  null	||'<{||}>'||
                                                'MOTHER_GDV_N:'||LV_DEPGD(i).v_MOTHER_GDV_N	||'<{||}>'||
                                                'MPA_AC_M:'|| LV_DEPGD(i).v_MPA_ACCOUNT_NAMES	||'<{||}>'||
                                                'MSTR_ON_DEP_X:'|| LV_DEPGD(i).v_MSTR_ON_DEP_X	||'<{||}>'||
                                                'MSW_APPLN_REF_X:'||LV_DEPGD(i).v_MSW_APPLN_REF_ID_X	||'<{||}>'||
                                                'NX_P_C:'||	 LV_DEPGD(i).v_NX_PORT_C	||'<{||}>'||
                                                'NX_P_CTRY_C:'|| LV_DEPGD(i).v_NX_PORT_CTRY_C	||'<{||}>'||
                                                'NX_P_CTRY_DESC_X:'||  null	||'<{||}>'||
                                                'NX_P_DESC_X:'||  null	||'<{||}>'||
                                                'NX_P_M	:'|| LV_DEPGD(i).v_NX_PORT_M	||'<{||}>'||
                                                'OFFICIAL_GDV_N	:'|| null	||'<{||}>'||
                                                'PAX_Q:'||  LV_DEPGD(i).v_PAX_Q	||'<{||}>'||
                                                'PERS_Q	:'||LV_DEPGD(i).v_PERS_Q	||'<{||}>'||
                                                'PROCESSED_BY_N	:'|| LV_DEPGD(i).v_PROCESSED_BY_X	||'<{||}>'||
                                                'PROCESSED_ON_DT:'|| LV_DEPGD(i).v_PROCESSED_ON_DT	||'<{||}>'||
                                                'PROCESSING_REM_X:'|| LV_DEPGD(i).v_PROCESSING_REM_X	||'<{||}>'||
                                                'SLN_C:'||LV_DEPGD(i).v_SLN_C	||'<{||}>'||
                                                'SLN_DESC_X	:'||  null	||'<{||}>'||
                                                'VSL_GT_ON_DEP_Q:'||  LV_DEPGD(i).v_VSL_GT_ON_DEP_Q	 ,


							                                'ERROR',

						                                  	null,

							                                V_SQLERRM,
                
                                       null	||'<{||}>'||
                                        LV_DEPGD(i).v_AGT_DECLR_AC_N	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_APPLN_REF_N	||'<{||}>'||
                                        LV_DEPGD(i).v_APPLN_ST_C	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_BUNKR_GR_C	||'<{||}>'||
                                        LV_DEPGD(i).v_BUNKR_Q	||'<{||}>'||
                                        LV_DEPGD(i).v_CGO_Q	||'<{||}>'||
                                        LV_DEPGD(i).v_CHARTERER_NAT_C	||'<{||}>'||
                                        LV_DEPGD(i).v_COMPANY_NAME	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_CRT_BY_N	||'<{||}>'||
                                        LV_DEPGD(i).v_CRT_ON_DT	||'<{||}>'||
                                        LV_DEPGD(i).v_CREW_Q	||'<{||}>'||
                                        LV_DEPGD(i).v_CST_N	||'<{||}>'||
                                        LV_DEPGD(i).v_DELETED_I	||'<{||}>'||
                                        LV_DEPGD(i).v_DEP_DECLR_DT	||'<{||}>'||
                                        LV_DEPGD(i).v_DEPARTURE_LOCATION	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_EXTL_APPLN_REF_ID_X	||'<{||}>'||
                                        LV_DEPGD(i).v_GDV_N	||'<{||}>'||
                                        LV_DEPGD(i).v_INTL_REM_X	||'<{||}>'||
                                        LV_DEPGD(i).v_LOCKVER_N	||'<{||}>'||
                                        LV_DEPGD(i).v_UPT_BY_X	||'<{||}>'||
                                        LV_DEPGD(i).v_UPT_ON_DT	||'<{||}>'||
                                        null	||'<{||}>'||
                                        null	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_MOTHER_GDV_N	||'<{||}>'||
                                        LV_DEPGD(i).v_MPA_ACCOUNT_NAMES	||'<{||}>'||
                                        LV_DEPGD(i).v_MSTR_ON_DEP_X	||'<{||}>'||
                                        LV_DEPGD(i).v_MSW_APPLN_REF_ID_X	||'<{||}>'||
                                        LV_DEPGD(i).v_NX_PORT_C	||'<{||}>'||
                                        LV_DEPGD(i).v_NX_PORT_CTRY_C	||'<{||}>'||
                                        null	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_NX_PORT_M	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_PAX_Q	||'<{||}>'||
                                        LV_DEPGD(i).v_PERS_Q	||'<{||}>'||
                                        LV_DEPGD(i).v_PROCESSED_BY_X	||'<{||}>'||
                                        LV_DEPGD(i).v_PROCESSED_ON_DT	||'<{||}>'||
                                        LV_DEPGD(i).v_PROCESSING_REM_X	||'<{||}>'||
                                        LV_DEPGD(i).v_SLN_C	||'<{||}>'||
                                        null	||'<{||}>'||
                                        LV_DEPGD(i).v_VSL_GT_ON_DEP_Q	
,

							                                'T'
                                                            );

			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEPGD;	

    /*
	 SELECT     COUNT(*)
     INTO LV_CNT_TT_AGD
     FROM
     SYN_ARRGD;
    */

	IF( LV_CNT_DEPGD =  LV_CNT_DEPGD_TGT ) AND LV_CNT_DEPGD <>  0  AND  LV_CNT_DEPGD_TGT <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD  <> LV_CNT_DEPGD_TGT AND  LV_CNT_DEPGD <> 0 AND  LV_CNT_DEPGD_TGT <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD  <> 0 AND  LV_CNT_DEPGD_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_TGT||' OUT OF ' || LV_CNT_DEPGD ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEPARTURE_GD_APPLICATION' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   



    pkg_datamigration_generic.proc_migration_recon('DEPARTURE_GD_APPLICATION', LV_CNT_DEPGD, 'SYN_DEPGD', LV_CNT_DEPGD_TGT,'Y');




	/***********************************************************************************************************
	Pushing records into CVS_INTEGRATION.DEP_GD_PURP_OF_CALL
    ***********************************************************************************************************/


	OPEN CUR_DEP_POC;

	pkg_datamigration_generic.proc_trace_exception('DEPGD_POC', 'PROC_3_PUSH_DEPGD', 'Insertion into SYN_DEPGD_POC', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form ARR_GD_PURP_OF_CALL and inseting into target table CVS_INTEGRATION.DEP_GD_PURP_OF_CALL ************------------------        

			FETCH CUR_DEP_POC BULK COLLECT INTO LV_DEPGD_POC LIMIT 10000;
       
            EXIT WHEN LV_DEPGD_POC.count = 0;
              

			--FORALL i IN LV_ARRGD_POC.first..LV_ARRGD_POC.last SAVE EXCEPTIONS  
			FOR i IN LV_DEPGD_POC.first..LV_DEPGD_POC.last
			LOOP
-------------************ SYN_ARRGD_POC is synonym of CVS_INTEGRATION.DEP_GD_PURP_OF_CALL  ************------------------  
			BEGIN
                   

            
      
			INSERT INTO SYN_DEPGD_POC
									(
									APPLN_REF_N	,
                                    DELETED_I	,
                                    ID	,
                                    LOCK_VER_N	,
                                    OTHERS_PURP_X	,
                                    OTHER_AFLOAT_ACT	,
                                    PURPCALL_C	,
                                    PURPCALL_OTHERS_TOW_VSL_M	,
                                    PURPCALL_OTHERS_UND_TOW_VSL_M	,
                                    PURP_CALL_OTHERS_TOW_X	

									)
							VALUES (
									LV_DEPGD_POC(i).v_APPLN_REF_N,	
                                    LV_DEPGD_POC(i).v_DELETED_I,	
                                    LV_DEPGD_POC(i).v_DEP_GD_PURP_OF_CALL_ID_N,	
                                    LV_DEPGD_POC(i).v_LOCK_VER_N,	
                                    LV_DEPGD_POC(i).v_OTHERS_PURPOSE_X,	
                                    	'9'	,
                                    LV_DEPGD_POC(i).v_PURPCALL_C,	
                                    LV_DEPGD_POC(i).v_PURPCALL_OTHERS_TOW_VSL_M,	
                                    '9',	
                                    LV_DEPGD_POC(i).v_PURP_CALL_OTHERS_TOW_X
                                                                            
									);
                    LV_CNT_DEPGD_POC_TGT := LV_CNT_DEPGD_POC_TGT+1;
                    

			EXCEPTION
			WHEN OTHERS THEN
         
            V_ERR_CODE := SQLCODE;
            
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

  pkg_datamigration_generic.proc_trace_exception('SYN_DEPGD_POC', 
  
                                                   'PROC_3_PUSH_DEPGD', 
                                                   
                                                     'APPLN_REF_N:'||LV_DEPGD_POC(i).v_APPLN_REF_N	||'<{||}>'||
                                                    'DELETED_I:'|| LV_DEPGD_POC(i).v_DELETED_I	||'<{||}>'||
                                                    'ID:'||LV_DEPGD_POC(i).v_DEP_GD_PURP_OF_CALL_ID_N	||'<{||}>'||
                                                    'LOCK_VER_N:'|| LV_DEPGD_POC(i).v_LOCK_VER_N	||'<{||}>'||
                                                    'OTHERS_PURP_X:'|| LV_DEPGD_POC(i).v_OTHERS_PURPOSE_X	||'<{||}>'||
                                                    'OTHER_AFLOAT_ACT:'||null||'<{||}>'||
                                                    'PURPCALL_C:'||LV_DEPGD_POC(i).v_PURPCALL_C	||'<{||}>'||
                                                    'PURPCALL_OTHERS_TOW_VSL_M:'|| LV_DEPGD_POC(i).v_PURPCALL_OTHERS_TOW_VSL_M	||'<{||}>'||
                                                    'PURPCALL_OTHERS_UND_TOW_VSL_M:'||null	||'<{||}>'||
                                                    'PURP_CALL_OTHERS_TOW_X:'||	 LV_DEPGD_POC(i).v_PURP_CALL_OTHERS_TOW_X,


							                                'ERROR',

						                                  	null,

							                                V_SQLERRM,
                
                                                    LV_DEPGD_POC(i).v_APPLN_REF_N	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_DELETED_I	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_DEP_GD_PURP_OF_CALL_ID_N	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_LOCK_VER_N	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_OTHERS_PURPOSE_X	||'<{||}>'||
                                                     null	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_PURPCALL_C	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_PURPCALL_OTHERS_TOW_VSL_M	||'<{||}>'||
                                                    null	||'<{||}>'||
                                                    LV_DEPGD_POC(i).v_PURP_CALL_OTHERS_TOW_X,

							                                'T'
                                                            );


			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEP_POC;

	IF( LV_CNT_DEPGD_POC =  LV_CNT_DEPGD_POC_TGT ) AND LV_CNT_DEPGD_POC_TGT <>  0  AND  LV_CNT_DEPGD_POC <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD_POC  <> LV_CNT_DEPGD_POC_TGT AND  LV_CNT_DEPGD_POC_TGT <> 0 AND  LV_CNT_DEPGD_POC <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD_POC  <> 0 AND  LV_CNT_DEPGD_POC_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_POC', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_POC_TGT||' OUT OF ' || LV_CNT_DEPGD_POC ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION.DEP_GD_PURP_OF_CALL' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEP_GD_POC', LV_CNT_DEPGD_POC, 'SYN_DEPGD_POC', LV_CNT_DEPGD_POC_TGT,'Y');


	/***********************************************************************************************************
	Pushing records into CVS_INTEGRATION.DEP_GD_PURP_OF_CALL
    ***********************************************************************************************************/

dbms_output.put_line(100);
	OPEN CUR_DEP_GD_PORT;
    dbms_output.put_line(200);

	pkg_datamigration_generic.proc_trace_exception('DEP_GD_PORT', 'PROC_3_PUSH_DEPGD', 'Insertion into target Table SYN_DEP_GD_P_CRT', 'START',NULL,NULL,NULL,NULL);
    dbms_output.put_line(300);
	LOOP
    -------------************ Fetching records form ARR_GD_PURP_OF_CALL_SYARD_LOC and inserting into target table CVS_INTEGRATION.DEP_GD_PURP_OF_CALL_SYARD_LOC ************------------------        
    dbms_output.put_line(400);
			FETCH CUR_DEP_GD_PORT BULK COLLECT INTO LV_DEPGD_PORT LIMIT 10000;
                dbms_output.put_line(500);
            EXIT WHEN LV_DEPGD_PORT.count = 0;
			--FORALL i IN LV_ARRGD_POC_SYL.first..LV_ARRGD_POC_SYL.last SAVE EXCEPTIONS
			FOR i IN LV_DEPGD_PORT.first..LV_DEPGD_PORT.last
			LOOP
-------------************ SYN_ARRGD_POC_SYL is synonym of CVS_INTEGRATION.DEP_GD_P_CRT  ************------------------  
			BEGIN

    dbms_output.put_line(600);
			INSERT INTO SYN_DEP_GD_P_CRT
									(															
									APPLN_REF_N	,
                                    CGO_Q	,
                                    CRT_BY_N	,
                                    CRT_ON_DT	,
                                    DELETED_I	,
                                    DEPDECLR_DT	,
                                    DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
                                    DOC_ID_ATTH_N	,
                                    GDV_N	,
                                    LOCK_VER_N	,
                                    LST_UPD_BY_N	,
                                    LST_UPD_ON_DT	,
                                    MSTRONDEP_X	,
                                    MSW_DOC_ID_N	,
                                    NX_CTRY_M	,
                                    NX_P_M	,
                                    OFFICIAL_GDV_N	,
                                    ORG_C	,
                                    PCCSEQ_N	,
                                    PCC_CANCL_DT	,
                                    PCC_DOC_M	,
                                    PCC_DOC_PATH_X	,
                                    PCC_EXPY_DT	,
                                    PCC_I	,
                                    PCC_ISSD_BY_M	,
                                    PCC_ISS_DT	,
                                    PCC_LATE_CANCL_I	,
                                    PCC_N	,
                                    PCC_PRNT_I	,
                                    PCC_ST_C	,
                                    VSLCALLSIGN_N	,
                                    VSLFLAG_M	,
                                    VSLGT_Q	,
                                    VSLIMO_N	,
                                    VSLMMSI_N	,
                                    VSL_M	
                                    
									)
							VALUES (									
									LV_DEPGD_PORT(I).v_APPLN_REF_N	,
                                    LV_DEPGD_PORT(I).v_CGO_Q	,
                                    LV_DEPGD_PORT(I).v_CRT_BY_N	,
                                    LV_DEPGD_PORT(I).v_CRT_ON_DT	,
                                    LV_DEPGD_PORT(I).v_DELETED_I	,
                                    LV_DEPGD_PORT(I).v_DEPDECLR_DT	,
                                    LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	,
                                    LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	,
                                    LV_DEPGD_PORT(I).v_GDV_N	,
                                    LV_DEPGD_PORT(I).v_LOCK_VER_N	,
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	,
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	,
                                    LV_DEPGD_PORT(I).v_MSTRONDEP_X	,
                                    LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	,
                                    LV_DEPGD_PORT(I).v_NXCTRY_M	,
                                    LV_DEPGD_PORT(I).v_NXPORT_M	,
                                    LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	,
                                    LV_DEPGD_PORT(I).v_ORG_C	,
                                    LV_DEPGD_PORT(I).v_PCCSEQ_N	,
                                    LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	,
                                                    '9'	,
                                                    '9'	,
                                    LV_DEPGD_PORT(I).v_PCC_EXPY_DT	,
                                    LV_DEPGD_PORT(I).v_PCC_I	,
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	,
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_DT	,
                                    LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	,
                                    LV_DEPGD_PORT(I).v_PCC_N	,
                                   LV_DEPGD_PORT(I).v_PCC_PRNT_I,	
                                    LV_DEPGD_PORT(I).v_PCC_ST_C	,
                                    LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	,
                                    LV_DEPGD_PORT(I).v_VSLFLAG_M	,
                                    LV_DEPGD_PORT(I).v_VSLGT_Q	,
                                    LV_DEPGD_PORT(I).v_VSLIMO_N	,
                                    LV_DEPGD_PORT(I).v_VSLMMSI_N	,
                                    LV_DEPGD_PORT(I).v_VSL_M	
                                    );
                                    
            LV_CNT_DEPGD_PORT_TGT :=LV_CNT_DEPGD_PORT_TGT+1;

			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;

           pkg_datamigration_generic.proc_trace_exception('SYN_DEP_GD_P_CRT', 
                                                            'PROC_3_PUSH_DEPGD', 

                                    'APPLN_REF_N:'||LV_DEPGD_PORT(I).v_APPLN_REF_N	||'<{||}>'||
                                    'CGO_Q:'||LV_DEPGD_PORT(I).v_CGO_Q	||'<{||}>'||
                                    'CRT_BY_N:'|| LV_DEPGD_PORT(I).v_CRT_BY_N	||'<{||}>'||
                                    'CRT_ON_DT:'|| LV_DEPGD_PORT(I).v_CRT_ON_DT	||'<{||}>'||
                                    'DELETED_I:'||LV_DEPGD_PORT(I).v_DELETED_I	||'<{||}>'||
                                    'DEPDECLR_DT:'||LV_DEPGD_PORT(I).v_DEPDECLR_DT	||'<{||}>'||
                                    'DEP_GD_PORT_CLEARENCE_CERT_ID_N:'|| LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	||'<{||}>'||
                                    'DOC_ID_ATTH_N:'|| LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	||'<{||}>'||
                                    'GDV_N:'||LV_DEPGD_PORT(I).v_GDV_N	||'<{||}>'||
                                    'LOCK_VER_N:'|| LV_DEPGD_PORT(I).v_LOCK_VER_N	||'<{||}>'||
                                    'LST_UPD_BY_N:'||LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	||'<{||}>'||
                                    'LST_UPD_ON_DT:'||LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	||'<{||}>'||
                                    'MSTRONDEP_X:'||LV_DEPGD_PORT(I).v_MSTRONDEP_X	||'<{||}>'||
                                    'MSW_DOC_ID_N:'||LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	||'<{||}>'||
                                    'NX_CTRY_M:'|| LV_DEPGD_PORT(I).v_NXCTRY_M	||'<{||}>'||
                                    'NX_P_M:'||LV_DEPGD_PORT(I).v_NXPORT_M	||'<{||}>'||
                                    'OFFICIAL_GDV_N:'||LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	||'<{||}>'||
                                    'ORG_C:'||LV_DEPGD_PORT(I).v_ORG_C	||'<{||}>'||
                                    'PCCSEQ_N:'|| LV_DEPGD_PORT(I).v_PCCSEQ_N	||'<{||}>'||
                                    'PCC_CANCL_DT:'||LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	||'<{||}>'||
                                    'PCC_DOC_M:'||  'not null'	||'<{||}>'||
                                    'PCC_DOC_PATH_X:'||  null	||'<{||}>'||
                                    'PCC_EXPY_DT:'|| LV_DEPGD_PORT(I).v_PCC_EXPY_DT	||'<{||}>'||
                                    'PCC_I:'|| LV_DEPGD_PORT(I).v_PCC_I	||'<{||}>'||
                                    'PCC_ISSD_BY_M:'|| LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	||'<{||}>'||
                                    'PCC_ISS_DT:'|| LV_DEPGD_PORT(I).v_PCC_ISSD_DT	||'<{||}>'||
                                    'PCC_LATE_CANCL_I:'|| LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	||'<{||}>'||
                                    'PCC_N:'|| LV_DEPGD_PORT(I).v_PCC_N	||'<{||}>'||
                                    'PCC_PRNT_I:'||LV_DEPGD_PORT(I).v_PCC_PRNT_I	||'<{||}>'||
                                    'PCC_ST_C:'|| LV_DEPGD_PORT(I).v_PCC_ST_C	||'<{||}>'||
                                    'VSLCALLSIGN_N:'||LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	||'<{||}>'||
                                    'VSLFLAG_M:'|| LV_DEPGD_PORT(I).v_VSLFLAG_M	||'<{||}>'||
                                    'VSLGT_Q:'|| LV_DEPGD_PORT(I).v_VSLGT_Q	||'<{||}>'||
                                    'VSLIMO_N:'|| LV_DEPGD_PORT(I).v_VSLIMO_N	||'<{||}>'||
                                    'VSLMMSI_N:'||LV_DEPGD_PORT(I).v_VSLMMSI_N	||'<{||}>'||
                                    'VSL_M:'||LV_DEPGD_PORT(I).v_VSL_M	 ,

							                                'ERROR',

						                                  	null,

							                                V_SQLERRM,

                                                     LV_DEPGD_PORT(I).v_APPLN_REF_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CGO_Q	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CRT_BY_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_CRT_ON_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DELETED_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DEPDECLR_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DEP_GD_PORT_CLEARENCE_CERT_ID_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_DOC_ID_ATTH_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_GDV_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LOCK_VER_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_BY_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_LAST_UPDATED_ON_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_MSTRONDEP_X	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_MSW_DOC_ID_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_NXCTRY_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_NXPORT_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_OFFICIAL_GDV_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_ORG_C	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCCSEQ_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_CANCEL_DT	||'<{||}>'||
                                                    'not null'	||'<{||}>'||
                                                    null	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_EXPY_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_BY_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ISSD_DT	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_LATE_CANCL_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_PRNT_I	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_PCC_ST_C	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLCALLSIGN_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLFLAG_M	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLGT_Q	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLIMO_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSLMMSI_N	||'<{||}>'||
                                    LV_DEPGD_PORT(I).v_VSL_M	
,


							                                'T'
                                                            );

			END;

			END LOOP;


    END LOOP;
	CLOSE CUR_DEP_GD_PORT;

	IF( LV_CNT_DEPGD_PORT_TGT =  LV_CNT_DEPGD_PORT) AND LV_CNT_DEPGD_PORT<>  0  AND  LV_CNT_DEPGD_PORT_TGT <> 0 THEN     

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DEPGD_PORT <> LV_CNT_DEPGD_PORT_TGT AND  LV_CNT_DEPGD_PORT<> 0 AND  LV_CNT_DEPGD_PORT_TGT <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DEPGD_PORT <> 0 AND  LV_CNT_DEPGD_PORT_TGT = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEP_GD_P_CLRCE_CERT', 'PROC_3_PUSH_DEPGD',
        LV_CNT_DEPGD_PORT_TGT||' OUT OF ' || LV_CNT_DEPGD_PORT ||' ROWS  HAVE BEEN INSERTED INTO CVS_INTEGRATION"."DEP_GD_P_CLRCE_CERT' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;   

    COMMIT;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('DEP_GD_P_CLRCE_CERT', LV_CNT_DEPGD_PORT, 'SYN_DEP_GD_P_CRT', LV_CNT_DEPGD_PORT_TGT,'Y');



	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_ARRIVAL_GD', 'PROC_3_PUSH_DEPGD', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_3_PUSH_DEPGD;
/