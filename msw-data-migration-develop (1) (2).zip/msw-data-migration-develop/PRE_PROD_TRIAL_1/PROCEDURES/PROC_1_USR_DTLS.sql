create or replace PROCEDURE PROC_1_USR_DTLS ( PV_RUN_ID IN   NUMBER) IS

    LV_CNT_ST         NUMBER;
    LV_CNT_SI         NUMBER;
    LV_CNT_TAR        NUMBER;
    V_ERR_CODE        VARCHAR2(1000);
    V_ERR_MSG         VARCHAR2(1000);
    V_SQLERRM         VARCHAR2(1000);
    V_EXP_ROWS_SI     VARCHAR2(4000);
    V_EXP_ROWS_APPL   VARCHAR2(4000);
    V_EXP_ROWS_DOC    VARCHAR2(4000);
   -- LV_SI_PUID_N                NUMBER ;

   /***********************************************************************************************************
   PROCEDURE NAME : PROC_1_USR_DTLS
   CREATED BY     : SOURANGSHU DHAR
   DATE           : 04-JUL-2019
   PURPOSE        : TO INSERT DATA FROM SOURCE STAGING TABLE TO INTERMIDIATE TABLE
   MODIFIED BY    :ROHIT KHOOL
   MODIFIED DATE  :10-SEP-2019

   **************************** CURSOR FOR FETCHING DATA FROM THE SOURCE STAGING TABLE ********************************************/
    CURSOR CR_SI_USR_DTLS IS
    SELECT
        B.PUID_N   ORG_PUID_N,
        C.PUID_N   INDV_PUID_N,
        A.ST_C,
        C.INDV_M,
        C.ID_N,
        C.IDTY_C,
        B.UEN_N,
        E.EMAILADDR_X,
        C.CRTON_DT,
        C.CRTBY_M,
        C.UPDON_DT,
        C.UPDBY_M
    FROM
        ST_PU_PROFILE A,
        ST_PU_USRORG B,
        ST_PU_USRINDV C,
        ST_PU_PROFILECONTACTMAPPER D,
        ST_PU_USRCONTACT E
    WHERE
        A.PUID_N = B.PUID_N (+)
        AND A.PUID_N = C.PUID_N (+)
        AND A.PUID_N = D.PUID_N (+)
        AND D.CONTACTID_N = E.CONTACTID_N
        AND E.CRTON_DT =(SELECT MAX(CRTON_DT) FROM ST_PU_USRCONTACT WHERE CONTACTID_N = D.CONTACTID_N);
------------------*************** CURSOR FOR FETCHING DATA FROM THE INTERMIDIATE TABLE *****------------------------
    CURSOR CR_USR_DTLS IS
    SELECT
        PUID_N,
        ST_C,
        INDV_M,
        INDVID_N,
        IDTY_C,
        UEN_N,
        EMAILADDR_X,
        CRTON_DT,
        CRTBY_M,
        UPDON_DT,
        UPDBY_M
    FROM
        SI_USR_DTLS;

---------------------***************** DECLARING TYPES ****************----------------------------

    TYPE REC_SI_USR_DTLS IS RECORD (
        ORG_PUID_N_R      ST_PU_USRORG.PUID_N%TYPE,
        INDV_PUID_N_R     ST_PU_USRINDV.PUID_N%TYPE,
        ST_C_R            ST_PU_PROFILE.ST_C%TYPE,
        INDV_M_R          ST_PU_USRINDV.INDV_M%TYPE,
        ID_N_R            ST_PU_USRINDV.ID_N%TYPE,
        IDTY_C_R          ST_PU_USRINDV.IDTY_C%TYPE,
        UEN_N_R           ST_PU_USRORG.UEN_N%TYPE,
        EMAILADDR_X_R     ST_PU_USRCONTACT.EMAILADDR_X%TYPE,
        CRTON_DT_R        ST_PU_USRINDV.CRTON_DT%TYPE,
        CRTBY_M_R         ST_PU_USRINDV.CRTBY_M%TYPE,
        UPDON_DT_R        ST_PU_USRINDV.UPDON_DT%TYPE,
        UPDBY_M_R         ST_PU_USRINDV.UPDBY_M%TYPE
    );
    TYPE TYP_SI_USR_DTLS IS
    TABLE OF REC_SI_USR_DTLS INDEX BY PLS_INTEGER;

    LV_SI_USR_DTLS    TYP_SI_USR_DTLS;

    TYPE REC_USR_DTLS IS RECORD (
        PUID_N_R          SI_USR_DTLS.PUID_N%TYPE,
        ST_C_R            SI_USR_DTLS.ST_C%TYPE,
        INDV_M_R          SI_USR_DTLS.INDV_M%TYPE,
        INDVID_N_R        SI_USR_DTLS.INDVID_N%TYPE,
        IDTY_C_R          SI_USR_DTLS.IDTY_C%TYPE,
        UEN_N_R           SI_USR_DTLS.UEN_N%TYPE,
        EMAILADDR_X_R     SI_USR_DTLS.EMAILADDR_X%TYPE,
        CRTON_DT_R        SI_USR_DTLS.CRTON_DT%TYPE,
        CRTBY_M_R         SI_USR_DTLS.CRTBY_M%TYPE,
        UPDON_DT_R        SI_USR_DTLS.UPDON_DT%TYPE,
        UPDBY_M_R         SI_USR_DTLS.UPDBY_M%TYPE
    );
    TYPE TYP_USR_DTLS IS
    TABLE OF REC_USR_DTLS INDEX BY PLS_INTEGER;

    LV_USR_DTLS       TYP_USR_DTLS;

BEGIN

    SELECT
    COUNT(*)
    INTO LV_CNT_ST
    FROM
        ST_PU_PROFILE;    ---- DRIVING TABLE COUNT 

    OPEN CR_SI_USR_DTLS;
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE SI_USR_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP
-------************ BULK COLLECT FOR INSERTING DATA INTO INTERMIDIATE  TABLE ***********************---------------
        FETCH CR_SI_USR_DTLS BULK COLLECT INTO LV_SI_USR_DTLS LIMIT 10000;
        EXIT WHEN LV_SI_USR_DTLS.COUNT = 0;

        FOR I IN LV_SI_USR_DTLS.FIRST..LV_SI_USR_DTLS.LAST LOOP

        BEGIN
                INSERT INTO SI_USR_DTLS (
                    PUID_N,
                    ST_C,
                    INDV_M,
                    INDVID_N,
                    IDTY_C,
                    UEN_N,
                    EMAILADDR_X,
                    CRTON_DT,
                    CRTBY_M,
                    UPDON_DT,
                    UPDBY_M
                ) VALUES (
                    NVL(LV_SI_USR_DTLS(I).ORG_PUID_N_R, LV_SI_USR_DTLS(I).INDV_PUID_N_R),
                    LV_SI_USR_DTLS(I).ST_C_R,
                    LV_SI_USR_DTLS(I).INDV_M_R,
                    LV_SI_USR_DTLS(I).ID_N_R,
                    LV_SI_USR_DTLS(I).IDTY_C_R,
                    LV_SI_USR_DTLS(I).UEN_N_R,
                    LV_SI_USR_DTLS(I).EMAILADDR_X_R,
                    LV_SI_USR_DTLS(I).CRTON_DT_R,
                    LV_SI_USR_DTLS(I).CRTBY_M_R,
                    LV_SI_USR_DTLS(I).UPDON_DT_R,
                    LV_SI_USR_DTLS(I).UPDBY_M_R
                );

        EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_SI_USR_DTLS(I).ORG_PUID_N_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).INDV_PUID_N_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).ID_N_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).IDTY_C_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).UEN_N_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).EMAILADDR_X_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).CRTON_DT_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).CRTBY_M_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).UPDON_DT_R
                                     || '<{||}>'
                                     || LV_SI_USR_DTLS(I).UPDBY_M_R;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

        END;
        END LOOP;
        COMMIT;
    END LOOP;



    SELECT  COUNT(*)
    INTO LV_CNT_SI
    FROM SI_USR_DTLS;   ---- INTERMIDATE TABLE COUNT 

    IF ( LV_CNT_SI = LV_CNT_ST ) AND LV_CNT_ST <> 0 AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_SI <> LV_CNT_ST AND LV_CNT_SI <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_SI <> LV_CNT_ST OR LV_CNT_SI = LV_CNT_ST ) AND ( LV_CNT_SI = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_SI
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_ST
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PROFILE', LV_CNT_ST, 'SI_USR_DTLS', LV_CNT_SI, 'N');

    OPEN CR_USR_DTLS;

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', 'INSERTION INTO TABLE USR_DTLS', 'START', PV_RUN_ID, NULL, NULL, 'T');

    LOOP

------------************ BULK COLLECT FOR INSERTING DATA INTO TARGET TABLE ***********************---------------
        FETCH CR_USR_DTLS BULK COLLECT INTO LV_USR_DTLS LIMIT 10000;
        EXIT WHEN LV_USR_DTLS.COUNT = 0;

        FOR J IN LV_USR_DTLS.FIRST..LV_USR_DTLS.LAST LOOP
            BEGIN
                INSERT INTO USR_DTLS (
                    ID,
                    ST_C,
                    PUID_N,
                    INDV_M,
                    INDV_N,
                    ID_TY_C,
                    UEN_N,
                    EMAIL_ADDR_X,
                    DELETED_I,
                    LOCK_VERSION,
                    CREATED_ON,
                    CREATED_BY,
                    LAST_UPDATED_ON,
                    LAST_UPDATED_BY
                ) VALUES (
                    SEQ_USR_SERV_ID.NEXTVAL,
                    DECODE(LV_USR_DTLS(J).ST_C_R, 'A', 'ACTIVE', 'SUSPENDED'),
                    LV_USR_DTLS(J).PUID_N_R,
                    LV_USR_DTLS(J).INDV_M_R,
                    LV_USR_DTLS(J).INDVID_N_R,
                    LV_USR_DTLS(J).IDTY_C_R,
                    LV_USR_DTLS(J).UEN_N_R,
                    LV_USR_DTLS(J).EMAILADDR_X_R,
                    0,
                    0,
                    LV_USR_DTLS(J).CRTON_DT_R,
                    LV_USR_DTLS(J).CRTBY_M_R,
                    LV_USR_DTLS(J).UPDON_DT_R,
                    LV_USR_DTLS(J).UPDBY_M_R
                );

            EXCEPTION
                WHEN OTHERS THEN
                    V_ERR_CODE := SQLCODE;
                    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
                    V_SQLERRM := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                                 || V_ERR_CODE
                                 || V_ERR_MSG
                                 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                    V_EXP_ROWS_SI := LV_USR_DTLS(J).PUID_N_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).INDV_M_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).INDVID_N_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).IDTY_C_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).UEN_N_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).EMAILADDR_X_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).CRTON_DT_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).CRTBY_M_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).UPDON_DT_R
                                     || '<{||}>'
                                     || LV_USR_DTLS(J).UPDBY_M_R;

                    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', V_SQLERRM, 'ERROR', PV_RUN_ID

                    , SQLERRM, V_EXP_ROWS_SI, 'T');

            END;
        END LOOP;
        COMMIT;
    END LOOP;



    SELECT
    COUNT(*)
    INTO LV_CNT_TAR
    FROM USR_DTLS;  ---- TARGET TABLE COUNT 

    IF ( LV_CNT_TAR = LV_CNT_SI ) AND LV_CNT_SI <> 0 AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'SUCCESS'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF LV_CNT_TAR <> LV_CNT_SI AND LV_CNT_TAR <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'PARTIALLY SUCCESSFULL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    ELSIF ( LV_CNT_TAR <> LV_CNT_SI OR LV_CNT_TAR = LV_CNT_SI ) AND ( LV_CNT_TAR = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USER_SERVICE', 'PROC_1_USR_DTLS', LV_CNT_TAR
                                                                                          || ' OUT OF '
                                                                                          || LV_CNT_SI
                                                                                          || ' RECORDS LOADED SUCCESSFULLY', 'FAIL'
                                                                                          , PV_RUN_ID, NULL, NULL, 'T');
    END IF;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_USR_DTLS', LV_CNT_SI, 'USR_DTLS', LV_CNT_TAR, 'N');
    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_PU_PROFILE', LV_CNT_ST, 'USR_DTLS', LV_CNT_TAR, 'Y');

EXCEPTION      
WHEN OTHERS THEN 
V_ERR_CODE := SQLCODE;
V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('USR_DTL', 'PROC_1_USR_DTLS', V_SQLERRM, 'FAIL',NULL,NULL,NULL,'T');

END PROC_1_USR_DTLS;