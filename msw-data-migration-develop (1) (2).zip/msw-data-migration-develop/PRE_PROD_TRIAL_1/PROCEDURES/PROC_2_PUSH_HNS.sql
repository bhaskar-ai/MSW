create or replace PROCEDURE PROC_2_PUSH_HNS  IS

/***********************************************************************************************************
procedure name : PROC_2_PUSH_HNS
Created By     : Rohit Khool
Date           : 02-Jul-2019
Modified date  : 22-Jul-2019
Purpose        : To push master table records from MSW_DATA_MIGRATION schema to respective target schemas HNS_SERVICE.
Modified by    :
Modified date  :
*************************************************************************************************************/
---**** cursor for fetching data from target  Table ****
    CURSOR CR_HNS_APL IS
    SELECT
        HA.APPLN_REF_N,
		HA.MSW_APPLN_REF_ID_X,
		HA.VSL_CALL_ID_N,
		HA.EXTL_APPLN_REF_ID_X,
		HA.MSW_VSL_ID_N,
		HA.VOY_N_X,
		HA.ETA_DT,
		HA.ETD_DT,
		HA.APPLCNT_ID_X,
		HA.CONT_PERS_M,
		HA.CO_M,
		HA.SUBR_EMAIL_I,
		HA.EMAIL_X,
		HA.SUBR_SMS_I,
		HA.MOBILE_N,
		HA.LST_PORT_CTRY_X,
		HA.LAST_PORT_C,
		HA.CFT_LIC_N,
		HA.CGO_TY_C,
		HA.APPLN_ST_C,
		HA.PROCESSED_BY_X,
		HA.PROCESSED_ON_DT,
		HA.PROCESSING_REM_X,
		HA.DELETED_I,
		HA.LOCK_VER_N,
		HA.CRT_ON_DT,
		HA.CRT_BY_X,
		HA.UPT_ON_DT,
		HA.UPT_BY_X,
		HA.INFRNGMNT_C,
		HA.INFRNGMNT_ACTN_X,
		HA.INFRNGMNT_USR_M,
		HA.INFRNGMNT_PROCESS_DT,
		HA.INFRNGMNT_PROCESS_RSN_X,
		HA.INFRNGMNT_RPT_N

    FROM
        HNS_APPLICATION HA;


	TYPE REC_HNS_APL IS RECORD
	(V_APPLN_REF_N				HNS_APPLICATION.APPLN_REF_N%TYPE,
	V_MSW_APPLN_REF_ID_X		HNS_APPLICATION.MSW_APPLN_REF_ID_X%TYPE,
	V_VSL_CALL_ID_N				HNS_APPLICATION.VSL_CALL_ID_N%TYPE,
	V_EXTL_APPLN_REF_ID_X		HNS_APPLICATION.EXTL_APPLN_REF_ID_X%TYPE,
	V_MSW_VSL_ID_N				HNS_APPLICATION.MSW_VSL_ID_N%TYPE,
	V_VOY_N_X					HNS_APPLICATION.VOY_N_X%TYPE,
	V_ETA_DT					HNS_APPLICATION.ETA_DT%TYPE,
	V_ETD_DT					HNS_APPLICATION.ETD_DT%TYPE,
	V_APPLCNT_ID_X				HNS_APPLICATION.APPLCNT_ID_X%TYPE,
	V_CONT_PERS_M				HNS_APPLICATION.CONT_PERS_M%TYPE,
	V_CO_M						HNS_APPLICATION.CO_M%TYPE,
	V_SUBR_EMAIL_I				HNS_APPLICATION.SUBR_EMAIL_I%TYPE,
	V_EMAIL_X					HNS_APPLICATION.EMAIL_X%TYPE,
	V_SUBR_SMS_I				HNS_APPLICATION.SUBR_SMS_I%TYPE,
	V_MOBILE_N					HNS_APPLICATION.MOBILE_N%TYPE,
	V_LST_PORT_CTRY_X			HNS_APPLICATION.LST_PORT_CTRY_X%TYPE,
	V_LAST_PORT_C				HNS_APPLICATION.LAST_PORT_C%TYPE,
	V_CFT_LIC_N					HNS_APPLICATION.CFT_LIC_N%TYPE,
	V_CGO_TY_C					HNS_APPLICATION.CGO_TY_C%TYPE,
	V_APPLN_ST_C				HNS_APPLICATION.APPLN_ST_C%TYPE,
	V_PROCESSED_BY_X			HNS_APPLICATION.PROCESSED_BY_X%TYPE,
	V_PROCESSED_ON_DT			HNS_APPLICATION.PROCESSED_ON_DT%TYPE,
	V_PROCESSING_REM_X			HNS_APPLICATION.PROCESSING_REM_X%TYPE,
	V_DELETED_I					HNS_APPLICATION.DELETED_I%TYPE,
	V_LOCK_VER_N				HNS_APPLICATION.LOCK_VER_N%TYPE,
	V_CRT_ON_DT					HNS_APPLICATION.CRT_ON_DT%TYPE,
	V_CRT_BY_X					HNS_APPLICATION.CRT_BY_X%TYPE,
	V_UPT_ON_DT					HNS_APPLICATION.UPT_ON_DT%TYPE,
	V_UPT_BY_X					HNS_APPLICATION.UPT_BY_X%TYPE,
	V_INFRNGMNT_C				HNS_APPLICATION.INFRNGMNT_C%TYPE,
	V_INFRNGMNT_ACTN_X			HNS_APPLICATION.INFRNGMNT_ACTN_X%TYPE,
	V_INFRNGMNT_USR_M			HNS_APPLICATION.INFRNGMNT_USR_M%TYPE,
	V_INFRNGMNT_PROCESS_DT		HNS_APPLICATION.INFRNGMNT_PROCESS_DT%TYPE,
	V_INFRNGMNT_PROCESS_RSN_X	HNS_APPLICATION.INFRNGMNT_PROCESS_RSN_X%TYPE,
	V_INFRNGMNT_RPT_N		  	HNS_APPLICATION.INFRNGMNT_RPT_N%TYPE

	);

	CURSOR CR_HNS_APL_SUB IS
	SELECT
		HAS.HNS_APPLN_SUBST_ID_N,
		HAS.APPLN_REF_N,
		HAS.DELETED_I,
		HAS.SEQ_N,
		HAS.SUBST_C,
		HAS.SUBST_M,
		HAS.UN_N,
		HAS.POLLN_CAT_C,
		HAS.CGO_GRP_C,
		HAS.FLASH_PT_N,
		HAS.HZ_IBC_C,
		HAS.SUBST_QTY_Q,
		HAS.STW_ONBD_X,
		HAS.OPERN_C,
		HAS.LOCN_C,
		HAS.OPERN_DT,
		HAS.CRT_ON_DT,
		HAS.CRT_BY_X,
		HAS.UPT_ON_DT,
		HAS.UPT_BY_X,
		HAS.LOCK_VER_N,
		HAS.LOCN_M

	FROM HNS_APPLICATION_SUBSTANCE HAS;


	TYPE REC_HNS_APL_SUB IS RECORD
	(V_HNS_APPLN_SUBST_ID_N		HNS_APPLICATION_SUBSTANCE.HNS_APPLN_SUBST_ID_N%TYPE,
	V_APPLN_REF_N				HNS_APPLICATION_SUBSTANCE.APPLN_REF_N%TYPE,
	V_DELETED_I					HNS_APPLICATION_SUBSTANCE.DELETED_I%TYPE,
	V_SEQ_N						HNS_APPLICATION_SUBSTANCE.SEQ_N%TYPE,
	V_SUBST_C					HNS_APPLICATION_SUBSTANCE.SUBST_C%TYPE,
	V_SUBST_M					HNS_APPLICATION_SUBSTANCE.SUBST_M%TYPE,
	V_UN_N						HNS_APPLICATION_SUBSTANCE.UN_N%TYPE,
	V_POLLN_CAT_C				HNS_APPLICATION_SUBSTANCE.POLLN_CAT_C%TYPE,
	V_CGO_GRP_C					HNS_APPLICATION_SUBSTANCE.CGO_GRP_C%TYPE,
	V_FLASH_PT_N				HNS_APPLICATION_SUBSTANCE.FLASH_PT_N%TYPE,
	V_HZ_IBC_C					HNS_APPLICATION_SUBSTANCE.HZ_IBC_C%TYPE,
	V_SUBST_QTY_Q				HNS_APPLICATION_SUBSTANCE.SUBST_QTY_Q%TYPE,
	V_STW_ONBD_X				HNS_APPLICATION_SUBSTANCE.STW_ONBD_X%TYPE,
	V_OPERN_C					HNS_APPLICATION_SUBSTANCE.OPERN_C%TYPE,
	V_LOCN_C					HNS_APPLICATION_SUBSTANCE.LOCN_C%TYPE,
	V_OPERN_DT					HNS_APPLICATION_SUBSTANCE.OPERN_DT%TYPE,
	V_CRT_ON_DT					HNS_APPLICATION_SUBSTANCE.CRT_ON_DT%TYPE,
	V_CRT_BY_X					HNS_APPLICATION_SUBSTANCE.CRT_BY_X%TYPE,
	V_UPT_ON_DT					HNS_APPLICATION_SUBSTANCE.UPT_ON_DT%TYPE,
	V_UPT_BY_X					HNS_APPLICATION_SUBSTANCE.UPT_BY_X%TYPE,
	V_LOCK_VER_N				HNS_APPLICATION_SUBSTANCE.LOCK_VER_N%TYPE,
	V_LOCN_M					HNS_APPLICATION_SUBSTANCE.LOCN_M%TYPE
	);

	TYPE TYPE_HNS_APL  IS TABLE OF REC_HNS_APL;
	LV_HNS_APL				TYPE_HNS_APL;

	TYPE TYPE_HNS_APL_SUB  IS TABLE OF REC_HNS_APL_SUB;
	LV_HNS_APL_SUB				TYPE_HNS_APL_SUB;


	LV_CNT_DM_HA        NUMBER;
	LV_CNT_TT_HA		NUMBER;
	LV_CNT_DM_HAS       NUMBER;
	LV_CNT_TT_HAS		NUMBER;
	V_ERR_CODE          NUMBER;
    V_ERR_MSG           VARCHAR2(500);
    V_SQLERRM           VARCHAR2(2500);
    V_EXP_ROWS          VARCHAR2(1000);

BEGIN

	SELECT
    COUNT(*) INTO LV_CNT_DM_HA
    FROM
    HNS_APPLICATION;

	SELECT
    COUNT(*) INTO LV_CNT_DM_HAS
    FROM
    HNS_APPLICATION_SUBSTANCE;

OPEN  CR_HNS_APL;
	pkg_datamigration_generic.proc_trace_exception('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS', 'Insertion into target Table HNS_APPLICATION', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.HNS_APPLICATION and inseting into target table HNS_SERVICE.HNS_APPLICATION ************------------------
        BEGIN

			FETCH CR_HNS_APL BULK COLLECT INTO LV_HNS_APL LIMIT 10000;
            EXIT WHEN LV_HNS_APL.count = 0;
			--FORALL i IN LV_HNS_APL.first..LV_HNS_APL.last SAVE EXCEPTIONS
			FOR i IN LV_HNS_APL.first..LV_HNS_APL.last
			LOOP
-------------************ SYN_HNS_APL is synonym of HNS_SERVICE.HNS_APPLN  ************------------------
			BEGIN

            INSERT INTO SYN_HNS_APL (
								APPLN_REF_N	,
								MSW_APPLN_REF_ID_N	,
								VSL_CALL_ID_N	,
								EXTL_APPLN_REF_ID_X	,
								MSW_VSL_ID_N	,
								VOY_N_X	,
								ETA_DT	,
								ETD_DT	,
								APPLCNT_ID_X	,
								CONT_PERS_M	,
								CO_M	,
								SUBR_EMAIL_I	,
								EMAIL_X	,
								SUBR_SMS_I	,
								MOBILE_N	,
								LST_PORT_CTRY_X	,
								LST_PORT_C	,
								CFT_LIC_X	,
								CGO_TY_C	,
								APPLN_ST_C	,
								PROCESSING_REM_X	,
								PROCESSED_BY_X	,
								PROCESSED_ON_DT	,
								CRT_BY_N	,
								CRT_ON_DT	,
								LST_UPD_BY_N	,
								LST_UPD_ON_DT	,
								LOCK_VER_N	,
								DELETED_I	,
								INFRGMT_ST_C	,
								INFRGMT_ACTN_X	,
								INFRGMT_USR_M	,
								INFRGMT_PROCESS_DT	,
								INFRGMT_PROCESS_RSN_X	,
								INFRGMT_RPT_N
								)

						VALUES (
								LV_HNS_APL(i).V_APPLN_REF_N,
								LV_HNS_APL(i).V_MSW_APPLN_REF_ID_X,
								LV_HNS_APL(i).V_VSL_CALL_ID_N,
								LV_HNS_APL(i).V_EXTL_APPLN_REF_ID_X,
								LV_HNS_APL(i).V_MSW_VSL_ID_N,
								LV_HNS_APL(i).V_VOY_N_X,
								LV_HNS_APL(i).V_ETA_DT,
								LV_HNS_APL(i).V_ETD_DT,
								LV_HNS_APL(i).V_APPLCNT_ID_X,
								LV_HNS_APL(i).V_CONT_PERS_M,
								LV_HNS_APL(i).V_CO_M,
								LV_HNS_APL(i).V_SUBR_EMAIL_I,
								LV_HNS_APL(i).V_EMAIL_X,
								LV_HNS_APL(i).V_SUBR_SMS_I,
								LV_HNS_APL(i).V_MOBILE_N,
								LV_HNS_APL(i).V_LST_PORT_CTRY_X,
								LV_HNS_APL(i).V_LAST_PORT_C,
								LV_HNS_APL(i).V_CFT_LIC_N,
								LV_HNS_APL(i).V_CGO_TY_C,
								LV_HNS_APL(i).V_APPLN_ST_C,
								LV_HNS_APL(i).V_PROCESSING_REM_X,
								LV_HNS_APL(i).V_PROCESSED_BY_X,
								LV_HNS_APL(i).V_PROCESSED_ON_DT,
								LV_HNS_APL(i).V_CRT_BY_X,
								LV_HNS_APL(i).V_CRT_ON_DT,
								LV_HNS_APL(i).V_UPT_BY_X,
								LV_HNS_APL(i).V_UPT_ON_DT,
								LV_HNS_APL(i).V_LOCK_VER_N,
								LV_HNS_APL(i).V_DELETED_I,
								LV_HNS_APL(i).V_INFRNGMNT_C,
								LV_HNS_APL(i).V_INFRNGMNT_ACTN_X,
								LV_HNS_APL(i).V_INFRNGMNT_USR_M	,
								LV_HNS_APL(i).V_INFRNGMNT_PROCESS_DT,
								LV_HNS_APL(i).V_INFRNGMNT_PROCESS_RSN_X,
								LV_HNS_APL(i).V_INFRNGMNT_RPT_N




								);


        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                v_exp_rows := 'APPLN_REF_N '
                              || LV_HNS_APL(i).V_APPLN_REF_N
                              || ' MSW_APPLN_REF_X '
                              || LV_HNS_APL(i).V_MSW_APPLN_REF_ID_X
                              || ' EXTL_APPLN_REF_X '
                              || LV_HNS_APL(i).V_EXTL_APPLN_REF_ID_X
                              || ' MSW_VSL_ID_N '
                              || LV_HNS_APL(i).V_MSW_VSL_ID_N
                              || 'VOY_N_X  '
                              || LV_HNS_APL(i).V_VOY_N_X
                              || ' ETA_DT '
                              || LV_HNS_APL(i).V_ETA_DT
                              || ' ETD_DT '
                              || LV_HNS_APL(i).V_ETD_DT
                              || 'APPLCNT_ID_X '
                              || LV_HNS_APL(i).V_APPLCNT_ID_X
                              || 'CONT_PERS_M '
                              || LV_HNS_APL(i).V_CONT_PERS_M
                              || 'CO_M '
                              || LV_HNS_APL(i).V_CO_M
                              || '....'
                              ;

             pkg_datamigration_generic.proc_trace_exception('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS',   V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,v_exp_rows,'T');

			END;

			END LOOP;

        END;
    END LOOP;
	CLOSE CR_HNS_APL;

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_HA
     FROM
     SYN_HNS_APL;

	IF( LV_CNT_TT_HA =  LV_CNT_DM_HA ) AND LV_CNT_DM_HA <>  0  AND  LV_CNT_TT_HA <> 0 THEN

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HA||' OUT OF ' || LV_CNT_TT_HA ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_HA  <> LV_CNT_TT_HA AND  LV_CNT_DM_HA <> 0 AND  LV_CNT_TT_HA <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HA||' OUT OF ' || LV_CNT_TT_HA ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_HA  <> 0 AND  LV_CNT_TT_HA = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HA||' OUT OF ' || LV_CNT_TT_HA ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;



    pkg_datamigration_generic.proc_migration_recon('DM_HNS_APPLICATION', LV_CNT_DM_HA, 'HNS_APPLICATION', LV_CNT_TT_HA,'Y');


	/***********************************************************************************************************
	Pushing records into HNS_SERVICE.HNS_APPLICATION_SUBSTANCE
    ***********************************************************************************************************/

	OPEN  CR_HNS_APL_SUB;
	pkg_datamigration_generic.proc_trace_exception('DM_HNS_APPLICATION_SUBSTANCE', 'PROC_2_PUSH_HNS', 'Insertion into target Table HNS_APPLICATION_SUBSTANCE', 'START',NULL,NULL,NULL,NULL);

	LOOP
    -------------************ Fetching records form MSW_DATA_MIGRATION.HNS_APPLICATION_SUBSTANCE and inseting into target table HNS_SERVICE.HNS_APPLICATION_SUBSTANCE ************------------------
        BEGIN

			FETCH CR_HNS_APL_SUB BULK COLLECT INTO LV_HNS_APL_SUB LIMIT 10000;
            EXIT WHEN LV_HNS_APL_SUB.count = 0;
			--FORALL i IN LV_HNS_APL_SUB.first..LV_HNS_APL_SUB.last SAVE EXCEPTIONS
			FOR i IN LV_HNS_APL_SUB.first..LV_HNS_APL_SUB.last
			LOOP
-------------************ SYN_HNS_APL_SUB is synonym of HNS_SERVICE.HNS_APPLN_SUBSTANCE  ************------------------
			BEGIN


            INSERT INTO SYN_HNS_APL_SUB (
								HNS_APPLN_SUBST_ID_N,
								APPLN_REF_N,
								SEQ_N,
								SUBST_C,
								SUBST_M,
								SUBST_QTY_Q,
								UN_X,
								POLLN_CAT_C,
								CGO_GRP_C,
								FLASH_PT_X,
								HZ_IBC_C,
								STW_ONBD_X,
								LOCN_C,
								OPERN_TY_C,
								OPERN_DT,
								CRT_BY_N,
								CRT_ON_DT,
								LST_UPD_BY_N,
								LST_UPD_ON_DT,
								LOCK_VER_N,
								DELETED_I,
								LOCN_M
								)

						VALUES (
								LV_HNS_APL_SUB(i).V_HNS_APPLN_SUBST_ID_N	,
								LV_HNS_APL_SUB(i).V_APPLN_REF_N	,
								LV_HNS_APL_SUB(i).V_SEQ_N	,
								LV_HNS_APL_SUB(i).V_SUBST_C	,
								LV_HNS_APL_SUB(i).V_SUBST_M	,
								LV_HNS_APL_SUB(i).V_SUBST_QTY_Q	,
								LV_HNS_APL_SUB(i).V_UN_N	,
								LV_HNS_APL_SUB(i).V_POLLN_CAT_C	,
								LV_HNS_APL_SUB(i).V_CGO_GRP_C	,
								LV_HNS_APL_SUB(i).V_FLASH_PT_N	,
								LV_HNS_APL_SUB(i).V_HZ_IBC_C	,
								LV_HNS_APL_SUB(i).V_STW_ONBD_X	,
								LV_HNS_APL_SUB(i).V_LOCN_C	,
								LV_HNS_APL_SUB(i).V_OPERN_C	,
								LV_HNS_APL_SUB(i).V_OPERN_DT	,
								LV_HNS_APL_SUB(i).V_CRT_BY_X	,
								LV_HNS_APL_SUB(i).V_CRT_ON_DT	,
								LV_HNS_APL_SUB(i).V_UPT_BY_X	,
								LV_HNS_APL_SUB(i).V_UPT_ON_DT	,
								LV_HNS_APL_SUB(i).V_LOCK_VER_N	,
								LV_HNS_APL_SUB(i).V_DELETED_I	,
								LV_HNS_APL_SUB(i).V_LOCN_M

								);


        EXCEPTION
        WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


                v_exp_rows := 'HNSAPPLNSUBSTID_N '
                              || LV_HNS_APL_SUB(i).V_HNS_APPLN_SUBST_ID_N
                              || ' APPLNREF_N '
                              || LV_HNS_APL_SUB(i).V_APPLN_REF_N
                              || ' DELETED_I '
                              || LV_HNS_APL_SUB(i).V_DELETED_I
                              || ' SEQ_N '
                              || LV_HNS_APL_SUB(i).V_SEQ_N
                              || 'SUBST_C  '
                              || LV_HNS_APL_SUB(i).V_SUBST_C
                              || ' SUBST_M '
                              || LV_HNS_APL_SUB(i).V_SUBST_M
                              || ' UN_N '
                              || LV_HNS_APL_SUB(i).V_UN_N
                              || 'POLLNCAT_C '
                              || LV_HNS_APL_SUB(i).V_POLLN_CAT_C
                              || 'FLASHPT_N '
                              || LV_HNS_APL_SUB(i).V_FLASH_PT_N
                              || 'HZIBC_C '
                              || LV_HNS_APL_SUB(i).V_HZ_IBC_C
                              || '....'
                              ;

             pkg_datamigration_generic.proc_trace_exception('DM_HNS_APPLICATION_SUBSTANCE', 'PROC_2_PUSH_HNS',   V_ERR_MSG, 'ERROR',NULL,V_SQLERRM,v_exp_rows,'T');

			END;

			END LOOP;

        END;
    END LOOP;
	CLOSE CR_HNS_APL_SUB;

	 SELECT
     COUNT(*)
     INTO LV_CNT_TT_HAS
     FROM
     SYN_HNS_APL_SUB;

	IF( LV_CNT_TT_HAS =  LV_CNT_DM_HAS ) AND LV_CNT_DM_HAS <>  0  AND  LV_CNT_TT_HAS <> 0 THEN

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION_SUBSTANCE', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HAS||' OUT OF ' || LV_CNT_TT_HAS ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION_SUBSTANCE' ,
        'SUCCESS',NULL,NULL,NULL,NULL);

    ELSIF  LV_CNT_DM_HAS  <> LV_CNT_TT_HAS AND  LV_CNT_DM_HAS <> 0 AND  LV_CNT_TT_HAS <> 0 THEN

       PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION_SUBSTANCE', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HAS||' OUT OF ' || LV_CNT_TT_HAS ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION_SUBSTANCE' ,
        'PARTIALLY SUCCESSFULL',NULL,NULL,NULL,NULL);


    ELSIF  LV_CNT_DM_HAS  <> 0 AND  LV_CNT_TT_HAS = 0 THEN

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DM_HNS_APPLICATION_SUBSTANCE', 'PROC_2_PUSH_HNS',
        LV_CNT_DM_HAS||' OUT OF ' || LV_CNT_TT_HAS ||' ROWS  HAVE BEEN INSERTED INTO HNS_SERVICE.HNS_APPLICATION_SUBSTANCE' ,
        'FAIL',NULL,NULL,NULL,NULL);

    END IF;

	COMMIT;

    pkg_datamigration_generic.proc_migration_recon('DM_HNS_APPLICATION_SUBSTANCE', LV_CNT_DM_HAS, 'HNS_APPLICATION_SUBSTANCE', LV_CNT_TT_HAS,'Y');

	EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        pkg_datamigration_generic.proc_trace_exception('DM_HNS_APPLICATION', 'PROC_2_PUSH_HNS', V_SQLERRM, 'ERROR',NULL,NULL,NULL,'T');

END PROC_2_PUSH_HNS;
/