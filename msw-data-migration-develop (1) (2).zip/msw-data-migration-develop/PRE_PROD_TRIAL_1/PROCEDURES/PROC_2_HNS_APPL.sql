create or replace PROCEDURE PROC_2_HNS_APPL(PV_RUN_ID IN NUMBER)  IS


/***********************************************************************************************************
procedure name : PROC_2_HNS_APPL
Created By     : R.M.KHOOL
Date           : 19-JUL-2019
Purpose        : Inserting  the data from ST_HN_NTCEHDR,ST_HN_NTCEDTL
                 SI_HNS_APP(Intermediate table) to HNS_APPLICATION & HNS_APPLICATION_SUBSTANCE(Target Table)
Modified by    :09-Aug_2019
Modified date  :

*************************************************************************************************************/
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARING VARIABLES FOR MAIN TABLE (CSV LOADED TABLE)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

 CURSOR CUR_HNSAP1 IS
       SELECT
                HDR.NTCE_N,
                HDR.NTCEVOY_N,
                HDR.NTCEVSLESTARR_DT,
                HDR.NTCEVSLESTDEP_DT,
                HDR.NTCECNTCT_M,
                HDR.NTCECO_M,
                HDR.NTCEEMLADDR_X,
                HDR.NTCECNTCT_N,
                HDR.NTCELSTPORTDESC_X,
                HDR.NTCELSTPORT_C,
                HDR.NTCECRAFTLIC_N,
                HDR.NTCECGOTY_C,
                HDR.CRTN_DT,
                HDR.NTCEAPPLNT_M,
                HDR.UPDT_DT,
                HDR.UPDT_BY,
                HDR.NTCEINFRNGMNT,
                HDR.INFRNGMNTACTN_X,
                HDR.INFUSER,
                HDR.INFPROCESS_DT,
                HDR.INFREASON_X,
                HDR.INFREPORT_N,
                DTL.NTCEDTLSNO_N,
                DTL.NTCESUBST_C,
                DTL.NTCESUBST_M,
                DTL.NTCEUN_N,
                DTL.NTCEPOLLNCAT_X,
                DTL.NTCECGOGRP_C,
                DTL.NTCEFLASHPT,
                DTL.NTCEHZIBC_X,
                DTL.NTCEVSLCARRYQTY_Q,
                DTL.NTCESTWONBD,
                DTL.NTCEACTN_X,
                DTL.NTCELOCN_C,
                DTL.NTCEOPERN_DT,
                DTL.CRTN_DT AS DTLCRTN_DT,
                DTL.CRTNBY_M ,
                DTL.UPDT_DT AS DTLUPDT_DT,
                DTL.UPDT_BY AS DTLUPDT_BY ,
                DTL.NTCELOCN_M,
                HDR.NTCEVSLRECID_N,
                V.MSW_VSL_ID_N,
                --UD.ID APPLCNT_ID_X,
                'MSW DM' APPLCNT_ID_X,
		HDR.NTCEVSL_M,
                HDR.NTCEVSLIMO_N,
                HDR.NTCECALLSIGN_M,
                HDR.NTCEVSLGT_Q,
                HDR.NTCEFLAG_C,
                HDR.NTCEVSLTY_C,
                HDR.NTCEORG_C


            FROM
                ST_HN_NTCEHDR HDR,
                ST_HN_NTCEDTL DTL,
              
                VESSEL V
            WHERE
                HDR.NTCE_N = DTL.NTCE_N
              AND 
               HDR.NTCEVSLRECID_N=V.VSL_REC_ID_N
              ORDER BY HDR.CRTN_DT;




        V_ST_COUNT             INTEGER; 
        V_ST_COUNT1            NUMBER;
        V_SRC_COUNT            NUMBER;
        V_TGT_COUNT            NUMBER;
        V_TGT_COUNT1           NUMBER;
		V_CNT_VR			   NUMBER;
		V_CNT_VC				NUMBER;
		V_CNT_AS			    NUMBER;
        V_ERR_CODE             NUMBER;
        V_ERR_MSG              VARCHAR2(2000);
        V_SQLERRM              VARCHAR2(2500);
        V_BLKEXPTN_COUNT       NUMBER(20, 0);
        V_BLKEXPTN_DESC        VARCHAR2(3000);
        V_MSG                  VARCHAR2(200);
        V_MSW_VSL_CALL_ID_OUT  NUMBER;
        V_FLAG                 VARCHAR2(1);
        V_EXP_ROWS_SI          VARCHAR2(3000);
        V_FLAG_VSL_REF         VARCHAR2(1);
        V_VSL_REF_ID_OUT       NUMBER;
     



  CURSOR CUR_HNSAP2 IS
    SELECT

        NTCE_N,
        NTCEVOY_N,
        NTCEVSLESTARR_DT,
        NTCEVSLESTDEP_DT,
        NTCECNTCT_M,
        NTCECO_M,
        NTCEEMLADDR_X,
        NTCECNTCT_N,
        NTCELSTPORTDESC_X,
        NTCELSTPORT_C,
        NTCECRAFTLIC_N,
        NTCECGOTY_C,
        CRTN_DT,
        NTCEAPPLNT_M,
        UPDT_DT,
        UPDT_BY,
        NTCEINFRNGMNT,
        INFRNGMNTACTN_X,
        INFUSER,
        INFPROCESS_DT,
        INFREASON_X,
        INFREPORT_N,
        NTCEDTLSNO_N,
        NTCESUBST_C,
        NTCESUBST_M,
        NTCEUN_N,
        NTCEPOLLNCAT_X,
        NTCECGOGRP_C,
        NTCEFLASHPT,
        NTCEHZIBC_X,
        NTCEVSLCARRYQTY_Q,
        NTCESTWONBD,
        NTCEACTN_X,
        NTCELOCN_C,
        NTCEOPERN_DT,
        DTLCRTN_DT,
        DTLCRTNBY_M,
        DTLUPDT_DT,
        DTLUPDT_BY,
        NTCELOCN_M,
        NTCEVSLRECID_N,
        MSW_VSL_ID_N,
        APPLCNT_ID_X,
        NTCEVSL_M,
        NTCEVSLIMO_N,
        NTCECALLSIGN_M,
        NTCEVSLGT_Q,
        NTCEFLAG_C,
        NTCEVSLTY_C,
        NTCEORG_C
    FROM
        SI_HNS_APP
        ORDER BY CRTN_DT ;            

 TYPE REC_HNS_APP_TG IS RECORD (

        V_NTCE_N		        SI_HNS_APP.NTCE_N%TYPE	,
        V_NTCEVOY_N		        SI_HNS_APP.NTCEVOY_N%TYPE	,
        V_NTCEVSLESTARR_DT		SI_HNS_APP.NTCEVSLESTARR_DT%TYPE	,
        V_NTCEVSLESTDEP_DT		SI_HNS_APP.NTCEVSLESTDEP_DT%TYPE	,
        V_NTCECNTCT_M		    SI_HNS_APP.NTCECNTCT_M%TYPE	,
        V_NTCECO_M		        SI_HNS_APP.NTCECO_M%TYPE	,
        V_NTCEEMLADDR_X		    SI_HNS_APP.NTCEEMLADDR_X%TYPE	,
        V_NTCECNTCT_N		    SI_HNS_APP.NTCECNTCT_N%TYPE	,
        V_NTCELSTPORTDESC_X		SI_HNS_APP.NTCELSTPORTDESC_X%TYPE	,
        V_NTCELSTPORT_C		    SI_HNS_APP.NTCELSTPORT_C%TYPE	,
        V_NTCECRAFTLIC_N		SI_HNS_APP.NTCECRAFTLIC_N%TYPE	,
        V_NTCECGOTY_C		    SI_HNS_APP.NTCECGOTY_C%TYPE	,
        V_CRTN_DT		        SI_HNS_APP.CRTN_DT%TYPE	,
        V_NTCEAPPLNT_M		    SI_HNS_APP.NTCEAPPLNT_M%TYPE	,
        V_UPDT_DT		        SI_HNS_APP.UPDT_DT%TYPE	,
        V_UPDT_BY		        SI_HNS_APP.UPDT_BY%TYPE	,
        V_NTCEINFRNGMNT		    SI_HNS_APP.NTCEINFRNGMNT%TYPE	,
        V_INFRNGMNTACTN_X		SI_HNS_APP.INFRNGMNTACTN_X%TYPE	,
        V_INFUSER		        SI_HNS_APP.INFUSER%TYPE	,
        V_INFPROCESS_DT		    SI_HNS_APP.INFPROCESS_DT%TYPE	,
        V_INFREASON_X		    SI_HNS_APP.INFREASON_X%TYPE	,
        V_INFREPORT_N		    SI_HNS_APP.INFREPORT_N%TYPE	,
        V_NTCEDTLSNO_N		    SI_HNS_APP.NTCEDTLSNO_N%TYPE	,
        V_NTCESUBST_C		    SI_HNS_APP.NTCESUBST_C%TYPE	,
        V_NTCESUBST_M		    SI_HNS_APP.NTCESUBST_M%TYPE	,
        V_NTCEUN_N		        SI_HNS_APP.NTCEUN_N%TYPE	,
        V_NTCEPOLLNCAT_X		SI_HNS_APP.NTCEPOLLNCAT_X%TYPE	,
        V_NTCECGOGRP_C		    SI_HNS_APP.NTCECGOGRP_C%TYPE	,
        V_NTCEFLASHPT		    SI_HNS_APP.NTCEFLASHPT%TYPE	,
        V_NTCEHZIBC_X		    SI_HNS_APP.NTCEHZIBC_X%TYPE	,
        V_NTCEVSLCARRYQTY_Q		SI_HNS_APP.NTCEVSLCARRYQTY_Q%TYPE	,
        V_NTCESTWONBD		    SI_HNS_APP.NTCESTWONBD%TYPE	,
        V_NTCEACTN_X		    SI_HNS_APP.NTCEACTN_X%TYPE	,
        V_NTCELOCN_C		    SI_HNS_APP.NTCELOCN_C%TYPE	,
        V_NTCEOPERN_DT		    SI_HNS_APP.NTCEOPERN_DT%TYPE	,
        V_DTLCRTN_DT		    SI_HNS_APP.DTLCRTN_DT%TYPE	,
        V_DTLCRTNBY_M		    SI_HNS_APP.DTLCRTNBY_M%TYPE	,
        V_DTLUPDT_DT		    SI_HNS_APP.DTLUPDT_DT%TYPE	,
        V_DTLUPDT_BY		    SI_HNS_APP.DTLUPDT_BY%TYPE	,
        V_NTCELOCN_M		    SI_HNS_APP.NTCELOCN_M%TYPE	,
        V_NTCEVSLRECID_N		SI_HNS_APP.NTCEVSLRECID_N%TYPE	,
        V_MSW_VSL_ID_N		    SI_HNS_APP.MSW_VSL_ID_N%TYPE,
        V_APPLCNT_ID_X          SI_HNS_APP.APPLCNT_ID_X%TYPE,
        V_NTCEVSL_M				SI_HNS_APP.NTCEVSL_M%TYPE	,
        V_NTCEVSLIMO_N          SI_HNS_APP.NTCEVSLIMO_N%TYPE	,
        V_NTCECALLSIGN_M        SI_HNS_APP.NTCECALLSIGN_M%TYPE	,
        V_NTCEVSLGT_Q           SI_HNS_APP.NTCEVSLGT_Q%TYPE	,
        V_NTCEFLAG_C            SI_HNS_APP.NTCEFLAG_C%TYPE	,
        V_NTCEVSLTY_C           SI_HNS_APP.NTCEVSLTY_C%TYPE	,
        V_NTCEORG_C             SI_HNS_APP.NTCEORG_C%TYPE	

    );
    TYPE TYPE_HNS_APP_TG IS
        TABLE OF REC_HNS_APP_TG;
    LV_HNS_APP_TG              TYPE_HNS_APP_TG;
    V_MSW_APPLN_REF_ID_X   	   VARCHAR2(20); 			 ---VALUE SHOULD BE 15 ONLY
    V_SUBR_EMAIL               VARCHAR2(2);
    V_SUBR_SMS_I               VARCHAR2(2);
    LV_HNS_APP_SEQ             HNS_APPLICATION.APPLN_REF_N%TYPE;   
    LV_HNS_APPSUB_SEQ          HNS_APPLICATION_SUBSTANCE.HNS_APPLN_SUBST_ID_N%TYPE;
    PV_HNS_APPL                HNS_APPLICATION%ROWTYPE;
    PV_HNS_APPL_SUB            HNS_APPLICATION_SUBSTANCE%ROWTYPE;
    LV_DATA_DUMP               CLOB;
    L_VAL               	   NUMBER(6);
    V_YEAR_MONTH        	   VARCHAR2(5);
    P_YYMM              	   VARCHAR2(5);


/********OPENING THE CURSOR FOR INTERMEDIATE TABLE*******/

BEGIN         



   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_HNS_APP', 'PROC_2_HNS_APPL', 'INSERTION INTO SI_HNS_APP STARTS', 'START',
   PV_RUN_ID, NULL, NULL,'T' );

   

    FOR I IN CUR_HNSAP1 LOOP

		BEGIN

			INSERT INTO SI_HNS_APP
                (
				NTCE_N	,
				NTCEVOY_N	,
				NTCEVSLESTARR_DT	,
				NTCEVSLESTDEP_DT	,
				NTCECNTCT_M	,
				NTCECO_M	,
				NTCEEMLADDR_X	,
				NTCECNTCT_N	,
				NTCELSTPORTDESC_X	,
				NTCELSTPORT_C	,
				NTCECRAFTLIC_N	,
				NTCECGOTY_C	,
				CRTN_DT	,
				NTCEAPPLNT_M	,
				UPDT_DT	,
				UPDT_BY	,
				NTCEINFRNGMNT	,
				INFRNGMNTACTN_X	,
				INFUSER	,
				INFPROCESS_DT	,
				INFREASON_X	,
				INFREPORT_N	,
				NTCEDTLSNO_N	,
				NTCESUBST_C	,
				NTCESUBST_M	,
				NTCEUN_N	,
				NTCEPOLLNCAT_X	,
				NTCECGOGRP_C	,
				NTCEFLASHPT	,
				NTCEHZIBC_X	,
				NTCEVSLCARRYQTY_Q	,
				NTCESTWONBD	,
				NTCEACTN_X	,
				NTCELOCN_C	,
				NTCEOPERN_DT	,
				DTLCRTN_DT	,
				DTLCRTNBY_M	,
				DTLUPDT_DT	,
				DTLUPDT_BY	,
				NTCELOCN_M	,
				NTCEVSLRECID_N	,
				MSW_VSL_ID_N,
                APPLCNT_ID_X,
                NTCEVSL_M,
                NTCEVSLIMO_N,
                NTCECALLSIGN_M,
                NTCEVSLGT_Q,
                NTCEFLAG_C,
                NTCEVSLTY_C,
                NTCEORG_C
				)
			VALUES
				(
            	I.NTCE_N	,
				I.NTCEVOY_N	,
				I.NTCEVSLESTARR_DT	,
				I.NTCEVSLESTDEP_DT	,
				I.NTCECNTCT_M	,
				I.NTCECO_M	,
				I.NTCEEMLADDR_X	,
				I.NTCECNTCT_N	,
				I.NTCELSTPORTDESC_X	,
				I.NTCELSTPORT_C	,
				I.NTCECRAFTLIC_N	,
				I.NTCECGOTY_C	,
				I.CRTN_DT	,
				I.NTCEAPPLNT_M	,
				I.UPDT_DT	,
				I.UPDT_BY	,
				I.NTCEINFRNGMNT	,
				I.INFRNGMNTACTN_X	,
				I.INFUSER	,
				I.INFPROCESS_DT	,
				I.INFREASON_X	,
				I.INFREPORT_N	,
				I.NTCEDTLSNO_N	,
				I.NTCESUBST_C	,
				I.NTCESUBST_M	,
				I.NTCEUN_N	,
				I.NTCEPOLLNCAT_X	,
				I.NTCECGOGRP_C	,
				I.NTCEFLASHPT	,
				I.NTCEHZIBC_X	,
				I.NTCEVSLCARRYQTY_Q	,
				I.NTCESTWONBD	,
				I.NTCEACTN_X	,
				I.NTCELOCN_C	,
				I.NTCEOPERN_DT	,
				I.DTLCRTN_DT	,
				I.crtnby_m ,
				I.DTLUPDT_DT	,
				I.DTLUPDT_BY	,
				I.NTCELOCN_M	,
				I.NTCEVSLRECID_N	,
				I.MSW_VSL_ID_N,
                I.APPLCNT_ID_X,
                I.NTCEVSL_M,
                I.NTCEVSLIMO_N,
                I.NTCECALLSIGN_M,
                I.NTCEVSLGT_Q,
                I.NTCEFLAG_C,
                I.NTCEVSLTY_C,
                I.NTCEORG_C
				); 

			EXCEPTION
				WHEN OTHERS THEN            
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE||SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;

				V_EXP_ROWS_SI:=  I.NTCE_N||'<{||}>'||
								I.NTCEVOY_N||'<{||}>'||
								I.NTCEVSLESTARR_DT||'<{||}>'||
								I.NTCEVSLESTDEP_DT||'<{||}>'||
								I.NTCECNTCT_M||'<{||}>'||
								I.NTCECO_M||'<{||}>'||
								I.NTCEEMLADDR_X||'<{||}>'||
								I.NTCECNTCT_N||'<{||}>'||
								I.NTCELSTPORTDESC_X||'<{||}>'||
								I.NTCELSTPORT_C||'<{||}>'||
								I.NTCECRAFTLIC_N||'<{||}>'||
								I.NTCECGOTY_C||'<{||}>'||
								I.CRTN_DT||'<{||}>'||
								I.NTCEAPPLNT_M||'<{||}>'||
								I.UPDT_DT||'<{||}>'||
								I.UPDT_BY||'<{||}>'||
								I.NTCEINFRNGMNT||'<{||}>'||
								I.INFRNGMNTACTN_X||'<{||}>'||
								I.INFUSER||'<{||}>'||
								I.INFPROCESS_DT||'<{||}>'||
								I.INFREASON_X||'<{||}>'||
								I.INFREPORT_N||'<{||}>'||
								I.NTCEDTLSNO_N||'<{||}>'||
								I.NTCESUBST_C||'<{||}>'||
								I.NTCESUBST_M||'<{||}>'||
								I.NTCEUN_N||'<{||}>'||
								I.NTCEPOLLNCAT_X||'<{||}>'||
								I.NTCECGOGRP_C||'<{||}>'||
								I.NTCEFLASHPT||'<{||}>'||
								I.NTCEHZIBC_X||'<{||}>'||
								I.NTCEVSLCARRYQTY_Q||'<{||}>'||
								I.NTCESTWONBD||'<{||}>'||
								I.NTCEACTN_X||'<{||}>'||
								I.NTCELOCN_C||'<{||}>'||
								I.NTCEOPERN_DT||'<{||}>'||
								I.DTLCRTN_DT||'<{||}>'||
								I.crtnby_m||'<{||}>'||
								I.DTLUPDT_DT||'<{||}>'||
								I.DTLUPDT_BY||'<{||}>'||
								I.NTCELOCN_M||'<{||}>'||
								I.NTCEVSLRECID_N||'<{||}>'||
								I.MSW_VSL_ID_N||'<{||}>'||
                                I.APPLCNT_ID_X||'<{||}>'||
                                I.NTCEVSL_M||'<{||}>'||
                                I.NTCEVSLIMO_N||'<{||}>'||
                                I.NTCECALLSIGN_M||'<{||}>'||
                                I.NTCEVSLGT_Q||'<{||}>'||
                                I.NTCEFLAG_C||'<{||}>'||
                                I.NTCEVSLTY_C;




                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_HNS_APP', 'PROC_2_HNS_APPL', V_ERR_MSG,
                                                                'ERROR', PV_RUN_ID, V_SQLERRM , V_EXP_ROWS_SI ,'T');
   

		END;                                                                                                

    END LOOP;  

  COMMIT;    





/*---RECORDS MISSED IN THE BUSINESS LOGIC---------*/

 BEGIN

		FOR I IN(
			SELECT
			ST.* FROM
			ST_HN_NTCEHDR ST 
			WHERE 
			ST.NTCE_N NOT IN (SELECT NTCE_N FROM SI_HNS_APP))
		LOOP

		 PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_HNS_APP', 'PROC_2_HNS_APPL','UNCOMMON RECORDSS ST_HN_NTCE_HDR',
																	   NULL,PV_RUN_ID,NULL, 
																		I.NTCE_N
																		|| '<{||}>'
																		|| I.NTCEVSLRECID_N
																		||'<{||}>'
																		||I.NTCEORG_C
																		||'<{||}>'
																		||I.NTCEVSL_M
																		||'<{||}>'
																		||I.NTCEVOY_N
																		||'<{||}>'
																		||I.NTCECO_M
																		||'<{||}>'
																		||I.NTCECNTCT_N
																		||'<{||}>'
																		||I.NTCECRAFTLIC_N
																		||'<{||}>'
																		||I.NTCECALLSIGN_M
																		||'<{||}>'
																		||I.NTCEFLAG_C
																		||'<{||}>'
																		||I.NTCEFLAG_M
																		||'<{||}>'
																		||I.NTCEVSLTY_C
																		||'<{||}>'
																		||I.NTCEVSLTY_M
																		||'<{||}>'
																		||I.NTCEVSLGT_Q
																		||'<{||}>'
																		||I.NTCELSTPORT_C
																		||'<{||}>'
																		||I.NTCELSTPORTDESC_X
																		||'<{||}>'
																		||I.NTCEVSLESTARR_DT
																		||'<{||}>'
																		||I.NTCEVSLESTDEP_DT
																		||'<{||}>'
																		||I.CRTN_DT
																		||'<{||}>'
																		||I.CRTNBY_M
																		||'<{||}>'                                                                
																		||I.NTCERECSTATUS
																		||'<{||}>'
																		||I.NTCELOGINID_C
																		||'<{||}>'
																		||I.NTCEAPPLNT_M
																		||'<{||}>'
																		||I.NTCECNTCT_M
																		||'<{||}>'
																		||I.NTCEEMLADDR_X
																		||'<{||}>'
																		||I.NTCEVSLIMO_N
																		||'<{||}>'
																		||I.NTCECGOTY_C
																		||'<{||}>'
																		||I.NTCEVSLESTARRTIME_X
																		||'<{||}>'
																		||I.NTCEVSLESTDEPTIME_X
																		||'<{||}>'
																		||I.NTCEINFRNGMNT
																		||'<{||}>'
																		||I.INFRNGMNTACTN_X
																		||'<{||}>'
																		||I.INFUSER
																		||'<{||}>'
																		||I.INFPROCESS_DT
																		||'<{||}>'
																		||I.INFREASON_X
																		||'<{||}>'
																		||I.UPDT_DT
																		||'<{||}>'
																		||I.UPDT_BY
																		||'*|'
																		||I.INFREPORT_N,
																		 'B');


		END LOOP;

		EXCEPTION  WHEN OTHERS THEN 

		 -- DBMS_OUTPUT.PUT_LINE(SQLERRM ||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE || V_ERR_MSG || DBMS_UTILITY.FORMAT_ERROR_STACK;


END;

BEGIN
-----FOR DTL TABLE------------

		FOR J IN (
				   SELECT
						NTCE_N	,
						NTCEDTLSNO_N	,
						NTCESUBST_C	,
						NTCESUBST_M	,
						NTCEUN_N	,
						NTCEPOLLNCAT_X	,
						NTCEFLASHPT	,
						NTCEVSLCARRYQTY_Q	,
						NTCESTWONBD	,
						NTCEACTN_X	,
						NTCELOCN_C	,
						NTCELOCN_M	,
						NTCEOPERN_DT	,
						CRTN_DT	,
						CRTNBY_M	,
						NTCEOPERNTIME_X	,
						NTCEINFRNGMNT	,
						NTCECGOGRP_C	,
						UPDT_DT	,
						UPDT_BY	,
						NEWLYADDED_I	,
						NTCEHZIBC_X	
				 FROM
					ST_HN_NTCEDTL ST 
					WHERE 
					ST.NTCE_N NOT IN (SELECT NTCE_N FROM SI_HNS_APP))

		LOOP

		PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ST_HN_NTCEDTL', 'PROC_2_HNS_APPL', 'UNCOMMON RECORDS ST_HN_NTCDTL',
																		NULL, PV_RUN_ID, NULL, 
																		J.NTCE_N
																		|| '<{||}>'
																		||J.NTCEDTLSNO_N
																		|| '<{||}>'
																		||J.NTCESUBST_C
																		|| '<{||}>'
																		||J.NTCESUBST_M
																		|| '<{||}>'
																		||J.NTCEUN_N
																		|| '<{||}>'
																		||J.NTCEPOLLNCAT_X
																		|| '<{||}>'
																		||J.NTCEFLASHPT
																		|| '<{||}>'
																		||J.NTCEVSLCARRYQTY_Q
																		|| '<{||}>'
																		||J.NTCESTWONBD
																		|| '<{||}>'
																		||J.NTCEACTN_X
																		|| '<{||}>'
																		||J.NTCELOCN_C
																		|| '<{||}>'
																		||J.NTCELOCN_M
																		|| '<{||}>'
																		||J.NTCEOPERN_DT
																		|| '<{||}>'
																		||J.CRTN_DT
																		|| '<{||}>'
																		||J.CRTNBY_M                                                                                                                            
																		|| '<{||}>'
																		||J.NTCEOPERNTIME_X
																		|| '<{||}>'
																		||J.NTCEINFRNGMNT
																		|| '<{||}>'
																		||J.NTCECGOGRP_C
																		|| '<{||}>'
																		||J.UPDT_DT
																		|| '<{||}>'
																		||J.UPDT_BY
																		|| '<{||}>'
																		||J.NEWLYADDED_I
																		|| '<{||}>'
																		||J.NTCEHZIBC_X,
																	   'D');



		END LOOP;

		EXCEPTION  WHEN OTHERS THEN 

		--  DBMS_OUTPUT.PUT_LINE(SQLERRM ||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );
				V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE|| V_ERR_MSG|| DBMS_UTILITY.FORMAT_ERROR_STACK;

END;

--END OF CAPTURING BE(BUSINESS ERROR) 


/***********************************************************************************************************
Reconciling the count of staging table  ST_HN_NTCEHDR and SI  table of HNS starts
*************************************************************************************************************/

    SELECT COUNT(*)
	INTO V_ST_COUNT
    FROM ST_HN_NTCEHDR;

--------------COUNT OF INTERMEDIATE TABLE

    SELECT COUNT(*)
	INTO V_SRC_COUNT
    FROM SI_HNS_APP;

 --START INSERTION IN RECON TABLE ACCORDING TO THE CONDITION----
	IF( V_SRC_COUNT =  V_ST_COUNT ) AND V_ST_COUNT <>  0  AND  V_SRC_COUNT <> 0 THEN     ----CONDITION FOR MIGRATION TABLE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
        V_SRC_COUNT||' OUT OF ' || V_ST_COUNT ||' ROWS  HAVE BEEN INSERTED INTO SI_HNS_APP' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    ELSIF  V_SRC_COUNT  <> V_ST_COUNT AND  V_SRC_COUNT <> 0 THEN 
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
        V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT ||' ROWS HAVE BEEN INSERTED INTO SI_HNS_APP' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');

    ELSIF ( V_SRC_COUNT  <> V_ST_COUNT OR  V_SRC_COUNT  = V_ST_COUNT ) AND ( V_SRC_COUNT = 0) THEN 
         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
         V_SRC_COUNT ||' OUT OF ' ||V_ST_COUNT||' ROWS HAVE BEEN INSERTED INTO SI_HNS_APP TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

    END IF;

--END;

/***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/ 

OPEN CUR_HNSAP2; 

   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION ( 'HNS_APPLICATION', 'PROC_2_HNS_APPL', 'HNS_APPLICATION', 'START',PV_RUN_ID,NULL,NULL,'T' );

   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION( 'HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL', 'HNS_APPLICATION_SUBSTANCE' , 'START' ,PV_RUN_ID,NULL,NULL,'T');

    LOOP

        

            FETCH CUR_HNSAP2 BULK COLLECT INTO LV_HNS_APP_TG LIMIT 10000 ;

            EXIT WHEN LV_HNS_APP_TG.COUNT = 0;

			-- INSERTING THE DATA FROM THE COLLECTION VARIABLE INTO THE TARGET TABLE 

            FOR I IN LV_HNS_APP_TG.FIRST..LV_HNS_APP_TG.LAST 
			LOOP
                LV_HNS_APP_SEQ := HNS_APP_SEQ.NEXTVAL;              ----SEQUENCE FOR HNS APPLICATIN
                LV_HNS_APPSUB_SEQ := HNS_APPSUB_SEQ.NEXTVAL;        ----SEQUENCE FOR HNS APPLICATIN SUBSTANCE

            BEGIN



				/*FINDING the year and month of the current record based on created on date */       

                SELECT TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT,'YY')|| TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT,'MM') 
				INTO V_YEAR_MONTH 
                FROM DUAL;

				/*Reset the sequence if the current year month doesnot match with the previous year and month  */ 

                IF V_YEAR_MONTH != P_YYMM  AND P_YYMM IS NOT NULL 
                THEN

                EXECUTE IMMEDIATE 'SELECT APP_SUB_HNS_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_HNS_SEQ INCREMENT BY -'|| L_VAL || ' MINVALUE 0';

                EXECUTE IMMEDIATE 'SELECT APP_SUB_HNS_SEQ.NEXTVAL FROM DUAL' INTO L_VAL;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE APP_SUB_HNS_SEQ INCREMENT BY 1 MINVALUE 0';

                END IF; -- END IF OF  THE SEQUENCE RESET 

				P_YYMM := V_YEAR_MONTH ;

                V_MSW_APPLN_REF_ID_X := 'MSW'
                                        || 'HNS'
                                        || TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT, 'YY')
                                        || TO_CHAR(LV_HNS_APP_TG(I).V_CRTN_DT, 'MM') 
                                        || TO_CHAR(APP_SUB_HNS_SEQ.NEXTVAL, 'FM00000');


   -----------------------FOR DECODE PUT THIS VALUE IN VARIABLE-----------

                   SELECT DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1) 
                   INTO V_SUBR_EMAIL
				   FROM DUAL;



                   SELECT  DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]'), '0'), 0, 0, 1)
                   INTO V_SUBR_SMS_I 
				   FROM DUAL;



----ASSISGNING THE JSON-------   

                    PV_HNS_APPL.APPLN_REF_N := LV_HNS_APP_SEQ;
                    PV_HNS_APPL.MSW_APPLN_REF_ID_X := V_MSW_APPLN_REF_ID_X ;
                    PV_HNS_APPL.EXTL_APPLN_REF_ID_X :=  LV_HNS_APP_TG(I).V_NTCE_N;       --NULL
                    PV_HNS_APPL.MSW_VSL_ID_N := LV_HNS_APP_TG(I).V_MSW_VSL_ID_N;
                    PV_HNS_APPL.VOY_N_X := LV_HNS_APP_TG(I).V_NTCEVOY_N;
                    PV_HNS_APPL.ETA_DT := LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT;
                    PV_HNS_APPL.ETD_DT := LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT;
                    PV_HNS_APPL.APPLCNT_ID_X := LV_HNS_APP_TG(I).V_APPLCNT_ID_X;--'PENDING';
                    PV_HNS_APPL.CONT_PERS_M := LV_HNS_APP_TG(I).V_NTCECNTCT_M;
                    PV_HNS_APPL.CO_M := LV_HNS_APP_TG(I).V_NTCECO_M;
                    PV_HNS_APPL.SUBR_EMAIL_I := V_SUBR_EMAIL ;   
                    PV_HNS_APPL.EMAIL_X := LV_HNS_APP_TG(I).V_NTCEEMLADDR_X;
                    PV_HNS_APPL.SUBR_SMS_I := V_SUBR_SMS_I;                                
                    PV_HNS_APPL.MOBILE_N := REGEXP_SUBSTR(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[0-9]+');
                    PV_HNS_APPL.LST_PORT_CTRY_X := LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X;
                    PV_HNS_APPL.LAST_PORT_C := LV_HNS_APP_TG(I).V_NTCELSTPORT_C;
                    PV_HNS_APPL.CFT_LIC_N := LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N;
                    PV_HNS_APPL.CGO_TY_C := LV_HNS_APP_TG(I).V_NTCECGOTY_C;
                    PV_HNS_APPL.APPLN_ST_C := 'APPROVED';
                    PV_HNS_APPL.PROCESSED_BY_X := NULL;
                    PV_HNS_APPL.PROCESSED_ON_DT := NULL;
                    PV_HNS_APPL.PROCESSING_REM_X := NULL;
                    PV_HNS_APPL.DELETED_I := 0;
                    PV_HNS_APPL.LOCK_VER_N := 0;
                    PV_HNS_APPL.CRT_ON_DT := LV_HNS_APP_TG(I).V_CRTN_DT;
                    PV_HNS_APPL.CRT_BY_X := 'MSW_DM';
                    PV_HNS_APPL.UPT_ON_DT := LV_HNS_APP_TG(I).V_UPDT_DT;
                    PV_HNS_APPL.UPT_BY_X := NVL(LV_HNS_APP_TG(I).V_UPDT_BY,'DATA MIGRATION');
                    PV_HNS_APPL.INFRNGMNT_C := LV_HNS_APP_TG(I).V_NTCEINFRNGMNT;

------------------ HNS SUBSTANCE ---------------------                    

                    PV_HNS_APPL_SUB.APPLN_REF_N := LV_HNS_APP_SEQ;
                    PV_HNS_APPL_SUB.DELETED_I := 0;
                    PV_HNS_APPL_SUB.SEQ_N := LV_HNS_APP_TG(I).V_NTCEDTLSNO_N;
                    PV_HNS_APPL_SUB.SUBST_C := LV_HNS_APP_TG(I).V_NTCESUBST_C;
                    PV_HNS_APPL_SUB.SUBST_M := LV_HNS_APP_TG(I).V_NTCESUBST_M;
                    PV_HNS_APPL_SUB.UN_N := LV_HNS_APP_TG(I).V_NTCEUN_N;
                    PV_HNS_APPL_SUB.POLLN_CAT_C := LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X;
                    PV_HNS_APPL_SUB.CGO_GRP_C := LV_HNS_APP_TG(I).V_NTCECGOGRP_C;
                    PV_HNS_APPL_SUB.FLASH_PT_N := LV_HNS_APP_TG(I).V_NTCEFLASHPT;
                    PV_HNS_APPL_SUB.HZ_IBC_C := LV_HNS_APP_TG(I).V_NTCEHZIBC_X;
                    PV_HNS_APPL_SUB.SUBST_QTY_Q := LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q;
                    PV_HNS_APPL_SUB.STW_ONBD_X := LV_HNS_APP_TG(I).V_NTCESTWONBD;
                    PV_HNS_APPL_SUB.OPERN_C := LV_HNS_APP_TG(I).V_NTCEACTN_X;
                    PV_HNS_APPL_SUB.LOCN_C := LV_HNS_APP_TG(I).V_NTCELOCN_C;
                    PV_HNS_APPL_SUB.OPERN_DT := LV_HNS_APP_TG(I).V_NTCEOPERN_DT;
                    PV_HNS_APPL_SUB.CRT_ON_DT := LV_HNS_APP_TG(I).V_DTLCRTN_DT;
                    PV_HNS_APPL_SUB.CRT_BY_X := LV_HNS_APP_TG(I).V_DTLCRTNBY_M;
                    PV_HNS_APPL_SUB.UPT_ON_DT := LV_HNS_APP_TG(I).V_DTLUPDT_DT;
                    PV_HNS_APPL_SUB.UPT_BY_X := LV_HNS_APP_TG(I).V_DTLUPDT_BY;
                    PV_HNS_APPL_SUB.LOCK_VER_N := '0';

------------**** JSON FUNC ***------------------------
            LV_DATA_DUMP := FNC_JSON_VAL_HNS(PV_HNS_APPL, PV_HNS_APPL_SUB); 
			
		PROC_1_VSL_REF (LV_HNS_APP_TG(I).V_MSW_VSL_ID_N ,LV_HNS_APP_TG(I).V_NTCEVSLRECID_N ,LV_HNS_APP_TG(I).V_NTCEVSL_M ,
        LV_HNS_APP_TG(I).V_NTCEVSLIMO_N ,LV_HNS_APP_TG(I).V_NTCECALLSIGN_M ,LV_HNS_APP_TG(I).V_NTCEVSLGT_Q ,LV_HNS_APP_TG(I).V_NTCEFLAG_C ,LV_HNS_APP_TG(I).V_NTCEVSLTY_C,V_VSL_REF_ID_OUT,V_FLAG_VSL_REF );

		IF V_FLAG_VSL_REF IS NULL THEN
		

		PROC_2_VC_AS  (LV_HNS_APP_TG(I).V_MSW_VSL_ID_N, LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT, LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT, NULL, NULL,
		NULL, V_MSW_APPLN_REF_ID_X, LV_HNS_APP_TG(I).V_NTCE_N, 'HNS',LV_DATA_DUMP, PV_RUN_ID, 'HNS_APPLICATION', V_MSW_VSL_CALL_ID_OUT ,V_FLAG,LV_HNS_APP_TG(I).V_NTCEORG_C,V_VSL_REF_ID_OUT);




			IF V_FLAG IS NULL THEN
			-------START INSERT 
			BEGIN --BEGIN END FOR HNS_APPLICATION
			
			INSERT INTO HNS_APPLICATION (
									APPLN_REF_N,
									MSW_APPLN_REF_ID_X,
									VSL_CALL_ID_N,
									EXTL_APPLN_REF_ID_X,
									MSW_VSL_ID_N,
									VOY_N_X,
									ETA_DT,
									ETD_DT,
									APPLCNT_ID_X,
									CONT_PERS_M,
									CO_M,
									SUBR_EMAIL_I,
									EMAIL_X,
									SUBR_SMS_I,
									MOBILE_N,
									LST_PORT_CTRY_X,
									LAST_PORT_C,
									CFT_LIC_N,
									CGO_TY_C,
									APPLN_ST_C,
									PROCESSED_BY_X,
									PROCESSED_ON_DT,
									PROCESSING_REM_X,
									DELETED_I,
									LOCK_VER_N,
									CRT_ON_DT,
									CRT_BY_X,
									UPT_ON_DT,
									UPT_BY_X,
									INFRNGMNT_C,
									INFRNGMNT_ACTN_X,
									INFRNGMNT_USR_M,
									INFRNGMNT_PROCESS_DT,
									INFRNGMNT_PROCESS_RSN_X,
									INFRNGMNT_RPT_N
								) 
						VALUES (
									LV_HNS_APP_SEQ,
									V_MSW_APPLN_REF_ID_X , 						--------- V_MSW_APPLN_REF_ID_X ,    
									V_MSW_VSL_CALL_ID_OUT,						
									LV_HNS_APP_TG(I).V_NTCE_N,                
									LV_HNS_APP_TG(I).V_MSW_VSL_ID_N,                               
									LV_HNS_APP_TG(I).V_NTCEVOY_N,
									LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT,
									LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT,
									LV_HNS_APP_TG(I).V_APPLCNT_ID_X,--'PENDING',
									LV_HNS_APP_TG(I).V_NTCECNTCT_M,
									LV_HNS_APP_TG(I).V_NTCECO_M,                   
									DECODE(NVL(LV_HNS_APP_TG(I).V_NTCEEMLADDR_X, 0),'0',0,1),  ---- V_SUBR_EMAIL_I
									LV_HNS_APP_TG(I).V_NTCEEMLADDR_X,
									DECODE(NVL(REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''), '0'), 0, 0, 1), ---SUBR_SMS_I
									REGEXP_REPLACE(LV_HNS_APP_TG(I).V_NTCECNTCT_N, '[^0-9]', ''),                  
									LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X,
									LV_HNS_APP_TG(I).V_NTCELSTPORT_C,
									LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N,
									LV_HNS_APP_TG(I).V_NTCECGOTY_C,
									'APPROVED',
									NULL,
									NULL,
									NULL,
									0,
									0,
									LV_HNS_APP_TG(I).V_CRTN_DT,
									NVL(LV_HNS_APP_TG(I).V_NTCEAPPLNT_M,'APPLICANT')   , ----THIS COL NOT CONTAINS THE NULL VALUES  'APPLICANT'                          
									LV_HNS_APP_TG(I).V_UPDT_DT,
									NVL(LV_HNS_APP_TG(I).V_UPDT_BY,'DATA MIGRATION'),
									LV_HNS_APP_TG(I).V_NTCEINFRNGMNT,
									LV_HNS_APP_TG(I).V_INFRNGMNTACTN_X,
									LV_HNS_APP_TG(I).V_INFUSER,
									LV_HNS_APP_TG(I).V_INFPROCESS_DT,
									LV_HNS_APP_TG(I).V_INFREASON_X,
									LV_HNS_APP_TG(I).V_INFREPORT_N
								);  
								
			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                    PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                    NULL,
                                                                                                                    'T'                                                                                                                    
                                                                                                                    );




						DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;
						DELETE FROM VESSEL_CALL WHERE VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;  
						DELETE FROM APPLICATION_SUBMISSION WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;


					CONTINUE;
								
			END;	
            /*     
			--Removed by rohit as V_VSL_REF_ID_OUT should be passed as IN parameter for PROC_2_VC_AS
			
            PROC_1_VSL_REF (LV_HNS_APP_TG(I).V_MSW_VSL_ID_N ,LV_HNS_APP_TG(I).V_NTCEVSLRECID_N ,LV_HNS_APP_TG(I).V_NTCEVSL_M ,
            LV_HNS_APP_TG(I).V_NTCEVSLIMO_N ,LV_HNS_APP_TG(I).V_NTCECALLSIGN_M ,LV_HNS_APP_TG(I).V_NTCEVSLGT_Q ,LV_HNS_APP_TG(I).V_NTCEFLAG_C ,LV_HNS_APP_TG(I).V_NTCEVSLTY_C,V_VSL_REF_ID_OUT,V_FLAG_VSL_REF );
			
			IF V_FLAG_VSL_REF ='F'
			THEN
			
			DELETE FROM HNS_APPLICATION WHERE APPLN_REF_N = LV_HNS_APP_SEQ;
			
			DELETE FROM VESSEL_CALL WHERE VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;  

			DELETE FROM APPLICATION_SUBMISSION WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;
			
			CONTINUE;
			
			END IF;
			*/
			ELSE --else part on inner IF statement
			DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;
			CONTINUE;		
			END IF; 
		
		ELSE
		CONTINUE;
		END IF;




			EXCEPTION
			WHEN OTHERS THEN
            V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                   PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                    PV_RUN_ID, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                    'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
																													'MSW_APPLN_REF_ID_X  :'||V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
																													'VSL_CALL_ID_N  :'||V_MSW_VSL_CALL_ID_OUT||'<{||}>'||
																													'EXTL_APPLN_REF_ID_X  :'||LV_HNS_APP_TG(I).V_NTCE_N          ||'<{||}>'||
																													'MSW_VSL_ID_N  :'||LV_HNS_APP_TG(I).V_MSW_VSL_ID_N    ||'<{||}>'||
																													'VOY_N_X  :'||LV_HNS_APP_TG(I).V_NTCEVOY_N||'<{||}>'||
																													'ETA_DT  :'||LV_HNS_APP_TG(I).V_NTCEVSLESTARR_DT||'<{||}>'||
																													'ETD_DT  :'||LV_HNS_APP_TG(I).V_NTCEVSLESTDEP_DT||'<{||}>'||
                                                                                                                    'APPLCNT_ID_X:'||LV_HNS_APP_TG(I).V_APPLCNT_ID_X||'<{||}>'||
																													'CONT_PERS_M  :'||LV_HNS_APP_TG(I).V_NTCECNTCT_M||'<{||}>'||
																													'CO_M  :'||LV_HNS_APP_TG(I).V_NTCECO_M ||'<{||}>'||
																													'EMAIL_X  :'||LV_HNS_APP_TG(I).V_NTCEEMLADDR_X||'<{||}>'||
																													'LST_PORT_CTRY_X  :'||LV_HNS_APP_TG(I).V_NTCELSTPORTDESC_X||'<{||}>'||
																													'LAST_PORT_C  :'|| LV_HNS_APP_TG(I).V_NTCELSTPORT_C||'<{||}>'||
																													'CFT_LIC_N  :'|| LV_HNS_APP_TG(I).V_NTCECRAFTLIC_N||'<{||}>'||
																													'CGO_TY_C  :'||LV_HNS_APP_TG(I).V_NTCECGOTY_C||'<{||}>'||
																													'APPLN_ST_C  :'||'APPROVED'||'<{||}>'||
																													'PROCESSED_BY_X  :'||NULL||'<{||}>'||
																													'PROCESSED_ON_DT  :'||NULL||'<{||}>'||
																													'PROCESSING_REM_X  :'||NULL||'<{||}>'||
																													'DELETED_I  :'||0||'<{||}>'||
																													'LOCK_VER_N  :'||0||'<{||}>'||
																													'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_CRTN_DT||'<{||}>'||
																													'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_NTCEAPPLNT_M                   ||'<{||}>'||
																													'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_UPDT_DT||'<{||}>'||
																													'UPT_BY_X  :'||NVL(LV_HNS_APP_TG(I).V_UPDT_BY,'DATA MIGRATION')||'<{||}>'||
																													'INFRNGMNT_C  :'||LV_HNS_APP_TG(I).V_NTCEINFRNGMNT||'<{||}>'||
																													'INFRNGMNT_ACTN_X  :'||LV_HNS_APP_TG(I).V_INFRNGMNTACTN_X||'<{||}>'||
																													'INFRNGMNT_USR_M  :'||LV_HNS_APP_TG(I).V_INFUSER||'<{||}>'||
																													'INFRNGMNT_PROCESS_DT  :'||LV_HNS_APP_TG(I).V_INFPROCESS_DT||'<{||}>'||
																													'INFRNGMNT_PROCESS_RSN_X  :'||LV_HNS_APP_TG(I).V_INFREASON_X||'<{||}>'||
																													'INFRNGMNT_RPT_N  :'||LV_HNS_APP_TG(I).V_INFREPORT_N,
                                                                                                                    'T'                                                                                                                    
                                                                                                                    );




						DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;
						DELETE FROM VESSEL_CALL WHERE VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;  
						DELETE FROM APPLICATION_SUBMISSION WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT;


					CONTINUE;
			END;

/***INSERTION STARTS INTO HNS_APPLICATION_SUBSTANCE*************/



            BEGIN
                    INSERT INTO HNS_APPLICATION_SUBSTANCE (
                        HNS_APPLN_SUBST_ID_N,
						APPLN_REF_N,
						DELETED_I,
						SEQ_N,
						SUBST_C,
						SUBST_M,
						UN_N,
						POLLN_CAT_C,
						CGO_GRP_C,
						FLASH_PT_N,
						HZ_IBC_C,
						SUBST_QTY_Q,
						STW_ONBD_X,
						OPERN_C,
						LOCN_C,
						OPERN_DT,
						CRT_ON_DT,
						CRT_BY_X,
						UPT_ON_DT,
						UPT_BY_X,
						LOCK_VER_N,
						LOCN_M				
                    )
					VALUES (
                        LV_HNS_APPSUB_SEQ,
                        LV_HNS_APP_SEQ,
                        0,
                        LV_HNS_APP_TG(I).V_NTCEDTLSNO_N,
                        LV_HNS_APP_TG(I).V_NTCESUBST_C,
                        LV_HNS_APP_TG(I).V_NTCESUBST_M,
                        LV_HNS_APP_TG(I).V_NTCEUN_N,
                        LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X,
                        LV_HNS_APP_TG(I).V_NTCECGOGRP_C,
                        LV_HNS_APP_TG(I).V_NTCEFLASHPT,
                        LV_HNS_APP_TG(I).V_NTCEHZIBC_X,
                        LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q,
                        LV_HNS_APP_TG(I).V_NTCESTWONBD,
                        LV_HNS_APP_TG(I).V_NTCEACTN_X,
                        LV_HNS_APP_TG(I).V_NTCELOCN_C,
                        LV_HNS_APP_TG(I).V_NTCEOPERN_DT,
                        LV_HNS_APP_TG(I).V_DTLCRTN_DT,
                        LV_HNS_APP_TG(I).V_DTLCRTNBY_M,
                        LV_HNS_APP_TG(I).V_DTLUPDT_DT,
                        LV_HNS_APP_TG(I).V_DTLUPDT_BY,
                        0,
						LV_HNS_APP_TG(I).V_NTCELOCN_M
                    );

                   -- COMMIT;
                EXCEPTION
                WHEN OTHERS THEN
                V_ERR_CODE := SQLCODE;
				V_ERR_MSG := SUBSTR(SQLERRM, 1, 200);
				V_SQLERRM := V_ERR_CODE
							 || V_ERR_MSG
							 || DBMS_UTILITY.FORMAT_ERROR_STACK;
                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'ERROR',
                                                                                                                            PV_RUN_ID,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||V_SQLERRM,
                                                                                                                            'HNS_APPLN_SUBST_ID_N  :'||LV_HNS_APPSUB_SEQ||'<{||}>'||
																															'APPLN_REF_N  :'||LV_HNS_APP_SEQ||'<{||}>'||
																															'DELETED_I  :'||0||'<{||}>'||
																															'SEQ_N  :'||LV_HNS_APP_TG(I).V_NTCEDTLSNO_N||'<{||}>'||
																															'SUBST_C  :'||LV_HNS_APP_TG(I).V_NTCESUBST_C||'<{||}>'||
																															'SUBST_M  :'||LV_HNS_APP_TG(I).V_NTCESUBST_M||'<{||}>'||
																															'UN_N  :'||LV_HNS_APP_TG(I).V_NTCEUN_N||'<{||}>'||
																															'POLLN_CAT_C  :'||LV_HNS_APP_TG(I).V_NTCEPOLLNCAT_X||'<{||}>'||
																															'CGO_GRP_C  :'||LV_HNS_APP_TG(I).V_NTCECGOGRP_C||'<{||}>'||
																															'FLASH_PT_N  :'||LV_HNS_APP_TG(I).V_NTCEFLASHPT||'<{||}>'||
																															'HZ_IBC_C  :'||LV_HNS_APP_TG(I).V_NTCEHZIBC_X||'<{||}>'||
																															'SUBST_QTY_Q  :'||LV_HNS_APP_TG(I).V_NTCEVSLCARRYQTY_Q||'<{||}>'||
																															'STW_ONBD_X  :'||LV_HNS_APP_TG(I).V_NTCESTWONBD||'<{||}>'||
																															'OPERN_C  :'||LV_HNS_APP_TG(I).V_NTCEACTN_X||'<{||}>'||
																															'LOCN_C  :'||LV_HNS_APP_TG(I).V_NTCELOCN_C||'<{||}>'||
																															'OPERN_DT  :'||LV_HNS_APP_TG(I).V_NTCEOPERN_DT||'<{||}>'||
																															'CRT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLCRTN_DT||'<{||}>'||
																															'CRT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLCRTNBY_M||'<{||}>'||
																															'UPT_ON_DT  :'||LV_HNS_APP_TG(I).V_DTLUPDT_DT||'<{||}>'||
																															'UPT_BY_X  :'||LV_HNS_APP_TG(I).V_DTLUPDT_BY||'<{||}>'||
																															'LOCK_VER_N  :'||0||'<{||}>'||
																															'LOCN_M  :'||LV_HNS_APP_TG(I).V_NTCELOCN_M
                                                                                                                            , 'T'
                                                                                                                            );

                      DELETE FROM HNS_APPLICATION WHERE APPLN_REF_N = LV_HNS_APP_SEQ;
					  DELETE FROM APPLICATION_SUBMISSION WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT ;
					  DELETE FROM VESSEL_CALL WHERE  VSL_CALL_ID_N = V_MSW_VSL_CALL_ID_OUT ; 
					  DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;


            END;

           END LOOP;

        
    END LOOP;

    COMMIT;

  CLOSE CUR_HNSAP2;





--------COUNT OF STAGING TABLE

    SELECT COUNT(*)
    INTO V_ST_COUNT
    FROM ST_HN_NTCEHDR;

    SELECT COUNT(*)
    INTO V_ST_COUNT1
    FROM ST_HN_NTCEDTL;

---COUNT OF INTERMEDIATE TABLE   

    SELECT COUNT(*)
    INTO V_SRC_COUNT
    FROM SI_HNS_APP;

----COUNT OF TARGRT TABLE           

    SELECT COUNT(*)
    INTO V_TGT_COUNT
    FROM HNS_APPLICATION; 

    SELECT COUNT(*)
    INTO V_TGT_COUNT1
    FROM HNS_APPLICATION_SUBSTANCE;
	
	
	SELECT COUNT(*)
    INTO V_CNT_VR
    FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N IN (SELECT VSL_REF_ID_N FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C = 'HNS');
	
	

	SELECT COUNT(*)INTO V_CNT_AS  FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C = 'HNS';
	
	SELECT COUNT(*)INTO V_CNT_VC  FROM VESSEL_CALL where vsl_call_id_n in (SELECT vsl_call_id_n FROM APPLICATION_SUBMISSION WHERE APPLN_TY_C = 'HNS') ;
	

----HNS_APPLICATION


	IF (V_TGT_COUNT =  V_SRC_COUNT) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
        V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

	ELSIF V_TGT_COUNT  <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
        V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||'ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


	ELSIF (V_TGT_COUNT  <> V_SRC_COUNT OR V_TGT_COUNT  = V_SRC_COUNT ) AND (V_TGT_COUNT = 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', 
       V_TGT_COUNT ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');
    END IF;



---HNS_APPLICATION_SUBSTANCE   

	IF (V_TGT_COUNT1 =  V_SRC_COUNT) AND V_SRC_COUNT <>  0  AND V_TGT_COUNT1 <> 0 THEN 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL', 
        V_TGT_COUNT1 ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE TABLE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

	ELSIF V_TGT_COUNT1 <> V_SRC_COUNT AND V_TGT_COUNT1 <> 0 THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL', 
        V_TGT_COUNT1 ||' OUT OF ' ||V_SRC_COUNT ||'ROWS  HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE TABLE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


	ELSIF (V_TGT_COUNT1  <> V_SRC_COUNT OR V_TGT_COUNT1  = V_SRC_COUNT ) AND (V_TGT_COUNT1= 0) THEN 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION_SUBSTANCE', 'PROC_2_HNS_APPL', 
       V_TGT_COUNT1 ||' OUT OF ' ||V_SRC_COUNT ||' ROWS HAVE BEEN INSERTED INTO HNS_APPLICATION_SUBSTANCE TABLE' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');
    END IF;








    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_HN_NTCEHDR', V_ST_COUNT, 'SI_HNS_APP', V_SRC_COUNT,'N');


    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_HNS_APP', V_SRC_COUNT, 'HNS_APPLICATION', V_TGT_COUNT,'N');


    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_HN_NTCEHDR', V_ST_COUNT, 'HNS_APPLICATION', V_TGT_COUNT,'Y');



 ---   PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_HNS_APP', V_SRC_COUNT, 'HNS_APPLICATION_SUBSTANCE', V_TGT_COUNT1,'N');



    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_HN_NTCEDTL', V_ST_COUNT1, 'HNS_APPLICATION_SUBSTANCE', V_TGT_COUNT1,'Y');
	
	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_HN_NTCEHDR', V_SRC_COUNT, 'VESSEL_REFERENCE', V_CNT_VR,'Y');
	
	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('HNS_APPLICATION', V_TGT_COUNT, 'VESSEL_CALL_HNS', V_CNT_VC,'Y');	
	
	PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('HNS_APPLICATION', V_TGT_COUNT, 'APPLICATION_SUBMISSION_HNS', V_CNT_AS,'Y');

EXCEPTION
    WHEN OTHERS THEN
        V_ERR_CODE := SQLCODE;
        V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)
                     || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
                     || 'HNS_APPLICATION';

        V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('HNS_APPLICATION', 'PROC_2_HNS_APPL', V_SQLERRM, 'ERROR',PV_RUN_ID,NULL,NULL,'T');
END;
/
