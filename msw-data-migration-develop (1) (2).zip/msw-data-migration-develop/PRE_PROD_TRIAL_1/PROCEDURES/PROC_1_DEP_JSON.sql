create or replace procedure PROC_1_DEP_JSON
is 


LVAL   clob;

v_err_code  number;
v_err_msg  varchar2(4000);

v_sqlerrm   varchar2(4000);
begin 


for i in (select a.	APPLN_REF_N			as		arr_APPLN_REF_N		,
a.	MSW_APPLN_REF_ID_X			as		arr_MSW_APPLN_REF_ID_X		,
a.	EXTL_APPLN_REF_ID_X			as		arr_EXTL_APPLN_REF_ID_X		,
a.	APPLCNT_ID_X			as		arr_APPLCNT_ID_X		,
a.	VSL_CALL_ID_N			as		arr_VSL_CALL_ID_N		,
a.	MSW_VSL_ID_N			as		arr_MSW_VSL_ID_N		,
a.	GD_TY_C			as		arr_GD_TY_C		,
a.	AGT_DECLR_AC_N			as		arr_AGT_DECLR_AC_N		,
a.	GDV_N			as		arr_GDV_N		,
a.	CONTACT_PERS_M			as		arr_CONTACT_PERS_M		,
a.	OFF_TEL_N			as		arr_OFF_TEL_N		,
a.	HOME_TEL_N			as		arr_HOME_TEL_N		,
a.	MOBILE_N			as		arr_MOBILE_N		,
a.	FAX_N			as		arr_FAX_N		,
a.	EMAIL_ADDR_X			as		arr_EMAIL_ADDR_X		,
a.	VSL_GT_Q			as		arr_VSL_GT_Q		,
a.	NEW_VSL_GT_Q			as		arr_NEW_VSL_GT_Q		,
a.	ARR_DECLR_DT			as		arr_ARR_DECLR_DT		,
a.	ARR_CTRY_FR_C			as		arr_ARR_CTRY_FR_C		,
a.	ARR_LAST_PORT_C			as		arr_ARR_LAST_PORT_C		,
a.	ARR_PAX_Q			as		arr_ARR_PAX_Q		,
a.	ARR_CREW_Q			as		arr_ARR_CREW_Q		,
a.	ARR_CGO_Q			as		arr_ARR_CGO_Q		,
a.	ARR_MSTR_ON_ARR_X			as		arr_ARR_MSTR_ON_ARR_X		,
a.	ARR_LOCN_ON_ARR_C			as		arr_ARR_LOCN_ON_ARR_C		,
a.	ARR_LOCN_ON_ARR_M			as		arr_ARR_LOCN_ON_ARR_M		,
a.	ARR_GRID_REF_N			as		arr_ARR_GRID_REF_N		,
a.	ARR_MOTHER_GDV_N			as		arr_ARR_MOTHER_GDV_N		,
a.	ARR_BUNKR_Q			as		arr_ARR_BUNKR_Q		,
a.	ARR_BUNKR_GR_C			as		arr_ARR_BUNKR_GR_C		,
a.	ARR_CST_N			as		arr_ARR_CST_N		,
a.	ARR_CHARTERER_NAT_C			as	arr_ARR_CHARTERER_NAT_C		,
a.	ARR_SLN_C			as		arr_ARR_SLN_C		,
a.	CALL_REC_ST_C			as		arr_CALL_REC_ST_C		,
a.	RTA_DT			as		arr_RTA_DT		,
a.	PCC_EXEMPN_RSN_X			as		arr_PCC_EXEMPN_RSN_X		,
a.	OFFICIAL_GDV_N			as		arr_OFFICIAL_GDV_N		,
a.	APPLN_ST_C			as		arr_APPLN_ST_C		,
a.	PROCESSED_BY_X			as		arr_PROCESSED_BY_X		,
a.	PROCESSED_ON_DT			as		arr_PROCESSED_ON_DT		,
a.	PROCESSING_REM_X			as		arr_PROCESSING_REM_X		,
a.	INTL_REM_X			as		arr_INTL_REM_X		,
a.	UNIT_NO_FROM			as		arr_UNIT_NO_FROM		,
a.	UNIT_NO_TO			as		arr_UNIT_NO_TO		,
a.	POSTAL_CODE			as		arr_POSTAL_CODE		,
a.	APPLICANT_NAME			as		arr_APPLICANT_NAME		,
a.	BUILDING_NAME			as		arr_BUILDING_NAME		,
a.	FIN			as		arr_FIN		,
a.	NRIC			as		arr_NRIC		,
a.	PASSPORT			as		arr_PASSPORT		,
a.	STREET_NAME			as		arr_STREET_NAME		,
a.	DELETED_I			as		arr_DELETED_I		,
a.	LOCK_VER_N			as		arr_LOCK_VER_N		,
a.	CRT_ON_DT			as		arr_CRT_ON_DT		,
a.	CRT_BY_N			as		arr_CRT_BY_N		,
a.	UPT_ON_DT			as		arr_UPT_ON_DT		,
a.	UPT_BY_X			as		arr_UPT_BY_X		,
d.	APPLN_REF_N			as		dep_APPLN_REF_N		,
d.	MSW_APPLN_REF_ID_X			as		dep_MSW_APPLN_REF_ID_X		,
d.	EXTL_APPLN_REF_ID_X			as		dep_EXTL_APPLN_REF_ID_X		,
d.	GDV_N			as		dep_GDV_N		,
d.	DEP_DECLR_DT			as		dep_DEP_DECLR_DT		,
d.	VSL_GT_ON_DEP_Q			as		dep_VSL_GT_ON_DEP_Q		,
d.	AGT_DECLR_AC_N			as		dep_AGT_DECLR_AC_N		,
d.	NX_PORT_CTRY_C			as		dep_NX_PORT_CTRY_C		,
d.	NX_PORT_C			as		dep_NX_PORT_C		,
d.	NX_PORT_M			as		dep_NX_PORT_M		,
d.	PERS_Q			as		dep_PERS_Q		,
d.	PAX_Q			as		dep_PAX_Q		,
d.	CREW_Q			as		dep_CREW_Q		,
d.	CGO_Q			as		dep_CGO_Q		,
d.	MSTR_ON_DEP_X			as		dep_MSTR_ON_DEP_X		,
d.	MOTHER_GDV_N			as		dep_MOTHER_GDV_N		,
d.	BUNKR_Q			as		dep_BUNKR_Q		,
d.	BUNKR_GR_C			as		dep_BUNKR_GR_C		,
d.	CST_N			as		dep_CST_N		,
d.	CHARTERER_NAT_C			as		dep_CHARTERER_NAT_C		,
d.	SLN_C			as		dep_SLN_C		,
d.	APPLN_ST_C			as		dep_APPLN_ST_C		,
d.	PROCESSED_BY_X			as		dep_PROCESSED_BY_X		,
d.	PROCESSED_ON_DT			as		dep_PROCESSED_ON_DT		,
d.	PROCESSING_REM_X			as		dep_PROCESSING_REM_X		,
d.	COMPANY_NAME			as		dep_COMPANY_NAME		,
d.	DEPARTURE_LOCATION			as		dep_DEPARTURE_LOCATION		,
d.	MPA_ACCOUNT_NAMES			as		dep_MPA_ACCOUNT_NAMES		,
d.	DELETED_I			as		dep_DELETED_I		,
d.	LOCKVER_N			as		dep_LOCKVER_N		,
d.	CRT_ON_DT			as		dep_CRT_ON_DT		,
d.	CRT_BY_N			as		dep_CRT_BY_N		,
d.	UPT_ON_DT			as		dep_UPT_ON_DT		,
d.	UPT_BY_X			as		dep_UPT_BY_X		,
d.	INTL_REM_X			as		dep_INTL_REM_X		

from arrival_gd_application a ,  departure_gd_application d where a.gdv_n = d.gdv_n  )

loop  --  loop of departute GD 

LVAL := '{';
LVAL := LVAL ||  '"agentDeclaredAccountNumber": "'||nvl(trim(i.arr_AGT_DECLR_AC_N),'null')||'",';
  LVAL := LVAL ||'"mpaAccountNames": "'||nvl(trim(i.dep_MPA_ACCOUNT_NAMES),'null')  ||'",';
  LVAL := LVAL ||'"mobilePhoneNumber":'|| nvl(trim(i.arr_MOBILE_N),'null') ||',';
  LVAL := LVAL ||'"emailAddress": "'||nvl(trim(i.arr_EMAIL_ADDR_X),'null')||'",';
  LVAL := LVAL ||'"faxNumber":'|| nvl(trim(i.arr_FAX_N),'null')||',';
  LVAL := LVAL ||'"applicantName": "'||nvl(trim(i.arr_APPLICANT_NAME),'null')||'",';
  LVAL := LVAL ||'"contactPersonName": "'||nvl(trim(i.arr_CONTACT_PERS_M),'null')||'",';
  LVAL := LVAL ||'"officePhoneNumber": "'|| nvl(trim(i.arr_OFF_TEL_N),'null')||'",';
  LVAL := LVAL ||'"vesselName":"'||'null'||'",';
  LVAL := LVAL ||'"imoNo":"'||'null'||'",';
  LVAL := LVAL ||'"craftLicenceNo":'|| 'null'||',';
  LVAL := LVAL ||'"nameOfOwner": "'||'null'||'",';
  LVAL := LVAL ||'"grossTonnage":'|| 'null'||',';
  LVAL := LVAL ||'"callSign": "'||'null'||'",';
  LVAL := LVAL ||'"flag": "'||'null'||'",';
  LVAL := LVAL ||'"officalNo": "'||nvl(trim(i.arr_OFF_TEL_N),'null')||'",';
  LVAL := LVAL ||'"characterNationalityCode": "'||'null'||'",';
  LVAL := LVAL ||'"shippingLineCode": "'||'null'||'",';
  LVAL := LVAL ||'"gdvNumber": "'||NVL(trim(i.DEP_GDV_N),'NULL')||'",';
  LVAL := LVAL ||'"officialGDVNumber": "'||trim(i.arr_OFFICIAL_GDV_N)||'",';
  LVAL := LVAL ||'"mdo": '||'null'||',';
  LVAL := LVAL ||'"mfo":'|| 'null'||',';
  LVAL := LVAL ||'"checkTerm": '||'null'||',';
  LVAL := LVAL ||'"mgo":'|| 'null'||',';
  LVAL := LVAL ||'"shipYardsLocation": [],';
  LVAL := LVAL ||'"nextPortCode": "'||nvl(trim(i.dep_NX_PORT_C),'null')||'",';
  LVAL := LVAL ||'"nextPortCountry": "'||nvl(trim(i.dep_NX_PORT_CTRY_C),'null')||'",';
  LVAL := LVAL ||'"departureDateTime": "'||'null'||'",';
  LVAL := LVAL ||'"nextPortName": "'||nvl(trim(i.dep_NX_PORT_M),'null')||'",';
  LVAL := LVAL ||'"departureReasons": "'||'null' ||'",';
  LVAL := LVAL ||'"departureOtherReasons": "'||'null'  ||'",';
  LVAL := LVAL ||'"departureLocation": "'  ||nvl(trim(i.dep_DEPARTURE_LOCATION),'null') ||'",';
  LVAL := LVAL ||'"masterOnDeparture": "'||nvl(trim(i.dep_MSTR_ON_DEP_X),'null')||'",';
  LVAL := LVAL ||'"numberOfCrew":'|| nvl(trim(i.dep_CREW_Q),'null')||',';
  LVAL := LVAL ||'"totalPassengersOnBoard":'|| nvl(trim(i.dep_PAX_Q),'null')||',';
  LVAL := LVAL ||'"totalCargoOnBoard": '||nvl(trim(i.dep_CGO_Q),'null')||',';
  LVAL := LVAL ||'"totalPersonsOnBoard": "'||nvl(trim(i.dep_PERS_Q),'null') ||'",';
  LVAL := LVAL ||'"arrivalMotherVessel": "' ||'null' ||'",';
  LVAL := LVAL ||'"motherGDV": "'||nvl(trim(i.dep_MOTHER_GDV_N),'null')||'",';
  LVAL := LVAL ||'"declaredArrivalDateTime":"'|| nvl(trim(i.arr_arr_declr_dt),'null')||'",';
  LVAL := LVAL ||'"motherVesselArrivalDateTime":'|| 'null'||',';
  LVAL := LVAL ||'"confirm": "'||'null'  || '",';
  LVAL := LVAL ||'"vesselCallId":'||nvl(trim(i.arr_VSL_CALL_ID_N),'null')||',';
  LVAL := LVAL ||'"vesselId":'|| nvl(trim(i.arr_MSW_VSL_ID_N),'null')||',';
  LVAL := LVAL ||'"otherAfloatActivities": "'|| 'null' ||'",';
  LVAL := LVAL ||'"departureGDPurposeOfCallEvents": [';







 for j in (select  PURPCALL_C, OTHERS_PURPOSE_X 
         from departure_gd_purpose_of_call
         where APPLN_REF_N =I.dep_APPLN_REF_N )

 loop

    LVAL := LVAL ||    '{';
     LVAL := LVAL ||  '"purposeOfCall": "'|| NVL(trim(j.PURPCALL_C),'NULL')||'",';
      LVAL := LVAL || '"othersPurpose": "'||NVL(trim(j.OTHERS_PURPOSE_X),'NULL')  ||'"';
    LVAL := LVAL || '},';

    end loop;

     LVAL :=  rtrim(LVAL,',');

     LVAL := LVAL || '],';

 LVAL := LVAL || '"mswApplicationReferenceOfAGD": "'||NVL(trim(i.arr_MSW_APPLN_REF_ID_X),'NULL')||'",';
LVAL := LVAL ||  '"createdOn": "'||NVL(trim(i.arr_CRT_ON_DT),'NULL')||'",';
LVAL := LVAL ||  '"createdBy": "'||NVL(trim(i.arr_CRT_BY_N),'NULL')||'",';
LVAL := LVAL ||  '"applicantId": "'||NVL(trim(i.arr_APPLCNT_ID_X),'NULL')||'",';





LVAL := LVAL ||   '"departureGDShipCertificates": [';
--need to put  the loop ..

LVAL := LVAL ||      '{';
LVAL := LVAL ||       '"classReportOnShipCertificatesStatus":'|| 'null'||',';
LVAL := LVAL ||       '"issuingClass": "'||'null' ||'",';
LVAL := LVAL ||       '"issueDate": "'||'null'||'",';
LVAL := LVAL ||       '"documentId":'|| 'null'||',';
LVAL := LVAL ||       '"certificateType": "'||'null'||'",';
LVAL := LVAL ||       '"classReportDocuments": "'||'null' ||'",';
LVAL := LVAL ||       '"createdBy": "'||'null'||'",';
LVAL := LVAL ||      ' "createdOn": "'||'null'||'"';
LVAL := LVAL ||     '},';
LVAL := LVAL ||      '{';
LVAL := LVAL ||      '"registrationStatus": "'||'null'  ||'",';
LVAL := LVAL ||      '"officialNo": "'||'null' ||'",';
LVAL := LVAL ||      '"issuingAuthority": "'||'null'  ||'",';
LVAL := LVAL ||      '"issueDate": "' ||'null'  ||'",';
LVAL := LVAL ||      '"portOfRegistry": "'||'null'  ||'",';
LVAL := LVAL ||      '"expiryDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"nameOfOwner": "'  || 'null'    ||'",';
LVAL := LVAL ||      '"yearBuilt": "'||'null'  || '",';
LVAL := LVAL ||      '"countryOfOwner": "' ||'null'  ||'",';
LVAL := LVAL ||      '"length": "'||'null'  ||'",';
LVAL := LVAL ||      '"breadth": "'||'null'  ||'",';
LVAL := LVAL ||      '"depth": "'||'null'  ||'",';
LVAL := LVAL ||      '"certificateType": "'|| 'null'||'",';
LVAL := LVAL ||      '"createdBy": "'||'NCS'||'",';
LVAL := LVAL ||     ' "createdOn": "'||'null'||'"';
LVAL := LVAL ||    '},';
LVAL := LVAL ||    '{';
LVAL := LVAL ||      '"submitNewIntsOilPollutionPreventionCertificates":'|| 'null'||',';
LVAL := LVAL ||      '"issuingClass": "'||'null'  ||'",';
LVAL := LVAL ||      '"issueDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"dateOfDelivery": "'||'null'  ||'",';
LVAL := LVAL ||      '"dueDate": "'||'null'  ||'",';
LVAL := LVAL ||      '"sopepSmpepIsOnBoard": "'|| 'null'  ||'",';
LVAL := LVAL ||      '"dwt": "'||'null'  ||'",';
LVAL := LVAL ||      '"certificateType": "'||'null'||'",';
LVAL := LVAL ||      '"createdBy": "'||'null'||'",';
LVAL := LVAL ||      '"createdOn": "'||'null'||'"';
LVAL := LVAL ||     '}';
LVAL := LVAL ||   ']';
LVAL := LVAL || '}';


insert into SI_JSON values (null,LVAL,sysdate,'GDD',trim(i.dep_MSW_APPLN_REF_ID_X));

LVAL := null;


end loop ;--of departure GD




exception  --- exception of   outer begin 


    WHEN OTHERS THEN
        v_err_code := sqlcode;
        v_err_msg := substr(sqlerrm, 1, 2000);
        v_sqlerrm := v_err_code
                     || v_err_msg
                     || dbms_utility.format_error_stack;
        pkg_datamigration_generic.proc_trace_exception('DEP_GD_JSON', 'proc_1_Dep_json', v_sqlerrm, 'ERROR',null,NULL,NULL,'T');


end ;
/