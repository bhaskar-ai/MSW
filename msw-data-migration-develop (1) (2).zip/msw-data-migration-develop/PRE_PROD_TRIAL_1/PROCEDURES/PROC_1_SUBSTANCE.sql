CREATE OR REPLACE PROCEDURE PROC_1_SUBSTANCE (PV_RUN_ID IN   NUMBER) IS  


/***********************************************************************************************************
PROCEDURE NAME : PROC_1_SUBSTANCE
CREATED BY     : ROHIT KHOOL
DATE           : 30-AUG-2019
PURPOSE        : INSERTING DATA INTO SUBSTANCE
MODIFIED BY    : 
MODIFIED DATE  : 

*************************************************************************************************************/


	CURSOR CUR_SUBSTANCE IS
    SELECT  SUBST_M,
			UN_N,
			POLLNCAT_X,
			CGOGRP_C,
			FLASHPT_X,
			HZIBC_X,
			SUBSTTY_C,
			SUBST_C,
			CRTN_DT,
			CRTNBY_M
    FROM   
	ST_HN_SUBSTPARAM;

    TYPE REC_SUBSTANCE IS RECORD (
		V_SUBST_M		ST_HN_SUBSTPARAM.SUBST_M%TYPE,
		V_UN_N			ST_HN_SUBSTPARAM.UN_N%TYPE,
		V_POLLNCAT_X	ST_HN_SUBSTPARAM.POLLNCAT_X%TYPE,
		V_CGOGRP_C		ST_HN_SUBSTPARAM.CGOGRP_C%TYPE,
		V_FLASHPT_X		ST_HN_SUBSTPARAM.FLASHPT_X%TYPE,
		V_HZIBC_X		ST_HN_SUBSTPARAM.HZIBC_X%TYPE,
		V_SUBSTTY_C		ST_HN_SUBSTPARAM.SUBSTTY_C%TYPE,
		V_SUBST_C		ST_HN_SUBSTPARAM.SUBST_C%TYPE,
		V_CRTN_DT		ST_HN_SUBSTPARAM.CRTN_DT%TYPE,
		V_CRTNBY_M		ST_HN_SUBSTPARAM.CRTNBY_M%TYPE
    );
	
    TYPE TYPE_SUBSTANCE IS   TABLE OF REC_SUBSTANCE;
	
    LV_SUBSTANCE     TYPE_SUBSTANCE;    
   

    V_SRC_COUNT            NUMBER;
    V_TGT_COUNT            NUMBER;
    V_ERR_CODE             NUMBER;
    V_ERR_MSG              VARCHAR2(4000);
    V_SQLERRM              VARCHAR2(4000);
	
BEGIN --OUTER BEGIN FOR PROC_1_SUBSTANCE



    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', 'INSERTION INTO  SUBSTANCE STARTS', 'START', NULL, NULL, NULL, 'T'); 


    OPEN CUR_SUBSTANCE;
    LOOP   -- CURSOR LOOP STARTS 
	
        FETCH CUR_SUBSTANCE BULK COLLECT INTO LV_SUBSTANCE LIMIT 10000;
        EXIT WHEN LV_SUBSTANCE.COUNT = 0;
		
        FOR I IN LV_SUBSTANCE.FIRST..LV_SUBSTANCE.LAST LOOP     --   FOR LOOP STARTS  WHICH INSERT DATA INTO THE   TARGET TABLE 
		
            BEGIN
                INSERT INTO SUBSTANCE	(
										SUBSTANCE_ID,
										SUBSTANCE_M,
										UN_X,
										POLLUTION_CAT_C,
										CGO_GRP_C,
										FLASH_PT_X,
										IBC_HAZ_C,
										SUBSTANCE_TY_C,
										CRT_ON_DT,
										CRT_BY_N,
										LST_UPD_ON_DT,
										LST_UPD_BY_N,
										LOCK_VER_N,
										DELETED_I
										)
								VALUES (
										SEQ_SUBSTANCE.NEXTVAL,		
										LV_SUBSTANCE(I).V_SUBST_M,		
										LV_SUBSTANCE(I).V_UN_N,		
										LV_SUBSTANCE(I).V_POLLNCAT_X,		
										LV_SUBSTANCE(I).V_CGOGRP_C,		
										LV_SUBSTANCE(I).V_FLASHPT_X,		
										LV_SUBSTANCE(I).V_HZIBC_X,		
					NVL(LV_SUBSTANCE(I).V_SUBSTTY_C,LV_SUBSTANCE(I).V_SUBST_C),
										LV_SUBSTANCE(I).V_CRTN_DT,		
										LV_SUBSTANCE(I).V_CRTNBY_M,	
										SYSDATE,
										'DATA MIGRATION',
										0,		
										0
										);

            EXCEPTION
                WHEN OTHERS THEN
                V_ERR_CODE := SQLCODE;
                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
                PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION	('SUBSTANCE', 'PROC_1_SUBSTANCE', V_SQLERRM , 'ERROR', PV_RUN_ID, V_ERR_MSG,
																	' SUBSTANCE_ID: '||SEQ_SUBSTANCE.CURRVAL||
																	' SUBSTANCE_M: '||LV_SUBSTANCE(I).V_SUBST_M||
																	' UN_X: '||LV_SUBSTANCE(I).V_UN_N||
																	' POLLUTION_CAT_C: '||LV_SUBSTANCE(I).V_POLLNCAT_X||
																	' CGO_GRP_C: '||LV_SUBSTANCE(I).V_CGOGRP_C||
																	' FLASH_PT_X: '||LV_SUBSTANCE(I).V_FLASHPT_X||
																	' IBC_HAZ_C: '||LV_SUBSTANCE(I).V_HZIBC_X||
																	' SUBSTANCE_TY_C: '||LV_SUBSTANCE(I).V_SUBSTTY_C||
																	' CRT_ON_DT: '||LV_SUBSTANCE(I).V_CRTN_DT||
																	' CRT_BY_N: '||LV_SUBSTANCE(I).V_CRTNBY_M||
																	' LST_UPD_ON_DT: '||SYSDATE||
																	' LST_UPD_BY_N: '||'DATA MIGRATION'||
																	' LOCK_VER_N: '||0||
																	' DELETED_I: '||0,
																	'B'
																);

            END;
			END LOOP;   -- END LOOP STARTS  INT THE TARGET TABLE 

    END LOOP;   -- CURSOR LOOP ENDS
	
	CLOSE CUR_SUBSTANCE;



/***********************************************************************************************************
RECONCILING THE COUNT OF STAGNG TABLE  TABLE  AND TARGET TABLE 
*************************************************************************************************************/
 --FIND THE COUNT OF QUERY (SOURCE TABLE) TO COMPARE THE COUNT WITH THE THAT OF SOURCE INRERMEWDIATE 

    SELECT
    COUNT(*) INTO V_SRC_COUNT
    FROM ST_HN_SUBSTPARAM;

    SELECT
    COUNT(*) INTO V_TGT_COUNT
    FROM  SUBSTANCE;

    PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('ST_HN_SUBSTPARAM', V_SRC_COUNT, 'SUBSTANCE', V_TGT_COUNT, 'N');
	
    IF ( V_TGT_COUNT = V_SRC_COUNT ) AND V_SRC_COUNT <> 0 AND V_TGT_COUNT <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS  HAVE BEEN INSERTED INTO SUBSTANCE TABLE'
                                                                                                                    , 'SUCCESS', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSIF V_TGT_COUNT <> V_SRC_COUNT AND V_TGT_COUNT <> 0 THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SUBSTANCE TABLE'
                                                                                                                    , 'PARTIALLY SUCCESSFULL'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    ELSIF ( V_TGT_COUNT <> V_SRC_COUNT OR V_TGT_COUNT = V_SRC_COUNT ) AND ( V_TGT_COUNT = 0 ) THEN
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SUBSTANCE TABLE'
                                                                                                                    , 'FAIL', NULL
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL);
    ELSE
        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', V_TGT_COUNT
                                                                                                                    || ' OUT OF '
                                                                                                                    || V_SRC_COUNT
                                                                                                                    || ' ROWS HAVE BEEN INSERTED INTO SUBSTANCE TABLE'
                                                                                                                    , 'AMBIGIOUS'
                                                                                                                    , NULL, NULL,
                                                                                                                    NULL, NULL);
    END IF;

/***********************************************************************************************************
RECONCILING THE COUNT OF STAGNG TABLE AND TARGET TABLE   ENDS
*************************************************************************************************************/

EXCEPTION      --OUTER EXCEPTION FOR PROC_1_SUBSTANCE
    WHEN OTHERS THEN
    V_ERR_CODE := SQLCODE;
    V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
    V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
	
    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SUBSTANCE', 'PROC_1_SUBSTANCE', V_SQLERRM, 'FAIL', NULL, NULL, NULL, 'T');

END;                --OUTER END  FOR PROC_1_SUBSTANCE

/
