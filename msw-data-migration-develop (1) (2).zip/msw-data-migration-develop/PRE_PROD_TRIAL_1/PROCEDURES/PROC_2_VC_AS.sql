create or replace PROCEDURE PROC_2_VC_AS (
V_MSW_VSL_ID IN NUMBER,
V_ETA_DT IN TIMESTAMP,
V_ETD_DT IN TIMESTAMP,
V_RTA_DT IN TIMESTAMP,
V_RTD_DT IN TIMESTAMP, 
V_MVMT_ID_N IN VARCHAR2,
V_MSW_APPLN_REF_ID_X IN VARCHAR2,
V_EXTL_APPLN_REF_ID_X IN VARCHAR2,
V_APPLN_TY_C VARCHAR2,
V_APPLN_DATA_X in CLOB,
V_RUN_ID IN NUMBER,
V_MSW_TBL_NAME IN VARCHAR2,
V_VSL_CALL_ID_OUT OUT NUMBER,
V_FLAG_OUT OUT VARCHAR2,
V_ORG_C IN VARCHAR2,
V_VSL_REF_NO IN NUMBER DEFAULT NULL)
IS
/***********************************************************************************************************
PROCEDURE NAME : PROC_MSW_VSL_CALL
CREATED BY     : R.M.KHOOL
DATE           : 16-APR-2019
PURPOSE        : INSERTING THE RECORD INTO VESSEL_CALL FROM FOR EVERY PAN APPLICATION RECORD APPLICATION.
MODIFIED BY    :
MODIFIED DATE  :

*************************************************************************************************************/
V_VSL_CALL_ID NUMBER;
V_APP_SUB_ID NUMBER;
V_VSL_MVMT_ST VARCHAR2(15);
V_APPLN_DATA  CLOB;

--V_MSW_APPLN_REF_ID_X VARCHAR2(15);
V_ERR_CODE         NUMBER;
V_EXP_ROWS         VARCHAR2(4000);
V_ERR_MSG          VARCHAR2(500);
V_SQLERRM          VARCHAR2(2500);
BEGIN
V_ERR_CODE := NULL;

IF V_APPLN_TY_C !='GDD' 

Then

SELECT VSL_CALL_SEQ.NEXTVAL INTO V_VSL_CALL_ID FROM DUAL;
select  CASE   
        WHEN V_RTD_DT IS NOT NULL then 'DEPARTED'
		WHEN V_RTD_DT IS NULL AND V_RTA_DT IS NOT NULL then 'ARRIVED'
		WHEN V_ETA_DT IS NOT NULL AND V_RTA_DT IS NULL then 'DUE_TO_ARRIVE'
        END INTO V_VSL_MVMT_ST
FROM DUAL;

--INSERTING DATA INTO TABLE VESSEL_CALL---
				BEGIN

				INSERT INTO VESSEL_CALL(VSL_CALL_ID_N, 
										MSW_VSL_ID_N, 
										ETA_DT, 
										ETD_DT,
                                        RTA_DT, 
										RTD_DT, 										
										DELETED_I, 
										LOCK_VER_N, 
										CRT_ON_DT, 
										CRT_BY_N, 
										UPT_ON_DT,
                                        UPT_BY_X,
                                        ST_C,
                                        MVMT_ID_N,
                                        VSL_MVMT_ST,
                                        VSL_REF_ID_N )
								VALUES (V_VSL_CALL_ID,
										V_MSW_VSL_ID,
										V_ETA_DT,
										V_ETD_DT,
										V_RTA_DT,
										V_RTD_DT,
                                        0,
                                        0,
                                        SYSDATE,
                                        'DATA MIGRATION',
                                        NULL,
                                        NULL,
                                        NULL,
                                        V_MVMT_ID_N,
                                        V_VSL_MVMT_ST,
                                        V_VSL_REF_NO
                                        );   


					 EXCEPTION
				       WHEN OTHERS THEN
                        V_FLAG_OUT:= 'F';
						V_ERR_CODE := SQLCODE;	

						V_EXP_ROWS :=  'VSL_CALL_ID_N: '||V_VSL_CALL_ID ||' MSW_VSL_ID_N: '||V_MSW_VSL_ID ||' ETA_DT: '||V_ETA_DT ||' ETD_DT: '||V_ETD_DT ||' RTA_DT: '||V_RTA_DT
										||' RTD_DT: '||V_RTD_DT || ' MVMT_ID_N: '||V_MVMT_ID_N ||' VSL_MVMT_ST: '||V_VSL_MVMT_ST||' '||V_MSW_TBL_NAME;                        

						V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

						V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

                        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_VC_AS', V_SQLERRM, 'ERROR',V_RUN_ID,V_ERR_MSG,V_EXP_ROWS,'T');

						COMMIT;


				END;		
	ELSE 
	SELECT VSL_CALL_SEQ.currval INTO V_VSL_CALL_ID FROM DUAL;
	END IF;

				BEGIN
				IF V_ERR_CODE IS NULL
				THEN
                SELECT APP_SUB_SEQ.NEXTVAL INTO V_APP_SUB_ID FROM DUAL;
--				SELECT V_APP_SUB_SEQ||TO_CHAR(SYSDATE,'YYYY')||TO_CHAR(SYSDATE,'MM')||TO_CHAR(SYSDATE,'DD')||TO_CHAR(APP_SUB_SEQ.NEXTVAL,'FM0000' ) INTO V_MSW_APPLN_REF_ID_X FROM DUAL;
                IF V_APPLN_TY_C = 'HNS'
                THEN 
                V_APPLN_DATA := '{"vesselCallId":'||V_VSL_CALL_ID||','||V_APPLN_DATA_X;
                ELSE
                V_APPLN_DATA :=V_APPLN_DATA_X;
                END IF;

				INSERT INTO APPLICATION_SUBMISSION (APPLN_SUBMISSN_ID_N,
                                                    MSW_APPLN_REF_ID_X,
													VSL_CALL_ID_N,
													EXTL_APPLN_REF_ID_X,
													MSW_VSL_ID_N,
													ETA_DT,
													ETD_DT,
													APPLN_TY_C,
													APPLN_DATA_X,
													ST_C,
													PROCESSING_REM_X,
													PROCESSED_BY_X,
													PROCESSED_ON_DT,
													CUTOFF_DT,
													LOCK_VER_N,
													CRT_ON_DT,
													CRT_BY_X,
													UPT_ON_DT,
													UPT_BY_X,
													DELETED_I,
                                                    ORG_C,
                                                    VSL_REF_ID_N,
                                                    REASON
                                                    )
											VALUES(V_APP_SUB_ID,
                                                   V_MSW_APPLN_REF_ID_X,
												   V_VSL_CALL_ID,
												   V_EXTL_APPLN_REF_ID_X,
												   V_MSW_VSL_ID,
												   V_ETA_DT,
												   V_ETD_DT,
												   V_APPLN_TY_C,
                                                   V_APPLN_DATA,
												  -- V_APPLN_DATA_X ,  --NULL,
												   'PROCESSED',
												   NULL,
												   NULL,
												   NULL,
												   NULL,
												   0,
												   SYSDATE,
												   'DATA MIGRATION',
												   NULL,
												   NULL,
												   0,
                                                   V_ORG_C,
                                                   V_VSL_REF_NO,
                                                   NULL);

                    END IF;

					EXCEPTION
					WHEN OTHERS THEN
                    V_FLAG_OUT:= 'F';
					--Deleting the record from VESSEL_CALL whenever we get exception while inserting record in APPLICATION_SUBMISSION
					IF V_APPLN_TY_C !='GDD' THEN
					DELETE FROM VESSEL_CALL WHERE VSL_CALL_ID_N = V_VSL_CALL_ID;
					END IF;
					V_ERR_CODE := SQLCODE;	
					V_EXP_ROWS :=  'APPLN_SUBMISSN_ID_N: '||V_APP_SUB_ID ||' MSW_APPLN_REF_ID_X: '||V_MSW_APPLN_REF_ID_X ||' VSL_CALL_ID_N: '||V_VSL_CALL_ID||
									' EXTL_APPLN_REF_ID_X: '||V_EXTL_APPLN_REF_ID_X ||' MSW_VSL_ID_N: '||V_MSW_VSL_ID ||' ETA_DT: '||V_ETA_DT ||' ETD_DT: '||V_ETD_DT||
									' APPLN_TY_C: '||V_APPLN_TY_C ||'ORG_C: '||'V_ORG_C'||'VSL_REF_ID_N: '||V_VSL_REF_NO ||' '||V_MSW_TBL_NAME;

					V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;

					V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

					PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('APPLICATION_SUBMISSION ' ||'&'|| ' VESSEL_CALL', 'PROC_2_VC_AS',V_SQLERRM, 'ERROR',V_RUN_ID,V_ERR_MSG,V_EXP_ROWS,'T');

					COMMIT;

				END;

    V_VSL_CALL_ID_OUT := V_VSL_CALL_ID ;


	EXCEPTION
    WHEN OTHERS THEN

      V_ERR_CODE := SQLCODE;

                V_ERR_MSG := SUBSTR(SQLERRM, 1, 200)||dbms_utility.format_error_backtrace;

                V_SQLERRM := V_ERR_CODE || V_ERR_MSG;

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('VESSEL_CALL', 'PROC_2_VC_AS', V_SQLERRM, 'ERROR',V_RUN_ID,V_ERR_MSG,NULL,'T');
END;
/