create or replace PROCEDURE PROC_2_DEPGD_DEPOC (PV_RUN_ID  in number)IS

/***********************************************************************************************************
procedure name : PROC_2_DEPGD_DEPOC
Created By     : C.N.BHASKAR
Date           : 29-june-2019
Purpose        : Inserting  the data from ST_CV_GDAppln,ST_CV_pendingAppln,ST_CV_vslCall (main table) to 
                 SI_ARRIVAL_GD_APPLICATION(Intermediate table) to ARRIVAL_GD_APPLICATION and ARRIVAL_GD_PURPOSE_OF_CALL(Target Table)
Modified by    :
Modified date  :

*************************************************************************************************************/

	/***********************************************************************************************************
	Defining the 'record type'  type to serve as the datatype of collection variable  of intermediate table
	*************************************************************************************************************/

type rec_gd_application is RECORD
( 
v_depgd_applnRef_n						SI_DEP_DEPOC.depgd_applnRef_n%type,
v_depgd_GDV_n						    SI_DEP_DEPOC.depgd_GDV_n%type,
v_depgd_depDeclr_dt						SI_DEP_DEPOC.depgd_depDeclr_dt%type,
v_depgd_vslGTOnDep_q					SI_DEP_DEPOC.depgd_vslGTOnDep_q%type,
v_depgd_agtDeclrAc_n					SI_DEP_DEPOC.depgd_agtDeclrAc_n%type,
v_depgd_nxPortCtry_c					SI_DEP_DEPOC.depgd_nxPortCtry_c%type,
v_depgd_nxPort_c						SI_DEP_DEPOC.depgd_nxPort_c%type,
v_depgd_nxPort_m						SI_DEP_DEPOC.depgd_nxPort_m%type,
v_depgd_pers_q						    SI_DEP_DEPOC.depgd_pers_q%type,
v_depgd_pax_q						    SI_DEP_DEPOC.depgd_pax_q%type,
v_depgd_crew_q						    SI_DEP_DEPOC.depgd_crew_q%type,
v_depgd_cgo_q						    SI_DEP_DEPOC.depgd_cgo_q%type,
v_depgd_mstrOnDep_x						SI_DEP_DEPOC.depgd_mstrOnDep_x%type,
v_depgd_motherGDV_n						SI_DEP_DEPOC.depgd_motherGDV_n%type,
v_depgd_bunkr_q						    SI_DEP_DEPOC.depgd_bunkr_q%type,
v_depgd_bunkrGr_c						SI_DEP_DEPOC.depgd_bunkrGr_c%type,
v_depgd_cst_n						    SI_DEP_DEPOC.depgd_cst_n%type,
v_depgd_ChartererNat_c					SI_DEP_DEPOC.depgd_ChartererNat_c%type,
v_depgd_sln_c						    SI_DEP_DEPOC.depgd_sln_c%type,
v_dep_applnSt_c						    SI_DEP_DEPOC.dep_applnSt_c%type,
v_dep_apprBy_m						    SI_DEP_DEPOC.dep_apprBy_m%type,
v_dep_apprOn_dt						    SI_DEP_DEPOC.dep_apprOn_dt%type,
v_dep_rem_x						        SI_DEP_DEPOC.dep_rem_x	%type,
v_dep_agt_m						        SI_DEP_DEPOC.dep_agt_m	%type,
v_depgd_crtOn_dt						SI_DEP_DEPOC.depgd_crtOn_dt%type,
v_depgd_crtBy_m						    SI_DEP_DEPOC.depgd_crtBy_m	%type,
v_depgd_updOn_dt						SI_DEP_DEPOC.depgd_updOn_dt%type,
v_depgd_updBy_m						    SI_DEP_DEPOC.depgd_updBy_m	%type,
v_depgd_intlRem_x						SI_DEP_DEPOC.depgd_intlRem_x%type,
v_DEP_POC_PURPCALL1                     SI_DEP_DEPOC.DEP_POC_PURPCALL1%type,
v_DEP_POC_PURPCALL2                     SI_DEP_DEPOC.DEP_POC_PURPCALL2%type,
v_DEP_POC_PURPCALL3                     SI_DEP_DEPOC.DEP_POC_PURPCALL3%type,
v_DEP_POC_PURPCALL4                     SI_DEP_DEPOC.DEP_POC_PURPCALL4%type,
v_DEP_POC_PURPCALL5                     SI_DEP_DEPOC.DEP_POC_PURPCALL5%type,
v_DEP_POC_PURPCALL6                     SI_DEP_DEPOC.DEP_POC_PURPCALL6%type,
v_DEP_POC_PURPCALL7                     SI_DEP_DEPOC.DEP_POC_PURPCALL7%type,
v_DEP_POC_PURPCALL9                     SI_DEP_DEPOC.DEP_POC_PURPCALL9%type,
v_DEP_POC_PURPCALLOTHERS_X              SI_DEP_DEPOC.DEP_POC_PURPCALLOTHERS_X%type,
v_DEP_POC_PURPCALLOTHERSTOW_X           SI_DEP_DEPOC.DEP_POC_PURPCALLOTHERSTOW_X%type,
v_DEP_POC_PURPCALLOTHERSTOWVSL_M        SI_DEP_DEPOC.DEP_POC_PURPCALLOTHERSTOWVSL_M%type,
v_VESSELCALLID                          SI_DEP_DEPOC.VESSELCALLID%type,
v_MSWVSLID_N                            SI_DEP_DEPOC. MSWVSLID_N%type,
v_ETA_DT                                SI_DEP_DEPOC.ETA_DT%type,
v_ETD_DT                                SI_DEP_DEPOC.ETD_DT%type,
v_VSL_REC_ID_N                          SI_DEP_DEPOC.VSLRECID_N%type,
v_VSL_REF_ID                            SI_DEP_DEPOC.VSL_REF_ID%type

);

    TYPE type_gd_application IS
    TABLE OF rec_gd_application;

    lv_gd_appllication type_gd_application;
    v_err_code NUMBER;
    v_err_msg VARCHAR2(500);
    v_sqlerrm VARCHAR2(2500);
    v_year_month VARCHAR2(40);
    arr_p_yymm VARCHAR2(100);
    dep_p_yymm VARCHAR2(100);
    l_val NUMBER;
    lval CLOB;
    v_syl CLOB;
    v_poc CLOB;
    depsylogs CLOB;
    v_msw_vsl_call_id_out NUMBER;
    v_flag_out VARCHAR2(100);
    v_msw_appln_ref_id_x VARCHAR2(20);
    v_del_arrgd NUMBER;
    v_del_depgd NUMBER;
    v_src_count NUMBER;
    v_tgt_count  number;
    V_VSL_REF_ID_OUT   varchar2(20);
    i_excep_cnt_tgt  number := 0;
    i_excep_cnt_tgt_poc  number := 0;
    i_excep_cnt_si   number := 0;
    

cursor CUR_GD_APPLN is   

select *
from 
SI_DEP_DEPOC
order by DEPGD_GDV_N,DEPGD_CRTON_DT;


begin  --outer begin

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_DEPOC', 'PROC_2_DEPGD_DEPOC','INSERTION INTO SI_DEP_DEPOC  STARTS' , 'START',null,null,null,'T');



FOR i IN

(
 SELECT M.*
FROM 
(select 
app.applnRef_n,
dep.GDV_n,
dep.depDeclr_dt,
dep.vslGTOnDep_q,
dep.agtDeclrAc_n,
dep.nxPortCtry_c,
dep.nxPort_c,
dep.nxPort_m,
dep.pers_q,
dep.pax_q,
dep.crew_q,
dep.cgo_q,
dep.mstrOnDep_x,
dep.motherGDV_n,
dep.bunkr_q,
dep.bunkrGr_c,
dep.cst_n,
dep.ChartererNat_c,
dep.sln_c,
pend.applnSt_c,
pend.apprBy_m,
pend.apprOn_dt,
app.rem_x,
dep.agt_m,
dep.crtOn_dt,
dep.crtBy_m,
dep.updOn_dt,
dep.updBy_m,
app.intlRem_x,
app.purpcall1_i,
app.purpcall2_i,
app.purpcall3_i,
app.purpcall4_i,
app.purpcall5_i,
app.purpcall6_i,
app.purpcall7_i,
app.purpcall9_i,
app.purpcallothers_x,
app.purpcallotherstow_x,
app.purpcallotherstowvsl_m,
si2.VSL_CALL_ID_N,
si2.MSW_VSL_ID_N ,
si2.ETA_DT,
si2.ETD_DT,
app.VSLRECID_N,
si2.VSL_REF_ID_N


from 

st_CV_depGD dep,
st_CV_GDAppln app ,
st_CV_vslCall call,
st_CV_pendingAppln pend,
SI_ARR_DEP_GD2  SI2


where
app.applnRef_n = dep.ref_n 
and  dep.GDV_n = call.GDV_n 
and   pend.applnRef_n = app.applnRef_n
and  depGDSt_c in ('1','5')
and si2.GDV_N = dep.GDV_n
)M

 ORDER BY
  M.gdv_n, M.crtOn_dt


    )

LOOP               

BEGIN                                            -- inner begin  of SI  tablee 

 INSERT INTO SI_DEP_DEPOC (DEPGD_APPLNREF_N,
DEPGD_GDV_N,
DEPGD_DEPDECLR_DT,
DEPGD_VSLGTONDEP_Q,
DEPGD_AGTDECLRAC_N,
DEPGD_NXPORTCTRY_C,
DEPGD_NXPORT_C,
DEPGD_NXPORT_M,
DEPGD_PERS_Q,
DEPGD_PAX_Q,
DEPGD_CREW_Q,
DEPGD_CGO_Q,
DEPGD_MSTRONDEP_X,
DEPGD_MOTHERGDV_N,
DEPGD_BUNKR_Q,
DEPGD_BUNKRGR_C,
DEPGD_CST_N,
DEPGD_CHARTERERNAT_C,
DEPGD_SLN_C,
DEP_APPLNST_C,
DEP_APPRBY_M,
DEP_APPRON_DT,
DEP_REM_X,
DEP_AGT_M,
DEPGD_CRTON_DT,
DEPGD_CRTBY_M,
DEPGD_UPDON_DT,
DEPGD_UPDBY_M,
DEPGD_INTLREM_X,
DEP_POC_PURPCALL1,
DEP_POC_PURPCALL2,
DEP_POC_PURPCALL3,
DEP_POC_PURPCALL4,
DEP_POC_PURPCALL5,
DEP_POC_PURPCALL6,
DEP_POC_PURPCALL7,
DEP_POC_PURPCALL9,
DEP_POC_PURPCALLOTHERS_X,
DEP_POC_PURPCALLOTHERSTOW_X,
DEP_POC_PURPCALLOTHERSTOWVSL_M,
VESSELCALLID,
MSWVSLID_N,
ETA_DT,
ETD_DT,
VSLRECID_N,
VSL_REF_ID

)

VALUES ( 
i.applnRef_n,
i.GDV_n,
i.depDeclr_dt,
i.vslGTOnDep_q,
i.agtDeclrAc_n,
i.nxPortCtry_c,
i.nxPort_c,
i.nxPort_m,
i.pers_q,
i.pax_q,
i.crew_q,
i.cgo_q,
i.mstrOnDep_x,
i.motherGDV_n,
i.bunkr_q,
i.bunkrGr_c,
i.cst_n,
i.ChartererNat_c,
i.sln_c,
i.applnSt_c,
i.apprBy_m,
i.apprOn_dt,
i.rem_x,
i.agt_m,
i.crtOn_dt,
i.crtBy_m,
i.updOn_dt,
i.updBy_m,
i.intlRem_x,
i.purpcall1_i,
i.purpcall2_i,
i.purpcall3_i,
i.purpcall4_i,
i.purpcall5_i,
i.purpcall6_i,
i.purpcall7_i,
i.purpcall9_i,
i.purpcallothers_x,
i.purpcallotherstow_x,
i.purpcallotherstowvsl_m,
i.VSL_CALL_ID_N,
i.MSW_VSL_ID_N,
i.ETA_DT,
i.ETD_DT,
i.VSLRECID_N,
i.VSL_REF_ID_N
);

exception  --inner exception of SI table 

 WHEN OTHERS THEN                                                     -- inner exception for handling any errors in the SI table 
 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
 
 i_excep_cnt_si := i_excep_cnt_si +1;

if i_excep_cnt_si < 50000  then 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'SI_DEP_DEPOC',
  'PROC_2_DEPGD_DEPOC',
'DEPGD_APPLNREF_N:'||	i.applnRef_n	||'<{||}>'||
'DEPGD_GDV_N:'||	i.GDV_n	             ||'<{||}>'||
'DEPGD_DEPDECLR_DT:'||	i.depDeclr_dt	||'<{||}>'||
'DEPGD_VSLGTONDEP_Q:'||	i.vslGTOnDep_q	||'<{||}>'||
'DEPGD_AGTDECLRAC_N:'||	i.agtDeclrAc_n	||'<{||}>'||
'DEPGD_NXPORTCTRY_C:'||	i.nxPortCtry_c	||'<{||}>'||
'DEPGD_NXPORT_C:'||	i.nxPort_c	||'<{||}>'||
'DEPGD_NXPORT_M:'||	i.nxPort_m	||'<{||}>'||
'DEPGD_PERS_Q:'||	i.pers_q	||'<{||}>'||
'DEPGD_PAX_Q:'||	i.pax_q	||'<{||}>'||
'DEPGD_CREW_Q:'||	i.crew_q	||'<{||}>'||
'DEPGD_CGO_Q:'||	i.cgo_q	||'<{||}>'||
'DEPGD_MSTRONDEP_X:'||	i.mstrOnDep_x	||'<{||}>'||
'DEPGD_MOTHERGDV_N:'||	i.motherGDV_n	||'<{||}>'||
'DEPGD_BUNKR_Q:'||	i.bunkr_q	||'<{||}>'||
'DEPGD_BUNKRGR_C:'||	i.bunkrGr_c	||'<{||}>'||
'DEPGD_CST_N:'||	i.cst_n	||'<{||}>'||
'DEPGD_CHARTERERNAT_C:'||	i.ChartererNat_c	||'<{||}>'||
'DEPGD_SLN_C:'||	i.sln_c	||'<{||}>'||
'DEP_APPLNST_C:'||	i.applnSt_c	||'<{||}>'||
'DEP_APPRBY_M:'||	i.apprBy_m	||'<{||}>'||
'DEP_APPRON_DT:'||	i.apprOn_dt	||'<{||}>'||
'DEP_REM_X:'||	i.rem_x	||'<{||}>'||
'DEP_AGT_M:'||	i.agt_m	||'<{||}>'||
'DEPGD_CRTON_DT:'||	i.crtOn_dt	||'<{||}>'||
'DEPGD_CRTBY_M:'||	i.crtBy_m	||'<{||}>'||
'DEPGD_UPDON_DT:'||	i.updOn_dt	||'<{||}>'||
'DEPGD_UPDBY_M:'||	i.updBy_m	||'<{||}>'||
'DEPGD_INTLREM_X:'||	i.intlRem_x	||'<{||}>'||
'DEP_POC_PURPCALL1:'||	i.purpcall1_i	||'<{||}>'||
'DEP_POC_PURPCALL2:'||	i.purpcall2_i	||'<{||}>'||
'DEP_POC_PURPCALL3:'||	i.purpcall3_i	||'<{||}>'||
'DEP_POC_PURPCALL4:'||	i.purpcall4_i	||'<{||}>'||
'DEP_POC_PURPCALL5:'||	i.purpcall5_i	||'<{||}>'||
'DEP_POC_PURPCALL6:'||	i.purpcall6_i	||'<{||}>'||
'DEP_POC_PURPCALL7:'||	i.purpcall7_i	||'<{||}>'||
'DEP_POC_PURPCALL9:'||	i.purpcall9_i	||'<{||}>'||
'DEP_POC_PURPCALLOTHERS_X:'||	i.purpcallothers_x	||'<{||}>'||
'DEP_POC_PURPCALLOTHERSTOW_X:'||	i.purpcallotherstow_x	||'<{||}>'||
'DEP_POC_PURPCALLOTHERSTOWVSL_M	:'||i.purpcallotherstowvsl_m	||'<{||}>'||
'VESSELCALL:'||i.VSL_CALL_ID_N ||'<{||}>'||
'MSWVSLID_N:'|| i.MSW_VSL_ID_N ||'<{||}>'||
'ETA_ID:' || i.ETA_DT ||'<{||}>'||
'ETD_ID:' || i.ETD_DT  ||'<{||}>'||
'VSLRECID:N'||i.VSLRECID_N  ||'<{||}>'||
'VSLREFID:N'||i.VSL_REF_ID_N

  ,
'ERROR',

PV_RUN_ID,

V_SQLERRM,

i.applnRef_n	||'<{||}>'||
i.GDV_n	||'<{||}>'||
i.depDeclr_dt	||'<{||}>'||
i.vslGTOnDep_q	||'<{||}>'||
i.agtDeclrAc_n	||'<{||}>'||
i.nxPortCtry_c	||'<{||}>'||
i.nxPort_c	||'<{||}>'||
i.nxPort_m	||'<{||}>'||
i.pers_q	||'<{||}>'||
i.pax_q	||'<{||}>'||
i.crew_q	||'<{||}>'||
i.cgo_q	||'<{||}>'||
i.mstrOnDep_x	||'<{||}>'||
i.motherGDV_n	||'<{||}>'||
i.bunkr_q	||'<{||}>'||
i.bunkrGr_c	||'<{||}>'||
i.cst_n	||'<{||}>'||
i.ChartererNat_c	||'<{||}>'||
i.sln_c	||'<{||}>'||
i.applnSt_c	||'<{||}>'||
i.apprBy_m	||'<{||}>'||
i.apprOn_dt	||'<{||}>'||
i.rem_x	||'<{||}>'||
i.agt_m	||'<{||}>'||
i.crtOn_dt	||'<{||}>'||
i.crtBy_m	||'<{||}>'||
i.updOn_dt	||'<{||}>'||
i.updBy_m	||'<{||}>'||
i.intlRem_x	||'<{||}>'||
i.purpcall1_i	||'<{||}>'||
i.purpcall2_i	||'<{||}>'||
i.purpcall3_i	||'<{||}>'||
i.purpcall4_i	||'<{||}>'||
i.purpcall5_i	||'<{||}>'||
i.purpcall6_i	||'<{||}>'||
i.purpcall7_i	||'<{||}>'||
i.purpcall9_i	||'<{||}>'||
i.purpcallothers_x	||'<{||}>'||
i.purpcallotherstow_x	||'<{||}>'||
i.purpcallotherstowvsl_m	||'<{||}>'||
i.VSL_CALL_ID_N  ||'<{||}>'||
i.MSW_VSL_ID_N ||'<{||}>'||
 i.ETA_DT ||'<{||}>'||
i.ETD_DT ||'<{||}>'||
i.VSLRECID_N  ||'<{||}>'||
i.VSL_REF_ID_N
,
 'T'
 );
 
 end if;

end ;   -- inner end of SI table 

end loop; -- end loop of for which inserts the data into the SI table 
commit;
PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('SI_DEP_DEPOC', 'PROC_2_DEPGD_DEPOC','INSERTION INTO SI_DEP_DEPOC  ENDS' , 'ENDS',null,null,null,'T');



---------------------------------------------------------------------------------------------------------------------------------


OPEN CUR_GD_APPLN;

loop     -- loop of the cursor  CUR_GD_APPLN

  FETCH CUR_GD_APPLN BULK COLLECT INTO LV_GD_APPLLICATION LIMIT 10000;

               EXIT WHEN LV_GD_APPLLICATION.count = 0;


                  FOR i IN LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 


                  loop       --loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST 




                     Select TO_CHAR(LV_GD_APPLLICATION(i).v_depgd_crtOn_dt,'YY')|| TO_CHAR(LV_GD_APPLLICATION(i).v_depgd_crtOn_dt,'MM') 
                       into V_YEAR_MONTH 
                       from dual;






                     IF v_year_month != dep_p_yymm  and  dep_p_yymm is not null  THEN


                                   EXECUTE IMMEDIATE 'select DEP_SUB_SEQ.NEXTVAL from dual'
                                      INTO l_val;
                                   EXECUTE IMMEDIATE 'alter sequence DEP_SUB_SEQ increment by -'|| l_val || ' minvalue 0';

                                   EXECUTE IMMEDIATE 'select  DEP_SUB_SEQ.NEXTVAL from dual'
                                      INTO l_val;
                                   EXECUTE IMMEDIATE 'alter sequence DEP_SUB_SEQ increment by 1 minvalue 0';


                      END IF;

                    dep_p_yymm :=     v_year_month;

                     V_MSW_APPLN_REF_ID_X := 'MSW'||'GDD'||TO_CHAR(LV_GD_APPLLICATION(i).v_depgd_crtOn_dt,'YY')||TO_CHAR(LV_GD_APPLLICATION(i).v_depgd_crtOn_dt,'MM')||TO_CHAR(DEP_SUB_SEQ.NEXTVAL,'FM00000' ) ;



/************************************************************************************************************************************************

DEPGD JASON STARTS

************************************************************************************************************************************************/
/*
LVAL := null;
LVAL := '{';
LVAL := LVAL|| '"applicationData": "{\"agentDeclaredAccountNumber\": \"'||  null   || '\",';
LVAL := LVAL||'\"applicationStatus\": \" '||null ||'\",';
LVAL := LVAL||'\"arrivalGDApplicationId\": \"'||null||'\",';
LVAL := LVAL||'\"bunkerGrade\": \"'||null||'\",';
LVAL := LVAL||'\"bunkerQuantity\": '||null||',';
LVAL := LVAL||'\"characterNationalityCode\": \"'||null||'\",';
LVAL := LVAL||'\"createdBy\": \"'||null||'\",';
LVAL := LVAL||'\"createdOn\": \"'||null||'\",';
LVAL := LVAL||'\"cstNumber\": '||null||',';
LVAL := LVAL|| '\"departureDateTime\": \"'||null||'\",';

DEPSYLOGS := '\"departureGDApplicationSyncLogs\": [';

DEPSYLOGS :=DEPSYLOGS ||'{\"departureGDApplicationId\":' ||null||',';
DEPSYLOGS :=DEPSYLOGS || '\"lockVersion\": '||null||',';
DEPSYLOGS :=DEPSYLOGS ||'\"syncStatus\":\"'||null||'\",';
DEPSYLOGS :=DEPSYLOGS || '\"syncTime\": \"'||null||'\"}],';

DEPSYLOGS :=DEPSYLOGS || '\"departureGDPurposeOfCalls\": [{\"departureGDApplicationId\": '||null||',';
DEPSYLOGS :=DEPSYLOGS ||  '\"lockVersion\": '||null||',';
DEPSYLOGS :=DEPSYLOGS ||  '\"purposeOfCall\": \"'||null||'\"}],';


LVAL := LVAL||DEPSYLOGS;

LVAL := LVAL|| '\"departureGDShipCertificates\": [{\"certificateType\": \"'||null||'\",';
LVAL := LVAL||'\"documentId\":'||null||',';
LVAL := LVAL|| '\"createdBy\": \"'||null||'\",';
LVAL := LVAL||'\"createdOn\": \"'||null||'\",';
LVAL := LVAL||'\"deleted\": '||null||',';
LVAL := LVAL||'\"dgdApplicationId\": '||null||',';
LVAL := LVAL||'\"dgdShipCertificateStatus\": \"'||null||'\",';
LVAL := LVAL||'\"dueDate\": \"'||null||'\",';
LVAL := LVAL||'\"issueDate\": \"'||null||'\",';
LVAL := LVAL||   '\"issuingAuthority\": \"'||null||'\",';
 LVAL := LVAL|| '\"issuingClass\": \"'||null||'\",';
 LVAL := LVAL|| '\"lastUpdatedBy\": \"'||null||'\",';
 LVAL := LVAL|| '\"lastUpdatedOn\": \"'||null||'\",';
 LVAL := LVAL|| '\"lockVersion\":'|| null||'}],';

  LVAL := LVAL||  '\"externalAppplicationReference\": \"'||null||'\",';
  LVAL := LVAL||  '\"gdvNumber\": \"'||null||'\",';
   LVAL := LVAL|| '\"lastUpdateBy\": \"'||null||'\",';
   LVAL := LVAL|| '\"lastUpdatedOn\": \"'||null||'\",';

    LVAL := LVAL|| '\"lockVersion\":'|| null||',';

  LVAL := LVAL|| '\"masterOnDeparture\": \"'||null||'\",';
 LVAL := LVAL||  '\"motherGDV\":\"'||null||'\",';
  LVAL := LVAL||'\"mswApplicationReference\": \"'||null||'\",';
  LVAL := LVAL|| '\"nextPortCode\": \"'||null||'\",';
  LVAL := LVAL||  '\"nextPortCountry\": \"'||null||'\",';
   LVAL := LVAL|| '\"nextPortName\": \"'||null||'\",';
 LVAL := LVAL||   '\"numberOfCrew\": '||null||',';
  LVAL := LVAL||  '\"processedBy\": \"'||null||'\",';
  LVAL := LVAL|| ' \"processedOn\":\"'||null||'\",';
  LVAL := LVAL||  '\"processingRemarks\": \"||'||null||'\",';
   LVAL := LVAL|| '\"shippingLineCode\": \"'||null||'\",';
  LVAL := LVAL|| '\"totalCargoOnBoard\": '||null||',';
  LVAL := LVAL|| '\"totalPassengersOnBoard\": '||null||',';
  LVAL := LVAL|| '\"totalPersonsOnBoard\": '||null||',';
   LVAL := LVAL|| '\"vesselGTOnDeparture\": '||null||',';
   LVAL := LVAL||  '\"vesselCallId\":'||null||',';
   LVAL := LVAL|| '\"vesselId\":'||null||',';
   LVAL := LVAL||  '\"applicationReferenceNumber\": '||null||'}",';
  LVAL := LVAL||  '"applicationDocuments": [';
  LVAL := LVAL||' {';
  LVAL := LVAL||   ' "applicationSubmission": {},';
    LVAL := LVAL||    ' "createdBy": "'||null||'",';
  LVAL := LVAL|| '"createdOn": "'||null||'",';
  LVAL := LVAL||   '"documentId":'|| null||',';
  LVAL := LVAL||    '"lockVersion":'|| null;
  LVAL := LVAL||     '  }';
   LVAL := LVAL||  '],';
  LVAL := LVAL||   ' "applicationSubmissionStatus": "'||null||'",';
  LVAL := LVAL||  '"applicationType": "'||null||'",';
  LVAL := LVAL||  ' "createdBy": "'||null||'",';
  LVAL := LVAL||  ' "createdOn": "'||null||'",';
  LVAL := LVAL|| ' "cutOffDate": "'||null||'",';
  LVAL := LVAL||   ' "expectedTimeOfArrival": "'||null||'",';
  LVAL := LVAL|| '  "expectedTimeOfDeparture": "'||null||'",';
  LVAL := LVAL||  '  "externalApplicationId": "'||null||'",';
  LVAL := LVAL||  ' "lastUpdatedBy": "'||null||'",';
  LVAL := LVAL||  ' "lastUpdatedOn": "'||null||'",';
 LVAL := LVAL||  ' "lockVersion":'|| null||',';
  LVAL := LVAL||   ' "processedBy": "'||null||'",';
 LVAL := LVAL|| ' "processedOn": "'||null||'",';
 LVAL := LVAL|| '  "vesselCall":'|| null||',';
LVAL := LVAL||   '  "vesselId":'|| null;
 LVAL := LVAL|| ' }';

*/
/************************************************************************************************************************************************

DEPGD JASON ENDS

************************************************************************************************************************************************/


/*

 PROC_1_VSL_REF(LV_GD_APPLLICATION(i).v_MSWVSLID_N,--done 
                LV_GD_APPLLICATION(i).v_VSL_REC_ID_N,--done 
                null,--V_VSL_M  done 
                null,--V_VSL_IMO_N  done 
                 null,--V_VSL_CALL_SIGN_N  done 
                null,--V_VSL_GT_Q  done 
                null,--V_VSL_FLAG_C  done
                null, --vsl_ty_c
                V_VSL_REF_ID_OUT,
               V_FLAG_OUT);*/

    --      IF V_FLAG_OUT IS NULL THEN    


/************************************************************************************************************************************************

insert into APPLICATION_SUBMISSION starts

************************************************************************************************************************************************/

begin 

INSERT INTO APPLICATION_SUBMISSION (APPLN_SUBMISSN_ID_N,
                                                    MSW_APPLN_REF_ID_X,
													VSL_CALL_ID_N,
													EXTL_APPLN_REF_ID_X,
													MSW_VSL_ID_N,
													ETA_DT,
													ETD_DT,
													APPLN_TY_C,
													APPLN_DATA_X,
													ST_C,
													PROCESSING_REM_X,
													PROCESSED_BY_X,
													PROCESSED_ON_DT,
													CUTOFF_DT,
													LOCK_VER_N,
													CRT_ON_DT,
													CRT_BY_X,
													UPT_ON_DT,
													UPT_BY_X,
													DELETED_I,
                                                    ORG_C,
                                                    VSL_REF_ID_N,
                                                    REASON)


											VALUES(APP_SUB_SEQ.NEXTVAL,
                                                   V_MSW_APPLN_REF_ID_X,
												   LV_GD_APPLLICATION(i).v_VESSELCALLID,
												   LV_GD_APPLLICATION(i).v_depgd_applnRef_n,
												   LV_GD_APPLLICATION(i).v_MSWVSLID_N,
												   LV_GD_APPLLICATION(i).V_ETA_DT,
												   LV_GD_APPLLICATION(i).V_ETD_DT,
												   'GDD',
												   null ,  --NULL,
												   'PROCESSED',
												   NULL,
												   NULL,
												   NULL,
												   NULL,
												   0,
												   SYSDATE,
												   'DATA MIGRATION',
												   NULL,
												   NULL,
												   0,
                                                   'MSW',
                                                   LV_GD_APPLLICATION(i).v_VSL_REF_ID,
                                                   null);



exception

when others  then  null;

 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
('APPLICATION_SUBMISSION',

'PROC_2_DEPGD_DEPOC',

'APPLN_SUBMISSN_ID_N:' || APP_SUB_SEQ.currval ||'<{||}>'||
'MSW_APPLN_REF_ID_X:' || V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
'VSL_CALL_ID_N:' || LV_GD_APPLLICATION(i).v_VESSELCALLID  ||'<{||}>'|| 
'EXTL_APPLN_REF_ID_X:'|| LV_GD_APPLLICATION(i).v_depgd_applnRef_n  ||'<{||}>'||
'MSW_VSL_ID_N:' || LV_GD_APPLLICATION(i).v_MSWVSLID_N  ||'<{||}>'||
'ETA_DT:' || LV_GD_APPLLICATION(i).V_ETA_DT  ||'<{||}>'||
'ETD_DT:' || LV_GD_APPLLICATION(i).V_ETD_DT  ||'<{||}>'||
'APPLN_TY_C:' || 'GDD'  ||'<{||}>'||
'APPLN_DATA_X:' || LVAL  ||'<{||}>'||
'ST_C:'  || 'PROCESSED'  ||'<{||}>'||
'PROCESSING_REM_X:' || null  ||'<{||}>'||
'PROCESSED_BY_X:' || null  ||'<{||}>'||
'PROCESSED_ON_DT:' || null  ||'<{||}>'||
'CUTOFF_DT:' || null  ||'<{||}>'||
'LOCK_VER_N:' || 0  ||'<{||}>'||
'CRT_ON_DT:' || sysdate  ||'<{||}>'||
'CRT_BY_X:' || 'DATA MIGRATION'  ||'<{||}>'||
'UPT_ON_DT:' || null  ||'<{||}>'||
'UPT_BY_X:'  || null  ||'<{||}>'||
'DELETED_I:' || 0   ||'<{||}>'||
'ORG_C:'  || 'MSW'   ||'<{||}>'||
'VSL_REF_ID_N:' || LV_GD_APPLLICATION(i).v_VSL_REF_ID   ||'<{||}>'||
'REASON:' ||null
,
'ERROR',
PV_RUN_ID,
V_SQLERRM,

 APP_SUB_SEQ.currval ||'<{||}>'||
 V_MSW_APPLN_REF_ID_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_VESSELCALLID  ||'<{||}>'|| 
LV_GD_APPLLICATION(i).v_depgd_applnRef_n  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_MSWVSLID_N  ||'<{||}>'||
LV_GD_APPLLICATION(i).V_ETA_DT  ||'<{||}>'||
LV_GD_APPLLICATION(i).V_ETD_DT  ||'<{||}>'||
 'GDD'  ||'<{||}>'||
 LVAL  ||'<{||}>'||
 'PROCESSED'  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 null  ||'<{||}>'||
 0  ||'<{||}>'||
sysdate  ||'<{||}>'||
'DATA MIGRATION'  ||'<{||}>'||
 null  ||'<{||}>'||
null  ||'<{||}>'||
 0   ||'<{||}>'||
 'MSW'   ||'<{||}>'||
LV_GD_APPLLICATION(i).v_VSL_REF_ID   ||'<{||}>'||
null



,
'T');









end;


/************************************************************************************************************************************************

insert into APPLICATION_SUBMISSION Ends

************************************************************************************************************************************************/




























/****************************************************************************************************************************************

insertion into DEP GD starts 
*******************************************************************************************************************************************/

Begin   --begin fo dep gd

insert into DEPARTURE_GD_APPLICATION(
APPLN_REF_N	,
MSW_APPLN_REF_ID_X	,
EXTL_APPLN_REF_ID_X	,
GDV_N	,
DEP_DECLR_DT	,
VSL_GT_ON_DEP_Q	,
AGT_DECLR_AC_N	,
NX_PORT_CTRY_C	,
NX_PORT_C	,
NX_PORT_M	,
PERS_Q	,
PAX_Q	,
CREW_Q	,
CGO_Q	,
MSTR_ON_DEP_X	,
MOTHER_GDV_N	,
BUNKR_Q	,
BUNKR_GR_C	,
CST_N	,
CHARTERER_NAT_C	,
SLN_C	,
APPLN_ST_C	,
PROCESSED_BY_X	,
PROCESSED_ON_DT	,
PROCESSING_REM_X	,
COMPANY_NAME	,
DEPARTURE_LOCATION	,
MPA_ACCOUNT_NAMES	,
DELETED_I	,
LOCKVER_N	,
CRT_ON_DT	,
CRT_BY_N	,
UPT_ON_DT	,
UPT_BY_X	,
INTL_REM_X	
)

values
(seq_dep_gd_app.nextval		,
V_MSW_APPLN_REF_ID_X		,
LV_GD_APPLLICATION(i).v_depgd_applnRef_n	,
LV_GD_APPLLICATION(i).v_depgd_GDV_n	,
LV_GD_APPLLICATION(i).v_depgd_depDeclr_dt	,
LV_GD_APPLLICATION(i).v_depgd_vslGTOnDep_q	,
LV_GD_APPLLICATION(i).v_depgd_agtDeclrAc_n	,
LV_GD_APPLLICATION(i).v_depgd_nxPortCtry_c	,
LV_GD_APPLLICATION(i).v_depgd_nxPort_c	,
LV_GD_APPLLICATION(i).v_depgd_nxPort_m	,
LV_GD_APPLLICATION(i).v_depgd_pers_q	,
LV_GD_APPLLICATION(i).v_depgd_pax_q	,
LV_GD_APPLLICATION(i).v_depgd_crew_q	,
LV_GD_APPLLICATION(i).v_depgd_cgo_q	,
LV_GD_APPLLICATION(i).v_depgd_mstrOnDep_x	,
LV_GD_APPLLICATION(i).v_depgd_motherGDV_n	,
LV_GD_APPLLICATION(i).v_depgd_bunkr_q	,
LV_GD_APPLLICATION(i).v_depgd_bunkrGr_c	,
LV_GD_APPLLICATION(i).v_depgd_cst_n	,
LV_GD_APPLLICATION(i).v_depgd_ChartererNat_c	,
LV_GD_APPLLICATION(i).v_depgd_sln_c	,
decode(LV_GD_APPLLICATION(i).v_dep_applnSt_c,1,'APPROVED',4,'CANCELLED',5,'DUPLICATE'),
LV_GD_APPLLICATION(i).v_dep_apprBy_m	,
LV_GD_APPLLICATION(i).v_dep_apprOn_dt	,
LV_GD_APPLLICATION(i).v_dep_rem_x	,
LV_GD_APPLLICATION(i).v_dep_agt_m	,
	null	,
	null	,
	0	,
	0	,
LV_GD_APPLLICATION(i).v_depgd_crtOn_dt	,
LV_GD_APPLLICATION(i).v_depgd_crtBy_m	,
LV_GD_APPLLICATION(i).v_depgd_updOn_dt	,
LV_GD_APPLLICATION(i).v_depgd_updBy_m	,
LV_GD_APPLLICATION(i).v_depgd_intlRem_x	
);


exception


when others then 

 V_ERR_CODE := SQLCODE;
 V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
V_SQLERRM := V_ERR_CODE || V_ERR_MSG;


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
('DEP_GD_APPLICATION',
'PROC_2_DEPGD_DEPOC',
'APPLN_REF_N:'||	seq_dep_gd_app.currval	||'<{||}>'||
'MSW_APPLN_REF_ID_X	:'||	V_MSW_APPLN_REF_ID_X	||'<{||}>'||
'EXTL_APPLN_REF_ID_X:'||	LV_GD_APPLLICATION(i).v_depgd_applnRef_n	||'<{||}>'||
'GDV_N:'||	LV_GD_APPLLICATION(i).v_depgd_GDV_n	||'<{||}>'||
'DEP_DECLR_DT:'||LV_GD_APPLLICATION(i).	v_depgd_depDeclr_dt	||'<{||}>'||
'VSL_GT_ON_DEP_Q:'||LV_GD_APPLLICATION(i).	v_depgd_vslGTOnDep_q	||'<{||}>'||
'AGT_DECLR_AC_N	:'||LV_GD_APPLLICATION(i).	v_depgd_agtDeclrAc_n	||'<{||}>'||
'NX_PORT_CTRY_C	:'||LV_GD_APPLLICATION(i).	v_depgd_nxPortCtry_c	||'<{||}>'||
'NX_PORT_C:'||LV_GD_APPLLICATION(i).	v_depgd_nxPort_c	||'<{||}>'||
'NX_PORT_M	:'||LV_GD_APPLLICATION(i).	v_depgd_nxPort_m	||'<{||}>'||
'PERS_Q:'||	LV_GD_APPLLICATION(i).	v_depgd_pers_q	||'<{||}>'||
'PAX_Q:'||LV_GD_APPLLICATION(i).	v_depgd_pax_q	||'<{||}>'||
'CREW_Q:'||	LV_GD_APPLLICATION(i).	v_depgd_crew_q	||'<{||}>'||
'CGO_Q:'||LV_GD_APPLLICATION(i).	v_depgd_cgo_q	||'<{||}>'||
'MSTR_ON_DEP_X:'||LV_GD_APPLLICATION(i).	v_depgd_mstrOnDep_x	||'<{||}>'||
'MOTHER_GDV_N:'||LV_GD_APPLLICATION(i).	v_depgd_motherGDV_n	||'<{||}>'||
'BUNKR_Q:'||	LV_GD_APPLLICATION(i).	v_depgd_bunkr_q	||'<{||}>'||
'BUNKR_GR_C	:'||	LV_GD_APPLLICATION(i).	v_depgd_bunkrGr_c	||'<{||}>'||
'CST_N:'||	LV_GD_APPLLICATION(i).	v_depgd_cst_n	||'<{||}>'||
'CHARTERER_NAT_C:'||	LV_GD_APPLLICATION(i).	v_depgd_ChartererNat_c	||'<{||}>'||
'SLN_C:'||	LV_GD_APPLLICATION(i).	v_depgd_sln_c	||'<{||}>'||
'APPLN_ST_C:'||	LV_GD_APPLLICATION(i).	v_dep_applnSt_c	||'<{||}>'||
'PROCESSED_BY_X	:'||	LV_GD_APPLLICATION(i).	v_dep_apprBy_m	||'<{||}>'||
'PROCESSED_ON_DT:'||	LV_GD_APPLLICATION(i).	v_dep_apprOn_dt	||'<{||}>'||
'PROCESSING_REM_X:'||	LV_GD_APPLLICATION(i).	v_dep_rem_x	||'<{||}>'||
'COMPANY_NAME:'||	LV_GD_APPLLICATION(i).	v_dep_agt_m	||'<{||}>'||
'DEPARTURE_LOCATION	:'||	null	||'<{||}>'||
'MPA_ACCOUNT_NAMES:'||	null	||'<{||}>'||
'DELETED_I:'||	0	||'<{||}>'||
'LOCKVER_N:'||	0	||'<{||}>'||
'CRT_ON_DT:'||LV_GD_APPLLICATION(i).	v_depgd_crtOn_dt	||'<{||}>'||
'CRT_BY_N:'||LV_GD_APPLLICATION(i).	v_depgd_crtBy_m	||'<{||}>'||
'UPT_ON_DT:'||LV_GD_APPLLICATION(i).	v_depgd_updOn_dt	||'<{||}>'||
'UPT_BY_X:'||LV_GD_APPLLICATION(i).	v_depgd_updBy_m	||'<{||}>'||
'INTL_REM_X	:'||LV_GD_APPLLICATION(i).v_depgd_intlRem_x	,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
seq_dep_gd_app.currval	||'<{||}>'||
V_MSW_APPLN_REF_ID_X||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_applnRef_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_GDV_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_depDeclr_dt	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_vslGTOnDep_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_agtDeclrAc_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_nxPortCtry_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_nxPort_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_nxPort_m	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_pers_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_pax_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_crew_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_cgo_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_mstrOnDep_x	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_motherGDV_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_bunkr_q	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_bunkrGr_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_cst_n	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_ChartererNat_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_sln_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_dep_applnSt_c	||'<{||}>'||
LV_GD_APPLLICATION(i).v_dep_apprBy_m	||'<{||}>'||
LV_GD_APPLLICATION(i).v_dep_apprOn_dt	||'<{||}>'||
LV_GD_APPLLICATION(i).v_dep_rem_x	||'<{||}>'||
LV_GD_APPLLICATION(i).v_dep_agt_m	||'<{||}>'||
	null	||'<{||}>'||
	null	||'<{||}>'||
	0	||'<{||}>'||
	0	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_crtOn_dt	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_crtBy_m	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_updOn_dt	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_updBy_m	||'<{||}>'||
LV_GD_APPLLICATION(i).v_depgd_intlRem_x	,
'T');

end if;

delete from APPLICATION_SUBMISSION where  VSL_CALL_ID_N = v_msw_vsl_call_id_out;-- need to check


continue;


end;  -- end of dep gd

/****************************************************************************************************************************************

insertion into DEP GD application  ends 
*******************************************************************************************************************************************/



/****************************************************************************************************************************************

insertion into DEP poc starts 
*******************************************************************************************************************************************/



begin   -- begin of dep gd  POC


begin 
 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL1)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Cargo Operation',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception

  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
            
    i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Cargo Operation'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Cargo Operation'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;

end;


begin 


 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL2)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Embarking/disembarking Passenger',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;
exception

  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Embarking/disembarking Passenger'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Embarking/disembarking Passenger'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;

end;





begin 


 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL3)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Taking Bunkers',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Taking Bunkers'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Taking Bunkers'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;
end;



begin 

 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL4)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Taking Suppliers',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Taking Suppliers'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Taking Suppliers'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;
end;


begin 

 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL5)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
 'Changing Crew',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;



exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Changing Crew'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Changing Crew'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;
end;


begin

 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL6)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Repair/Docking/Outfitting',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Repair/Docking/Outfitting'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Repair/Docking/Outfitting'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;
end;


begin


 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL7)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
'Offshore Vessel',
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||'Offshore Vessel'  ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
'Offshore Vessel'  ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;

end;





begin

 IF trim(upper(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALL9)) =  'Y'  then 

insert into departure_gd_purpose_of_call(
DEP_GD_PURP_OF_CALL_ID_N,
APPLN_REF_N,
PURPCALL_C,
DELETED_I,
LOCK_VER_N,
OTHERS_PURPOSE_X,
PURP_CALL_OTHERS_TOW_X,
PURPCALL_OTHERS_TOW_VSL_M)

values
(SEQ_DEP_GD_POC.nextval,
seq_dep_gd_app.currval, 
Decode(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,'SI','Shipped in as Cargo','SO','Shipped out as Cargo','TO','Towing','RP',' Recreation/Pleasure','OT','Other'),
0,
0,
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X,
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X,null),		
 decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X),'TO',
    (decode(trim(LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X),'TOU', LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M,null))));

end if;


exception


  when others then 

            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 
            
                i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEPARTURE_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval ||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval  ||'<{||}>'||
'PURPCALL_C:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X ||'<{||}>'||
'DELETED_I:'||0  ||'<{||}>'||
'LOCK_VER_N:'||0  ||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval ||'<{||}>'||
seq_dep_gd_app.currval  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X ||'<{||}>'||
0  ||'<{||}>'||
0  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X  ||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M

 ,
 'T'
 );
 
 end if;
end;



exception   -- exception of DEP GD poc

when others then 

 V_ERR_CODE := SQLCODE;
  V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
 V_SQLERRM := V_ERR_CODE || V_ERR_MSG;
 
     i_excep_cnt_tgt_poc := i_excep_cnt_tgt_poc +1;

if i_excep_cnt_tgt_poc < 50000  then 

  PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION
  ( 'DEP_POC',
  'PROC_2_DEPGD_DEPOC',
'DEP_GD_PURP_OF_CALL_ID_N:'||SEQ_DEP_GD_POC.currval||'<{||}>'||
'APPLN_REF_N:'||seq_dep_gd_app.currval||'<{||}>'||
'PURPCALL_C:'||'***'||'<{||}>'||
'DELETED_I:'||'0'||'<{||}>'||
'LOCK_VER_N:'||0||'<{||}>'||
'OTHERS_PURPOSE_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X||'<{||}>'||
'PURP_CALL_OTHERS_TOW_X:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X||'<{||}>'||
'PURPCALL_OTHERS_TOW_VSL_M:'||LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
'ERROR',
PV_RUN_ID,
V_SQLERRM,
SEQ_DEP_GD_POC.currval||'<{||}>'||
seq_dep_gd_app.currval||'<{||}>'||
'***'||'<{||}>'||
'0'||'<{||}>'||
0||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERS_X||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOW_X||'<{||}>'||
LV_GD_APPLLICATION(i).v_DEP_POC_PURPCALLOTHERSTOWVSL_M
 ,
 'T'
 );
 end if;


continue;
end;    -- end of DEP GD POC

/****************************************************************************************************************************************

insertion into DEP poc ends 
*******************************************************************************************************************************************/






















--end if; -- end of V_FLAG

                  end loop;    -- end loop of LV_GD_APPLLICATION.FIRST..LV_GD_APPLLICATION.LAST   
commit;

end loop; -- end of CUR_GD_APPLN


close CUR_GD_APPLN;




/*****************************************************************************************************************************

CALLING A PROC TO dELETE THE dATA   FROM THE APPLICATION SUBMISSION WHICH ARE NOT PRESENT IN DEPARTURE GD  --START

*******************************************************************************************************************************/


proc_depgd_appsub_del();



/*****************************************************************************************************************************

CALLING A PROC TO dELETE THE dATA   FROM THE APPLICATION SUBMISSION WHICH ARE NOT PRESENT IN DEPARTURE GD  --ENDS

*******************************************************************************************************************************/





/*****************************************************************************************************************************


*******************************************************************************************************************************/




/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO    v_src_count
FROM    st_cv_gdappln appln
where   appln.GDTY_C in('D','C') ;



SELECT COUNT(*)
INTO V_TGT_COUNT
FROM
SI_DEP_DEPOC ;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_gdappln', V_SRC_COUNT, 'SI_DEP_DEPOC', V_TGT_COUNT,'N');	




        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into SI_DEP_DEPOC table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_DEPOC table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_DEPOC table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_DEP_DEPOC table' ,
        'AMBIGIOUS',null,null,null,null);

end if;




/***********************************************************************************************************
Reconciling the count of source staging  GD Arrival  and source intermdiate of GD Departure ends 
*************************************************************************************************************/






/***********************************************************************************************************
Reconciling the count of source intermediate GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO v_src_count
FROM
SI_DEP_DEPOC;



     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM departure_gd_application;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('SI_DEP_DEPOC', V_SRC_COUNT, 'DEPARTURE_GD_APPLICATION', V_TGT_COUNT,'N');	  



        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into DEPARTURE_GD_APPLICATION table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEPARTURE_GD_APPLICATION table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEPARTURE_GD_APPLICATION table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('DEPARTURE_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into DEPARTUREGD_APPLICATION table' ,
        'AMBIGIOUS',null,null,null,null);

end if;

/***********************************************************************************************************
Reconcilation of source intermediate GD Arrival  and target table of GD Departure  ends
*************************************************************************************************************/








/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure starts 
*************************************************************************************************************/



SELECT COUNT(*)
INTO    v_src_count
FROM    st_cv_gdappln appln
where   appln.GDTY_C in('D','C') ;


     SELECT COUNT(*)
     INTO V_TGT_COUNT
     FROM departure_gd_application;



  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('st_cv_gdappln', V_SRC_COUNT, 'DEPARTURE_GD_APPLICATION', V_TGT_COUNT,'Y');	  




/***********************************************************************************************************
Reconciling the count of staging  GD Arrival  and target table of GD Departure ends 
*************************************************************************************************************/


/***********************************************************************************************************
Reconcilation of GD Departure  POC starts
*************************************************************************************************************/

     SELECT SUM (CNT) INTO v_src_count  FROM (
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL1 ='Y' )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL2 ='Y'   ) 
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL3 ='Y'  )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL4 ='Y'  ) 
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL5 ='Y'  )
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL6 ='Y'  ) 
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL7 ='Y'  ) 
    UNION ALL
    (SELECT COUNT(*) CNT FROM SI_DEP_DEPOC WHERE DEP_POC_PURPCALL9 ='Y'  ) 
    );




   select count(*)  into V_TGT_COUNT from departure_gd_purpose_of_call;


  PKG_DATAMIGRATION_GENERIC.PROC_MIGRATION_RECON('No:of Ys in SI_DEP_DEPOC', V_SRC_COUNT, 'departure_gd_purpose_of_call', V_TGT_COUNT,'Y');	  



        if (v_tgt_count =  v_src_count ) and v_src_count <>  0  and v_tgt_count <> 0 then 

         PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('departure_gd_purpose_of_call', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows  have been inserted into departure_gd_purpose_of_call table' ,
        'SUCCESS',null,null,null,null);

        elsif v_tgt_count  <> v_src_count and v_tgt_count <> 0 then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('departure_gd_purpose_of_call', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into departure_gd_purpose_of_call table' ,
        'PARTIALLY SUCCESSFULL',null,null,null,null);


    elsif (v_tgt_count  <> v_src_count or v_tgt_count  = v_src_count ) and (v_tgt_count = 0) then 

        PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('departure_gd_purpose_of_call', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into departure_gd_purpose_of_call table' ,
        'FAIL',null,null,null,null);

        else 

    PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('departure_gd_purpose_of_call', 'PROC_2_DEPGD_DEPOC', 
 v_tgt_count ||' out of ' ||v_src_count ||' rows have been inserted into departure_gd_purpose_of_call table' ,
        'AMBIGIOUS',null,null,null,null);

end if;



/***********************************************************************************************************
Reconcilation of GD Departure POC  Ends
*************************************************************************************************************/



































exception  --outer exception 

when others then 


            V_ERR_CODE := SQLCODE;
            V_ERR_MSG := SUBSTR(SQLERRM, 1, 200) || dbms_utility.format_error_backtrace;
            V_SQLERRM := V_ERR_CODE || V_ERR_MSG; 

              PKG_DATAMIGRATION_GENERIC.PROC_TRACE_EXCEPTION('ARR_DEP_GD_APPLICATION', 'PROC_2_DEPGD_DEPOC', V_SQLERRM, 'FAIL',null,null,null,'T');

end ;  -- outer end
/