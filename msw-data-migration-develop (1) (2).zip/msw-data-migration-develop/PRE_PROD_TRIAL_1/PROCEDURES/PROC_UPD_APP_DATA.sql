create or replace procedure PROC_UPD_APP_DATA
/***********************************************************************************************************
procedure name : PROC_UPD_APP_DATA
Created By     : Mariamma Joseph
Date           : 14-AUG-2019
Purpose        : Update the JSON value in APPLICATION_SUBMISSION table

Modified by    :
Modified date  :

*************************************************************************************************************/
(
PV_APP_TYP VARCHAR2
)

IS 
CURSOR CUR_APP_DAT
IS 
SELECT APPLN_SUBMISSN_ID_N,APPLN_DATA_X ,MSW_VSL_REF_ID
 FROM 
 SI_JSON WHERE APPLN_TYPE=PV_APP_TYP;

 TYPE REC_APP_DAT IS RECORD
(
APPLN_SUBMISSN_ID_N 	SI_JSON.APPLN_SUBMISSN_ID_N%type,
APPLN_DATA_X		SI_JSON.APPLN_DATA_X%type,
MSW_VSL_REF_ID     SI_JSON.msw_vsl_ref_id%type
);
TYPE TYPE_APP_TBL  IS TABLE OF REC_APP_DAT;
LV_APP_TBL				TYPE_APP_TBL;
--lv_APP_DAT_TBL APP_DAT_TBL;


BEGIN




if pv_app_typ = 'PAN' or pv_app_typ =  'GDD'  then 

open CUR_APP_DAT;
Loop
fetch CUR_APP_DAT 
bulk collect into LV_APP_TBL limit 1000;
exit when LV_APP_TBL.count = 0;
forall i in LV_APP_TBL.first .. LV_APP_TBL.last 

UPDATE APPLICATION_SUBMISSION SET 
APPLN_DATA_X=LV_APP_TBL(i).APPLN_DATA_X WHERE 
MSW_APPLN_REF_ID_X=LV_APP_TBL(i).MSW_VSL_REF_ID;

commit;

end Loop;




close CUR_APP_DAT;


else 

open CUR_APP_DAT;
Loop
fetch CUR_APP_DAT 
bulk collect into LV_APP_TBL limit 10000;

exit when LV_APP_TBL.count = 0;

forall i in LV_APP_TBL.first .. LV_APP_TBL.last 







UPDATE APPLICATION_SUBMISSION SET 
APPLN_DATA_X=LV_APP_TBL(i).APPLN_DATA_X WHERE 
APPLN_SUBMISSN_ID_N=LV_APP_TBL(i).APPLN_SUBMISSN_ID_N;




commit;
end Loop;
close CUR_APP_DAT;


end if;

exception when others then


pkg_datamigration_generic.proc_trace_exception(
'UPDJSON',
'PROC_UPD_APP_DATA',
SQLERRM||dbms_utility.format_error_backtrace||
dbms_utility.format_error_stack
, 'ERROR',
null, 
SQLERRM,
NULL,
'T');
END;
/