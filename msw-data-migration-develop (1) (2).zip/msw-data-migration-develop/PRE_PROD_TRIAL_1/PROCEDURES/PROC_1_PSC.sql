create or replace PROCEDURE PROC_1_PSC(PV_RUN_ID IN NUMBER) IS

/***************************************
declaring Cursor  VARIable for intermediate table
****************************************/



/*************************************************************************************************************************************************************************	
			procedure name : PROC_PAN_SHIP_CERTIFICATE
			Created By     : Vaishnavi R. Yembarwar
			Date           : 17-APR-2019
			Purpose        : Inserting  the data from ST_PANS_pansInfoFrMRLog3,
                             SI_PAN_SHIP_ACTIVITY to             
                             Target table "PAN_SHIP_CERTIFICATE".
			Modified by    :C.N.Bhaskar
			Modified date  :
*************************************************************************************************************************************************************************/



cursor cr_pan1_shpC is

    SELECT 

                b.APPLN_REF_N,
                VALIDCR_I ,
                validPSS_i,
                validSCC_i,
                validSRC_i,
                validDC_i,
                validSMC_i,
                validIOPP_i,
                validICF_i,
                validISPP_i,
                VALIDIAPP_I,
                validILLC_i,
                validITC_i,
                validIAS_i,
                validBCC_i,
                validCLC_i,
             VALIDISSC_I,
			 certCRExpy_dt,
			 certPSSExpy_dt,
			 certSCCExpy_dt,
			 certSRCExpy_dt,
			 certDCExpy_dt,
			 certSMCExpy_dt,
			 certIOPPExpy_dt,
			 certICFExpy_dt,
			 certISPPExpy_dt,
			 certIAPPExpy_dt,
			 certILLCExpy_dt,
			 certITCExpy_dt,
			 certIASExpy_dt,
			 certCLCExpy_dt,
			 certBCCExpy_dt,
             CERTISSCEXPY_DT,
			CERTISSCAUTH_X,
            TIMESTAMP_DT,
			USERID_N

   from ST_PANS_pansInfoFrMRLog3 a, 
   pan_application b
   where
   a.pansid_n=b.EXTL_APPLN_REF_ID_X;           



-----------defining the 'record type'-------------  


		v_dr_st_count          number;
		v_src_count            INTEGER;
		v_tgt_count            INTEGER;
		v_err_code             NUMBER;
		v_err_msg              VARCHAR2(2000);
		v_sqlerrm              VARCHAR2(2500);
        V_EXP_ROWS             VARCHAR2(2000);
		v_blkexptn_count       NUMBER(20, 0);
		v_blkexptn_desc        VARCHAR2(3000);	
        v_tgt_count1           NUMBER(20);
        V_SI_COUNT             NUMBER(20);
	    v_exp_rows1            VARCHAR2(1000);
        v_exp_rows2            VARCHAR2(1000);
		v_exp_rows3            VARCHAR2(1000);
		v_exp_rows4            VARCHAR2(1000);
		v_exp_rows5            VARCHAR2(1000);
		v_exp_rows6            VARCHAR2(1000);
		v_exp_rows7            VARCHAR2(1000);
		v_exp_rows8            VARCHAR2(1000);
		v_exp_rows9            VARCHAR2(1000);
		v_exp_rows10           VARCHAR2(1000);
		v_exp_rows11           VARCHAR2(1000);
		v_exp_rows12           VARCHAR2(1000);
		v_exp_rows13           VARCHAR2(1000);
		v_exp_rows14           VARCHAR2(1000);
		v_exp_rows15           VARCHAR2(1000);
		v_exp_rows16           VARCHAR2(1000);
		v_exp_rows17           VARCHAR2(1000);
		v_exp_rows18           VARCHAR2(1000);
		v_exp_rows19           VARCHAR2(1000);



/***------------------------------------------------
declaring Cursor the VARIable for TARGET table
----------------------------------------------**/				

Cursor pan2_shpC is							

         SELECT 
	             APPLNREF_N,               
				 VALIDCR_I ,
				 validPSS_i,
                 validSCC_i,
				 validSRC_i,
				 validDC_i,
				 validSMC_i,
				 validIOPP_i,
				 validICF_i,
				 validISPP_i,
				 VALIDIAPP_I,
				 validILLC_i,
				 validITC_i,
				 validIAS_i,
				 validBCC_i,
				 validCLC_i,
				 validISSC_i,
                 certCRExpy_dt,
                 certPSSExpy_dt,
                 certSCCExpy_dt,
                 certSRCExpy_dt,
                 certDCExpy_dt,
                 certSMCExpy_dt,
                 certIOPPExpy_dt,
                 certICFExpy_dt,
                 certISPPExpy_dt,
                 certIAPPExpy_dt,
                 certILLCExpy_dt,
                 certITCExpy_dt,
                 certIASExpy_dt,
                 certCLCExpy_dt,
                 certBCCExpy_dt,
                 CERTISSCEXPY_DT,
                 CERTISSCAUTH_X,        	
                 TIMESTAMP_DT,
                 USERID_N
	       from 
       SI_PAN_SHIP_CERTIFICATE;

	TYPE rec_pan_CT_TG  is record
    (

	v_applnRef_n   			SI_PAN_SHIP_CERTIFICATE.applnRef_n%TYPE,
	v_VALIDCR_I 		    SI_PAN_SHIP_CERTIFICATE.VALIDCR_I%TYPE,
	v_validPSS_i			SI_PAN_SHIP_CERTIFICATE.validPSS_i%TYPE,
	v_validSCC_i			SI_PAN_SHIP_CERTIFICATE.validSCC_i%TYPE,
	v_validSRC_i			SI_PAN_SHIP_CERTIFICATE.validSRC_i%TYPE,
	v_validDC_i				SI_PAN_SHIP_CERTIFICATE.validDC_i%TYPE,
	v_validSMC_i			SI_PAN_SHIP_CERTIFICATE.validSMC_i%TYPE,
	v_validIOPP_i			SI_PAN_SHIP_CERTIFICATE.validIOPP_i%TYPE,
	v_validICF_i			SI_PAN_SHIP_CERTIFICATE.validICF_i%TYPE,
	v_validISPP_i			SI_PAN_SHIP_CERTIFICATE.validISPP_i%TYPE,
	v_VALIDIAPP_I			SI_PAN_SHIP_CERTIFICATE.VALIDIAPP_I%TYPE,
	v_validILLC_i			SI_PAN_SHIP_CERTIFICATE.validILLC_i%TYPE,
	v_validITC_i			SI_PAN_SHIP_CERTIFICATE.validITC_i%TYPE,
	v_validIAS_i			SI_PAN_SHIP_CERTIFICATE.validIAS_i%TYPE,
	v_validBCC_i			SI_PAN_SHIP_CERTIFICATE.validBCC_i%TYPE,
	v_validCLC_i			SI_PAN_SHIP_CERTIFICATE.validCLC_i%TYPE,
	v_validISSC_i			SI_PAN_SHIP_CERTIFICATE.validISSC_i%TYPE,
	v_certCRExpy_dt		    SI_PAN_SHIP_CERTIFICATE.certCRExpy_dt%TYPE,
	v_certPSSExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certPSSExpy_dt%TYPE,
	v_certSCCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certSCCExpy_dt%TYPE,
	v_certSRCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certSRCExpy_dt%TYPE,
	v_certDCExpy_dt		    SI_PAN_SHIP_CERTIFICATE.certDCExpy_dt%TYPE,
	v_certSMCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certSMCExpy_dt%TYPE,
	v_certIOPPExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certIOPPExpy_dt%TYPE,
	v_certICFExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certICFExpy_dt%TYPE,
	v_certISPPExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certISPPExpy_dt%TYPE,
	v_certIAPPExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certIAPPExpy_dt%TYPE,
	v_certILLCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certILLCExpy_dt%TYPE,
	v_certITCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certITCExpy_dt%TYPE,
	v_certIASExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certIASExpy_dt%TYPE,
	v_certCLCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certCLCExpy_dt%TYPE,
	v_certBCCExpy_dt	    SI_PAN_SHIP_CERTIFICATE.certBCCExpy_dt%TYPE,
    v_CERTISSCEXPY_DT   	SI_PAN_SHIP_CERTIFICATE.CERTISSCEXPY_DT%TYPE,
    v_CERTISSCAUTH_X   	    SI_PAN_SHIP_CERTIFICATE.CERTISSCAUTH_X%TYPE,
    v_TIMESTAMP_DT       	SI_PAN_SHIP_CERTIFICATE.TIMESTAMP_DT%TYPE,	
	v_USERID_N   			SI_PAN_SHIP_CERTIFICATE.USERID_N%TYPE

	);

	TYPE type_pan_ship_CT_TG
           IS Table of rec_pan_CT_TG;

		lv_pan_ship_CT_TG      type_pan_ship_CT_TG;

   --  	SEQ_PAN_SHP_CERT.NEXTVAL    PAN_SHIP_CERTificate.PAN_SHIP_CERT_ID_N%type;

i_excep_cnt_si  number := 0;


i_excep_cnt_tgt  number := 0; 

lv_expiry_dt TIMESTAMP;

BEGIN  -- outer begin 



  pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_PSC', 'SI_PAN_SHIP_CERTIFICATE', 'START',PV_RUN_ID,NULL,NULL,'T');

 FOR  i IN  cr_pan1_shpC	loop   -- si for loop
  BEGIN    -- begin  for SI 
	INSERT INTO SI_PAN_SHIP_CERTIFICATE 
           (        
                   APPLNREF_N,
                    VALIDCR_I ,
                    validPSS_i,
                    validSCC_i,
                    validSRC_i,
                    validDC_i,
                    validSMC_i,
                    validIOPP_i,
                    validICF_i,
                    validISPP_i,
                    VALIDIAPP_I,
                    validILLC_i,
                    validITC_i,
                    validIAS_i,
                    validBCC_i,
                    validCLC_i,
                    validISSC_i, 
                 certCRExpy_dt,
                 certPSSExpy_dt,
                 certSCCExpy_dt,
                 certSRCExpy_dt,
                 certDCExpy_dt,
                 certSMCExpy_dt,
                 certIOPPExpy_dt,
                 certICFExpy_dt,
                 certISPPExpy_dt,
                 certIAPPExpy_dt,
                 certILLCExpy_dt,
                 certITCExpy_dt,
                 certIASExpy_dt,
                 certBCCExpy_dt,
                 certCLCExpy_dt,                 
                CERTISSCEXPY_DT,
				CERTISSCAUTH_X,
                TIMESTAMP_DT,
				USERID_N
            )			
     Values
           (

            i.APPLN_REF_N   ,
            i.VALIDCR_I ,
            i.validPSS_i,
            i.validSCC_i,
            i.validSRC_i,
            i.validDC_i,
            i.validSMC_i,
            i.validIOPP_i,
            i.validICF_i,
            i.validISPP_i,
            i.VALIDIAPP_I,
            i.validILLC_i,
            i.validITC_i,
            i.validIAS_i,
            i.validBCC_i,
            i.validCLC_i,
            i.validISSC_i,
            i.certCRExpy_dt,
            i.certPSSExpy_dt,
            i.certSCCExpy_dt,
            i.certSRCExpy_dt,
            i.certDCExpy_dt,
            i.certSMCExpy_dt,
            i.certIOPPExpy_dt,
            i.certICFExpy_dt,
            i.certISPPExpy_dt,
            i.certIAPPExpy_dt,
            i.certILLCExpy_dt,
            i.certITCExpy_dt,
            i.certIASExpy_dt,
            i.certCLCExpy_dt,
            i.certBCCExpy_dt,
            i.CERTISSCEXPY_DT  ,
            i.CERTISSCAUTH_X   ,
            i.TIMESTAMP_DT    , 
            i.USERID_N 



		);

EXCEPTION  -- exception si  
        WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  

           v_exp_rows :=
                       'APPLNREF_N :'	    ||i.APPLN_REF_N||'<{||}>'||
                        'VALIDCR_I  :'	    ||i.VALIDCR_I 	||'<{||}>'||
                        'validPSS_i :'	    ||i.validPSS_i 	||'<{||}>'||
                        'validSCC_i :'	    ||i.validSCC_i 	||'<{||}>'||
                        'validSRC_i :'	    ||i.validSRC_i 	||'<{||}>'||
                        'validDC_i :'	    ||i.validDC_i 	||'<{||}>'||
                        'validSMC_i :'	    ||i.validSMC_i 	||'<{||}>'||
                        'validIOPP_i :'	    ||i.validIOPP_i	||'<{||}>'||
                        'validICF_i :'	    ||i.validICF_i 	||'<{||}>'||
                        'validISPP_i :'	    ||i.validISPP_i ||'<{||}>'||
                        'VALIDIAPP_I :'	    ||i.VALIDIAPP_I ||'<{||}>'||
                        'validILLC_i :' 	||i.validILLC_i ||'<{||}>'||
                        'validITC_i :'	    ||i.validITC_i 	||'<{||}>'||
                        'validIAS_i :'	    ||i.validIAS_i 	||'<{||}>'||
                        'validBCC_i :'	    ||i.validBCC_i 	||'<{||}>'||
                        'validCLC_i :'	    ||i.validCLC_i 	||'<{||}>'||
                        'validISSC_i  :'	||i.validISSC_i ||'<{||}>'||
                        'certCRExpy_dt :'	||i.certCRExpy_dt||'<{||}>'||
                        'certPSSExpy_dt :'	||i.certPSSExpy_dt||'<{||}>'||
                        'certSCCExpy_dt :'	||i.certSCCExpy_dt||'<{||}>'||
                        'certSRCExpy_dt :'	||i.certSRCExpy_dt||'<{||}>'||
                        'certDCExpy_dt :'	||i.certDCExpy_dt||'<{||}>'||
                        'certSMCExpy_dt :'	||i.certSMCExpy_dt||'<{||}>'||
                        'certIOPPExpy_dt :'	||i.certIOPPExpy_dt||'<{||}>'||
                        'certICFExpy_dt :'	||i.certICFExpy_dt||'<{||}>'||
                        'certISPPExpy_dt :'	||i.certISPPExpy_dt||'<{||}>'||
                        'certIAPPExpy_dt :'	||i.certIAPPExpy_dt||'<{||}>'||
                        'certILLCExpy_dt :'	||i.certILLCExpy_dt||'<{||}>'||
                        'certITCExpy_dt :'	||i.certITCExpy_dt||'<{||}>'||
                        'certIASExpy_dt :'	||i.certIASExpy_dt||'<{||}>'||
                        'certBCCExpy_dt :'	||i.certCLCExpy_dt||'<{||}>'||
                        'certCLCExpy_dt :'	||i.certBCCExpy_dt||'<{||}>'||
                        'CERTISSCEXPY_DT :'	||i.CERTISSCEXPY_DT||'<{||}>'||
                        'CERTISSCAUTH_X :'	||i.CERTISSCAUTH_X||'<{||}>'||
                        'TIMESTAMP_DT :'	||i.TIMESTAMP_DT||'<{||}>'||
                        'USERID_N:'	||i.USERID_N ;	
                        
i_excep_cnt_si := i_excep_cnt_si +1;

if i_excep_cnt_si < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'SI_PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC', 
             v_exp_rows ,
             'ERROR',
              PV_RUN_ID,
              v_sqlerrm,
                i.APPLN_REF_N||'<{||}>'||
                i.VALIDCR_I 	||'<{||}>'||
                i.validPSS_i 	||'<{||}>'||
                i.validSCC_i 	||'<{||}>'||
                i.validSRC_i 	||'<{||}>'||
                i.validDC_i 	||'<{||}>'||
                i.validSMC_i 	||'<{||}>'||
                i.validIOPP_i	||'<{||}>'||
                i.validICF_i 	||'<{||}>'||
                i.validISPP_i ||'<{||}>'||
                i.VALIDIAPP_I ||'<{||}>'||
                i.validILLC_i ||'<{||}>'||
                i.validITC_i 	||'<{||}>'||
                i.validIAS_i 	||'<{||}>'||
               i.validBCC_i 	||'<{||}>'||
                i.validCLC_i 	||'<{||}>'||
                i.validISSC_i ||'<{||}>'||
                i.certCRExpy_dt||'<{||}>'||
                i.certPSSExpy_dt||'<{||}>'||
                i.certSCCExpy_dt||'<{||}>'||
                i.certSRCExpy_dt||'<{||}>'||
               i.certDCExpy_dt||'<{||}>'||
               i.certSMCExpy_dt||'<{||}>'||
                i.certIOPPExpy_dt||'<{||}>'||
               i.certICFExpy_dt||'<{||}>'||
                i.certISPPExpy_dt||'<{||}>'||
               i.certIAPPExpy_dt||'<{||}>'||
               i.certILLCExpy_dt||'<{||}>'||
                 i.certITCExpy_dt||'<{||}>'||
                 i.certIASExpy_dt||'<{||}>'||
                i.certCLCExpy_dt||'<{||}>'||
                 i.certBCCExpy_dt||'<{||}>'||
                 i.CERTISSCEXPY_DT||'<{||}>'||
               i.CERTISSCAUTH_X||'<{||}>'||
               i.TIMESTAMP_DT||'<{||}>'||
              i.USERID_N ,
              'T');
              
              end if;



  END;  -- end si 

 END LOOP;      -- si end loop 


 /*****************----------------------------buisness error starts here----------------------***************/
/*

 begin

 for i in
 (
   select * from ST_PANS_pansInfoFrMRLog3  
    where pansid_n  not in 
    (select EXTL_APPLN_REF_ID_X  from  pan_application ))

 loop

 pkg_datamigration_generic.proc_trace_exception('SI_PAN_SHIP_CERTIFICATE', 'proc_1_PSC','uncommon recordss',
                                                               null,PV_RUN_ID,null, 
                                                                'VSLRECID_N:'	||	i.VSLRECID_N	||'<{||}>'||
                                                                'PANSID_N:'||i.PANSID_N	||'<{||}>'||
                                                                'VALIDISSC_I:'||i.VALIDISSC_I||'<{||}>'||
                                                                'CERTISSCAUTH_X:'||i.CERTISSCAUTH_X	||'<{||}>'||
                                                                'CERTISSCEXPY_DT:'||i.CERTISSCEXPY_DT||'<{||}>'||
                                                                'VALIDCR_I:'	||i.VALIDCR_I||'<{||}>'||
                                                                'CERTCRAUTH_X:'	||i.CERTCRAUTH_X||'<{||}>'||
                                                                'CERTCREXPY_DT:'||i.CERTCREXPY_DT	||'<{||}>'||
                                                                'VALIDPSS_I:'	||i.VALIDPSS_I	||'<{||}>'||
                                                                'CERTPSSAUTH_X:'||i.CERTPSSAUTH_X	||'<{||}>'||
                                                                'CERTPSSEXPY_DT:'||	i.CERTPSSEXPY_DT||'<{||}>'||
                                                                'VALIDSCC_I:'	||i.VALIDSCC_I	||'<{||}>'||
                                                                'CERTSCCAUTH_X:'||i.CERTSCCAUTH_X	||'<{||}>'||
                                                                'CERTSCCEXPY_DT:'||	i.CERTSCCEXPY_DT||'<{||}>'||
                                                                'VALIDSRC_I:'	||i.VALIDSRC_I	||'<{||}>'||
                                                                'CERTSRCAUTH_X:'||i.CERTSRCAUTH_X	||'<{||}>'||
                                                                'CERTSRCEXPY_DT:'||i.CERTSRCEXPY_DT	||'<{||}>'||
                                                                'VALIDDC_I:'	||i.VALIDDC_I	||'<{||}>'||
                                                                'CERTDCAUTH_X:'	||i.CERTDCAUTH_X||'<{||}>'||
                                                                'CERTDCEXPY_DT:'||i.CERTDCEXPY_DT||'<{||}>'||
                                                                'VALIDSMC_I:'	||i.VALIDSMC_I	||'<{||}>'||
                                                                'CERTSMCAUTH_X:'||i.CERTSMCAUTH_X||'<{||}>'||
                                                                'CERTSMCEXPY_DT:'||i.CERTSMCEXPY_DT	||'<{||}>'||
                                                                'VALIDIOPP_I:'	||i.VALIDIOPP_I	||'<{||}>'||
                                                                'CERTIOPPAUTH_X:'||	i.CERTIOPPAUTH_X||'<{||}>'||
                                                                'CERTIOPPEXPY_DT:'||i.CERTIOPPEXPY_DT||'<{||}>'||
                                                                'VALIDICF_I:'	||i.VALIDICF_I	||'<{||}>'||
                                                                'CERTICFAUTH_X:'||i.CERTICFAUTH_X||'<{||}>'||
                                                                'CERTICFEXPY_DT:'||i.CERTICFEXPY_DT	||'<{||}>'||
                                                                'VALIDISPP_I:'	||i.VALIDISPP_I	||'<{||}>'||
                                                                'CERTISPPAUTH_X:'||i.CERTISPPAUTH_X	||'<{||}>'||
                                                                'CERTISPPEXPY_DT:'||i.CERTISPPEXPY_DT||'<{||}>'||
                                                                'VALIDIAPP_I:'	||i.VALIDIAPP_I	||'<{||}>'||
                                                                'CERTIAPPAUTH_X:'||	i.CERTIAPPAUTH_X||'<{||}>'||
                                                                'CERTIAPPEXPY_DT:'||i.CERTIAPPEXPY_DT||'<{||}>'||
                                                                'VALIDILLC_I:'	||i.VALIDILLC_I	||'<{||}>'||
                                                                'CERTILLCAUTH_X:'||i.CERTILLCAUTH_X	||'<{||}>'||
                                                                'CERTILLCEXPY_DT:'||i.CERTILLCEXPY_DT||'<{||}>'||
                                                                'VALIDITC_I:'	||i.VALIDITC_I	||'<{||}>'||
                                                                'CERTITCAUTH_X:'||i.CERTITCAUTH_X||'<{||}>'||
                                                                'CERTITCEXPY_DT:'||i.CERTITCEXPY_DT	||'<{||}>'||
                                                                'VALIDIAS_I:'	||i.VALIDIAS_I	||'<{||}>'||
                                                                'CERTIASAUTH_X:'||i.CERTIASAUTH_X||'<{||}>'||
                                                                'CERTIASEXPY_DT:'||i.CERTIASEXPY_DT	||'<{||}>'||
                                                                'VALIDCLC_I:'	||i.VALIDCLC_I	||'<{||}>'||
                                                                'CERTCLCAUTH_X:'||i.CERTCLCAUTH_X||'<{||}>'||
                                                                'CERTCLCEXPY_DT:'||i.CERTCLCEXPY_DT	||'<{||}>'||
                                                                'VALIDBCC_I:'	||i.VALIDBCC_I	||'<{||}>'||
                                                                'CERTBCCAUTH_X:'||i.CERTBCCAUTH_X||'<{||}>'||
                                                                'CERTBCCEXPY_DT:'||i.CERTBCCEXPY_DT||'<{||}>'||
                                                                'USERID_N:'	||i.USERID_N	||'<{||}>'||
                                                                'TIMESTAMP_DT:'	||	i.TIMESTAMP_DT,
                                                                'B');


end loop;
exception  when others then 

 --- DBMS_OUTPUT.PUT_LINE(SQLERRM ||dbms_utility.format_error_backtrace );
      v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace   ;

end;


*/

 /**************************end of buisness erro logic*********************************/   


 /***********************************************************************************************************
INSERTING DATA FROM INTERMEDIATE TABLE INTO TARGET TABLE
*************************************************************************************************************/          			


open  pan2_shpC;

	   pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_PSC','PAN_SHIP_CERTIFICATE' , 'START',PV_RUN_ID,NULL,NULL,'T');

LOOP    -- cursor loop  pan2_shpC

 BEGIN   -- begin pan2_shpC  

    FETCH pan2_shpC  BULK COLLECT INTO lv_pan_ship_CT_TG LIMIT 3000;
	EXIT WHEN lv_pan_ship_CT_TG .count = 0;	
    FOR i IN lv_pan_ship_CT_TG .first..lv_pan_ship_CT_TG .last 

	LOOP --lv_pan_ship_CT_TG  for loop 
 /****************insertion statement for the col CERT_TY and DUE_DATE oF TAble PAN_SHIP_CERTIFICATE**********************/



         IF upper(trim(lv_pan_ship_CT_TG(i).v_VALIDCR_I)) =  'Y' 
         THEN 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certCRExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certCRExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
         begin 
        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
         'CR',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certCRExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,

		 Null,
		 Null,
		 0,
		 0		 

		 );


         exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'CR' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CR' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;


         end;



		END IF;



        IF upper(trim(lv_pan_ship_CT_TG(i).v_validPSS_i)) =  'Y' then

                        begin 

begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certPSSExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certPSSExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
         'PSS',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certPSSExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',		 
		 lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
         lv_pan_ship_CT_TG(i).v_USERID_N,
		 Null,
		 Null,
		 0,
		 0		 

		 );

                    exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'|| 'PSS' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					 'PSS' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


        end if;

		IF upper(trim(lv_pan_ship_CT_TG(i).v_validSCC_i)) =  'Y' then

                        begin 

begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSCCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSCCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
	      SEQ_PAN_SHP_CERT.NEXTVAL,
		  lv_pan_ship_CT_TG(i).v_applnRef_n,
         'SCC',
		  Null,
          lv_expiry_dt,
          --to_timestamp(lv_pan_ship_CT_TG(i).v_certSCCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM'),
		  lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
          null,
          null,
          'Accepted',
		  lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		  lv_pan_ship_CT_TG(i).v_USERID_N,
		  Null,
		  Null,
		  0,
		  0		 

		 );


                    exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'|| 'SCC'||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					 'SCC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;




		END IF;	

        IF upper(trim(lv_pan_ship_CT_TG(i).v_validSRC_i)) =  'Y' then

                        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSRCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSRCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;


           INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
         'SRC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certSRCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT,
		 lv_pan_ship_CT_TG(i).v_USERID_N,	
		 Null,
		 Null,
		 0,
		 0		 

		 );


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'|| 'SRC'||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					 'SRC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');


end if;

         end;


		END IF;

		IF upper(trim(lv_pan_ship_CT_TG(i).v_validDC_i)) =  'Y' then

                        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certDCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certDCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;


        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
         'DC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certDCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,
		 Null,
		 Null,
		 0,
		 0		 

		 );


                 exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  

i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'DC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'DC'||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;

		END IF;

		IF upper(trim(lv_pan_ship_CT_TG(i).v_validSMC_i)) =  'Y' then

                        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSMCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certSMCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;


         INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'SMC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certSMCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
        'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,	
		 Null,
		 Null,
		 0,
		 0		 

		 );

              exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'SMC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'SMC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


		END IF;

		IF upper(trim(lv_pan_ship_CT_TG(i).v_validIOPP_i)) =  'Y' then

                        begin 

begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIOPPExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIOPPExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'IOPP',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certIOPPExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
          lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT,	 
		 lv_pan_ship_CT_TG(i).v_USERID_N,		
		 Null,
		 Null,
		 0,
		 0		 

		 );


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  

i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'IOPP' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'IOPP' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;




		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validICF_i)) =  'Y' then

                begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certICFExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certICFExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'CF',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certICFExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT,	 
		 lv_pan_ship_CT_TG(i).v_USERID_N,		
		 Null,
		 Null,
		 0,
		 0		 
		 );

                       exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'CF' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CF' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;



		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validISPP_i)) =  'Y' then 

                begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certISPPExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certISPPExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

          INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'ISPP',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certISPPExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,    
		 Null,
		 Null,
		 0,
		 0		 

		 );


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  

i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'|| 'ISPP' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					 'ISPP' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;




		END IF;

		IF upper(trim(lv_pan_ship_CT_TG(i).v_VALIDIAPP_I)) =  'Y' then 

                begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIAPPExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIAPPExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
         INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'IAPP',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certIAPPExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	, 
		 lv_pan_ship_CT_TG(i).v_USERID_N,		
		 Null,
		 Null,
		 0,
		 0		 
		 );


                      exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  

i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 


             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'IAPP' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'IAPP' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validILLC_i)) =  'Y' then

                begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certILLCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certILLCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;

        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'ILLC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certILLCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',		 
		 lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
         lv_pan_ship_CT_TG(i).v_USERID_N,
		 Null,
		 Null,
		 0,
		 0		 
		 );


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'ILLC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'ILLC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validITC_i)) =  'Y' then

        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certITCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certITCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
          INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'ITC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certITCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,		 
		 Null,
		 Null,
		 0,
		 0		 

		 );   


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'ITC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'ITC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;

		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validIAS_i)) =  'Y' then

        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIASExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certIASExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'IAS',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certIASExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,

		 Null,
		 Null,
		 0,
		 0		 

		 );


       exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'IAS' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'IAS' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validBCC_i)) =  'Y' then

        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certBCCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certBCCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
'BCC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certBCCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,		 
		 Null,
		 Null,
		 0,
		 0		 
		 );


                      exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'BCC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'BCC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;


		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validCLC_i)) = 'Y' then

        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certCLCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certCLCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'CLC',
		 Null,
         lv_expiry_dt,
         --to_timestamp(lv_pan_ship_CT_TG(i).v_certCLCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
		 lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT,
		 lv_pan_ship_CT_TG(i).v_USERID_N,		
		 Null,
		 Null,
		 0,
		 0		 

		 );


                      exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'CLC' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CLC' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');
              
              end if;



         end;


		END IF;


		IF upper(trim(lv_pan_ship_CT_TG(i).v_validISSC_i)) =  'Y' then

        begin 
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certISSCExpy_dt, 'yyyy mm dd HH12:MI:SS:FF3AM');
exception 
when others then
begin
lv_expiry_dt:=to_timestamp(lv_pan_ship_CT_TG(i).v_certISSCExpy_dt, 'yymmdd hh12:mi:ss:ff3AM');
exception when others then
lv_expiry_dt:=null;
end;
end;
        INSERT INTO  PAN_SHIP_CERTIFICATE
	          (    
                        PAN_SHIP_CERT_ID_N,
						APPLN_REF_N,
						CERT_TY_C,
						ISSD_DT,
						DUE_D,
						ISS_AUTHY_CTRY_C,
						ISSG_CL_C,
						MANDT_CERT_I,
						PAN_CERTIFICATE_ST_C,
						CRT_ON_DT,
						CRT_BY_N,
						LAST_UPDATED_ON_DT,
						LAST_UPDATED_BY_N,
						DELETED_I,
						LOCK_VER_N

						)
       VALUES
	    (
		 SEQ_PAN_SHP_CERT.NEXTVAL,
         lv_pan_ship_CT_TG(i).v_applnRef_n,
        'ISS',
		 Null,
         lv_expiry_dt,
         --to_timestamp(Lv_pan_ship_CT_TG(i).v_certISSCExpy_dt,'yyyy mm dd HH12:MI:SS:FF3AM'),
	     lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X,
         null,
         null,
         'Accepted',
         lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT	 ,
		 lv_pan_ship_CT_TG(i).v_USERID_N,		
		 Null,
		 Null,
	     0,
		 0		 
		 );


                     exception

         WHEN OTHERS THEN
            v_err_code := sqlcode;
            v_err_msg := substr(sqlerrm, 1, 200);
            v_sqlerrm := v_err_code
                         || v_err_msg
                         ||dbms_utility.format_error_backtrace ;  


i_excep_cnt_tgt := i_excep_cnt_tgt +1;

if i_excep_cnt_tgt < 50000  then 

             pkg_datamigration_generic.proc_trace_exception(

             'PAN_SHIP_CERTIFICATE', 
             'proc_1_PSC',


                    'PAN_SHIP_CERT_ID_N:'||SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					'APPLN_REF_N:'||lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'CERT_TY_C:'||'ISS' ||'<{||}>'||
					'ISSD_DT:'||Null ||'<{||}>'||
					'DUE_D:'|| lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					'ISS_AUTHY_CTRY_C:'||lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					'ISSG_CL_C:'||null ||'<{||}>'||
					'MANDT_CERT_I:'||null  ||'<{||}>'||
					'PAN_CERTIFICATE_ST_C:'||'Accepted' ||'<{||}>'||
					'CRT_ON_DT:'||lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					'CRT_BY_N:'|| lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					'LAST_UPDATED_ON_DT:'||null ||'<{||}>'||
					'LAST_UPDATED_BY_N:'||null  ||'<{||}>'||
					'DELETED_I:'||0 ||'<{||}>'||
					'LOCK_VER_N:'||0
                           ,

             'ERROR',

              PV_RUN_ID,

              v_sqlerrm,


                    SEQ_PAN_SHP_CERT.currval ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_applnRef_n ||'<{||}>'||
					'ISS' ||'<{||}>'||
					Null ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_certCRExpy_dt ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_CERTISSCAUTH_X ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					'Accepted' ||'<{||}>'||
					lv_pan_ship_CT_TG(i).v_TIMESTAMP_DT ||'<{||}>'||
					 lv_pan_ship_CT_TG(i).v_USERID_N  ||'<{||}>'||
					null ||'<{||}>'||
					null  ||'<{||}>'||
					0 ||'<{||}>'||
					0


                ,

              'T');

end if;

         end;



		END IF;






 END LOOP;  --lv_pan_ship_CT_TG  for loop 

 END;  -- pan2_shpC  end 

END LOOP;  -- pan2_shpC   cursor end loop 


commit;

CLOSE pan2_shpC;	                 

/*----end of target cursor panship cert--------*/


-----driving table count---

 select count(*)
  into v_dr_st_count 
  from  ST_PANS_pansInfoFrMRLog3;


---count of staging table-----------------

       SELECT COUNT(*)              
            INTO v_src_count
              from ST_PANS_pansInfoFrMRLog3 a, pan_application b
               where
               a.pansid_n=b.EXTL_APPLN_REF_ID_X;                            

----count of intermediate table----------------- 

 select count(*)
  into v_si_count
   from si_pan_ship_certificate;






   if( v_si_count  =  v_src_count ) and v_si_count  <>  0  and  v_src_count <> 0 then     ----condition for migration table

        pkg_datamigration_generic.proc_trace_exception('QUERY_OUTPUT', 'proc_1_psc', 
        v_si_count ||' out of ' || v_src_count ||' rows  have been inserted into SI_pan_ship_certificate' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

    elsif  v_si_count <> v_src_count and  v_si_count  <> 0 then 

       pkg_datamigration_generic.proc_trace_exception('QUERY_OUTPUT', 'proc_1_psc', 
        v_si_count ||' out of ' ||v_src_count ||' rows have been inserted into SI_pan_ship_certificate' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


    elsif (v_si_count <>v_src_count or  v_src_count  = v_si_count ) and (v_si_count = 0) then 

        pkg_datamigration_generic.proc_trace_exception('QUERY_OUTPUT', 'proc_1_psc', 
         v_si_count  ||' out of ' ||v_src_count||' rows have been inserted into SI_pan_ship_certificate table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

    END IF;







 ----count of target table----------------- 

     SELECT COUNT(*)
            INTO  v_tgt_count1     ------- FOR intermediate TABLE
           FROM PAN_SHIP_CERTIFICATE;


---logic for recon count in target table recon--------------

   if(  v_si_count  = v_tgt_count1) and v_si_count <>  0  and v_tgt_count1 <> 0 then     ----condition for migration table
        pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_psc', 
        v_tgt_count1 ||' out of ' || v_si_count ||' rows  have been inserted into PAN_SHIP_CERTIFICATE' ,
        'SUCCESS',PV_RUN_ID,NULL,NULL,'T');

   elsif  v_si_count <> v_tgt_count1 and  v_tgt_count1 <> 0 then 
        pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_psc', 
        v_tgt_count||' out of ' ||v_tgt_count1 ||' rows have been inserted into PAN_SHIP_CERTIFICATE' ,
        'PARTIALLY SUCCESSFULL',PV_RUN_ID,NULL,NULL,'T');


   elsif (v_si_count <> v_tgt_count1 or  v_si_count  = v_tgt_count1) and (v_tgt_count1 = 0) then 
        pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_psc', 
        v_si_count  ||' out of ' ||v_tgt_count1||' rows have been inserted into PAN_SHIP_CERTIFICATE table' ,
        'FAIL',PV_RUN_ID,NULL,NULL,'T');

   END IF; 


/**************calling recon logic for panship certificate*************************/       



      pkg_datamigration_generic.proc_migration_recon('ST_PANS_pansInfoFrMRLog3', v_src_count , 'SI_PAN_SHIP_CERTIFICATE', v_si_count,'N'); 
	  pkg_datamigration_generic.proc_migration_recon('SI_PAN_SHIP_CERTIFICATE',  v_si_count, 'PAN_SHIP_CERTIFICATE', v_tgt_count1,'N'); 
      pkg_datamigration_generic.proc_migration_recon('ST_PANS_pansInfoFrMRLog3', v_dr_st_count , 'PAN_SHIP_CERTIFICATE',  v_tgt_count1,'Y'); 



/***************outer exception****************************/


	EXCEPTION  -- outrt exception 
      WHEN OTHERS THEN

        v_err_code := sqlcode;

                v_err_msg := substr(sqlerrm, 1, 200)||dbms_utility.format_error_backtrace||'PAN_ERROR';

                v_sqlerrm := v_err_code || v_err_msg;

        pkg_datamigration_generic.proc_trace_exception('PAN_SHIP_CERTIFICATE', 'proc_1_PSC', v_sqlerrm , 'ERROR',PV_RUN_ID,NULL,NULL,'T');
end;  -- outer end
/