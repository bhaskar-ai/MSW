#!/bin/bash
cd Load_Master_Tbl
sh runSrcSQLLoader.sh 2>&1 | tee 02_runSrcSQLLoader.log
cd ..
