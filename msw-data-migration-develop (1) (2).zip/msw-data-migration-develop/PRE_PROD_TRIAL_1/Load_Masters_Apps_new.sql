set serveroutput on;
set define off;
declare 
lv_cnt number;
lv_runid	number(10);
LV_CHK_RUN	NUMBER(2);
begin
lv_runid:=fnc_run_dm('TRANSFORM');
--DBMS_OUTPUT.PUT_line('1');
--SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL' AND FLOW='TRANSFORM';
--DBMS_OUTPUT.PUT_line('LV_CHK_RUN 2'||LV_CHK_RUN);
--IF LV_CHK_RUN = 0 THEN 
--proc_1_vsl(lv_cnt,lv_runid);
/*m if lv_cnt = 0 then 
insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL','Y',SYSDATE);
END IF;--LV_CNT

else 
--DBMS_OUTPUT.PUT_line('Inside slese 3');
	SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL_CERTIFICATE' AND FLOW='TRANSFORM';
--DBMS_OUTPUT.PUT_line('LV_CHK_RUN slese 3'||LV_CHK_RUN);
	if LV_CHK_RUN =0 then 
    --DBMS_OUTPUT.PUT_line('inside 5');
m*/	 --
--proc_1_vsl_cert_for(lv_cnt,lv_runid);
    --DBMS_OUTPUT.PUT_line('inside 6 - '||lv_cnt);
/*m	if lv_cnt=0 then 
		insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL_CERTIFICATE','Y',SYSDATE);
	end if;--lv_cnt
	else 
    -- DBMS_OUTPUT.PUT_line('inside 7 - '||lv_cnt);
	SELECT COUNT(*) INTO LV_CHK_RUN FROM TBL_RUN_DETAILS WHERE RUNID=lv_runid AND  TABLE_NAME='VESSEL_CERTIFICATE_ATTRIBUTES' AND FLOW='TRANSFORM'; 
		if LV_CHK_RUN =0 then 
m*/			--
--proc_1_vsl_cert_Attr(lv_runid);
/*m            insert into TBL_RUN_DETAILS values (lv_runid,'TRANSFORM','VESSEL_CERTIFICATE_ATTRIBUTES','Y',SYSDATE);
		end if;
	end if; --LV_CHK_RUN VESSEL_CERTIFICATE
*/
--PROC_1_CHANGE_AGENCY_APPLCN(lv_runid);
--PROC_1_CRUISE_OPERATOR_CONTROL(lv_runid);
--PROC_VC_VR_AS_DEL_ARRGD;
--PROC_2_ARRGD_PURCAL(lv_runid);
--PROC_1_ARRIVAL_GD_SHIPYARD_LOC(lv_runid);
--PROC_AGD_JSON;
--PROC_UPD_APP_DATA('AGD');
--PROC_2_DEPGD_DEPOC(lv_runid);
--PROC_1_DEP_GD_P_CLRCE_CERT(lv_runid);
--PROC_1_DEP_JSON;
--proc_2_dg_appl(lv_runid);
--PROC_DG_JSON;
--PROC_UPD_APP_DATA('DGD');
--PROC_2_PUSH_DGDS;
PROC_1_PUSH_DG_PSA_JPC;
--PROC_2_PUSH_DGCHEM_DGPSN;
--PROC_2_PAN_APP_VCALL(lv_runid);
--PROC_2_PAN_APP(lv_runid);
--PROC_1_PASS_PORT(lv_runid);
--PROC_1_PSA(lv_runid);
--PROC_1_PSC(lv_runid);
--PROC_2_PUSH_PA_POC;
--PROC_3_PUSH_PSC_PSA_PPC;
--PROC_2_HNS_APPL(lv_runid);
--PROC_3_PUSH_MASTERS;
--PROC_3_PUSH_ARRGD;
--PROC_3_PUSH_DEPGD;
--PROC_2_PUSH_HNS;
--PROC_1_SUBSTANCE(lv_runid);
--END IF; --LV_CHK_RUN Vessel
exception
when others then
dbms_OUTPUT.PUT_line('Error in Script'||sqlerrm|| dbms_utility.format_error_backtrace);
   

end;
/
