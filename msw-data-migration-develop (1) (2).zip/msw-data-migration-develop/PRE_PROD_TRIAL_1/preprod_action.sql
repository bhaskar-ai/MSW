alter table ST_CV_ARRGD modify MSTRONARR_X VARCHAR2(40 CHAR);
alter table st_dg_pm4 modify tn_m varchar2(300 char);
SQL> alter table ST_PANS_LAST10SHPTOSHPACTFRMRLOG modify userid_n varchar2(35 char);

Table altered.

SQL> alter table ST_PANS_LAST10SHPTOSHPACTFRMRLOG modify locnlat varchar2(15 char);

Table altered.

SQL> alter table ST_PANS_LAST10SHPTOSHPACTFRMRLOG modify locnlong varchar2(15 char);

Table altered.

SQL> alter table ST_PANS_LAST10SHPTOSHPACTFRMRLOG modify locn_x varchar2(30 char);

Table altered.i

SQL> alter table ST_PANS_PANSINFOFRMRLOG modify agenttelno_c varchar2(15 char);

Table altered.

SQL> alter table ST_PANS_PANSINFOFRMRLOG modify locn_x varchar2(20 char);

Table altered.

SQL> alter table ST_HN_NTCEDTL modify NTCESTWONBD varchar2(50 char);

Table altered.



SQL> alter table ST_HN_NTCEHDR modify NTCELOGINID_C varchar2(10 char);

Table altered.


SQL> alter table ST_PANS_PANSINFOFRMRLOG2 modify MVFWDDFT_Q number(3,1);

Table altered.

SQL> alter table ST_PANS_PANSINFOFRMRLOG2 modify mvmiddft_q number(3,1);

Table altered.

SQL> alter table ST_PANS_PANSINFOFRMRLOG2 modify mvaftdft_q number(3,1);

Table altered.
