spool './cleanup_script.log';
set linesize 200;
set trimspool on;
set trimout on;
set pagesize 50000;

------------------
-- Disable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' disable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/

---Truncate all tables

DECLARE
BEGIN
 FOR CUR IN (SELECT 'truncate table '||table_name as label from user_tables) 
  LOOP
     execute immediate cur.label;
  END LOOP;
END;
/
------------------
-- Enable Foreign constraints
------------------
DECLARE
BEGIN
  FOR aaaa IN 
    (SELECT 'alter table '||table_name||' enable constraint '||constraint_name as label
    FROM user_constraints
    WHERE constraint_type = 'R'
    ORDER BY table_name) 
  LOOP
   execute immediate aaaa.label;
  END LOOP;
END;

/


-- Count every table
select
   table_name,
   to_number(
   extractvalue(
      xmltype(
         dbms_xmlgen.getxml('select count(*) c from '||table_name))
    ,'/ROWSET/ROW/C')) count
from 
   user_tables
order by 
   count desc, table_name;
   
   
 spool off;
 
 exit;
