#!/bin/bash
echo "Start of Data Migration Load Masters"
sqlplus -s msw_data_migration/H-cK8T7HN<<EOF
spool DM_Masters.log;
@ Load_Masters_Apps.sql;
spool off;
EOF
echo 'End of Data Migration Load Masters'
