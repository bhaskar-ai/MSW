#!/bin/bash
 
sh Load_Masters_Apps.sh 2>&1 | tee 03_transform_new.log
