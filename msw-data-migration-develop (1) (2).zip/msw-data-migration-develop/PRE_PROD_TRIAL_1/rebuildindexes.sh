#!/bin/bash
sqlplus -s msw_data_migration/H-cK8T7HN<<EOF
@Rebuildindexes.sql
EOF
echo "End of Rebuilding Index script"
~

