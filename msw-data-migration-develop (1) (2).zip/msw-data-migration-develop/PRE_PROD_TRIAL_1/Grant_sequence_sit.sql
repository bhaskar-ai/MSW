/*
SQL> alter session set "_ORACLE_SCRIPT"=true;

Session altered.

SQL>  create user msw_data_migration identified by H-cK8T7HN;

User created.
*/

grant select on E_APPLICATION_SERVICE.ISEQ$$_ISEQ$$_117450 to MSW_DATA_MIGRATION_UAT; 
grant select on E_APPLICATION_SERVICE.APPLN_SUBMISSN to MSW_DATA_MIGRATION_UAT; 
grant select on E_APPLICATION_SERVICE.VSL_CALL to MSW_DATA_MIGRATION_UAT; 
grant select on E_APPLICATION_SERVICE.VSL_REF to MSW_DATA_MIGRATION_UAT; 
grant select on E_APPLICATION_SERVICE.ISEQ$$_ISEQ$$_117415 to MSW_DATA_MIGRATION_UAT;
grant select on E_APPLICATION_SERVICE.ISEQ$$_117445 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100815 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100818 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100824 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100827 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100827 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_121603 to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ARR_GD_APPLN to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ARR_GD_PURP_OF_CALL to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ARR_GD_PURP_OF_CALL_SYARD_LOC to MSW_DATA_MIGRATION_UAT;
grant select on CVS_INTEGRATION.ISEQ$$_100845 to MSW_DATA_MIGRATION_UAT;
grant select on DGDS_INTEGRATION.ISEQ$$_101438 to MSW_DATA_MIGRATION_UAT;
grant select on DGDS_INTEGRATION.ISEQ$$_101441 to MSW_DATA_MIGRATION_UAT;
grant select on DGDS_INTEGRATION.ISEQ$$_118558 to MSW_DATA_MIGRATION_UAT;
grant select on DGDS_INTEGRATION.ISEQ$$_118562 to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.ISEQ$$_97011 to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.ISEQ$$_97017 to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.ISEQ$$_97020 to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.VSL to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.VSL_CERT to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.VSL_CERT_ATTRB to MSW_DATA_MIGRATION_UAT;
grant select on VESSEL_SERVICE.ISEQ$$_97014 to MSW_DATA_MIGRATION_UAT;
grant select on HNS_SERVICE.ISEQ$$_101351 to MSW_DATA_MIGRATION_UAT;
grant select on HNS_SERVICE.ISEQ$$_101354 to MSW_DATA_MIGRATION_UAT;
grant select on HNS_SERVICE.HNS_APPLN_BKP to MSW_DATA_MIGRATION_UAT;
grant select on HNS_SERVICE.HNS_APPLN_SUBSTANCE to MSW_DATA_MIGRATION_UAT;
grant select on PANS_NOAS_INTEGRATION.ISEQ$$_97030 to MSW_DATA_MIGRATION_UAT;
grant select on PANS_NOAS_INTEGRATION.ISEQ$$_97033 to MSW_DATA_MIGRATION_UAT;
grant select on PANS_NOAS_INTEGRATION.ISEQ$$_97036 to MSW_DATA_MIGRATION_UAT;
grant select on PANS_NOAS_INTEGRATION.ISEQ$$_97039 to MSW_DATA_MIGRATION_UAT;

grant select ,insert, update , delete on CVS_INTEGRATION.ARR_GD_APPLN to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on CVS_INTEGRATION.ARR_GD_PURP_OF_CALLto MSW_DATA_MIGRATION_UAT; 
grant select ,insert, update , delete on CVS_INTEGRATION.ARR_GD_PURP_OF_CALL_SYARD_LOC to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on E_APPLICATION_SERVICE.APPLN_SUBMISSN to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on DGDS_INTEGRATION.DG_APPLN to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on DGDS_INTEGRATION.DG_APPLN_DOC to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on HNS_SERVICE.HNS_APPLN to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on HNS_SERVICE.HNS_APPLN_SUBSTANCE to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on E_APPLICATION_SERVICE.VSL_CALL to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on E_APPLICATION_SERVICE.VSL_REF to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on VESSEL_SERVICE.VSL to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on VESSEL_SERVICE.VSL_CERT to MSW_DATA_MIGRATION_UAT;
grant select ,insert, update , delete on VESSEL_SERVICE.VSL_CERT_ATTRB to MSW_DATA_MIGRATION_UAT;


/*
--Vessel Schema
--CRAFT_TYPE	CRAFT_TYPE_ID_N	
grant select on MSW_VSL_SVC.ISEQ$$_81829  to msw_data_migration; 

--VESSEL	MSW_VSL_ID_N	
grant select on MSW_VSL_SVC.ISEQ$$_81832  to msw_data_migration;

--VESSEL_CERTIFICATE	VSL_CERT_ID_N	
grant select on MSW_VSL_SVC.ISEQ$$_81835  to msw_data_migration; 

--VESSEL_CERTIFICATE_ATTRIBUTES	
--VSL_CERT_ATTRB_ID_N
grant select on 	MSW_VSL_SVC.ISEQ$$_81838 to msw_data_migration; 

--VESSEL_TYPE	VSL_TYPE_ID_N	
grant select on MSW_VSL_SVC.ISEQ$$_81826 to msw_data_migration;

--Master table grants;
grant select on MSW_VSL_SVC.VESSEL to msw_data_migration;

grant select on MSW_VSL_SVC.VESSEL_TYPE to msw_data_migration;

grant select on MSW_VSL_SVC.CRAFT_TYPE to msw_data_migration;

-----CVS  table grants
grant select on CVS_INTEGRATION.ISEQ$$_100815  to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_81634" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_81640" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_81643" to msw_data_migration;
grant select on "MSW_CVS_INTEGRATION"."ISEQ$$_89738" to msw_data_migration;
--DGDS tables
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_97115 to msw_data_migration;
grant select on MSW_DGDS_INTEGRATION.ISEQ$$_97118 to msw_data_migration;
-- HNS tables
grant select on MSW_HNS_SVC.ISEQ$$_89776 to msw_data_migration;
grant select on MSW_HNS_SVC.ISEQ$$_89779 to msw_data_migration;
--PAN tables
--E Application
grant select on E_APPLICATION_SERVICE.ISEQ$$_ISEQ$$_117450;

*/