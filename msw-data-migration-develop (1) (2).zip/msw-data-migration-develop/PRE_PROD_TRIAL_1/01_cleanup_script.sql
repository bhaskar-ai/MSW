sqlplus -s msw_data_migration/H-cK8T7HN @./cleanup_script.sql
