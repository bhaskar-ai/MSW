#!/bin/bash
echo "Start of Report"
sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
set lines 200 pages 200
set markup html on
spool /tmp/recon.xls
select rownum,STNAME,scount,SICOUNT,tblnm,tcount,DIFSIT,DIFSST,stime,etime,etime-stime DiffTime/*,status,tcno*/ from (select ROWNUM sno, MODULE_NAME TBLNM,substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1) SCOUNT,  substr(ERROR_DESCRIPTION,1,instr(ERROR_DESCRIPTION,'out')-1) TCOUNT,to_number(substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1))-to_number(substr(ERROR_DESCRIPTION,1,instr(ERROR_DESCRIPTION,'out')-1)) REDIFF ,(select trc_date_time from tbl_trace_migration where MODULE_NAME=t.MODULE_NAME and substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1) is null and rownum=1 )Stime,(select max (trc_date_time) from tbl_trace_migration where MODULE_NAME=t.MODULE_NAME )Etime,(select SOURCE_TBL_COUNT from tbl_migration_recon where TARGET_TBL=t.MODULE_NAME  and flag='N') SICOUNT,(select SOURCE_TABLE from tbl_migration_recon where TARGET_TBL=t.MODULE_NAME  and flag='Y') STNAME ,(select SOURCE_TBL_COUNT-TARGET_TBL_COUNT from tbl_migration_recon where TARGET_TBL=t.MODULE_NAME  and flag='Y') DIFSST,(select SOURCE_TBL_COUNT-TARGET_TBL_COUNT from tbl_migration_recon where TARGET_TBL=t.MODULE_NAME  and flag='N') DIFSIT,t.TRC_NUMBWER tcno,status from tbl_trace_migration t order by t.TRC_NUMBWER ) tb where scount is not null and tb.status<>'START' ;
spool off
EOF

sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
set lines 200 pages 200
set markup html on
spool /tmp/dm_errors.xls
select rownum sno,MODULE_NAME, status, ERROR_DESCRIPTION from TBL_TRACE_MIGRATION where MODULE_NAME not like 'SI%' and status='ERROR';
spool off
EOF

sqlplus -s msw_data_migration/H-cK8T7HN <<EOF
set lines 200 pages 200
set markup html on
spool /tmp/dm_load.xls
select    rownum,scount,tblnm,scount,tcount,rediff,stime,etime,etime-stime DiffTime/*,status,tcno*/ from (select ROWNUM sno, MODULE_NAME TBLNM,substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1) SCOUNT,  substr(ERROR_DESCRIPTION,1,instr(ERROR_DESCRIPTION,'out')-1) TCOUNT,         to_number(substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1))-to_number(substr(ERROR_DESCRIPTION,1,instr(ERROR_DESCRIPTION,'out')-1)) REDIFF ,(select trc_date_time from tbl_trace_migration where MODULE_NAME=t.MODULE_NAME and substr(ERROR_DESCRIPTION,instr(ERROR_DESCRIPTION,'out')+7,instr(ERROR_DESCRIPTION,'out')-1) is null and rownum=1 )Stime,(select max (trc_date_time) from tbl_trace_migration where MODULE_NAME=t.MODULE_NAME )Etime,t.TRC_NUMBWER tcno,status from tbl_trace_migration t order by t.TRC_NUMBWER ) tb where scount is not null and tb.status<>'START';
spool off;
EOF
echo "End of Report"

