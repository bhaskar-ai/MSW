create or replace PROCEDURE proc_2_dg_appl (
    pv_run_id IN   NUMBER
) IS

    lv_cnt_st                  NUMBER;
    lv_cnt_si                  NUMBER;
  -- lv_cnt_src              NUMBER;
    lv_cnt_PSA_JPC              NUMBER;
    lv_cnt_tar_appl            NUMBER;
    lv_cnt_tar_doc             NUMBER;
    LV_pm4supportingdocindx_n   NUMBER; 
    LV_ty_x                     VARCHAR2(100);  
    LV_pm4id_n                  NUMBER;
    v_err_code                 VARCHAR2(1000);
    v_err_msg                  VARCHAR2(1000);
    v_sqlerrm                  VARCHAR2(1000);
  -- v_m_blkexptn_count      VARCHAR2 (100);
  -- v_m_blkexptn_desc       VARCHAR2 (1000);
    v_exp_rows_si              VARCHAR2(4000);
    v_exp_rows_appl            VARCHAR2(4000);
    v_exp_rows_doc             VARCHAR2(4000);
    v_exp_rows1                VARCHAR2(1000);
    v_exp_rows2                VARCHAR2(1000);
    v_exp_rows3                VARCHAR2(1000);
    v_exp_rows4                VARCHAR2(1000);
    v_exp_rows5                VARCHAR2(1000);
    v_exp_rows6                VARCHAR2(1000);
    v_exp_rows7                VARCHAR2(1000);
    v_exp_rows8                VARCHAR2(1000);
    v_exp_rows9                VARCHAR2(1000);
    v_exp_rows10               VARCHAR2(1000);
    v_exp_rows11               VARCHAR2(1000);
    v_exp_rows12               VARCHAR2(1000);
    v_exp_rows13               VARCHAR2(1000);
    v_exp_rows14               VARCHAR2(1000);
    v_exp_rows15               VARCHAR2(1000);
    v_exp_rows16               VARCHAR2(1000);
    v_exp_rows17               VARCHAR2(1000);
    v_exp_rows18               VARCHAR2(1000);
    v_exp_rows19               VARCHAR2(1000);
    v_exp_rows20               VARCHAR2(1000);
    v_exp_rows21               VARCHAR2(1000);
    v_exp_rows22               VARCHAR2(1000);
    v_exp_rows23               VARCHAR2(1000);
    v_exp_rows24               VARCHAR2(1000);
    v_exp_rows25               VARCHAR2(1000);
    v_exp_rows26               VARCHAR2(1000);
    v_exp_rows27               VARCHAR2(1000);
    v_exp_rows28               VARCHAR2(1000);
    v_exp_rows29               VARCHAR2(1000);
    v_exp_rows30               VARCHAR2(1000);
    v_exp_rows31               VARCHAR2(1000);
    v_exp_rows32               VARCHAR2(1000);
    v_exp_rows33               VARCHAR2(1000);
    v_exp_rows34               VARCHAR2(1000);
    v_exp_rows35               VARCHAR2(1000);
    v_exp_rows36               VARCHAR2(1000);
    v_exp_rows37               VARCHAR2(1000);
    v_exp_rows38               VARCHAR2(1000);
    v_exp_rows39               VARCHAR2(1000);
    v_exp_rows40               VARCHAR2(1000);
    v_exp_rows41               VARCHAR2(1000);
    v_exp_rows42               VARCHAR2(1000);
    v_exp_rows43               VARCHAR2(1000);
    v_exp_rows44               VARCHAR2(1000);
    v_exp_rows45               VARCHAR2(1000);
    v_exp_rows46               VARCHAR2(1000);
    v_exp_rows47               VARCHAR2(1000);
    v_exp_rows48               VARCHAR2(1000);
    v_exp_rows49               VARCHAR2(1000);
    v_exp_rows50               VARCHAR2(1000);
    LV_waste_i                 NUMBER(1) ;
    LV_residue_i               NUMBER(1) ;
    LV_tankcntr_i              NUMBER(1) ;
    lv_subr_email_i             NUMBER(1);
    lv_subr_sms_i           NUMBER(1);
    lv_errcnt                  number(20) default 0;

   /***********************************************************************************************************
   procedure name : proc_2_dg_appl
   Created By     : Sourangshu Dhar
   Date           : 15-Apr-2019
   Purpose        : To insert data from Source Staging Table to Intermidiate Table
   Modified by    :
   Modified date  :

   *************************************************************************************************************/
    CURSOR cr_si_dg_application IS
   ------*************** Cursor for fetching data from the Source Staging Table *****----

    SELECT
                a.pm4id_n,
                a.loclcontact_m,
                a.notifnmtd_c,
                a.mobile_n,
                a.opern_c,
                a.locn_c,
                a.cntr_n,
                a.bl_n,
                a.imocl_c,
                a.un_n,
                a.psn_m,
                a.tn_m,
                a.pkgty_c,
                a.flashpt_n,
                a.compbgrp_c,
                a.wt_n,
                a.waste_i,
                a.residue_i,
                a.tankcntr_i,
                a.st_c,
                a.mparem_x,
                a.vettedon_dt,
                a.vettedby_m,
                a.crton_dt,
                a.crtby_m,
                a.updon_dt,
                a.updby_m,
                a.emailaddr_x,
                a.usrinputvsl_m,
                a.craftlic_n,
                b.eta_dt,
                b.rta_dt,
                b.rtd_dt,
                b.invoy_n,
                b.outvoy_n,
                b.vslid_n,
                vl.msw_vsl_id_n, a.NOOFPKG_N, a.SENDERORG_C,
				a.org_c,a.uen_n,a.org_m,a.usrid_c,a.usr_m,
				a.wc_c,a.autogenty_c,a.submissn_dt
            FROM
                st_dg_pm4 a,
                st_dg_vslcall b,
                vessel vl
            WHERE
                a.vslcallindx_n = b.vslcallindx_n
                AND b.vslid_n = vl.vsl_rec_id_n ;

    TYPE rec_si_dg_application IS RECORD (
        pm4id_n_r                  st_dg_pm4.pm4id_n%TYPE,
        loclcontact_m_r            st_dg_pm4.loclcontact_m%TYPE,
        notifnmtd_c_r              st_dg_pm4.notifnmtd_c%TYPE,
        mobile_n_r                 st_dg_pm4.mobile_n%TYPE,
        opern_c_r                  st_dg_pm4.opern_c%TYPE,
        locn_c_r                   st_dg_pm4.locn_c%TYPE,
        cntr_n_r                   st_dg_pm4.cntr_n%TYPE,
        bl_n_r                     st_dg_pm4.bl_n%TYPE,
        imocl_c_r                  st_dg_pm4.imocl_c%TYPE,
        un_n_r                     st_dg_pm4.un_n%TYPE,
        psn_m_r                    st_dg_pm4.psn_m%TYPE,
        tn_m_r                     st_dg_pm4.tn_m%TYPE,
        pkgty_c_r                  st_dg_pm4.pkgty_c%TYPE,
        flashpt_n_r                st_dg_pm4.flashpt_n%TYPE,
        compbgrp_c_r               st_dg_pm4.compbgrp_c%TYPE,
        wt_n_r                     st_dg_pm4.wt_n%TYPE,
        waste_i_r                  st_dg_pm4.waste_i%TYPE,
        residue_i_r                st_dg_pm4.residue_i%TYPE,
        tankcntr_i_r               st_dg_pm4.tankcntr_i%TYPE,
        st_c_r                     st_dg_pm4.st_c%TYPE,
        mparem_x_r                 st_dg_pm4.mparem_x%TYPE,
        vettedon_dt_r              st_dg_pm4.vettedon_dt%TYPE,
        vettedby_m_r               st_dg_pm4.vettedby_m%TYPE,
        crton_dt_r                 st_dg_pm4.crton_dt%TYPE,
        crtby_m_r                  st_dg_pm4.crtby_m%TYPE,
        updon_dt_r                 st_dg_pm4.updon_dt%TYPE,
        updby_m_r                  st_dg_pm4.updby_m%TYPE,
        emailaddr_x_r              st_dg_pm4.emailaddr_x%TYPE,
        usrinputvsl_m_r            st_dg_pm4.usrinputvsl_m%TYPE,
        craftlic_n_r               st_dg_pm4.craftlic_n%TYPE,
        eta_dt_r                   st_dg_vslcall.eta_dt%TYPE,
        rta_dt_r                   st_dg_vslcall.rta_dt%TYPE,
        rtd_dt_r                   st_dg_vslcall.rtd_dt%TYPE,
        invoy_n_r                  st_dg_vslcall.invoy_n%TYPE,
        outvoy_n_r                 st_dg_vslcall.outvoy_n%TYPE,
        vslid_n_r                  st_dg_vslcall.vslid_n%TYPE,
       -- subrisk_c_r                st_dg_subrisk.subrisk_c%TYPE,
      --  pm4supportingdocindx_n_r   st_dg_pm4supportingdoc.pm4supportingdocindx_n%TYPE,
      --  ty_x_r                     st_pm4supportingdoc_mapping.ty_x%TYPE,
        msw_vsl_id_n_r             NUMBER,
        NOOFPKG_N_r                 st_dg_pm4.NOOFPKG_N%TYPE,
        SENDERORG_C_r               st_dg_pm4.SENDERORG_C%TYPE,
		org_c_r						st_dg_pm4.ORG_C%TYPE,
		uen_n_r						st_dg_pm4.UEN_N%TYPE,
		org_m_r						st_dg_pm4.ORG_M%TYPE,
		usrid_c_r					st_dg_pm4.USRID_C%TYPE,
		usr_m_r						st_dg_pm4.USR_M%TYPE,
		wc_c_r						st_dg_pm4.WC_C%TYPE,
		autogenty_c_r				st_dg_pm4.autogenty_c%TYPE,
		submissn_dt_r				st_dg_pm4.submissn_dt%TYPE

    );

    TYPE typ_si_dg_application IS
        TABLE OF rec_si_dg_application INDEX BY PLS_INTEGER;
    lv_si_dg_application       typ_si_dg_application;

   CURSOR cr_dg_appl IS
      --*************** Cursor for fetching data from the Intermidiate Table *****----
    SELECT
        pm4id_n,
        loclcontact_m,
        notifnmtd_c,
        mobile_n,
        DECODE(opern_c, 'D', 'DISCHARGE', 'L', 'LOADING', 'T', 'TRANSIT') opern_c,
        locn_c,
        cntr_n,
        bl_n,
        imocl_c,
        un_n,
        psn_m,
        tn_m,
        pkgty_c,
        flashpt_n,
        compbgrp_c,
        wt_n,
        waste_i,
        residue_i,
        tankcntr_i,
        DECODE(st_c, 'W', 'Withdrawn', 'A', 'Approved', 'P', 'Pending', 'N', 'Not Approved') st_c,
        crton_dt,
        crtby_m,
        updon_dt,
        updby_m,
        DECODE(nvl(emailaddr_x, '0'), '0', 0, 1) subr_email_i,
        emailaddr_x,
        DECODE(nvl(mobile_n, '0'), '0', 0, 1) subr_sms_i,
        usrinputvsl_m,
        craftlic_n,
        eta_dt,
        rta_dt,
        rtd_dt,
        invoy_n,
        outvoy_n,
      --  subrisk_c,
        mparem_x,
        vettedby_m,
        vettedon_dt,
        vslid_n,
        pm4supportingdocindx_n,
        ty_x,
        msw_vsl_id_n,NOOFPKG_N,SENDERORG_C,
		org_c,uen_n,org_m,usrid_c,usr_m,
		wc_c,autogenty_c,submissn_dt
    FROM
        si_dg_application
    ORDER BY
        crton_dt;

   --***************** Declaring Types ****************------




    TYPE rec_dg_application IS RECORD (
        pm4id_n_r				si_dg_application.pm4id_n%TYPE,
        loclcontact_m_r			si_dg_application.loclcontact_m%TYPE,
        notifnmtd_c_r			si_dg_application.notifnmtd_c%TYPE,
        mobile_n_r				si_dg_application.mobile_n%TYPE,
        opern_c_r				varchar2(20),
        locn_c_r				si_dg_application.locn_c%TYPE,
        cntr_n_r				si_dg_application.cntr_n%TYPE,
        bl_n_r					si_dg_application.bl_n%TYPE,
        imocl_c_r				si_dg_application.imocl_c%TYPE,
        un_n_r					si_dg_application.un_n%TYPE,
        psn_m_r					si_dg_application.psn_m%TYPE,
        tn_m_r					si_dg_application.tn_m%TYPE,
        pkgty_c_r				si_dg_application.pkgty_c%TYPE,
        flashpt_n_r				si_dg_application.flashpt_n%TYPE,
        compbgrp_c_r			si_dg_application.compbgrp_c%TYPE,
        wt_n_r					si_dg_application.wt_n%TYPE,
        waste_i_r				si_dg_application.waste_i%TYPE,
        residue_i_r				si_dg_application.residue_i%TYPE,
        tankcntr_i_r			si_dg_application.tankcntr_i%TYPE,
        st_c_r					varchar2(20),
        crton_dt_r				si_dg_application.crton_dt%TYPE,
        crtby_m_r				si_dg_application.crtby_m%TYPE,
        updon_dt_r				si_dg_application.updon_dt%TYPE,
        updby_m_r               si_dg_application.updby_m%TYPE,
        subr_email_i_r            number,
        emailaddr_x_r			si_dg_application.emailaddr_x%TYPE,
        subr_sms_i_r              number,
        usrinputvsl_m_r			si_dg_application.usrinputvsl_m%TYPE,
        craftlic_n_r			si_dg_application.craftlic_n%TYPE,
        eta_dt_r				si_dg_application.eta_dt%TYPE,
        rta_dt_r				si_dg_application.rta_dt%TYPE,
        rtd_dt_r				si_dg_application.rtd_dt%TYPE,
        invoy_n_r				si_dg_application.invoy_n%TYPE,
        outvoy_n_r				si_dg_application.outvoy_n%TYPE,
        mparem_x_r				si_dg_application.mparem_x%TYPE,
        vettedby_m_r			si_dg_application.vettedby_m%TYPE,
        vettedon_dt_r			si_dg_application.vettedon_dt%TYPE,
        vslid_n_r				si_dg_application.vslid_n%TYPE,
        pm4supportingdocindx_n_r	si_dg_application.pm4supportingdocindx_n%TYPE,
        ty_x_r					si_dg_application.ty_x%TYPE,
        msw_vsl_id_n_r			si_dg_application.msw_vsl_id_n%TYPE,
        NOOFPKG_N_r				si_dg_application.NOOFPKG_N%TYPE,
        SENDERORG_C_r			si_dg_application.SENDERORG_C%TYPE,
        org_c_r					si_dg_application.org_c%TYPE,
        uen_n_r					si_dg_application.uen_n%TYPE,
        org_m_r					si_dg_application.org_m%TYPE,
        usrid_c_r				si_dg_application.usrid_c%TYPE,
        usr_m_r					si_dg_application.usr_m%TYPE,
        wc_c_r					si_dg_application.wc_c%TYPE,
        autogenty_c_r			si_dg_application.autogenty_c%TYPE,
        submissn_dt_r			si_dg_application.submissn_dt%TYPE
    );
    TYPE typ_dg_application IS
        TABLE OF rec_dg_application INDEX BY PLS_INTEGER;
    lv_dg_application       typ_dg_application;

    v_sq_appln_ref_n           NUMBER;
    v_msw_appln_ref_id_x       VARCHAR2(20);
    v_msw_vsl_call_id          NUMBER;
    v_flag                     VARCHAR2(1);
    pv_dg_application          dangerous_goods_application%rowtype;
    pv_dg_application_doc      dangerous_goods_application_document%rowtype;
    lval                       CLOB;
    lv_data_dump               CLOB;
    pv_data_dump               CLOB;
    l_val                      NUMBER(6);
    v_year_month               NUMBER(4);
    v_yr_mnth                  NUMBER(4);
    p_yymm                     VARCHAR2(5);
    v_blkexptn_count           NUMBER(20, 0);
    lv_max                     VARCHAR2(20);
    lv_yrmnth                  NUMBER(4);
    V_VSL_REF_ID_OUT       NUMBER;
    V_FLAG_VSL_REF         VARCHAR2(1);
    V_CNT                   NUMBER := 0 ;
BEGIN  -- OUTER BEGIN  


    SELECT
        COUNT(*)
    INTO lv_cnt_st
    FROM
        st_dg_pm4;    --driving table count 

    OPEN cr_si_dg_application;
    pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', 'Insertion into Table SI_DG_APPLICATION', 'START'
    , pv_run_id, NULL, NULL, 'T');

    LOOP   -- CURSOR LOOP STARTS 
         -------************ Bulk collect for inserting data into Intermidiate  Table ***********************---------------
            FETCH cr_si_dg_application BULK COLLECT INTO lv_si_dg_application LIMIT 10000;
            EXIT WHEN lv_si_dg_application.count = 0;
          --  FORALL i IN lv_si_dg_application.first..lv_si_dg_application.last SAVE EXCEPTIONS
            FOR i IN lv_si_dg_application.first..lv_si_dg_application.last

            LOOP  -- FOR LOOP   I 

            BEGIN   -- sI TALE BEGIN 
                INSERT INTO si_dg_application (
                    pm4id_n,
                    loclcontact_m,
                    notifnmtd_c,
                    mobile_n,
                    opern_c,
                    locn_c,
                    cntr_n,
                    bl_n,
                    imocl_c,
                    un_n,
                    psn_m,
                    tn_m,
                    pkgty_c,
                    flashpt_n,
                    compbgrp_c,
                    wt_n,
                    waste_i,
                    residue_i,
                    tankcntr_i,
                    st_c,
                    mparem_x,
                    vettedby_m,
                    vettedon_dt,
                    crton_dt,
                    crtby_m,
                    updon_dt,
                    updby_m,
                    emailaddr_x,
                    usrinputvsl_m,
                    craftlic_n,
                    eta_dt,
                    rta_dt,
                    rtd_dt,
                    invoy_n,
                    outvoy_n,
                    subrisk_c,
                  --  pm4supportingdocindx_n,
                 --   ty_x,
                    vslid_n,
                    msw_vsl_id_n,NOOFPKG_N,SENDERORG_C,
					org_c,uen_n,org_m,usrid_c,usr_m,
		wc_c,autogenty_c,submissn_dt
                ) VALUES (
                    lv_si_dg_application(i).pm4id_n_r,
                    lv_si_dg_application(i).loclcontact_m_r,
                    lv_si_dg_application(i).notifnmtd_c_r,
                    lv_si_dg_application(i).mobile_n_r,
                    lv_si_dg_application(i).opern_c_r,
                    lv_si_dg_application(i).locn_c_r,
                    lv_si_dg_application(i).cntr_n_r,
                    lv_si_dg_application(i).bl_n_r,
                    lv_si_dg_application(i).imocl_c_r,
                    lv_si_dg_application(i).un_n_r,
                    lv_si_dg_application(i).psn_m_r,
                    lv_si_dg_application(i).tn_m_r,
                    lv_si_dg_application(i).pkgty_c_r,
                    lv_si_dg_application(i).flashpt_n_r,
                    lv_si_dg_application(i).compbgrp_c_r,
                    lv_si_dg_application(i).wt_n_r,
                    lv_si_dg_application(i).waste_i_r,
                    lv_si_dg_application(i).residue_i_r,
                    lv_si_dg_application(i).tankcntr_i_r,
                    lv_si_dg_application(i).st_c_r,
                    lv_si_dg_application(i).mparem_x_r,
                    lv_si_dg_application(i).vettedby_m_r,
                    lv_si_dg_application(i).vettedon_dt_r,
                    lv_si_dg_application(i).crton_dt_r,
                    lv_si_dg_application(i).crtby_m_r,
                    lv_si_dg_application(i).updon_dt_r,
                    lv_si_dg_application(i).updby_m_r,
                    lv_si_dg_application(i).emailaddr_x_r,
                    lv_si_dg_application(i).usrinputvsl_m_r,
                    lv_si_dg_application(i).craftlic_n_r,
                    lv_si_dg_application(i).eta_dt_r,
                    lv_si_dg_application(i).rta_dt_r,
                    lv_si_dg_application(i).rtd_dt_r,
                    lv_si_dg_application(i).invoy_n_r,
                    lv_si_dg_application(i).outvoy_n_r,
                    null,                           --lv_si_dg_application(i).subrisk_c_r,
                 --   lv_si_dg_application(i).pm4supportingdocindx_n_r,
                 --   lv_si_dg_application(i).ty_x_r,
                    lv_si_dg_application(i).vslid_n_r,
                    lv_si_dg_application(i).msw_vsl_id_n_r, 
                    lv_si_dg_application(i).NOOFPKG_N_r,
                    lv_si_dg_application(i).SENDERORG_C_r,
					lv_si_dg_application(i).org_c_r,		
					lv_si_dg_application(i).uen_n_r	,	
					lv_si_dg_application(i).org_m_r	,	
					lv_si_dg_application(i).usrid_c_r,	
					lv_si_dg_application(i).usr_m_r		,
					lv_si_dg_application(i).wc_c_r		,
					lv_si_dg_application(i).autogenty_c_r,
					lv_si_dg_application(i).submissn_dt_r
                );

        EXCEPTION  -- SI EXCEPTION
            WHEN OTHERS THEN
                        v_err_code := sqlcode;
                        v_err_msg := substr(sqlerrm, 1, 200);
                        v_sqlerrm := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| v_err_code || v_err_msg;

        V_EXP_ROWS_SI:=            lv_si_dg_application(i).pm4id_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).loclcontact_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).notifnmtd_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).mobile_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).opern_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).locn_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).cntr_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).bl_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).imocl_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).un_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).psn_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).tn_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).pkgty_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).flashpt_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).compbgrp_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).wt_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).waste_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).residue_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).tankcntr_i_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).st_c_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).mparem_x_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vettedby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vettedon_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).crton_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).crtby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).updon_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).updby_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).emailaddr_x_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).usrinputvsl_m_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).craftlic_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).eta_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).rta_dt_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).invoy_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).outvoy_n_r
                                /*     || '<{||}>'
                                     || lv_si_dg_application(i).pm4supportingdocindx_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).ty_x_r  */
                                     || '<{||}>'
                                     || lv_si_dg_application(i).vslid_n_r
                                     || '<{||}>'
                                     || lv_si_dg_application(i).msw_vsl_id_n_r;


    if lv_errcnt < 50000 then 

        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', v_sqlerrm, 'ERROR', pv_run_id,
                                                        sqlerrm, v_exp_rows_si, 'T');
        lv_errcnt:=lv_errcnt+1;
    end if;

            END ;  -- SI END 
        END LOOP;   -- FOR LOOP I   ENDS
       COMMIT;
    END LOOP;   -- CURSOR LOOP  ENDS

    close cr_si_dg_application;



    SELECT
        COUNT(*)
    INTO lv_cnt_si
    FROM
        si_dg_application;

    IF ( lv_cnt_si = lv_cnt_st ) AND lv_cnt_st <> 0 AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'SUCCESS'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    ELSIF lv_cnt_si <> lv_cnt_st AND lv_cnt_si <> 0 THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'PARTIALLY SUCCESSFULL'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    ELSIF ( lv_cnt_si <> lv_cnt_st OR lv_cnt_si = lv_cnt_st ) AND ( lv_cnt_si = 0 ) THEN
        pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', lv_cnt_si
                                                                                           || ' out of '
                                                                                           || lv_cnt_st
                                                                                           || ' records loaded successfully', 'FAIL'
                                                                                           , pv_run_id, NULL, NULL, 'T');
    END IF;

    pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'SI_DG_APPLICATION', lv_cnt_si, 'N');

      ------------------------------------ Inserting data into DG_Appl. Staging Table ---------------------------------------

OPEN cr_dg_appl;

pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', 'Insertion into Table DG_Appl.and DG_Appl_Doc'

, 'START', pv_run_id, NULL, NULL, 'T');

LOOP
    FETCH cr_dg_appl BULK COLLECT INTO lv_dg_application LIMIT 10000;
    EXIT WHEN lv_dg_application.count = 0;
    FOR j IN lv_dg_application.first..lv_dg_application.last

      --  FOR j IN cr_dg_appl 
     LOOP    -- FOR LOOP J  
        BEGIN   -- INNER BEGIN J 
            v_sq_appln_ref_n := seq_dg_appl.nextval;
            SELECT
                TO_CHAR(lv_dg_application(j).crton_dt_r, 'YY')
                || TO_CHAR(lv_dg_application(j).crton_dt_r, 'MM')
            INTO v_year_month
            FROM
                dual;

            IF v_year_month != p_yymm AND p_yymm IS NOT NULL THEN
                EXECUTE IMMEDIATE 'select APP_SUB_SEQ_DG.NEXTVAL from dual'
                INTO l_val;
                EXECUTE IMMEDIATE 'alter sequence APP_SUB_SEQ_DG increment by -'
                                  || l_val
                                  || ' minvalue 0';
                EXECUTE IMMEDIATE 'select APP_SUB_SEQ_DG.NEXTVAL from dual'
                INTO l_val;
                EXECUTE IMMEDIATE 'alter sequence APP_SUB_SEQ_DG increment by 1 minvalue 0';
            END IF;

            p_yymm := v_year_month;
            v_msw_appln_ref_id_x := 'MSW'
                                    || 'DGD'
                                    || TO_CHAR(lv_dg_application(j).crton_dt_r, 'YY')
                                    || TO_CHAR(lv_dg_application(j).crton_dt_r, 'MM')
                                    || TO_CHAR(app_sub_seq_dg.nextval, 'FM00000');

----------**** Vessel Call and Appl.Submission Insertion *****----------------------

            SELECT
                DECODE(lv_dg_application(j).waste_i_r, 'Y', 1, 'N', 0),
                DECODE(lv_dg_application(j).residue_i_r, 'Y', 1, 'N', 0),
                DECODE(lv_dg_application(j).tankcntr_i_r, 'Y', 1, 'N', 0),
                DECODE(nvl(lv_dg_application(j).emailaddr_x_r, '0'), '0', 0, 1) subr_email_i,
                DECODE(nvl(lv_dg_application(j).mobile_n_r, '0'), '0', 0, 1) subr_sms_i
            INTO
                lv_waste_i,
                lv_residue_i,
                lv_tankcntr_i,
                lv_subr_email_i,
                lv_subr_sms_i
            FROM
                dual;

            pv_dg_application.appln_ref_n := v_sq_appln_ref_n;
            pv_dg_application.vsl_call_id_n := v_msw_vsl_call_id;
            pv_dg_application.extl_appln_ref_x := lv_dg_application(j).pm4id_n_r;
            pv_dg_application.applcnt_id_x := '1';
            pv_dg_application.msw_appln_ref_id_x := v_msw_appln_ref_id_x;
            pv_dg_application.cont_pers_m := lv_dg_application(j).loclcontact_m_r;
            pv_dg_application.mobile_n := lv_dg_application(j).mobile_n_r;
            pv_dg_application.eta_dt := lv_dg_application(j).eta_dt_r;
            pv_dg_application.rta_dt := lv_dg_application(j).rta_dt_r;
            pv_dg_application.in_voy_x := lv_dg_application(j).invoy_n_r;
            pv_dg_application.out_voy_x := lv_dg_application(j).outvoy_n_r;
            pv_dg_application.opern_c := lv_dg_application(j).opern_c_r;
            pv_dg_application.locn_c := lv_dg_application(j).locn_c_r;
            pv_dg_application.cntr_x := lv_dg_application(j).cntr_n_r;
            pv_dg_application.ucr_x := lv_dg_application(j).bl_n_r;
            pv_dg_application.imo_cl_c := lv_dg_application(j).imocl_c_r;
            pv_dg_application.un_x := lv_dg_application(j).un_n_r;
            pv_dg_application.psn_n := lv_dg_application(j).psn_m_r;
            pv_dg_application.tn_n := lv_dg_application(j).tn_m_r;
            pv_dg_application.pkg_ty_c := lv_dg_application(j).pkgty_c_r;
            pv_dg_application.pkg_ty_others_x := NULL;
            pv_dg_application.flash_pt_n := lv_dg_application(j).flashpt_n_r;
            pv_dg_application.wt_n := lv_dg_application(j).wt_n_r;
            pv_dg_application.waste_i := lv_waste_i;
            pv_dg_application.residue_i := lv_residue_i;
              --  pv_dg_application.sub_risk_c := lv_dg_application(j).subrisk_c;
            pv_dg_application.tank_cntr_i := lv_tankcntr_i;
            pv_dg_application.st_c := lv_dg_application(j).st_c_r;
            pv_dg_application.processing_rem_x := lv_dg_application(j).mparem_x_r;
            pv_dg_application.processed_by_x := lv_dg_application(j).vettedby_m_r;
            pv_dg_application.processed_on_dt := lv_dg_application(j).vettedon_dt_r;
            pv_dg_application.crt_by_x := lv_dg_application(j).crtby_m_r;
            pv_dg_application.crt_on_dt := lv_dg_application(j).crton_dt_r;
            pv_dg_application.upt_by_x := lv_dg_application(j).updby_m_r;
            pv_dg_application.upt_on_dt := lv_dg_application(j).updon_dt_r;
            pv_dg_application.subr_email_i := lv_subr_email_i;   --lv_dg_application(j).subr_email_i_r;
            pv_dg_application.email_x := lv_dg_application(j).emailaddr_x_r;
            pv_dg_application.subr_sms_i := lv_subr_sms_i;  --lv_dg_application(j).subr_sms_i_r;
            pv_dg_application.usr_input_vsl_m := lv_dg_application(j).usrinputvsl_m_r;
            pv_dg_application.dgs_declrd_i := NULL;
            pv_dg_application.cft_lic_x := lv_dg_application(j).craftlic_n_r;
				/* Commented by Maria 
                pv_dg_application.org_c	 := lv_dg_application(j).org_c;
				pv_dg_application.uen_n	:= lv_dg_application(j).uen_n;	
				pv_dg_application.org_m	:= lv_dg_application(j).org_m;	
				pv_dg_application.usrid_c := lv_dg_application(j).usrid_c;
				pv_dg_application.usr_m	:= lv_dg_application(j).usr_m;
				pv_dg_application.wc_c	:= lv_dg_application(j).wc_c;
				pv_dg_application.submissn_dt := lv_dg_application(j).submissn_dt;*/
            pv_dg_application_doc.dg_appln_doc_id_n := seq_dg_appl_doc.nextval;
            pv_dg_application_doc.appln_ref_n := v_sq_appln_ref_n;
        --   pv_dg_application_doc.doc_id_n := s.pm4supportingdocindx_n;
        --   pv_dg_application_doc.ty_c :=   s.ty_x;
            pv_dg_application_doc.crt_by_x := lv_dg_application(j).crtby_m_r;
            pv_dg_application_doc.crt_on_dt := lv_dg_application(j).crton_dt_r;
            pv_dg_application_doc.lock_ver_n := 0;
            lv_data_dump := fnc_json_val_dgd(pv_dg_application, pv_dg_application_doc);  
            
      
/*
----VESSEL_REFERENCE Insertion---
            proc_1_vsl_ref(lv_dg_application(j).msw_vsl_id_n_r, lv_dg_application(j).vslid_n_r, NULL, NULL, NULL, NULL, NULL, NULL, 
                            v_vsl_ref_id_out, v_flag_vsl_ref);
---------- Vessel Call and Appl.Submission Insertion *****----------------------

            IF v_flag_vsl_ref IS NULL THEN
                proc_2_vc_as(lv_dg_application(j).msw_vsl_id_n_r, lv_dg_application(j).eta_dt_r, NULL, lv_dg_application(j).rta_dt_r, 
                lv_dg_application(j).rtd_dt_r, NULL, v_msw_appln_ref_id_x, lv_dg_application(j).pm4id_n_r, 'DGD', NULL, pv_run_id, 'DANGEROUS_GOODS_APPLICATION'
                , v_msw_vsl_call_id, v_flag, 'MSW', v_vsl_ref_id_out);
                
    */         

-------************ Inserting data into DG_Appl. Staging Table ***********************---------------

           --     IF v_flag IS NULL THEN
            IF lv_dg_application(j).senderorg_c_r IN (
                'JPC',
                'PSA'
            ) THEN
                BEGIN
                    INSERT INTO dg_psa_jpc (
                        psa_jpc_ref_n,
                        pm4id_x,
                        co_org_c,
                        co_uen_x,
                        co_m,
                        usr_id_n,
                        applcnt_m,
                        cont_pers_m,
                        email_addr_x,
                        mobile_x,
                        notifn_mtd_c,
                        vsl_id_n,
                        vsl_m,
                        in_voy_n,
                        out_voy_n,
                        eta_dt,
                        rta_dt,
                        mvmt_id_n,
                        locn_c,
                        opern_ty_c,
                        cft_lic_x,
                        cntr_n,
                        bl_n,
                        imo_cl_c,
                        un_n,
                        shpg_m,
                        tn_m,
                        pkg_ty,
                        no_of_pkg_n,
                        residue_i,
                        tank_cntr_i,
                        wt_n,
                        waste_i,
                        flash_pt_n,
                        st_c,
                        wt_c,
                        mpa_rem_x,
                        dg_vetted_by,
                        dg_vetted_dt,
                        auto_gen_ty_c,
                        dg_submissn_dt,
                        crt_by_n,
                        crt_on_dt,
                        lst_upd_by_n,
                        lst_upd_on_dt,
                        lock_ver_n,
                        deleted_i
                    ) VALUES (
                        seq_dg_psa_jpc.NEXTVAL,
                        lv_dg_application(j).pm4id_n_r,
                        lv_dg_application(j).org_c_r,
                        lv_dg_application(j).uen_n_r,
                        lv_dg_application(j).org_m_r,
                        lv_dg_application(j).usrid_c_r,
                        lv_dg_application(j).usr_m_r,
                        lv_dg_application(j).loclcontact_m_r,
                        lv_dg_application(j).emailaddr_x_r,
                        lv_dg_application(j).mobile_n_r,
                        NVL(lv_dg_application(j).notifnmtd_c_r,DECODE(nvl(lv_dg_application(j).emailaddr_x_r, '0'),'0',
                            DECODE(nvl(lv_dg_application(j).mobile_n_r, '0'),'0','0','2'),'1'))  ,
                        lv_dg_application(j).msw_vsl_id_n_r,
                        lv_dg_application(j).usrinputvsl_m_r,
                        lv_dg_application(j).invoy_n_r,
                        lv_dg_application(j).outvoy_n_r,
                        lv_dg_application(j).eta_dt_r,
                        lv_dg_application(j).rta_dt_r,
                        11,
                        lv_dg_application(j).locn_c_r,
                        lv_dg_application(j).opern_c_r,
                        lv_dg_application(j).craftlic_n_r,
                        lv_dg_application(j).cntr_n_r,
                        lv_dg_application(j).bl_n_r,
                        lv_dg_application(j).imocl_c_r,
                        lv_dg_application(j).un_n_r,
                        'DM',
                        lv_dg_application(j).tn_m_r,
                        lv_dg_application(j).pkgty_c_r,
                        lv_dg_application(j).noofpkg_n_r,
                        DECODE(lv_dg_application(j).residue_i_r, 'Y', 1, 'N', 0),
                        DECODE(lv_dg_application(j).tankcntr_i_r, 'Y', 1, 'N', 0),
                        lv_dg_application(j).wt_n_r,
                        DECODE(lv_dg_application(j).waste_i_r, 'Y', 1, 'N', 0),
                        lv_dg_application(j).flashpt_n_r,
                        lv_dg_application(j).st_c_r,
                        lv_dg_application(j).wc_c_r,
                        lv_dg_application(j).mparem_x_r,
                        lv_dg_application(j).vettedby_m_r,
                        lv_dg_application(j).vettedon_dt_r,
                        'DM',
                        lv_dg_application(j).submissn_dt_r,
                        lv_dg_application(j).crtby_m_r,
                        lv_dg_application(j).crton_dt_r,
                        lv_dg_application(j).updby_m_r,
                        lv_dg_application(j).updon_dt_r,
                        0,
                        0
                    );

                EXCEPTION
                    WHEN OTHERS THEN
                        IF lv_errcnt < 50000 THEN
                            pkg_datamigration_generic.proc_trace_exception('DG_PSA_JPC', 'PROC_2_DG_APPL', dbms_utility.format_error_backtrace
                            || dbms_utility.format_error_stack, 'ERROR', pv_run_id, sqlerrm, NULL, 'T');

                            lv_errcnt := lv_errcnt + 1;
                        END IF;

                        CONTINUE;
                END;
            ELSE
----VESSEL_REFERENCE Insertion---
                proc_1_vsl_ref(lv_dg_application(j).msw_vsl_id_n_r, lv_dg_application(j).vslid_n_r, NULL, NULL, NULL, NULL, NULL,
                NULL, v_vsl_ref_id_out, v_flag_vsl_ref);
---------- Vessel Call and Appl.Submission Insertion *****----------------------

                IF v_flag_vsl_ref IS NULL THEN
                    proc_2_vc_as(lv_dg_application(j).msw_vsl_id_n_r, lv_dg_application(j).eta_dt_r, NULL, lv_dg_application(j).rta_dt_r
                    , lv_dg_application(j).rtd_dt_r, NULL, v_msw_appln_ref_id_x, lv_dg_application(j).pm4id_n_r, 'DGD', NULL, pv_run_id
                    , 'DANGEROUS_GOODS_APPLICATION', v_msw_vsl_call_id, v_flag, 'MSW', v_vsl_ref_id_out);

                    IF v_flag IS NULL THEN
                        BEGIN
                            INSERT INTO dangerous_goods_application (
                                appln_ref_n,
                                vsl_call_id_n,
                                extl_appln_ref_x,
                                applcnt_id_x,
                                msw_appln_ref_id_x,
                                cont_pers_m,
                                mobile_n,
                                eta_dt,
                                rta_dt,
                                in_voy_x,
                                out_voy_x,
                                                     --etd_dt,
                                opern_c,
                                locn_c,
                                cntr_x,
                                ucr_x,
                                imo_cl_c,
                                un_x,
                                psn_n,
                                tn_n,
                                pkg_ty_c,
                                pkg_ty_others_x,
                                flash_pt_n,
                                wt_n,
                                waste_i,
                                residue_i,
                                                     --  bl_x,
                                sub_risk_c,
                                tank_cntr_i,
                                st_c,
                                processing_rem_x,
                                processed_by_x,
                                processed_on_dt,
                                crt_by_x,
                                crt_on_dt,
                                upt_by_x,
                                upt_on_dt,
                                subr_email_i,
                                email_x,
                                subr_sms_i,
                                usr_input_vsl_m,
                                dgs_declrd_i,
                                cft_lic_x,
                                deleted_i,
                                lock_ver_n,
                                msw_vsl_id_n,
                                noofpkg_n
                              --  ,vsl_m
                            ) VALUES (
                                v_sq_appln_ref_n,
                                v_msw_vsl_call_id,                    --VSL_CALL_ID_N
                                lv_dg_application(j).pm4id_n_r,
                                '1',                                   --APPLCNT_ID_X
                                v_msw_appln_ref_id_x,            --MSW_APPLN_REF_ID_X
                                lv_dg_application(j).loclcontact_m_r,
                                lv_dg_application(j).mobile_n_r,
                                lv_dg_application(j).eta_dt_r,
                                lv_dg_application(j).rta_dt_r,
                                lv_dg_application(j).invoy_n_r,
                                lv_dg_application(j).outvoy_n_r,
                                lv_dg_application(j).opern_c_r,
                                lv_dg_application(j).locn_c_r,
                                lv_dg_application(j).cntr_n_r,
                                lv_dg_application(j).bl_n_r,
                                lv_dg_application(j).imocl_c_r,
                                lv_dg_application(j).un_n_r,
                                lv_dg_application(j).psn_m_r,
                                lv_dg_application(j).tn_m_r,
                                lv_dg_application(j).pkgty_c_r,
                                NULL,
                                lv_dg_application(j).flashpt_n_r,
                                lv_dg_application(j).wt_n_r,
                                DECODE(lv_dg_application(j).waste_i_r, 'Y', 1, 'N', 0),
                                DECODE(lv_dg_application(j).residue_i_r, 'Y', 1, 'N', 0),
                    -- NULL,
                                NULL,   --lv_dg_application(j).subrisk_c,
                                DECODE(lv_dg_application(j).tankcntr_i_r, 'Y', 1, 'N', 0),
                                lv_dg_application(j).st_c_r,
                                lv_dg_application(j).mparem_x_r,
                                lv_dg_application(j).vettedby_m_r,
                                lv_dg_application(j).vettedon_dt_r,
                                lv_dg_application(j).crtby_m_r,
                                lv_dg_application(j).crton_dt_r,
                                lv_dg_application(j).updby_m_r,
                                lv_dg_application(j).updon_dt_r,
                                lv_subr_email_i,   --lv_dg_application(j).subr_email_i_r,
                                lv_dg_application(j).emailaddr_x_r,
                                lv_subr_sms_i,  --lv_dg_application(j).subr_sms_i_r,
                                lv_dg_application(j).usrinputvsl_m_r,
                                NULL,
                                lv_dg_application(j).craftlic_n_r,
                                0,
                                0,
                                lv_dg_application(j).msw_vsl_id_n_r,
                                lv_dg_application(j).noofpkg_n_r
                              --  ,lv_dg_application(j).usrinputvsl_m_r
                            );

                        EXCEPTION
                            WHEN OTHERS THEN
                                v_err_code := sqlcode;
                                v_exp_rows1 := v_sq_appln_ref_n;
                                v_exp_rows2 := v_msw_vsl_call_id;                    --VSL_CALL_ID_N
                                v_exp_rows3 := lv_dg_application(j).pm4id_n_r;
                                v_exp_rows4 := '1';                                   --APPLCNT_ID_X
                                v_exp_rows5 := v_msw_appln_ref_id_x;            --MSW_APPLN_REF_ID_X
                                v_exp_rows6 := lv_dg_application(j).loclcontact_m_r;
                                v_exp_rows7 := lv_dg_application(j).mobile_n_r;
                                v_exp_rows8 := lv_dg_application(j).eta_dt_r;
                                v_exp_rows9 := lv_dg_application(j).rta_dt_r;
                                v_exp_rows10 := lv_dg_application(j).invoy_n_r;
                                v_exp_rows11 := lv_dg_application(j).outvoy_n_r;
                                v_exp_rows12 := lv_dg_application(j).opern_c_r;
                                v_exp_rows13 := lv_dg_application(j).locn_c_r;
                                v_exp_rows14 := lv_dg_application(j).cntr_n_r;
                                v_exp_rows15 := lv_dg_application(j).bl_n_r;
                                v_exp_rows16 := lv_dg_application(j).imocl_c_r;
                                v_exp_rows17 := lv_dg_application(j).un_n_r;
                                v_exp_rows18 := lv_dg_application(j).psn_m_r;
                                v_exp_rows19 := lv_dg_application(j).tn_m_r;
                                v_exp_rows20 := lv_dg_application(j).pkgty_c_r;
                                v_exp_rows21 := NULL;
                                v_exp_rows22 := lv_dg_application(j).flashpt_n_r;
                                v_exp_rows23 := lv_dg_application(j).wt_n_r;
                                v_exp_rows24 := lv_dg_application(j).waste_i_r;
                                v_exp_rows25 := lv_dg_application(j).residue_i_r;
                  --  v_exp_rows26 := lv_dg_application(j).subrisk_c;
                                v_exp_rows27 := lv_dg_application(j).tankcntr_i_r;
                                v_exp_rows28 := lv_dg_application(j).st_c_r;
                                v_exp_rows29 := lv_dg_application(j).mparem_x_r;
                                v_exp_rows30 := lv_dg_application(j).vettedby_m_r;
                                v_exp_rows31 := lv_dg_application(j).vettedon_dt_r;
                                v_exp_rows32 := lv_dg_application(j).crtby_m_r;
                                v_exp_rows33 := lv_dg_application(j).crton_dt_r;
                                v_exp_rows34 := lv_dg_application(j).updon_dt_r;
                                v_exp_rows35 := lv_dg_application(j).updby_m_r;
                                v_exp_rows36 := lv_subr_email_i;    --lv_dg_application(j).subr_email_i_r;
                                v_exp_rows37 := lv_dg_application(j).emailaddr_x_r;
                                v_exp_rows38 := lv_subr_sms_i;   --lv_dg_application(j).subr_sms_i_r;
                                v_exp_rows39 := lv_dg_application(j).usrinputvsl_m_r;
                                v_exp_rows40 := NULL;
                                v_exp_rows41 := lv_dg_application(j).craftlic_n_r;
                                v_exp_rows_appl := v_exp_rows1
                                                   || '<{||}>'
                                                   || v_exp_rows2
                                                   || '<{||}>'
                                                   || v_exp_rows3
                                                   || '<{||}>'
                                                   || v_exp_rows4
                                                   || '<{||}>'
                                                   || v_exp_rows5
                                                   || '<{||}>'
                                                   || v_exp_rows6
                                                   || '<{||}>'
                                                   || v_exp_rows7
                                                   || '<{||}>'
                                                   || v_exp_rows8
                                                   || '<{||}>'
                                                   || v_exp_rows9
                                                   || '<{||}>'
                                                   || v_exp_rows10
                                                   || '<{||}>'
                                                   || v_exp_rows11
                                                   || '<{||}>'
                                                   || v_exp_rows12
                                                   || '<{||}>'
                                                   || v_exp_rows13
                                                   || '<{||}>'
                                                   || v_exp_rows14
                                                   || '<{||}>'
                                                   || v_exp_rows15
                                                   || '<{||}>'
                                                   || v_exp_rows16
                                                   || '<{||}>'
                                                   || v_exp_rows17
                                                   || '<{||}>'
                                                   || v_exp_rows18
                                                   || '<{||}>'
                                                   || v_exp_rows19
                                                   || '<{||}>'
                                                   || v_exp_rows20
                                                   || '<{||}>'
                                                   || v_exp_rows21
                                                   || '<{||}>'
                                                   || v_exp_rows22
                                                   || '<{||}>'
                                                   || v_exp_rows23
                                                   || '<{||}>'
                                                   || v_exp_rows24
                                                   || '<{||}>'
                                                   || v_exp_rows25
                                                   || '<{||}>'
                                                   || v_exp_rows26
                                                   || '<{||}>'
                                                   || v_exp_rows27
                                                   || '<{||}>'
                                                   || v_exp_rows28
                                                   || '<{||}>'
                                                   || v_exp_rows29
                                                   || '<{||}>'
                                                   || v_exp_rows30
                                                   || '<{||}>'
                                                   || v_exp_rows31
                                                   || '<{||}>'
                                                   || v_exp_rows32
                                                   || '<{||}>'
                                                   || v_exp_rows33
                                                   || '<{||}>'
                                                   || v_exp_rows34
                                                   || '<{||}>'
                                                   || v_exp_rows35
                                                   || '<{||}>'
                                                   || v_exp_rows36
                                                   || '<{||}>'
                                                   || v_exp_rows37
                                                   || '<{||}>'
                                                   || v_exp_rows38
                                                   || '<{||}>'
                                                   || v_exp_rows39
                                                   || '<{||}>'
                                                   || v_exp_rows40
                                                   || '<{||}>'
                                                   || v_exp_rows41;

                                IF lv_errcnt < 50000 THEN
                                    pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL'
                                    , dbms_utility.format_error_backtrace || dbms_utility.format_error_stack, 'ERROR', pv_run_id,
                                    sqlerrm, v_exp_rows_appl, 'T');

                                    lv_errcnt := lv_errcnt + 1;
                                END IF;

                                CONTINUE;
                        END;

                    END IF;

                ELSE --else part on inner IF statement
				--DELETE FROM VESSEL_REFERENCE WHERE VSL_REF_ID_N = V_VSL_REF_ID_OUT;
                    CONTINUE;
                END IF;

            END IF;

------------ **************** Inserting into Dangerous Goods Appl. Document ********-------------------------

            FOR s IN (
                SELECT
                    doc1.pm4supportingdocindx_n,
                    doc2.ty_x,
                    doc2.pm4id_n
                FROM
                    st_pm4supportingdoc_mapping doc2,
                    st_dg_pm4supportingdoc doc1,
                    st_cm_docmetadata y
                WHERE
                    doc2.pm4supportingdocindx_n = doc1.pm4supportingdocindx_n
                    AND doc1.filepath_x = y.docid_n (+)
                    AND doc2.pm4id_n = lv_dg_application(j).pm4id_n_r
            ) LOOP
                IF v_flag IS NULL AND s.pm4supportingdocindx_n IS NOT NULL THEN
                    BEGIN
                        INSERT INTO dangerous_goods_application_document (
                            dg_appln_doc_id_n,
                            appln_ref_n,
                            doc_id_n,
                            ty_c,
                            crt_by_x,
                            crt_on_dt,
                            deleted_i,
                            lock_ver_n,
                            doc_other_ty_c
                        ) VALUES (
                            seq_dg_appl_doc.NEXTVAL,
                            v_sq_appln_ref_n, --lv_dg_application_doc(j).appln_ref_n_r,
                            s.pm4supportingdocindx_n,
                            s.ty_x,
                            lv_dg_application(j).crtby_m_r,
                            lv_dg_application(j).crton_dt_r,
                            0,
                            0,
                            NULL
                        );

                    EXCEPTION
                        WHEN OTHERS THEN
                            v_err_code := sqlcode;
                            v_exp_rows1 := seq_dg_appl_doc.currval;
                            v_exp_rows2 := v_sq_appln_ref_n;
                            v_exp_rows3 := s.pm4supportingdocindx_n;
                            v_exp_rows4 := s.ty_x;
                            v_exp_rows5 := lv_dg_application(j).crtby_m_r;
                            v_exp_rows6 := lv_dg_application(j).crton_dt_r;
                            v_exp_rows_doc := v_exp_rows1
                                              || '<{||}>'
                                              || v_exp_rows2
                                              || '<{||}>'
                                              || v_exp_rows3
                                              || '<{||}>'
                                              || v_exp_rows4
                                              || '<{||}>'
                                              || v_exp_rows5
                                              || '<{||}>'
                                              || v_exp_rows6;

                            IF lv_errcnt < 50000 THEN
                                pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', dbms_utility
                                .format_error_backtrace || dbms_utility.format_error_stack, 'ERROR', pv_run_id, sqlerrm, v_exp_rows_doc
                                , 'T');

                                lv_errcnt := lv_errcnt + 1;
                            END IF;

                    END;

                END IF;
            END LOOP; -- FOR LOOP S

        EXCEPTION
            WHEN OTHERS THEN
                IF lv_errcnt < 50000 THEN
                    pkg_datamigration_generic.proc_trace_exception('DG_APPLICATION', 'PROC_2_DG_APPL', v_sqlerrm, 'ERROR', pv_run_id
                    , sqlerrm || dbms_utility.format_error_backtrace, 'Error for lv_dg_application(j).pm4id_n' || lv_dg_application
                    (j).pm4id_n_r, 'T');

                    lv_errcnt := lv_errcnt + 1;
                END IF;
        END;
    END LOOP;

    COMMIT;
END LOOP;

CLOSE cr_dg_appl;
/*
begin 
proc_dg_vr_vc_as_del    ;
end ;   */

       SELECT
            COUNT(*)
        INTO lv_cnt_PSA_JPC
        FROM
            DG_PSA_JPC ; 

        SELECT
            COUNT(*)
        INTO lv_cnt_tar_appl
        FROM
            dangerous_goods_application;

        SELECT
            COUNT(*)
        INTO lv_cnt_tar_doc
        FROM
            dangerous_goods_application_document; 

        pkg_datamigration_generic.proc_trace_exception('DG_PSA_JPC', 'PROC_2_DG_APPL', lv_cnt_PSA_JPC
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'SUCCESS', pv_run_id
                                                                                                            , NULL, NULL, 'T');

        IF ( lv_cnt_tar_appl = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar_appl <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'SUCCESS', pv_run_id
                                                                                                            , NULL, NULL, 'T');
        ELSIF lv_cnt_tar_appl <> lv_cnt_si AND lv_cnt_tar_appl <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'PARTIALLY SUCCESSFULL'
                                                                                                            , pv_run_id, NULL, NULL
                                                                                                            , 'T');
        ELSIF ( lv_cnt_tar_appl <> lv_cnt_si OR lv_cnt_tar_appl = lv_cnt_si ) AND ( lv_cnt_tar_appl = 0 ) THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application', 'PROC_2_DG_APPL', lv_cnt_tar_appl
                                                                                                            || ' out of '
                                                                                                            || lv_cnt_si
                                                                                                            || ' records loaded successfully'
                                                                                                            , 'FAIL', pv_run_id, NULL
                                                                                                            , NULL, 'T');
        END IF;

        IF ( lv_cnt_tar_doc = lv_cnt_si ) AND lv_cnt_si <> 0 AND lv_cnt_tar_doc <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'SUCCESS',
                                                                                                                     pv_run_id, NULL
                                                                                                                     , NULL, 'T')
                                                                                                                     ;
        ELSIF lv_cnt_tar_doc <> lv_cnt_si AND lv_cnt_tar_doc <> 0 THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'PARTIALLY SUCCESSFULL'
                                                                                                                     , pv_run_id,
                                                                                                                     NULL, NULL, 'T'
                                                                                                                     );
        ELSIF ( lv_cnt_tar_doc <> lv_cnt_si OR lv_cnt_tar_doc = lv_cnt_si ) AND ( lv_cnt_tar_doc = 0 ) THEN
            pkg_datamigration_generic.proc_trace_exception('Dangerous_Goods_Application_Document', 'PROC_2_DG_APPL', lv_cnt_tar_doc
                                                                                                                     || ' out of '
                                                                                                                     || lv_cnt_si
                                                                                                                     || ' records loaded successfully'
                                                                                                                     , 'FAIL', pv_run_id
                                                                                                                     , NULL, NULL
                                                                                                                     , 'T');
        END IF;

        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'DG_PSA_JPC', lv_cnt_PSA_JPC, 'N');
        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'Dangerous_Goods_Application', lv_cnt_tar_appl

        , 'N');
        pkg_datamigration_generic.proc_migration_recon('SI_DG_APPLICATION', lv_cnt_si, 'Dangerous_Goods_Application_Document', lv_cnt_tar_doc
        , 'N');
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'DG_PSA_JPC', lv_cnt_PSA_JPC, 'Y'
        );
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'Dangerous_Goods_Application', lv_cnt_tar_appl, 'Y'
        );
        pkg_datamigration_generic.proc_migration_recon('ST_DG_PM4', lv_cnt_st, 'Dangerous_Goods_Application_Document', lv_cnt_tar_doc
        , 'Y');

END proc_2_dg_appl;