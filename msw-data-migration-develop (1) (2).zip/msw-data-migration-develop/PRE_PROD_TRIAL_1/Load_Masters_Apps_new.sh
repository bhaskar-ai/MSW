#!/bin/bash
echo "Start of Data Migration"
echo "Start datetime: " date
SECONDS=0
sqlplus -s msw_data_migration/H-cK8T7HN<<EOF
spool on
spool DATA_MIGRATION_new.log
@ Load_Masters_Apps_new.sql;
spool off;
EOF
echo "End datetime: " date
duration=$SECONDS
echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."
echo "End of Data Migration"

